/* SSV Hafen-Manager – Verwaltungsoberfläche */
(function () {
  'use strict';

  const HF = window.HAFEN, G = window.HAFEN_GEBUEHREN, SEPA = window.HAFEN_SEPA, PLAN = window.HAFEN_PLAN;
  const { H, Q } = HF;
  const esc = H.esc;
  const $ = (s, r = document) => r.querySelector(s);
  let d = HF.laden();
  const heute = H.tag(new Date());

  /* ------------------------------------------------------------ Rollen */
  const ROLLEN = {
    vorstand: { name: 'Vorstand', tabs: '*', bank: true },
    brueckenwart: { name: 'Brückenwartin', tabs: ['uebersicht', 'plan', 'plaetze', 'boote', 'eigner', 'belegung', 'abwesenheiten', 'gaeste', 'gastkarte', 'warteliste', 'lagern', 'aufgaben', 'arbeitsdienst', 'arbeitsbereiche', 'mitteilungen', 'veranstaltungen'], bank: false },
    hafenmeister: { name: 'Hafenmeister', tabs: ['uebersicht', 'plan', 'plaetze', 'gaeste', 'gastkarte', 'abwesenheiten', 'lagern', 'aufgaben', 'arbeitsdienst', 'arbeitsbereiche', 'mitteilungen'], bank: false },
    kassenwart: { name: 'Kassenwart', tabs: ['uebersicht', 'plan', 'eigner', 'antraege', 'verband', 'finanzen', 'abrechnung', 'rechnungen', 'kontoauszug', 'hafengeld', 'gebuehren', 'arbeitsdienst', 'arbeitsbereiche', 'mitteilungen', 'veranstaltungen', 'einstellungen', 'verlauf'], bank: true }
  };
  // Acht Bereiche statt neunzehn Menüpunkte, jeder mit einem Thema; innerhalb eines Bereichs wechseln Reiter oben auf der Seite.
  // Die Reiter-IDs (#lagern, #verband …) bleiben gleich – alte Links und Lesezeichen funktionieren weiter.
  const ICON = {
    uebersicht: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    hafen: '<circle cx="12" cy="5" r="2"/><path d="M12 7v14M5 13a7 7 0 0 0 14 0M8 10h8"/>',
    gaeste: '<path d="M12 3v13M12 4l6 10h-6M11 7l-5 7h5M4 17h16l-2 3H6z"/>',
    mitglieder: '<circle cx="9" cy="7" r="4"/><path d="M2 21v-1a6 6 0 0 1 12 0v1M16 3.5a4 4 0 0 1 0 7.5M22 21v-1a6 6 0 0 0-4-5.6"/>',
    arbeit: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
    verein: '<path d="M3 10v4a1 1 0 0 0 1 1h3l6 4V5L7 9H4a1 1 0 0 0-1 1zM17 8.5a5 5 0 0 1 0 7M19.8 6a8.5 8.5 0 0 1 0 12"/>',
    finanzen: '<path d="M18 7a7 7 0 1 0 0 10M4 10h10M4 14h10"/>',
    verwaltung: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>'
  };
  const BEREICHE = [
    ['uebersicht', 'Übersicht', [['uebersicht', 'Übersicht']]],
    ['hafen', 'Hafen', [['plan', 'Hafenplan'], ['plaetze', 'Liegeplätze'], ['belegung', 'Belegung'], ['lagern', 'Kran & Termine'], ['warteliste', 'Warteliste']]],
    ['gaeste', 'Gäste & grünes Schild', [['gaeste', 'Gastlieger'], ['gastkarte', 'Karte & Kalender'], ['abwesenheiten', 'Grünes Schild']]],
    ['mitglieder', 'Mitglieder & Boote', [['eigner', 'Mitglieder'], ['boote', 'Boote'], ['antraege', 'Aufnahmeanträge']]],
    ['arbeit', 'Arbeitsdienst', [['arbeitsdienst', 'Stunden'], ['arbeitsbereiche', 'Arbeitsgruppen'], ['aufgaben', 'Schäden & Wartung']]],
    ['verein', 'Mitteilungen & Veranstaltungen', [['mitteilungen', 'Mitteilungen'], ['veranstaltungen', 'Veranstaltungen']]],
    ['finanzen', 'Finanzen', [['finanzen', 'Auf einen Blick'], ['abrechnung', 'Abrechnen'], ['rechnungen', 'Rechnungen & Offenes'], ['kontoauszug', 'Zahlungseingang'], ['hafengeld', 'Hafengeld'], ['gebuehren', 'Gebührenordnung']]],
    ['verwaltung', 'Verwaltung', [['einstellungen', 'Einstellungen'], ['verband', 'Verbandsmeldung'], ['verlauf', 'Änderungsverlauf']]]
  ];
  const TABS = BEREICHE.map(([, n, ts]) => [n, ts]);
  const bereichVon = (t) => (BEREICHE.find(([, , ts]) => ts.some(([x]) => x === t)) || BEREICHE[0])[0];
  // Bereichsname aus den Reitern, die die Rolle sieht: wer keine Boote sieht, liest „Mitglieder“ statt „Mitglieder & Boote“
  const KURZNAME = { mitglieder: ['boote', 'Mitglieder'], gaeste: ['abwesenheiten', 'Gäste'], verein: ['veranstaltungen', 'Mitteilungen'] };
  const bereichTitel = (id, n) => { const k = KURZNAME[id]; return k && rolle && !darf(k[0]) ? k[1] : n; };
  const zuletzt = {};   // zuletzt geöffneter Reiter je Bereich
  let rolle = null, tab = 'uebersicht';
  const darf = (t) => rolle && (ROLLEN[rolle].tabs === '*' || ROLLEN[rolle].tabs.includes(t));
  const bankSichtbar = () => rolle && ROLLEN[rolle].bank;

  /* ------------------------------------------------------------ Saison */
  const SAISON = HF.aktuelleSaison();
  const sd = G.saisonDaten(d, SAISON);
  const imSommer = heute >= sd.auslagern && heute < sd.einlagern;
  // Bezugszeitpunkt: im Sommer immer „heute“; in der Winterpause zeigt der Sommerplan einen deutlich gekennzeichneten Rückblick
  const tagVor = (t, n) => H.tag(new Date(new Date(t + 'T12:00:00').getTime() - n * 864e5));
  const rueckblick = HF.modus !== 'supabase' ? '2026-08-15' : heute < sd.auslagern ? sd.auslagern : tagVor(sd.einlagern, 1);
  let planStand = { modus: imSommer ? 'sommer' : 'winter', datum: imSommer ? heute : rueckblick, ansicht: imSommer ? 'gesamt' : 'land', markiere: null, luftbild: false };
  const stichtagText = (t) => t === heute ? 'heute' : (t < heute ? 'Rückblick' : 'Vorschau');

  /* ------------------------------------------------------------ Helfer */
  const DB = HF.modus === 'supabase';
  // Speichern: Demo sofort im Browser, Vereinsdatenbank im Hintergrund – Fehler werden gemeldet
  HF.db.onFehler = (e) => { toast('Nicht gespeichert: ' + e.message, 'fehler', 7000); if (DB) neuLaden(true); };
  // Stand der Datenbank neu holen: nach abgelehntem Speichern, beim Zurückkehren in den Tab und alle 90 Sekunden
  async function neuLaden(still) {
    try { await HF.neuLaden(); d = HF.d; if (rolle && !$('#modal').firstChild) zeige(tab, true); }
    catch (x) { if (!still) toast('Neu laden fehlgeschlagen: ' + x.message, 'fehler'); }
  }
  if (DB) {
    const auffrischen = () => { const a = document.activeElement; if (!rolle || document.hidden || $('#modal').firstChild || (a && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName))) return; neuLaden(true); };
    setInterval(auffrischen, 90e3); document.addEventListener('visibilitychange', () => { if (!document.hidden) auffrischen(); });
  }
  function speichern(meldung) { const p = HF.sichern(); if (meldung) toast(meldung); return p; }
  function toast(t, art, ms) { const el = $('#toast'); el.textContent = t; el.className = 'toast zeigen' + (art ? ' ' + art : ''); clearTimeout(toast.t); toast.t = setTimeout(() => { el.className = 'toast'; }, ms || 3200); }
  let vorModal = null;
  function modal(html, breit) {
    vorModal = document.activeElement;
    const m = $('#modal'); m.innerHTML = '<div class="modal"><div class="modal-karte' + (breit ? ' breit' : '') + '" role="dialog" aria-modal="true" aria-labelledby="modal-titel"><button class="modal-x" data-zu aria-label="Schließen">×</button>' + html + '</div></div>';
    document.body.classList.add('modal-offen');
    const el = m.firstChild; el.addEventListener('click', (e) => { if (e.target === el || e.target.closest('[data-zu]')) zu(); });
    const t = el.querySelector('h2'); if (t) t.id = 'modal-titel';
    const f = el.querySelector('input:not([type=hidden]),select,textarea'); if (f) setTimeout(() => f.focus(), 30);
    return el;
  }
  function zu() { $('#modal').innerHTML = ''; document.body.classList.remove('modal-offen'); if (vorModal && vorModal.isConnected) vorModal.focus(); }
  // Tastatur: Escape schließt Dialoge; klickbare Tabellenzeilen per Tab erreichbar und mit Enter/Leertaste zu öffnen
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && $('#modal').firstChild) return zu();
    const z = e.target.closest && e.target.closest('tr.klickbar, .kz-link');
    if (z && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); z.click(); }
  });
  new MutationObserver(() => {
    document.querySelectorAll('#main tr.klickbar:not([tabindex])').forEach((z) => { z.tabIndex = 0; z.setAttribute('role', 'button'); });
    document.querySelectorAll('#main input:not([aria-label]):not([id])').forEach((i) => {
      if (i.closest('label')) return;
      const zeile = i.closest('tr'); const sp = i.closest('td'); const kopf = sp && i.closest('table').querySelector('thead th:nth-child(' + (sp.cellIndex + 1) + ')');
      const name = i.placeholder || ((zeile && zeile.cells[0] ? zeile.cells[0].textContent : '') + (kopf ? ' ' + kopf.textContent : ''));
      if (name) i.setAttribute('aria-label', name.trim());
    });
  }).observe(document.getElementById('main'), { childList: true, subtree: true });
  function kopf(titel, unter, aktionen) { return '<div class="kopf"><div><h1>' + titel + '</h1>' + (unter ? '<p>' + unter + '</p>' : '') + '</div><div class="aktionen">' + (aktionen || '') + '</div></div>'; }
  const DEMO = DB ? '' : '<div class="demo-band"><strong>Demo:</strong> alle Daten sind erfunden und bleiben in diesem Browser.</div>';
  const planAnnahme = () => !d.einstellungen.plan_bestaetigt;
  const iban = (s) => bankSichtbar() ? esc(String(s || '').replace(/(.{4})/g, '$1 ').trim()) : (s ? '•••• ' + esc(String(s).slice(-4)) : '');
  const bootTxt = (b) => b ? '„' + esc(b.name) + '“ · ' + esc(b.typ) : '–';
  const masse = (b) => H.zahl(b.laenge) + ' × ' + H.zahl(b.breite) + ' m';
  const mOpt = (sel, filter = () => true) => d.mitglieder.filter(filter).sort((a, b) => a.nachname.localeCompare(b.nachname, 'de')).map((m) => '<option value="' + m.id + '"' + (m.id === sel ? ' selected' : '') + '>' + esc(m.nachname + ', ' + m.vorname) + ' (' + H.ART[m.art] + ')</option>').join('');
  const bOpt = (sel) => d.boote.slice().sort((a, b) => a.name.localeCompare(b.name, 'de')).map((b) => '<option value="' + b.id + '"' + (b.id === sel ? ' selected' : '') + '>' + esc(b.name) + ' – ' + esc(Q.name(Q.mitglied(b.eigner_id))) + '</option>').join('');
  // Versicherung: Gültigkeit plus Nachweis-Stand (selbst angegeben → eingereicht → geprüft)
  const nachweisTag = (b) => b.vers_status === 'geprueft' ? '<span class="tag ok" title="geprüft' + (b.vers_geprueft_am ? ' am ' + H.datum(b.vers_geprueft_am) : '') + '">✓ geprüft</span>' : b.vers_status === 'eingereicht' ? '<span class="tag gast">Nachweis prüfen</span>' : '<span class="tag">ungeprüft</span>';
  const versTag = (b) => { const s = Q.versicherungsStatus(b, heute); return (s === 'ok' ? '<span class="tag ok">bis ' + H.datum(b.vers_bis) + '</span>' : s === 'bald' ? '<span class="tag warn">läuft ' + H.datum(b.vers_bis) + ' ab</span>' : s === 'fehlt' ? '<span class="tag rot">fehlt</span>' : '<span class="tag rot">abgelaufen ' + H.datum(b.vers_bis) + '</span>') + (s === 'fehlt' ? '' : ' ' + nachweisTag(b)); };
  const ZAHLART = { bar: 'bar', ueberweisung: 'Überweisung', paypal: 'PayPal', karte: 'Karte', offen: 'Zahlart offen' };
  // „gemeldet“ = Gast hat auf der Gast-Seite angegeben, dass er bezahlt hat; der Eingang wird hier bestätigt
  const zahlungText = (g) => esc(ZAHLART[g.zahlung] || g.zahlung || '') + ' · ' + (g.bezahlt_am ? '<span class="tag ok">bezahlt ' + H.kurz(g.bezahlt_am) + '</span>' : g.zahlung_gemeldet ? '<span class="tag gast">vom Gast gemeldet – noch nicht geprüft</span>' : '<span class="tag warn">noch nicht bezahlt</span>');
  const angabe = (t) => (/^\s*platz/i.test(t) ? '' : 'Platz ') + String(t).trim();   // vom Gast eingetippte Platznummer
  const platzName = (id) => Q.platz(id) ? Q.platzName(id) : '–';   // „Platz 12“, „Längsseits L1“, Lagerplatz „P01 · Nordlager“ (daten.js)
  function download(name, text, typ) {
    const blob = new Blob([text], { type: typ }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  const csv = (zeilen) => '﻿' + zeilen.map((z) => z.map((v) => { const s = v == null ? '' : String(v); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(';')).join('\r\n');
  // Briefkopf für Seiten, die direkt aus dem Programm gedruckt werden (nur im Druck sichtbar) – Flagge oben links wie auf allen Vereinsdokumenten
  const druckKopf = () => { const e = d.einstellungen; return '<div class="druck-kopf"><svg class="stander" aria-hidden="true"><use href="#stander"/></svg><div><strong>' + esc(e.verein_name) + '</strong>' + esc(e.verein_strasse) + '<br>' + esc(e.verein_ort) + '<br>' + esc(e.verein_email) + '</div></div>'; };
  function oeffnen(url) { if (!window.open(url, '_blank')) location.href = url; }

  /* Gastlieger: passt ein Platz für den ganzen Aufenthalt? Gleiche Regeln wie in der Datenbank:
   * nicht gesperrt, Boxmaße und Wassertiefe, kein anderer Gast, und an jedem Tag mit Dauerlieger ein grünes Schild. */
  const naechteVon = (von, n) => { const t = []; for (let i = 0; i < n; i++) t.push(H.tag(new Date(new Date(von + 'T12:00:00').getTime() + i * 864e5))); return t; };
  const abreise = (g) => H.tag(new Date(new Date(g.ankunft + 'T12:00:00').getTime() + g.naechte * 864e5));
  function platzPruefen(p, von, n, laenge, breite, tiefgang, ohneGast) {
    const gruende = []; let art = 'frei';
    if (p.gesperrt) gruende.push('Platz ist gesperrt');
    if (laenge && p.max_laenge && laenge > p.max_laenge) gruende.push('Boot überschreitet die Boxmaße (Länge ' + H.zahl(laenge, 1) + ' m, erlaubt ' + H.zahl(p.max_laenge, 1) + ' m)');
    if (breite && p.max_breite && breite > p.max_breite) gruende.push('Boot überschreitet die Boxmaße (Breite ' + H.zahl(breite, 1) + ' m, erlaubt ' + H.zahl(p.max_breite, 1) + ' m)');
    if (tiefgang && p.tiefe && tiefgang > p.tiefe) gruende.push('Tiefgang ' + H.zahl(tiefgang, 1) + ' m, Wassertiefe nur ' + H.zahl(p.tiefe, 1) + ' m');
    for (const t of naechteVon(von, n)) {
      const g = d.gaeste.find((x) => x.id !== ohneGast && x.platz_id === p.id && x.status !== 'storniert' && x.ankunft <= t && abreise(x) > t);
      if (g) { gruende.push('am ' + H.kurz(t) + ' schon an „' + g.bootsname + '“ vergeben'); break; }
      if (Q.belegungPlatz(Number(t.slice(0, 4)), 'sommer', p.id)) {
        if (Q.abwesendAm(p.id, t)) { art = 'unterwegs'; continue; }
        const aw = Q.abwesendAm(p.id, von); const zurueck = !aw && d.abwesenheiten.find((a) => a.platz_id === p.id && a.bis === tagVor(t, 1));
        gruende.push(aw ? 'Aufenthalt überschreitet die Freigabe (Eigner zurück am ' + H.datum(aw.bis) + ')' : zurueck ? 'der Eigner ist zurück (grünes Schild endete am ' + H.datum(zurueck.bis) + ')' : 'am ' + H.kurz(t) + ' liegt hier der Dauerlieger (kein grünes Schild)');
        break;
      }
    }
    return { ok: !gruende.length, art, gruende };
  }
  function verfuegbarePlaetze(von, naechte, laenge, breite, tiefgang, ohneGast) {
    return d.liegeplaetze.map((p) => ({ p, ...platzPruefen(p, von, naechte, laenge, breite, tiefgang, ohneGast) })).filter((x) => x.ok)
      .sort((a, b) => (a.art === 'frei' ? 0 : 1) - (b.art === 'frei' ? 0 : 1) || a.p.max_laenge - b.p.max_laenge);
  }

  const STATUS_TAG = { belegt: '', unterwegs: 'gruen', gast: 'gast', saisongast: 'lila', frei: 'ok', gesperrt: 'rot' };   // Farbe des Status-Schilds je Wasserplatz
  /* ============================================================ Übersicht */
  const V = {};
  let sprung = null;   // Ziel in der nächsten Seite (Selektor): Kästchen wird angehakt, Feld ins Bild gerollt und gewählt
  V.uebersicht = (main) => {
    const st = {}; if (imSommer) d.liegeplaetze.forEach((p) => { const s2 = Q.statusWasser(p, SAISON, heute); st[s2] = (st[s2] || 0) + 1; });
    const versProbleme = d.boote.filter((b) => ['abgelaufen', 'bald', 'fehlt'].includes(Q.versicherungsStatus(b, heute)));
    const nachweise = d.boote.filter((b) => b.vers_status === 'eingereicht');
    const zuSchwer = d.boote.filter((b) => Q.zuSchwer(b, 'kran')); const zuSchwerSteg = zuSchwer.filter((b) => Q.zuSchwer(b, 'steg'));
    const anfragen = d.gaeste.filter((g) => g.status === 'angemeldet');
    const gaesteHeute = d.gaeste.filter((g) => g.status !== 'storniert' && g.platz_id && g.ankunft <= heute && abreise(g) > heute);
    const winterOffen = G.vorschau(d, SAISON, 'winter', heute).filter((x) => !x.schon_abgerechnet && x.summe > 0);
    const offeneRe = d.rechnungen.filter((r) => Q.rest(r) > 0);
    const sepaOffen = offeneRe.filter((r) => r.sepa && !r.sepa_lauf);
    const rueck = d.rechnungen.filter((r) => Q.rstatus(r, heute) === 'ruecklastschrift');
    const schaeden = (d.aufgaben || []).filter((t) => t.status !== 'erledigt');
    const wasserVergeben = Q.belegungen(SAISON, 'sommer').filter((b) => b.platz_typ === 'wasser').length;
    const naechste = (d.saisons || []).find((x) => x.jahr === SAISON + 1);
    const e = d.einstellungen;
    // Drei Gruppen: Heute wichtig (Tagesgeschäft), Anstehend, Einrichtung abschließen
    const heuteL = [], anst = [], einr = [];
    const add = (liste, tab, txt, art, extra) => liste.push({ tab, txt, art, extra: extra || '' });
    // Konflikte: Gäste, deren Platz nicht mehr passt (z. B. Eigner früher zurück)
    const konflikte = d.gaeste.filter((g) => g.platz_id && !['storniert', 'abgereist'].includes(g.status) && abreise(g) > heute).map((g) => {
      const ab = g.ankunft > heute ? g.ankunft : heute; const rest = Math.round((new Date(abreise(g) + 'T12:00:00') - new Date(ab + 'T12:00:00')) / 864e5);
      const p = Q.platz(g.platz_id); const pr = p ? platzPruefen(p, ab, rest, g.laenge, g.breite, g.tiefgang, g.id) : { ok: false, gruende: ['Platz unbekannt'] };
      return pr.ok ? null : { g, grund: pr.gruende[0] };
    }).filter(Boolean);
    const ankuenfte = d.gaeste.filter((g) => g.ankunft === heute && g.status !== 'storniert');
    if (darf('gaeste')) konflikte.forEach(({ g, grund }) => add(heuteL, 'gaeste', 'Konflikt ' + platzName(g.platz_id) + ': Gast „' + esc(g.bootsname) + '“ – ' + esc(grund), 'rot', 'data-gast="' + g.id + '"'));
    if (anfragen.length && darf('gaeste')) add(heuteL, 'gaeste', anfragen.length + (anfragen.length > 1 ? ' Gäste liegen' : ' Gast liegt') + ' ohne bestätigten Platz (selbst angemeldet) – bitte prüfen', 'gast');
    const zahlPruef = d.gaeste.filter((g) => g.zahlung_gemeldet && !g.bezahlt_am && g.status !== 'storniert');
    if (zahlPruef.length && (darf('gaeste') || darf('kontoauszug'))) add(anst, darf('gaeste') ? 'gaeste' : 'kontoauszug', zahlPruef.length + ' Gast-Zahlung' + (zahlPruef.length > 1 ? 'en' : '') + ' vom Gast gemeldet, noch nicht geprüft – Eingang bestätigen (' + zahlPruef.map((g) => esc(ZAHLART[g.zahlung] || g.zahlung)).join(', ') + ')', 'gast');
    if (ankuenfte.length && darf('gaeste')) add(heuteL, 'gaeste', ankuenfte.length + (ankuenfte.length === 1 ? ' Gast kommt' : ' Gäste kommen') + ' heute an: ' + ankuenfte.map((g) => '„' + esc(g.bootsname) + '“').join(', '), 'gast');
    const abreisePruefen = darf('gaeste') ? d.gaeste.filter((g) => gastLage(g).offen.includes('abreise')) : [];
    if (abreisePruefen.length) add(heuteL, 'gaeste', abreisePruefen.length + (abreisePruefen.length === 1 ? ' Gast reist heute ab oder ist überfällig' : ' Gäste reisen heute ab oder sind überfällig') + ': ' + abreisePruefen.map((g) => '„' + esc(g.bootsname) + '“').join(', ') + ' – Abreise bestätigen', 'warn');
    const dringend = schaeden.filter((t) => t.prioritaet === 'hoch' || (t.faellig && t.faellig < heute));
    if (dringend.length && darf('aufgaben')) add(heuteL, 'aufgaben', dringend.length + (dringend.length === 1 ? ' dringender oder überfälliger Schaden' : ' dringende oder überfällige Schäden/Wartungen') + ': ' + dringend.slice(0, 2).map((t) => esc(t.titel)).join(', '), 'rot');
    if (rueck.length && darf('rechnungen')) add(heuteL, 'rechnungen', rueck.length + ' Rücklastschrift' + (rueck.length > 1 ? 'en' : '') + ' – Mitglied ansprechen oder erneut einziehen', 'rot', 'data-re-filter="ruecklastschrift"');
    (d.arbeitseinsaetze || []).filter((x) => x.datum === heute).forEach((x) => { if (darf('arbeitsdienst')) add(heuteL, 'arbeitsdienst', 'Heute Arbeitseinsatz „' + esc(x.titel) + '“ – QR-Plakat aushängen', 'gast'); });
    if (darf('veranstaltungen')) (d.veranstaltungen || []).filter((v) => !v.abgesagt && v.datum >= heute && v.datum <= tagVor(heute, -21)).sort((a, b) => a.datum.localeCompare(b.datum)).forEach((v) => {
      const s2 = verStand(v); add(anst, 'veranstaltungen', esc(v.titel) + ' am ' + H.kurz(v.datum) + ': ' + s2.pers + (s2.pers === 1 ? ' Person' : ' Personen') + ' zugesagt' + (v.max_personen ? ' von ' + v.max_personen : '') + (v.anmeldung_bis && v.anmeldung_bis >= heute ? ' · Anmeldung bis ' + H.kurz(v.anmeldung_bis) : ''), 'gast', 'data-ver-oeffnen="' + v.id + '"'); });
    const gemeldetAD = d.arbeitsdienst.filter((a) => a.status === 'eingereicht');
    if (gemeldetAD.length && darf('arbeitsdienst')) add(anst, 'arbeitsdienst', gemeldetAD.length + ' gemeldete Arbeitsstunden bestätigen', 'gast');
    const neueAntraege = (d.antraege || []).filter((a) => a.status === 'neu');
    if (neueAntraege.length && darf('antraege')) add(anst, 'antraege', neueAntraege.length + ' Aufnahmeantr' + (neueAntraege.length > 1 ? 'äge warten' : 'ag wartet') + ' auf den Vorstand', 'warn');
    if (winterOffen.length && darf('abrechnung')) add(anst, 'abrechnung', 'Winterlager ' + SAISON + '/' + String(SAISON + 1).slice(2) + ' abrechnen (' + winterOffen.length + ' Mitglieder, ' + H.geld(winterOffen.reduce((s, x) => s + x.summe, 0)) + ')', 'warn', 'data-abr-per="winter"');
    const kaZuletzt = e.kontoauszug_zuletzt; const kaAlt = !kaZuletzt || kaZuletzt < tagVor(heute, 30);
    if (darf('kontoauszug') && kaAlt && (offeneRe.length || d.sepa_laeufe.length)) add(anst, 'kontoauszug', 'Kontoauszug abgleichen – ' + (kaZuletzt ? 'zuletzt am ' + H.datum(kaZuletzt) : 'noch nie eingelesen') + ' (' + offeneRe.length + ' Rechnungen offen)', 'gast');
    if (sepaOffen.length && darf('abrechnung')) add(anst, 'abrechnung', sepaOffen.length + ' Rechnungen warten auf die Lastschrift-Datei für die Bank', 'warn');
    if (nachweise.length && darf('boote')) add(anst, 'boote', nachweise.length + ' Versicherungsnachweis' + (nachweise.length > 1 ? 'e' : '') + ' prüfen', 'gast', 'data-sprung="#probl"');
    if (versProbleme.length && darf('boote')) add(anst, 'boote', versProbleme.length + ' Boote: Versicherung abgelaufen, fehlt oder läuft in 30 Tagen ab', 'warn', 'data-sprung="#probl"');
    if (zuSchwer.length && darf('boote')) add(anst, 'boote', zuSchwer.length + (zuSchwer.length > 1 ? ' Boote' : ' Boot') + ' über ' + Q.maxTxt('kran') + ' – ' + (zuSchwer.length > 1 ? 'werden' : 'wird') + ' nicht gekrant' + (zuSchwerSteg.length ? ', davon ' + zuSchwerSteg.length + ' über ' + Q.maxTxt('steg') + ' (auch kein Wasserliegeplatz)' : ''), 'warn', 'data-sprung="#probl"');
    const normal = schaeden.filter((t) => !dringend.includes(t));
    if (normal.length && darf('aufgaben')) add(anst, 'aufgaben', normal.length + ' offene Schäden/Wartungen', 'warn');
    if (!e.steuer_hinweis && darf('einstellungen')) add(einr, 'einstellungen', 'Steuerhinweis für Rechnungen festlegen (mit dem Steuerberater klären)', 'warn', 'data-sprung="[name=steuer_hinweis]"');
    if (darf('einstellungen') && !(SEPA.ibanGueltig(e.iban) && SEPA.glaeubigerGueltig(e.glaeubiger_id))) add(einr, 'einstellungen', 'Vereinskonto und Gläubiger-ID für die Lastschrift eintragen', 'warn', 'data-sprung="[name=glaeubiger_id]"');
    if (!e.arbeitsdienst_bestaetigt && rolle === 'vorstand') add(einr, 'einstellungen', 'Regeln für den Arbeitsdienst beschließen (Soll, Befreiungen, Übertrag, Ersatz)', 'warn', 'data-sprung="[name=arbeitsdienst_soll]"');
    if (planAnnahme() && darf('belegung')) add(einr, 'plaetze', 'Boxmaße, Brücken und Wassertiefen eintragen und bestätigen', 'warn');
    if (!naechste && darf('einstellungen')) add(einr, 'einstellungen', 'Saisontermine ' + (SAISON + 1) + ' (Auslagern/Einlagern) eintragen', 'warn', 'data-sprung="[name=aus_' + (SAISON + 1) + ']"');
    const warte = d.warteliste.filter((w) => w.status === 'wartend').length;
    const yy = String(SAISON + 1).slice(2);
    const karten = imSommer
      ? '<div class="kz"><small>Liegeplätze belegt</small><strong>' + ((st.belegt || 0) + (st.unterwegs || 0) + (st.saisongast || 0)) + ' / ' + d.liegeplaetze.length + '</strong><span>' + (st.frei || 0) + ' frei · ' + (st.gesperrt || 0) + ' gesperrt</span></div>' +
        '<div class="kz"><small>Eigner unterwegs</small><strong style="color:var(--gruen)">' + (st.unterwegs || 0) + '</strong><span>grünes Schild heute</span></div>' +
        '<div class="kz"><small>Gastlieger</small><strong style="color:#8a5e05">' + gaesteHeute.length + '</strong><span>heute im Hafen · ' + anfragen.length + (anfragen.length === 1 ? ' Anfrage' : ' Anfragen') + '</span></div>' +
        '<div class="kz"><small>Winterlager</small><strong>' + Q.belegungen(SAISON, 'winter').length + '</strong><span>Boote an Land</span></div>'
      : '<div class="kz"><small>Winterlager ' + SAISON + '/' + yy + '</small><strong>' + Q.belegungen(SAISON, 'winter').length + '</strong><span>Boote an Land</span></div>' +
        '<div class="kz"><small>Wasserplätze Sommer ' + SAISON + '</small><strong>' + wasserVergeben + ' / ' + d.liegeplaetze.length + '</strong><span>vergeben (Saison beendet)</span></div>' +
        '<div class="kz"><small>Nächstes Auslagern</small><strong style="font-size:20px">' + (naechste ? H.datum(naechste.auslagern) : 'Termin offen') + '</strong><span>' + (naechste ? 'Saison ' + (SAISON + 1) : 'noch nicht eingetragen') + '</span></div>';
    const handy = window.matchMedia('(max-width: 860px)').matches;
    // Etikett = Thema (nicht Farbe): Gäste, Arbeitsdienst, Boote …; Farbe zeigt die Dringlichkeit
    const THEMA = { gaeste: 'Gäste', arbeitsdienst: 'Arbeitsdienst', boote: 'Boote', abrechnung: 'Geld', antraege: 'Anträge', aufgaben: 'Schäden', einstellungen: 'Einrichtung', plaetze: 'Liegeplätze', veranstaltungen: 'Termine', kontoauszug: 'Geld', rechnungen: 'Geld', finanzen: 'Geld' };
    const MAX = 5;
    const zeilen = (l) => '<table class="tab todo"><tbody>' + l.map((x, i) => '<tr class="' + (darf(x.tab) ? 'klickbar' : '') + (i >= MAX ? ' todo-mehr' : '') + '"' + (darf(x.tab) ? ' data-gehe="' + x.tab + '" ' + x.extra : '') + (i >= MAX ? ' hidden' : '') + '><td><span class="tag ' + x.art + '">' + (THEMA[x.tab] || 'offen') + '</span></td><td>' + x.txt + '</td><td class="r">' + (darf(x.tab) ? '→' : '') + '</td></tr>').join('') + '</tbody></table>' +
      (l.length > MAX ? '<button class="btn klein todo-weitere" type="button">+ ' + (l.length - MAX) + ' weitere anzeigen</button>' : '');
    // Dringendes zuerst (rot vor warn vor Hinweis)
    const RANG = { rot: 0, warn: 1, gast: 2 }; [heuteL, anst, einr].forEach((l) => l.sort((a, b) => (RANG[a.art] ?? 3) - (RANG[b.art] ?? 3)));
    const gruppe = (titel, l, offen, leer) => !l.length && !leer ? '' : '<details class="panel todo-gruppe"' + (offen ? ' open' : '') + '><summary><h2>' + titel + '</h2><span class="tag' + (l.length ? '' : ' ok') + '">' + l.length + '</span></summary>' + (l.length ? zeilen(l) : '<p class="leer">' + leer + '</p>') + '</details>';
    main.innerHTML = kopf('Moin, ' + ROLLEN[rolle].name + '!', 'Stand heute, ' + H.datum(heute) + ' · ' + (imSommer ? 'Sommer ' + SAISON + ' – die Boote sind im Wasser' : 'Winterpause seit ' + H.datum(sd.einlagern) + ' (Winterlager ' + SAISON + '/' + yy + ')'),
      darf('plan') ? '<button class="btn dunkel" data-gehe="plan">Hafenplan öffnen</button>' : '') + DEMO +
      gruppe('Heute wichtig', heuteL, true, 'Heute ist nichts Dringendes.') +
      gruppe('Anstehend', anst, !handy) +
      gruppe('Einrichtung abschließen', einr, !handy && heuteL.length + anst.length < 6) +
      '<div class="karten">' + karten +
      '<div class="kz"><small>Warteliste</small><strong>' + warte + '</strong><span>Mitglieder warten</span></div>' +
      (darf('rechnungen') ? '<div class="kz kz-link" role="link" tabindex="0" data-gehe="rechnungen" data-re-filter="nicht_bezahlt" title="Offene Rechnungen ansehen"><small>Offene Rechnungen · Hafen & Beiträge</small><strong>' + H.geld(offeneRe.reduce((s, r) => s + Q.rest(r), 0)) + '</strong><span>' + offeneRe.length + (offeneRe.length === 1 ? ' Rechnung' : ' Rechnungen') + ' · Getränke siehe Kasse</span></div>' : '') + '</div>';
    main.querySelectorAll('[data-gast]').forEach((z) => z.addEventListener('click', (ev) => { ev.stopPropagation(); gastForm(d.gaeste.find((g) => g.id === z.dataset.gast)); }, true));
    main.querySelectorAll('[data-ver-oeffnen]').forEach((z) => z.addEventListener('click', () => { verAuswahl = z.dataset.verOeffnen; }, true));   // danach führt data-gehe zur Teilnehmerliste
    main.querySelectorAll('[data-sprung]').forEach((z) => z.addEventListener('click', () => { sprung = z.dataset.sprung; }, true));   // danach führt data-gehe zur passenden Stelle (Filter/Feld)
    main.querySelectorAll('.todo-weitere').forEach((k) => k.addEventListener('click', () => { k.previousElementSibling.querySelectorAll('.todo-mehr').forEach((z) => { z.hidden = false; }); k.remove(); }));
  };

  /* ============================================================ Hafenplan */
  // Planungen: Entwürfe neben dem gültigen Lageplan („so will ich es nächstes Jahr haben“)
  const planungen = () => Array.isArray(d.einstellungen.lageplan_planungen) ? d.einstellungen.lageplan_planungen : [];
  const planVoll = (x) => ({ ...PLAN.STANDARD, laengs: [], punkte: [], lager: [], ...x });
  const planungName = () => { const vor = 'Saison ' + (SAISON + 1); let n = prompt('Wie soll die Planung heißen?\n(z. B. „Saison ' + (SAISON + 1) + '“ oder „Nordlager neu“)', planungen().some((x) => x.name === vor) ? 'Planung ' + (planungen().length + 1) : vor); n = n && n.trim().slice(0, 60); return n || null; };
  function planungBearbeiten(pl) {
    window.HAFEN_PLAN_EDITOR.oeffnen({ plan: planVoll(pl.plan), eigen: false, entwurf: true, titel: 'Planung „' + pl.name + '“', daten: d,
      onSpeichern: (neu) => { pl.plan = neu; pl.stand = heute; speichern('Planung „' + pl.name + '“ gespeichert – der gültige Plan ist unverändert.'); zeige('plan', true); } });
  }
  // Plätze, die im Plan neu sind, im Verein anlegen (nach Rückfrage). Gibt die Anzahl zurück.
  function plaetzeAnlegen(plan, neuP) {
    const wasser = ((neuP && neuP.wasser) || []).filter((nr) => !d.liegeplaetze.some((x) => String(x.nr) === String(nr))), land = ((neuP && neuP.land) || []).filter((id) => !d.landplaetze.some((x) => x.id === id));
    if (!wasser.length && !land.length) return 0;
    if (!confirm('Im Plan stehen Plätze, die es im Verein noch nicht gibt:\n' + (wasser.length ? 'Wasser: ' + window.HAFEN_PLAN_EDITOR.bereiche(wasser) + '\n' : '') + (land.length ? 'Land: ' + window.HAFEN_PLAN_EDITOR.bereiche(land) + '\n' : '') +
      '\nJetzt anlegen? Maße und Box-Klasse übernimmt das Programm aus dem Plan – bitte danach unter „Liegeplätze“ prüfen.')) return 0;
    const voll = planVoll(plan); const geo = PLAN.plaetzeVon(voll); const r1 = (v) => Math.round(v * 10) / 10;
    wasser.forEach((nr) => { const g = geo.plaetze.find((x) => x.nr === String(nr)), l = (voll.laengs || []).find((x) => String(x.nr) === String(nr)); if (!g && !l) return;
      const breite = g ? g.voll * voll.m : (Number(l.h) || 10) * voll.m, laenge = g ? g.tiefe * voll.m : l.w * voll.m;
      let id = 'LP' + (/^\d+$/.test(nr) ? String(nr).padStart(2, '0') : nr); while (d.liegeplaetze.some((x) => x.id === id)) id += 'N';
      d.liegeplaetze.push({ id, nr: String(nr), bruecke: g ? (g.bruecke || 'ost') : 'laengs', box: g ? (breite >= 3.9 ? 'I' : breite >= 3.3 ? 'II' : 'III') : 'L', max_laenge: r1(laenge + (g ? 1 : 0)), max_breite: r1(Math.max(1, breite - 0.3)),
        tiefe: null, strom: true, gesperrt: false, sonderpreis: null, notiz: 'Neu aus dem Lageplan (' + H.datum(heute) + ') – Maße und Box-Klasse prüfen' }); });
    // Lage des neuen Lagerplatzes aus seinem Lagerfeld: wie die schon vorhandenen Plätze im selben Feld, sonst nach dem Feldnamen.
    // Ist sie nicht sicher, bleibt sie leer – dann nennen Anzeige und Rechnung keine Lage (lieber keine als eine falsche).
    const lagerG = PLAN.lagerVon(voll);
    const lageVon = (id, art) => {
      const g = lagerG.find((x) => x.id === id); const feld = g && (voll.lager || []).find((L) => L.id === g.lager);
      if (feld) {
        const zahl = {}; lagerG.filter((x) => x.lager === feld.id && x.id !== id).forEach((x) => { const lp = d.landplaetze.find((y) => y.id === x.id); if (lp && lp.bereich) zahl[lp.bereich] = (zahl[lp.bereich] || 0) + 1; });
        const best = Object.keys(zahl).sort((a, b) => zahl[b] - zahl[a])[0]; if (best) return best;
        const n = String(feld.name || '').toLowerCase();
        if (/west/.test(n)) return 'west'; if (/nord/.test(n)) return 'nord'; if (/au(ß|ss)en/.test(n)) return 'aussen'; if (/halle/.test(n)) return 'halle';
      }
      return art === 'halle' ? 'halle' : art === 'aussen' ? 'aussen' : null;
    };
    land.forEach((id) => { const art = /^H/i.test(id) ? 'halle' : /^A/i.test(id) ? 'aussen' : 'palette'; const z = (id.match(/\d+/) || [''])[0].replace(/^0+/, '');
      d.landplaetze.push({ id, bez: ({ halle: 'Halle ', aussen: 'Außenlager ', palette: 'Palette ' })[art] + (z || id), art, bereich: lageVon(id, art) }); });
    return wasser.length + land.length;
  }
  /* Plan drucken: eigene Druckseite im SSV-Briefkopf (Flagge links, Adresse rechts), mit Legende, Maßstab und Nordpfeil */
  function planDruckDialog(pl, svgJetzt) {
    const A = svgJetzt._ansichten || PLAN.ANSICHTEN; const jetzt = (svgJetzt._kamera ? svgJetzt._kamera.ansicht : null);
    modal('<h2>Plan drucken</h2><p class="unter">' + (pl ? 'Planung „' + esc(pl.name) + '“' : 'Gültiger Hafenplan') + ' · im Druckfenster kannst du auch „Als PDF sichern“ wählen.</p>' +
      '<form id="pdf" class="form">' +
      '<label class="feld">Was?<select name="modus"><option value="sommer"' + (planStand.modus === 'sommer' ? ' selected' : '') + '>Sommer – Belegung im Wasser</option><option value="winter"' + (planStand.modus === 'winter' ? ' selected' : '') + '>Winterlager – Belegung an Land</option><option value="leer">Nur der Plan (ohne Boote)</option></select></label>' +
      '<label class="feld">Ausschnitt<select name="ansicht"><option value="gesamt">Ganzer Hafen</option>' + (jetzt ? '<option value="jetzt">So wie gerade am Bildschirm</option>' : '') + '<option value="ost">Ostbrücke</option><option value="west">Westbrücke</option><option value="schwimm">Schwimmbrücke</option><option value="land"' + (planStand.modus === 'winter' ? ' selected' : '') + '>Lager an Land</option></select></label>' +
      '<label class="feld">Papier<select name="papier"><option value="A4">A4 quer</option><option value="A3">A3 quer</option></select></label>' +
      '<label class="feld">Farben<select name="farbe"><option value="hell">Hell (spart Tinte)</option><option value="voll">Kräftig wie am Bildschirm</option></select></label>' +
      '<label class="feld check voll"><input type="checkbox" name="liste" checked> Belegungsliste (Platz · Boot · Eigner) auf einem zweiten Blatt</label></form>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="pd-ok">Drucken</button></div>');
    $('#pd-ok').addEventListener('click', () => { const f = new FormData($('#pdf')); const o = { modus: f.get('modus'), ansicht: f.get('ansicht') === 'jetzt' ? jetzt : f.get('ansicht'), papier: f.get('papier'), hell: f.get('farbe') === 'hell', liste: !!f.get('liste') }; zu(); planDrucken(pl, o); });
  }
  function planDrucken(pl, o) {
    const alt = $('#plan-druckseite'); if (alt) alt.remove();
    const seite = document.createElement('div'); seite.id = 'plan-druckseite'; seite.className = 'plan-druckseite';
    const leer = o.modus === 'leer', winter = o.modus === 'winter'; const per = winter ? 'winter' : 'sommer';
    const titel = (pl ? 'Planung „' + pl.name + '“' : 'Hafenplan') + ' · ' + (leer ? 'Lageplan' : winter ? 'Winterlager ' + SAISON + '/' + String(SAISON + 1).slice(2) : 'Sommer ' + SAISON + ' · Stand ' + H.datum(planStand.datum));
    seite.style.setProperty('--pd-h', o.papier === 'A3' ? '218mm' : '134mm');
    seite.innerHTML = '<div class="pd-blatt1">' + druckKopf() + '<div class="pd-titel"><h1>' + esc(titel) + '</h1><span>gedruckt am ' + H.datum(heute) + ' · Maßstab siehe Leiste · Norden oben</span></div><div class="pd-plan" id="pd-plan"></div>' +
      '<div class="pd-legende">' + (leer ? '' : winter ? '<span><i class="lg-boot plane"></i>an Land belegt</span><span><i class="lg-feld leer"></i>frei</span>' :
        '<span><i class="lg-boje gruen"></i>frei für Gäste</span><span><i class="lg-boje rot"></i>belegt</span><span><i class="lg-boot"></i>Dauerlieger</span><span><i class="lg-boot gast"></i>Gastlieger</span><span><i class="lg-boot saison"></i>Saison-Gast</span><span><i class="lg-feld gruen"></i>grünes Schild</span>') +
      (pl ? '<span><i class="lg-feld neu"></i>neuer Platz (Planung)</span>' : '') + '<span class="pd-quelle">Grundlage: amtliches Luftbild · ' + esc(PLAN.QUELLE.replace('Luftbild: ', '')) + '</span></div></div>';
    document.body.appendChild(seite);
    const plan = pl ? planVoll(pl.plan) : undefined;
    const sv = PLAN.zeichnen(seite.querySelector('#pd-plan'), { plan, entwurf: !!pl, namen: true, schweb: false, intro: false, modus: winter ? 'winter' : 'sommer', saison: SAISON, datum: planStand.datum, ansicht: o.ansicht,
      wasser: leer ? (() => ({ status: 'leer' })) : undefined, land: leer ? (() => 'frei') : undefined, idPraefix: 'pd-' });   // eigene IDs: Verläufe/Muster des Bildschirmplans sind beim Drucken ausgeblendet
    PLAN.massstabInAnsicht(sv);   // Maßstab und Nordpfeil auch im Ausschnitt sichtbar
    sv.classList.add('nah', 'druck'); sv.classList.toggle('druck-hell', o.hell); if (leer) sv.classList.add('ohne-bojen');
    if (o.liste && !leer) {   // zweites Blatt: wer liegt wo
      const P = plan || PLAN.aktiv(); const nrn = PLAN.plaetzeVon(P).plaetze.map((x) => x.nr).concat((P.laengs || []).map((x) => String(x.nr)));
      // Winter: alle Lagerplätze aus dem Plan, dazu belegte Landplätze, die (noch) nicht im Plan sind (z. B. Halle H1–H4) – damit kein Boot fehlt
      const imPlan = PLAN.lagerVon(P).map((g) => ({ id: g.id, nr: g.id }));
      const ohnePlan = winter ? (d.landplaetze || []).filter((lp) => !imPlan.some((g) => g.id === lp.id) && Q.belegungPlatz(SAISON, per, lp.id)).map((lp) => ({ id: lp.id, nr: Q.platzName(lp) })) : [];
      const zeilen = winter ? imPlan.concat(ohnePlan).map((g) => { const bel = Q.belegungPlatz(SAISON, per, g.id); const b = bel && Q.boot(bel.boot_id); return [g.nr, b ? '„' + b.name + '“' + (b.typ ? ' · ' + b.typ : '') : '– frei –', b ? Q.name(Q.mitglied(b.eigner_id)) : '', b ? masse(b) : '']; })
        : nrn.map((nr) => { const lp = d.liegeplaetze.find((x) => String(x.nr) === nr); if (!lp) return [nr, '– neu –', '', '']; const st = Q.statusWasser(lp, SAISON, planStand.datum); const bel = Q.belegungPlatz(SAISON, 'sommer', lp.id); const b = bel && Q.boot(bel.boot_id); const g = Q.gastAm(lp.id, planStand.datum);
          return [nr, b ? '„' + b.name + '“' + (b.typ ? ' · ' + b.typ : '') : '– frei –', b ? Q.name(Q.mitglied(b.eigner_id)) : '', (g ? 'Gast „' + g.bootsname + '“' : st === 'unterwegs' ? 'grünes Schild bis ' + H.kurz(Q.abwesendAm(lp.id, planStand.datum).bis) : st === 'gesperrt' ? 'gesperrt' : '')]; });
      // A4: zwei Tabellen nebeneinander, A3: drei – so bleiben Platz, Boot und Eigner ganz lesbar (lange Namen brechen um)
      const spalten = o.papier === 'A3' ? 3 : 2; const je = Math.ceil(zeilen.length / spalten);
      const tab = (z) => '<table class="tab pd-tab"><thead><tr><th>Platz</th><th>Boot</th><th>Eigner</th><th>' + (winter ? 'Maße' : 'Hinweis') + '</th></tr></thead><tbody>' + z.map((r) => '<tr><td><strong>' + esc(r[0]) + '</strong></td><td>' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td><td>' + (winter ? r[3] : esc(r[3])) + '</td></tr>').join('') + '</tbody></table>';
      const blatt = document.createElement('div'); blatt.className = 'pd-blatt2'; blatt.style.setProperty('--pd-sp', spalten);
      blatt.innerHTML = druckKopf() + '<div class="pd-titel"><h1>Belegungsliste · ' + esc(winter ? 'Winterlager ' + SAISON + '/' + String(SAISON + 1).slice(2) : 'Sommer ' + SAISON + ' · Stand ' + H.datum(planStand.datum)) + '</h1></div><div class="pd-zwei">' +
        Array.from({ length: spalten }, (_, i) => zeilen.slice(i * je, (i + 1) * je)).filter((z) => z.length).map(tab).join('') + '</div>';
      seite.appendChild(blatt);
    }
    const st = document.createElement('style'); st.id = 'plan-druck-seite'; st.textContent = '@page { size: ' + o.papier + ' landscape; margin: 9mm; }'; document.head.appendChild(st);
    document.body.classList.add('druckt-plan');
    const fertig = () => { document.body.classList.remove('druckt-plan'); seite.remove(); st.remove(); window.removeEventListener('afterprint', fertig); };
    window.addEventListener('afterprint', fertig);
    setTimeout(() => { if (window.SSV_KEIN_DRUCK) return; window.print(); }, 150);
  }
  const AUSSCHNITTE = [['gesamt', 'Ganzer Hafen'], ['ost', 'Ostbrücke'], ['west', 'Westbrücke'], ['schwimm', 'Schwimmbrücke'], ['land', 'Lagerflächen an Land']];
  // Anfahrt in der Seitenkarte des Hafenplans – Google Maps und Apple Karten (Vorgabe: kein OpenStreetMap)
  const HAFEN_LAGE = { lat: '53.91139', lng: '10.70111' };
  function anfahrtHtml() {
    const e = d.einstellungen; const adr = [e.verein_strasse, e.verein_ort].filter(Boolean).map(esc).join(', ');
    return '<div class="abschnitt anfahrt"><h3>Anfahrt</h3>' + (adr ? '<p class="unter" style="margin:0 0 8px">' + adr + '</p>' : '') + '<div class="aktionen" style="margin-top:0">' +
      '<a class="btn klein" href="https://www.google.com/maps/search/?api=1&query=' + HAFEN_LAGE.lat + '%2C' + HAFEN_LAGE.lng + '" target="_blank" rel="noopener">In Google Maps öffnen</a>' +
      '<a class="btn klein" href="https://maps.apple.com/?ll=' + HAFEN_LAGE.lat + ',' + HAFEN_LAGE.lng + '&q=' + encodeURIComponent(e.verein_name || 'Schwartauer Segler-Verein') + '&z=17" target="_blank" rel="noopener">In Apple Karten öffnen</a></div></div>';
  }
  V.plan = (main) => {
    const legende = planStand.modus === 'sommer'
      ? '<span><i class="lg-boje gruen"></i>grüne Boje: frei für Gäste</span><span><i class="lg-boje rot"></i>rote Boje: belegt</span><span><i class="lg-boot"></i>Dauerlieger</span><span><i class="lg-boot gast"></i>Gastlieger</span><span><i class="lg-boot saison"></i>Saison-Gast</span><span><i class="lg-feld gruen"></i>grünes Schild (Eigner unterwegs)</span><span><i class="lg-feld sperr"></i>gesperrt</span>'
      : '<span><i class="lg-boot plane"></i>Lagerplatz belegt</span><span><i class="lg-feld leer"></i>frei</span><span><i class="lg-feld wasser"></i>Wasserplatz (Winterpause)</span>';
    const anders = planStand.modus === 'sommer' && planStand.datum !== heute;
    const pl = darf('einstellungen') ? planungen().find((x) => x.id === planStand.planung) : null; if (!pl) planStand.planung = null;
    if (!planStand.vb) planStand.frei = false;   // „eigener Ausschnitt“ nur, solange der verschobene Ausschnitt gilt
    const planer = darf('einstellungen');   // Planungen, Lageplan bearbeiten: wie bisher Vorstand (und Kassenwart, der die Einstellungen pflegt)
    const haken = (an) => '<span class="zm-haken" aria-hidden="true">' + (an ? '✓' : '') + '</span>';
    main.innerHTML = kopf('Hafenplan', planStand.modus === 'sommer' ? 'Sommer ' + SAISON + ' · Stand am ' + H.datum(planStand.datum) + ' (' + stichtagText(planStand.datum) + ')' : 'Winterlager ' + SAISON + '/' + String(SAISON + 1).slice(2) + (imSommer ? '' : ' · Stand heute'),
      // Stichtag oben rechts im Kopf (nur Sommer): so bleibt die Leiste über dem Plan bei vier Bedienelementen
      planStand.modus === 'sommer' ? '<label class="plan-tag"><span>Stand am</span><input type="date" id="plan-datum" value="' + planStand.datum + '" min="' + sd.auslagern + '" max="' + sd.einlagern + '"></label>' : '') +
      (anders ? '<div class="hinweis warn stichtag"><span><strong>' + stichtagText(planStand.datum) + ':</strong> Du siehst den Stand am ' + H.datum(planStand.datum) + ' – nicht den heutigen' + (imSommer ? '' : ' (heute ist Winterpause)') + '.</span><button class="btn klein" id="zu-heute">Zum heutigen Stand</button></div>' : '') +
      (pl ? '<div class="hinweis warn stichtag planung-band"><span><strong>Planung „' + esc(pl.name) + '“</strong> – ein Entwurf, zuletzt geändert am ' + H.datum(pl.stand) + '. Der gültige Plan bleibt unverändert, bis du die Planung gültig schaltest. Gestrichelt gelb = neue Plätze.</span>' +
        '<span class="planung-knoepfe"><button class="btn klein primaer" id="pl-gueltig">Gültig schalten</button><button class="btn klein" id="pl-name">Umbenennen</button><button class="btn klein" id="pl-weg">Löschen</button><button class="btn klein" id="pl-zurueck">Zum gültigen Plan</button></span></div>' : '') +
      '<div class="plan-layout"><div class="plan-box"><div class="plan-leiste' + (planer ? '' : ' mit-druck') + '">' +
      // Eine Zeile, vier Bedienelemente: Sommer | Winter (mit Stichtag), Ausschnitt, Ansicht ▾, Plan ▾ (Planer) bzw. Drucken
      '<span class="plan-seg" role="group" aria-label="Jahreszeit"><button type="button" class="btn klein' + (planStand.modus === 'sommer' ? ' aktiv' : '') + '" data-modus="sommer" aria-pressed="' + (planStand.modus === 'sommer') + '">Sommer</button><button type="button" class="btn klein' + (planStand.modus === 'winter' ? ' aktiv' : '') + '" data-modus="winter" aria-pressed="' + (planStand.modus === 'winter') + '">Winter</button></span>' +
      '<label class="plan-aus"><span>Ausschnitt:</span><select id="plan-ausschnitt">' + AUSSCHNITTE.map(([k, n]) => '<option value="' + k + '"' + (!planStand.frei && planStand.ansicht === k ? ' selected' : '') + '>' + n + '</option>').join('') +
        '<option value="" hidden' + (planStand.frei ? ' selected' : '') + '>eigener Ausschnitt</option></select></label>' +
      '<span class="zm plan-zm"><button type="button" class="btn klein zm-knopf zm-text" id="plan-ansicht" aria-haspopup="true" aria-expanded="false">Ansicht ▾</button><span class="zm-liste" role="menu" hidden>' +
        '<button type="button" class="zm-punkt" role="menuitemcheckbox" id="plan-bild" aria-checked="' + !!planStand.luftbild + '">' + haken(planStand.luftbild) + 'Luftbild</button>' +
        '<button type="button" class="zm-punkt" role="menuitemcheckbox" id="plan-abend" aria-checked="' + !!planStand.abend + '" title="Abendansicht: die Bojen leuchten">' + haken(planStand.abend) + 'Abendstimmung</button></span></span>' +
      (planer ? '<span class="zm plan-zm"><button type="button" class="btn klein zm-knopf zm-text" id="plan-menue" aria-haspopup="true" aria-expanded="false">Plan ▾</button><span class="zm-liste" role="menu" hidden id="plan-wahl">' +
          '<span class="zm-titel">Welcher Plan?</span><button type="button" class="zm-punkt" role="menuitemradio" data-plan-wahl="" aria-checked="' + !pl + '">' + haken(!pl) + 'Gültiger Plan</button>' +
          planungen().map((x) => '<button type="button" class="zm-punkt" role="menuitemradio" data-plan-wahl="' + esc(x.id) + '" aria-checked="' + (planStand.planung === x.id) + '">' + haken(planStand.planung === x.id) + 'Planung: ' + esc(x.name) + '</button>').join('') +
          '<button type="button" class="zm-punkt" role="menuitem" data-plan-wahl="+">' + haken(false) + '+ Neue Planung …</button><span class="zm-trenn" role="separator"></span>' +
          '<button type="button" class="zm-punkt" role="menuitem" id="plan-edit">' + haken(false) + (pl ? 'Planung bearbeiten …' : 'Lageplan bearbeiten …') + '</button>' +
          '<button type="button" class="zm-punkt" role="menuitem" id="plan-druck">' + haken(false) + 'Plan drucken …</button></span></span>'
        : '<button type="button" class="btn klein" id="plan-druck">Drucken</button>') +
      '</div><div class="plan-flaeche" id="plan"></div><div class="legende">' + legende + (planStand.luftbild ? '<span class="quelle-zeile">' + esc(PLAN.QUELLE) + '</span>' : '') + '</div></div><aside class="detail"><div id="detail"></div>' + anfahrtHtml() + '</aside></div>' +
      '<p class="hinweis" style="margin-top:12px">Maßstäblicher Plan nach amtlichem Luftbild (DOP20)' + (d.einstellungen.lageplan ? ', vom Verein nachgezeichnet. ' : '. ') + (planAnnahme() ? 'Zuordnung, Nummerierung und Boxmaße sind eine <strong>Annahme</strong>, bis der Verein sie unter „Liegeplätze“ bestätigt – die Platzempfehlung für Gäste ist bis dahin nur eine Orientierung. ' : '') + 'Tippe auf einen Platz für Details; mit „Ausschnitt“ (z. B. Ostbrücke) zoomst du heran und siehst die Platznummern.</p>';
    const zh = $('#zu-heute'); if (zh) zh.addEventListener('click', () => { if (imSommer) planStand.datum = heute; else { planStand.modus = 'winter'; planStand.ansicht = 'land'; planStand.vb = null; } planStand.markiere = null; zeige('plan'); });
    const svg = PLAN.zeichnen($('#plan'), { plan: pl ? planVoll(pl.plan) : undefined, entwurf: !!pl, namen: true, abend: planStand.abend && !planStand.luftbild, luftbild: planStand.luftbild, modus: planStand.modus, saison: SAISON, datum: planStand.datum, ansicht: planStand.vb || planStand.ansicht, intro: !planStand.vb, markiere: planStand.markiere, onKlick: (id) => { planStand.markiere = id; detail(id); markieren(id); } });
    // Verschieben/Zoomen wie in einer Karten-App, dazu Vollbild (Esc beendet)
    const box = main.querySelector('.plan-box');
    const vollbild = (an) => { const v = an == null ? !box.classList.contains('vollbild') : an; box.classList.toggle('vollbild', v); document.body.classList.toggle('plan-vollbild', v); planStand.voll = v;
      const k = box.querySelector('[data-k=voll]'); if (k) { k.textContent = v ? '✕' : '⛶'; k.setAttribute('aria-label', v ? 'Vollbild beenden' : 'Vollbild'); } };
    const kam = PLAN.kamera(svg, { vollbild: () => vollbild(), onAnsicht: (v) => { planStand.vb = v.slice(); } }); if (planStand.voll) vollbild(true);
    // Von anderer Stelle „im Plan zeigen“: Kamera gleitet zum markierten Platz
    if (planStand.fokus && planStand.markiere) { planStand.fokus = false; setTimeout(() => { const g = svg.querySelector('[data-platz="' + planStand.markiere + '"]'); if (!g) return;
      const r = g.getBoundingClientRect(), sr = svg.getBoundingClientRect(), vb = kam.ansicht; if (!sr.width) return;
      const cx = vb[0] + (r.left + r.width / 2 - sr.left) / sr.width * vb[2], cy = vb[1] + (r.top + r.height / 2 - sr.top) / sr.height * vb[3]; kam.zu([cx - 95, cy - 60, 190, 120]); }, 450); }
    const escVoll = (e) => { if (!box.isConnected) return document.removeEventListener('keydown', escVoll, true);
      if (e.key === 'Escape' && box.classList.contains('vollbild') && !$('#modal').firstChild) { e.stopPropagation(); vollbild(false); } };
    document.addEventListener('keydown', escVoll, true);
    function markieren(id) { svg.querySelectorAll('.markiert').forEach((x) => x.classList.remove('markiert')); const g = svg.querySelector('[data-platz="' + id + '"]'); if (g) g.classList.add('markiert'); }
    const aus = $('#plan-ausschnitt');
    aus.addEventListener('change', () => { if (!aus.value) return; planStand.ansicht = aus.value; planStand.frei = false; PLAN.zoomen(svg, planStand.ansicht); });
    // Selbst verschoben oder gezoomt → Auswahl zeigt „eigener Ausschnitt“; so lässt sich derselbe Ausschnitt wieder wählen
    const eigen = () => { if (planStand.frei) return; planStand.frei = true; aus.value = ''; };
    svg.addEventListener('wheel', eigen, { passive: true }); svg.addEventListener('dblclick', eigen);
    svg.addEventListener('pointermove', () => { if (svg.classList.contains('zieht')) eigen(); });
    const ctl = box.querySelector('.plan-ctl'); if (ctl) ctl.addEventListener('click', (e) => { const k = e.target.closest('[data-k]'); if (!k) return;
      if (k.dataset.k === 'alles') { planStand.frei = false; planStand.ansicht = 'gesamt'; aus.value = 'gesamt'; } else if (k.dataset.k !== 'voll') eigen(); });
    main.querySelectorAll('[data-modus]').forEach((b) => b.addEventListener('click', () => { planStand.modus = b.dataset.modus; planStand.markiere = null; planStand.vb = null; if (planStand.modus === 'winter' && planStand.ansicht === 'gesamt') planStand.ansicht = 'land'; if (planStand.modus === 'sommer' && planStand.ansicht === 'land') planStand.ansicht = 'gesamt'; zeige('plan'); }));
    const dat = $('#plan-datum'); if (dat) dat.addEventListener('change', () => { planStand.datum = dat.value || planStand.datum; zeige('plan'); });
    $('#plan-bild').addEventListener('click', () => { planStand.luftbild = !planStand.luftbild; zeige('plan', true); });
    $('#plan-abend').addEventListener('click', (e) => { planStand.abend = !planStand.abend; if (planStand.abend && planStand.luftbild) { planStand.luftbild = false; return zeige('plan', true); } svg.classList.toggle('abend', planStand.abend);
      e.currentTarget.setAttribute('aria-checked', planStand.abend); e.currentTarget.querySelector('.zm-haken').textContent = planStand.abend ? '✓' : ''; });
    const pe = $('#plan-edit'); if (pe) pe.addEventListener('click', () => pl ? planungBearbeiten(pl) : window.HAFEN_PLAN_EDITOR.oeffnen({
      plan: d.einstellungen.lageplan || PLAN.STANDARD, eigen: !!d.einstellungen.lageplan, daten: d,
      onSpeichern: (neu, neuP) => { d.einstellungen.lageplan = neu; const n = plaetzeAnlegen(neu, neuP); speichern('Lageplan gespeichert – er gilt jetzt für alle.' + (n ? ' ' + n + ' neue Plätze angelegt.' : '')); zeige('plan', true); },
      onPlanung: (neu) => { const name = planungName(); if (!name) return false; const x = { id: H.uid('PL'), name, plan: neu, stand: heute }; d.einstellungen.lageplan_planungen = planungen().concat([x]); planStand.planung = x.id; speichern('Als Planung „' + name + '“ gesichert – der gültige Plan ist unverändert.'); zeige('plan', true); return true; },
      onVorlage: () => { delete d.einstellungen.lageplan; speichern('Vorlage wiederhergestellt.'); zeige('plan', true); }
    }));
    // Plan ▾ → „Welcher Plan?“: gültiger Plan, eine Planung oder eine neue Planung (Kopie des gültigen Plans)
    main.querySelectorAll('[data-plan-wahl]').forEach((b) => b.addEventListener('click', () => { const w = b.dataset.planWahl;
      if (w === '+') { const name = planungName(); if (!name) return;
        const x = { id: H.uid('PL'), name, plan: JSON.parse(JSON.stringify(d.einstellungen.lageplan || PLAN.STANDARD)), stand: heute }; d.einstellungen.lageplan_planungen = planungen().concat([x]); planStand.planung = x.id; speichern('Planung „' + name + '“ angelegt – eine Kopie des gültigen Plans.'); zeige('plan', true); return planungBearbeiten(x); }
      if ((w || null) === (planStand.planung || null)) return;
      planStand.planung = w || null; planStand.markiere = null; zeige('plan', true); }));
    const an = (id, fn) => { const b = $('#' + id); if (b) b.addEventListener('click', fn); };
    an('pl-zurueck', () => { planStand.planung = null; zeige('plan', true); });
    an('pl-name', () => { const n = prompt('Name der Planung:', pl.name); if (!n || !n.trim()) return; pl.name = n.trim().slice(0, 60); speichern('Umbenannt.'); zeige('plan', true); });
    an('pl-weg', () => { if (!confirm('Planung „' + pl.name + '“ löschen? Der gültige Plan bleibt, wie er ist.')) return; d.einstellungen.lageplan_planungen = planungen().filter((x) => x.id !== pl.id); planStand.planung = null; speichern('Planung gelöscht.'); zeige('plan', true); });
    an('pl-gueltig', () => {
      const pr = PLAN.pruefen(planVoll(pl.plan), d); const fehlt = pr.fehlen.concat(pr.landFehlen);
      if (!confirm('Planung „' + pl.name + '“ jetzt gültig schalten?\n\nSie ersetzt den Hafenplan für alle. Der bisherige Plan bleibt als Planung „Bisheriger Plan“ erhalten – du kannst jederzeit zurück.' +
        (fehlt.length ? '\n\nAchtung: Diese Plätze gibt es im Verein, sie stehen aber nicht mehr im Plan und wären nicht mehr zu sehen: ' + window.HAFEN_PLAN_EDITOR.bereiche(fehlt) + '.' : ''))) return;
      const alt = { id: H.uid('PL'), name: 'Bisheriger Plan (bis ' + H.datum(heute) + ')', plan: JSON.parse(JSON.stringify(d.einstellungen.lageplan || PLAN.STANDARD)), stand: heute };
      d.einstellungen.lageplan = pl.plan; d.einstellungen.lageplan_planungen = planungen().filter((x) => x.id !== pl.id).concat([alt]); planStand.planung = null;
      const n = plaetzeAnlegen(pl.plan, { wasser: pr.unbekannt, land: pr.landUnbekannt });
      speichern('Die Planung gilt jetzt für alle.' + (n ? ' ' + n + ' neue Plätze angelegt.' : '')); zeige('plan', true); });
    $('#plan-druck').addEventListener('click', () => planDruckDialog(pl, svg));
    if (planStand.markiere) detail(planStand.markiere); else detailLeer();
  };

  function detailLeer() {
    const el = $('#detail'); if (!el) return;
    if (planStand.modus === 'winter') {
      const bel = Q.belegungen(SAISON, 'winter');
      // je Lage (Nordlager, Winterlager West, Außenlager); die Halle nur, wenn dort jemand steht – der Plan zeigt keine Halle
      const lagen = []; d.landplaetze.forEach((p) => { const l = Q.lage(p) || 'Sonstige'; let x = lagen.find((y) => y.l === l); if (!x) lagen.push(x = { l, n: 0, b: 0, halle: p.art === 'halle' }); x.n++; if (bel.some((y) => y.platz_id === p.id)) x.b++; });
      el.innerHTML = '<h2>Winterlager</h2><p class="unter">' + SAISON + '/' + String(SAISON + 1).slice(2) + ' · Einlagern war am ' + H.datum(sd.einlagern) + '</p><dl>' +
        lagen.filter((x) => !x.halle || x.b).map((x) => '<dt>' + esc(x.l) + '</dt><dd>' + x.b + ' von ' + x.n + ' belegt</dd>').join('') +
        '<dt>Gesamt</dt><dd><strong>' + bel.length + ' Boote an Land</strong></dd></dl>' + (darf('belegung') ? '<div class="aktionen"><button class="btn" id="pk-belegung">Belegungsplan</button></div>' : darf('lagern') ? '<div class="aktionen"><button class="btn" id="pk-belegung">Belegungsplan ansehen</button></div>' : '');
      // mit Belegungsrecht → Hafen → Belegung (Winter); sonst die Druckseite des Belegungsplans (nur lesen)
      const pk = el.querySelector('#pk-belegung'); if (pk) pk.addEventListener('click', () => { if (darf('belegung')) { belegungStand.periode = 'winter'; zeige('belegung'); } else oeffnen('drucken.html?art=belegungsplan'); });
      return;
    }
    const tagX = planStand.datum;
    const gruen = d.liegeplaetze.filter((p) => Q.statusWasser(p, SAISON, tagX) === 'unterwegs');
    const frei = d.liegeplaetze.filter((p) => Q.statusWasser(p, SAISON, tagX) === 'frei');
    el.innerHTML = '<h2>Für Gäste frei</h2><p class="unter">am ' + H.datum(tagX) + ' (' + stichtagText(tagX) + ') – freie Plätze und Plätze mit grünem Schild</p>' +
      '<dl>' + frei.map((p) => '<dt><span class="tag">frei</span></dt><dd><a href="#" data-platz-link="' + p.id + '">' + platzName(p.id) + '</a> · Box ' + p.box + ' · bis ' + H.zahl(p.max_laenge, 1) + ' m</dd>').join('') +
      gruen.map((p) => { const a = Q.abwesendAm(p.id, tagX); return '<dt><span class="tag gruen">grün</span></dt><dd><a href="#" data-platz-link="' + p.id + '">' + platzName(p.id) + '</a> · bis ' + H.kurz(a.bis) + '</dd>'; }).join('') + '</dl>' +
      (darf('gaeste') && planStand.modus === 'sommer' ? '<div class="aktionen"><button class="btn primaer" data-neuer-gast>+ Gastlieger einweisen</button></div>' : '');
    el.querySelectorAll('[data-platz-link]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); planStand.markiere = a.dataset.platzLink; planStand.fokus = true; planStand.vb = null; zeige('plan'); }));
    const ng = el.querySelector('[data-neuer-gast]'); if (ng) ng.addEventListener('click', () => gastForm({}));
  }

  function detail(id) {
    const el = $('#detail'); const p = Q.platz(id); if (!p || !el) return;
    const tagX = planStand.datum;
    if (p.bez) {
      // Landplatz
      const per = planStand.modus === 'winter' ? 'winter' : 'sommer';
      const bel = Q.belegungPlatz(SAISON, per, id); const b = bel && Q.boot(bel.boot_id); const m = b && Q.mitglied(b.eigner_id);
      el.innerHTML = '<h2>' + esc(Q.platzName(p)) + '</h2><p class="unter">Lagerplatz · ' + (per === 'winter' ? 'Winter ' + SAISON + '/' + String(SAISON + 1).slice(2) : 'Sommer ' + SAISON) + '</p>' +
        (b ? '<dl><dt>Boot</dt><dd>' + bootTxt(b) + '</dd><dt>Maße</dt><dd>' + masse(b) + ' · ' + H.zahl(b.gewicht_t, 1) + ' t</dd><dt>Eigner</dt><dd>' + esc(Q.name(m)) + '</dd>' +
          (p.art !== 'palette' ? '<dt>Fläche</dt><dd>' + G.flaeche(d, bel, b) + ' m²</dd>' : '') + (bel.nicht_kranen ? '<dt>Hinweis</dt><dd><span class="tag warn">nicht kranen</span></dd>' : '') + '</dl>' : '<p class="leer">Frei.</p>') +
        (darf('belegung') ? '<div class="aktionen"><button class="btn" data-gehe-bel>Belegung bearbeiten</button></div>' : '');
      const gb = el.querySelector('[data-gehe-bel]'); if (gb) gb.addEventListener('click', () => { belegungStand.periode = per; zeige('belegung'); });
      return;
    }
    const status = planStand.modus === 'winter' ? 'Winterpause' : PLAN.STATUS_TEXT[Q.statusWasser(p, SAISON, tagX)];
    const bel = Q.belegungPlatz(SAISON, 'sommer', id); const b = bel && Q.boot(bel.boot_id); const m = b && Q.mitglied(b.eigner_id);
    const aw = Q.abwesendAm(id, tagX); const gast = Q.gastAm(id, tagX);
    const kommende = d.abwesenheiten.filter((a) => a.platz_id === id && a.bis >= tagX).sort((a, x) => a.von.localeCompare(x.von));
    const probleme = b ? Q.passt(b, p) : [];
    el.innerHTML = '<h2>' + (p.box === 'L' ? 'Längsseits ' : 'Platz ') + esc(p.nr) + '</h2><p class="unter">' + H.BRUECKE[p.bruecke] + ' · ' + (p.box === 'L' ? 'Sondertarif' : 'Box ' + p.box) + ' · max. ' + H.zahl(p.max_laenge, 1) + ' × ' + H.zahl(p.max_breite, 1) + ' m' + (p.tiefe ? ' · Wassertiefe ' + H.zahl(p.tiefe, 1) + ' m' : '') + (p.strom ? ' · Strom' : '') + '</p>' +
      (planStand.modus === 'sommer' && tagX !== heute ? '<p class="hinweis" style="margin:0 0 8px">Status am ' + H.datum(tagX) + ' (' + stichtagText(tagX) + ')</p>' : '') +
      (d.aufgaben || []).filter((t) => t.platz_id === id && t.status !== 'erledigt').map((t) => '<p class="hinweis warn">' + esc(t.titel) + ' <small>(' + ({ offen: 'offen', in_arbeit: 'in Arbeit' })[t.status] + ')</small></p>').join('') +
      '<p><span class="tag ' + (STATUS_TAG[Q.statusWasser(p, SAISON, tagX)] || '') + '">' + esc(status) + '</span></p>' +
      (p.gesperrt ? '<p class="hinweis warn">' + esc(p.notiz || 'Gesperrt') + '</p>' : '') +
      (b ? '<dl><dt>Boot</dt><dd>' + bootTxt(b) + '</dd><dt>Maße</dt><dd>' + masse(b) + ' · Tiefgang ' + H.zahl(b.tiefgang) + ' m</dd><dt>Gewicht</dt><dd>' + H.zahl(b.gewicht_t, 1) + ' t' + (Q.zuSchwer(b) ? ' <span class="tag rot">über ' + Q.maxTxt() + ' (Kran)</span>' : '') + '</dd>' +
        '<dt>Versicherung</dt><dd>' + versTag(b) + '</dd><dt>Eigner</dt><dd>' + esc(Q.name(m)) + ' <span class="tag">' + H.ART[m.art] + '</span></dd><dt>Telefon</dt><dd><a href="tel:' + esc((m.tel || '').replace(/\s/g, '')) + '">' + esc(m.tel) + '</a></dd></dl>' +
        (probleme.length ? '<p class="hinweis warn" style="margin-top:10px">Passt nicht: ' + probleme.map(esc).join(', ') + '</p>' : '') + '<div class="bootsfoto" id="bootsfoto"></div>' : '<p class="leer">Kein Dauerlieger in dieser Saison.</p>') +
      (gast ? '<div class="abschnitt"><h3>Gastlieger</h3><dl><dt>Boot</dt><dd>„' + esc(gast.bootsname) + '“ · ' + H.zahl(gast.laenge, 1) + ' m</dd><dt>Skipper</dt><dd>' + esc(gast.skipper) + (gast.herkunft ? ' · ' + esc(gast.herkunft) : '') + '</dd><dt>Zeitraum</dt><dd>' + H.kurz(gast.ankunft) + ', ' + gast.naechte + ' Nacht' + (gast.naechte > 1 ? 'e' : '') + '</dd><dt>Zahlung</dt><dd>' + zahlungText(gast) + '</dd></dl></div>' : '') +
      (kommende.length ? '<div class="abschnitt"><h3>Grünes Schild</h3><dl>' + kommende.map((a) => '<dt>' + H.kurz(a.von) + '–' + H.kurz(a.bis) + '</dt><dd>' + esc(a.notiz || '') + (a === aw ? ' <span class="tag gruen">jetzt</span>' : '') + '</dd>').join('') + '</dl></div>' : '') +
      '<div class="aktionen">' +
      (b && darf('abwesenheiten') ? '<button class="btn gruen" data-aw>Grünes Schild eintragen</button>' : '') +
      (darf('gaeste') && planStand.modus === 'sommer' && !gast && !p.gesperrt && (!bel || aw) ? '<button class="btn primaer" data-gast>Gast einweisen</button>' : '') +
      (darf('belegung') ? '<button class="btn" data-sperre>' + (p.gesperrt ? 'Sperre aufheben' : 'Sperren') + '</button>' : '') +
      (b && darf('boote') ? '<button class="btn" data-boot>Boot</button>' : '') + '</div>';
    const on = (s, f) => { const x = el.querySelector(s); if (x) x.addEventListener('click', f); };
    on('[data-aw]', () => abwesenheitForm({ boot_id: b.id }));
    on('[data-gast]', () => gastForm({ platz_id: id, ankunft: tagX }));
    on('[data-boot]', () => bootForm(b));
    on('[data-sperre]', () => {
      if (!p.gesperrt) { const grund = prompt('Grund der Sperre (z. B. Dalben defekt):', ''); if (grund === null) return; p.notiz = grund; }
      p.gesperrt = !p.gesperrt; speichern(p.gesperrt ? 'Platz gesperrt.' : 'Sperre aufgehoben.'); zeige('plan');
    });
    if (b) HF.dok.liste({ boot_id: b.id }).then((l) => { const foto = l.find((x) => x.art === 'foto'); if (!foto) return; return HF.dok.inhalt(foto.id).then((x) => { const box = $('#bootsfoto'); if (box && x) box.innerHTML = '<img alt="Foto von „' + esc(b.name) + '“" src="data:' + x.typ + ';base64,' + x.inhalt + '">'; }); }).catch(() => {});
    if (window.matchMedia('(max-width: 1200px)').matches) { const dt = document.querySelector('.detail'); if (dt) dt.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  }

  /* ============================================================ Liegeplätze */
  let masseModus = false;
  V.plaetze = (main) => {
    if (masseModus && darf('belegung')) return masseTabelle(main);
    const tagX = planStand.datum;
    const mitTiefe = d.liegeplaetze.some((p) => p.tiefe);   // Spalte „Tiefe“ nur, wenn mindestens ein Wert eingetragen ist
    main.innerHTML = kopf('Liegeplätze', d.liegeplaetze.length + ' Wasserplätze · ' + d.landplaetze.length + ' Lagerplätze an Land', '<button class="btn" id="csv">CSV</button>' + (darf('belegung') ? '<button class="btn primaer" id="masse-alle">Maße bearbeiten</button>' : '')) +
      (planAnnahme() ? '<p class="hinweis warn">Boxmaße und Brückenzuordnung sind noch <strong>Annahmen</strong>. ' + (darf('belegung') ? 'Bitte die echten Maße (und wenn bekannt die Wassertiefe) über „Maße“ eintragen und danach unter Einstellungen bestätigen.' : 'Der Vorstand bzw. die Brückenwartin tragen die echten Maße ein.') + '</p>' : '') +
      '<div class="filter"><input class="suche" id="such" placeholder="Platz, Boot oder Eigner …"><select class="suche" id="br" style="min-width:0"><option value="">Alle Brücken</option>' + Object.entries(H.BRUECKE).map(([k, v]) => '<option value="' + k + '">' + v + '</option>').join('') + '</select></div>' +
      '<div class="panel"><table class="tab kt"><thead><tr><th>Platz</th><th>Brücke · Box</th><th class="r">max. Länge × Breite</th>' + (mitTiefe ? '<th class="r">Tiefe</th>' : '') + '<th>Boot</th><th>Eigner</th><th>Status ' + (tagX === heute ? 'heute' : H.kurz(tagX) + ' (' + stichtagText(tagX) + ')') + '</th>' + (darf('belegung') ? '<th></th>' : '') + '</tr></thead><tbody id="tb"></tbody></table></div>';
    const render = () => {
      const f = $('#such').value.toLowerCase(), br = $('#br').value;
      $('#tb').innerHTML = d.liegeplaetze.filter((p) => !br || p.bruecke === br).map((p) => {
        const bel = Q.belegungPlatz(SAISON, 'sommer', p.id); const b = bel && Q.boot(bel.boot_id); const m = b && Q.mitglied(b.eigner_id);
        const s = Q.statusWasser(p, SAISON, tagX);
        const txt = (p.nr + ' ' + (b ? b.name : '') + ' ' + (m ? Q.name(m) : '')).toLowerCase();
        if (f && !txt.includes(f)) return '';
        const lageBox = H.BRUECKE[p.bruecke] + ' · ' + (p.box === 'L' ? 'Sondertarif' : 'Box ' + p.box);
        return '<tr class="klickbar" data-p="' + p.id + '"><td class="k-titel"><strong>' + (p.box === 'L' ? '' : '<span class="k-nur">Platz </span>') + esc(p.nr) + '</strong><span class="k-nur"> · ' + lageBox + '</span></td><td class="k-weg nw">' + lageBox + '</td>' +
          '<td class="r k-mass"><span class="nw">' + H.zahl(p.max_laenge, 1) + ' × ' + H.zahl(p.max_breite, 1) + ' m</span>' + (mitTiefe && p.tiefe ? '<span class="k-nur nw"> · Tiefe ' + H.zahl(p.tiefe, 1) + ' m</span>' : '') + '</td>' +
          (mitTiefe ? '<td class="r k-weg">' + (p.tiefe ? '<span class="nw">' + H.zahl(p.tiefe, 1) + ' m</span>' : '–') + '</td>' : '') +
          '<td class="k-boot">' + (b ? esc(b.name) + (Q.passt(b, p).length ? ' <span class="tag warn">passt nicht</span>' : '') : '') + '</td><td class="k-eigner">' + (m ? esc(Q.name(m)) : '') + '</td><td class="k-status"><span class="tag ' + (STATUS_TAG[s] || '') + '">' + PLAN.STATUS_TEXT[s].replace(' – grünes Schild', '') + '</span></td>' + (darf('belegung') ? '<td class="r k-aktion"><button class="btn klein" data-masse="' + p.id + '">Maße</button></td>' : '') + '</tr>';
      }).join('') || '<tr><td colspan="9" class="leer">Kein Platz gefunden.</td></tr>';
    };
    render(); $('#such').addEventListener('input', render); $('#br').addEventListener('change', render);
    const ma = $('#masse-alle'); if (ma) ma.addEventListener('click', () => { masseModus = true; zeige('plaetze'); });
    $('#tb').addEventListener('click', (e) => { const m = e.target.closest('[data-masse]'); if (m) { e.stopPropagation(); return platzForm(Q.platz(m.dataset.masse)); } const r = e.target.closest('[data-p]'); if (r) { planStand.markiere = r.dataset.p; planStand.fokus = true; planStand.vb = null; zeige('plan'); } });
    $('#csv').addEventListener('click', () => download('liegeplaetze.csv', csv([['Platz', 'Brücke', 'Box', 'max. Länge', 'max. Breite', 'Strom', 'Boot', 'Eigner', 'Mitgliedsart']].concat(d.liegeplaetze.map((p) => {
      const bel = Q.belegungPlatz(SAISON, 'sommer', p.id); const b = bel && Q.boot(bel.boot_id); const m = b && Q.mitglied(b.eigner_id);
      return [p.nr, H.BRUECKE[p.bruecke], p.box, H.zahl(p.max_laenge, 1), H.zahl(p.max_breite, 1), p.strom ? 'ja' : 'nein', b ? b.name : '', m ? Q.name(m) : '', m ? H.ART[m.art] : ''];
    }))), 'text/csv'));
  };

  /* Alle Plätze in einer Tabelle durchtippen (Tab/Enter springt weiter); Vorlage je Box füllt viele auf einmal */
  function masseTabelle(main) {
    const zahlFeld = (p, k, step) => '<input class="masse" type="number" inputmode="decimal" step="' + step + '" min="0" data-id="' + p.id + '" data-k="' + k + '" value="' + (p[k] == null ? '' : p[k]) + '" aria-label="' + esc(platzName(p.id)) + ' ' + ({ max_laenge: 'Länge', max_breite: 'Breite', tiefe: 'Wassertiefe' })[k] + '">';
    main.innerHTML = kopf('Liegeplätze – Maße bearbeiten', 'Werte eintippen, mit Tab oder Enter weiter. Geänderte Felder werden gelb markiert; gespeichert wird mit einem Klick.',
      '<button class="btn" id="m-abbr">Abbrechen</button><button class="btn primaer" id="m-ok">Speichern</button>') +
      '<div class="panel"><h2>Vorlage je Box</h2><div class="filter" style="align-items:flex-end"><label class="feld">Box<select id="v-box"><option>I</option><option>II</option><option>III</option></select></label>' +
      '<label class="feld">Länge (m)<input id="v-l" type="number" step="0.01" inputmode="decimal" style="width:100px"></label><label class="feld">Breite (m)<input id="v-b" type="number" step="0.01" inputmode="decimal" style="width:100px"></label>' +
      '<label class="feld">Wassertiefe (m)<input id="v-t" type="number" step="0.1" inputmode="decimal" style="width:100px"></label><button class="btn" id="v-los">Für alle Plätze dieser Box eintragen</button></div>' +
      '<p class="hinweis" style="margin:8px 0 0">Leere Felder der Vorlage bleiben unverändert. Danach einzelne Plätze in der Tabelle anpassen.</p></div>' +
      '<div class="panel"><table class="tab masse-tab"><thead><tr><th>Platz</th><th>Brücke</th><th>Box</th><th class="r">Länge (m)</th><th class="r">Breite (m)</th><th class="r">Tiefe (m)</th><th>Strom</th></tr></thead><tbody>' +
      d.liegeplaetze.map((p) => '<tr><td><strong>' + esc(p.nr) + '</strong></td><td>' + H.BRUECKE[p.bruecke] + '</td>' +
        '<td><select class="masse" data-id="' + p.id + '" data-k="box" aria-label="' + esc(platzName(p.id)) + ' Box">' + ['I', 'II', 'III', 'L'].map((b) => '<option' + (p.box === b ? ' selected' : '') + '>' + b + '</option>').join('') + '</select></td>' +
        '<td class="r">' + zahlFeld(p, 'max_laenge', '0.01') + '</td><td class="r">' + zahlFeld(p, 'max_breite', '0.01') + '</td><td class="r">' + zahlFeld(p, 'tiefe', '0.1') + '</td>' +
        '<td><input type="checkbox" class="masse" data-id="' + p.id + '" data-k="strom"' + (p.strom ? ' checked' : '') + ' aria-label="' + esc(platzName(p.id)) + ' Strom"></td></tr>').join('') + '</tbody></table></div>' +
      '<div class="aktionen" style="justify-content:flex-end"><button class="btn primaer" id="m-ok2">Speichern</button></div>';
    const felder = [...main.querySelectorAll('.masse')];
    const markieren = (el) => { const p = Q.platz(el.dataset.id); const alt = el.dataset.k === 'strom' ? !!p.strom : el.dataset.k === 'box' ? p.box : (p[el.dataset.k] == null ? '' : String(p[el.dataset.k]));
      const zahlK = !['strom', 'box'].includes(el.dataset.k);   // Zahlen vergleichen, damit „9,5“ = 9.5 nicht als Änderung gilt
      const neu = el.type === 'checkbox' ? el.checked : el.value; el.classList.toggle('geaendert', zahlK ? (neu.trim() === '' ? alt !== '' : H.dez(neu) !== Number(alt) || alt === '') : String(neu) !== String(alt)); };
    felder.forEach((el) => el.addEventListener(el.type === 'checkbox' || el.tagName === 'SELECT' ? 'change' : 'input', () => markieren(el)));
    // Enter springt wie Tab ins nächste Feld derselben Spalte
    main.querySelector('.masse-tab').addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' || e.target.tagName !== 'INPUT') return; e.preventDefault();
      const gleich = felder.filter((x) => x.dataset.k === e.target.dataset.k); const n = gleich[gleich.indexOf(e.target) + 1]; if (n) { n.focus(); n.select && n.select(); }
    });
    $('#v-los').addEventListener('click', () => {
      const box = $('#v-box').value; const w = { max_laenge: $('#v-l').value, max_breite: $('#v-b').value, tiefe: $('#v-t').value }; let n = 0;
      felder.filter((el) => w[el.dataset.k] !== undefined && w[el.dataset.k] !== '' && main.querySelector('select.masse[data-id="' + el.dataset.id + '"]').value === box).forEach((el) => { el.value = w[el.dataset.k]; markieren(el); n++; });
      toast(n ? 'Vorlage in ' + Math.round(n / Object.values(w).filter(Boolean).length) + ' Plätze eingetragen – bitte prüfen und speichern.' : 'Bitte mindestens einen Wert eintragen.');
    });
    const ende = () => { masseModus = false; zeige('plaetze'); };
    $('#m-abbr').addEventListener('click', () => { if (main.querySelector('.geaendert') && !confirm('Änderungen verwerfen?')) return; ende(); });
    const sichern = () => {
      const geaendert = felder.filter((el) => el.classList.contains('geaendert'));
      if (!geaendert.length) return ende();
      for (const el of geaendert) { if (['max_laenge', 'max_breite'].includes(el.dataset.k) && !(H.dez(el.value) > 0)) { el.focus(); return toast(platzName(el.dataset.id) + ': bitte eine Zahl über 0 eintragen.', 'fehler'); } }
      geaendert.forEach((el) => { const p = Q.platz(el.dataset.id); const k = el.dataset.k;
        p[k] = k === 'strom' ? el.checked : k === 'box' ? el.value : (el.value.trim() === '' ? null : H.dez(el.value)); });
      speichern(new Set(geaendert.map((el) => el.dataset.id)).size + ' Plätze gespeichert.'); ende();
    };
    $('#m-ok').addEventListener('click', sichern); $('#m-ok2').addEventListener('click', sichern);
  }

  function platzForm(p) {
    const el = modal('<h2>' + esc(platzName(p.id)) + ' – Maße</h2><p class="hinweis">Diese Werte nutzt die Platzempfehlung für Gäste und die Warteliste. Wassertiefe leer lassen, wenn sie nicht bekannt ist.</p><form id="f" class="form">' +
      '<label class="feld">Box<select name="box">' + ['I', 'II', 'III', 'L'].map((b) => '<option value="' + b + '"' + (p.box === b ? ' selected' : '') + '>' + (b === 'L' ? 'Längsseits (Sondertarif)' : 'Box ' + b) + '</option>').join('') + '</select><small>bestimmt die Liegegebühr</small></label>' +
      '<label class="feld">Brücke<select name="bruecke">' + Object.entries(H.BRUECKE).map(([k, v]) => '<option value="' + k + '"' + (p.bruecke === k ? ' selected' : '') + '>' + v + '</option>').join('') + '</select></label>' +
      '<label class="feld">max. Länge (m)<input name="max_laenge" type="number" step="0.01" min="1" required value="' + (p.max_laenge || '') + '"></label>' +
      '<label class="feld">max. Breite (m)<input name="max_breite" type="number" step="0.01" min="0.5" required value="' + (p.max_breite || '') + '"></label>' +
      '<label class="feld">Wassertiefe (m)<input name="tiefe" type="number" step="0.1" min="0.3" value="' + (p.tiefe || '') + '"><small>bei mittlerem Wasser</small></label>' +
      '<label class="feld check"><input type="checkbox" name="strom"' + (p.strom ? ' checked' : '') + '> Strom am Platz</label>' +
      '<label class="feld voll">Notiz<input name="notiz" value="' + esc(p.notiz || '') + '"></label></form>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>');
    $('#ok', el).addEventListener('click', () => {
      const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm));
      Object.assign(p, { box: x.box, bruecke: x.bruecke, max_laenge: H.dez(x.max_laenge), max_breite: H.dez(x.max_breite), tiefe: x.tiefe ? H.dez(x.tiefe) : null, strom: !!x.strom, notiz: x.notiz });
      speichern('Maße gespeichert.'); zu(); zeige(tab);
    });
  }

  /* ============================================================ Boote */
  V.boote = (main) => {
    main.innerHTML = kopf('Boote', d.boote.length + ' Boote im Verein', '<button class="btn primaer" id="neu">+ Boot anmelden</button>') +
      '<div class="filter"><input class="suche" id="such" placeholder="Boot, Segelnr., Eigner …" aria-label="Boot, Typ, Segelnummer oder Eigner suchen"><label class="feld check"><input type="checkbox" id="probl"> nur mit Handlungsbedarf</label></div>' +
      '<div class="panel"><table class="tab"><thead><tr><th>Boot</th><th>Typ</th><th class="r">L × B</th><th class="r">Gewicht</th><th>Eigner</th><th>Platz Sommer</th><th>Versicherung</th></tr></thead><tbody id="tb"></tbody></table></div>';
    const render = () => {
      const f = $('#such').value.toLowerCase(), nurP = $('#probl').checked;
      $('#tb').innerHTML = d.boote.slice().sort((a, b) => a.name.localeCompare(b.name, 'de')).map((b) => {
        const m = Q.mitglied(b.eigner_id); const bel = Q.belegungBoot(SAISON, 'sommer', b.id);
        const vs = Q.versicherungsStatus(b, heute); const probl = vs !== 'ok' || b.vers_status === 'eingereicht' || Q.zuSchwer(b) || (bel && bel.platz_typ === 'wasser' && Q.passt(b, Q.platz(bel.platz_id)).length);
        if (nurP && !probl) return '';
        if (f && !(b.name + ' ' + b.typ + ' ' + b.segelnr + ' ' + Q.name(m)).toLowerCase().includes(f)) return '';
        return '<tr class="klickbar" data-b="' + b.id + '"><td><strong>' + esc(b.name) + '</strong><br><small style="color:var(--muted)">' + esc(b.segelnr) + '</small></td><td>' + esc(b.typ) + '</td><td class="r">' + masse(b) + '</td>' +
          '<td class="r">' + H.zahl(b.gewicht_t, 1) + ' t' + (Q.zuSchwer(b) ? ' <span class="tag rot">!</span>' : '') + '</td><td>' + esc(Q.name(m)) + '</td><td>' + (bel ? platzName(bel.platz_id) : '–') + '</td><td>' + versTag(b) + '</td></tr>';
      }).join('');
    };
    render(); $('#such').addEventListener('input', render); $('#probl').addEventListener('change', render);
    $('#tb').addEventListener('click', (e) => { const r = e.target.closest('[data-b]'); if (r) bootForm(Q.boot(r.dataset.b)); });
    $('#neu').addEventListener('click', () => bootForm({}));
  };
  function bootForm(b) {
    const neu = !b.id;
    const el = modal('<h2>' + (neu ? 'Boot anmelden' : '„' + esc(b.name) + '“') + '</h2><p class="hinweis">Laut Hafenbetriebsordnung muss jedes Boot vor dem Einbringen angemeldet werden und versichert sein (Personen-, Sach- und Umweltschäden, Bergung). Grenzen: Kran ' + Q.maxTxt('kran') + ', Steg/Wasserliegeplatz ' + Q.maxTxt('steg') + '.</p><form id="f" class="form">' +
      '<label class="feld">Bootsname<input name="name" required value="' + esc(b.name || '') + '"></label>' +
      '<label class="feld">Typ<input name="typ" value="' + esc(b.typ || '') + '" placeholder="z. B. Dehler 34"></label>' +
      '<label class="feld voll">Eigner<select name="eigner_id" required><option value="">bitte wählen</option>' + mOpt(b.eigner_id) + '</select></label>' +
      '<label class="feld">Länge (m)<input name="laenge" type="number" step="0.01" min="1" required value="' + (b.laenge || '') + '"></label>' +
      '<label class="feld">Breite (m)<input name="breite" type="number" step="0.01" min="0.5" required value="' + (b.breite || '') + '"></label>' +
      '<label class="feld">Tiefgang (m)<input name="tiefgang" type="number" step="0.01" value="' + (b.tiefgang || '') + '"></label>' +
      '<label class="feld">Gewicht (t)<input name="gewicht_t" type="number" step="0.1" required value="' + (b.gewicht_t || '') + '"><small>inkl. Ausrüstung – Kran max. ' + Q.maxTxt('kran') + ', Steg max. ' + Q.maxTxt('steg') + '</small></label>' +
      '<label class="feld">Segelnummer / Kennzeichen<input name="segelnr" value="' + esc(b.segelnr || '') + '"></label>' +
      '<label class="feld">Versicherung<input name="versicherung" value="' + esc(b.versicherung || '') + '"></label>' +
      '<label class="feld">Versichert bis<input name="vers_bis" type="date" value="' + esc(b.vers_bis || '') + '"></label>' +
      '<label class="feld voll">Notiz<input name="notiz" value="' + esc(b.notiz || '') + '"></label></form>' +
      (neu ? '<p class="hinweis">Den Versicherungsnachweis kannst du nach dem Speichern hochladen.</p>' : '<div class="abschnitt nachweis"><h3>Versicherungsnachweis</h3><p id="nw-stand"></p><div id="nw-liste"><p class="leer">Wird geladen …</p></div>' +
        '<div class="aktionen"><label class="btn">Nachweis hochladen<input type="file" id="nw-datei" accept="application/pdf,image/*" hidden></label><label class="btn">Bootsfoto<input type="file" id="foto-datei" accept="image/*" hidden></label>' +
        '<button class="btn gruen" id="nw-ok"' + (b.vers_status === 'geprueft' ? ' hidden' : '') + '>Als geprüft markieren</button>' + (verlaufErlaubt() ? '<button class="btn" id="b-verlauf">Verlauf</button>' : '') + '</div></div>') +
      '<div class="modal-fuss">' + (neu ? '' : '<button class="btn gefahr links" id="weg">Abmelden</button>') + '<button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>');
    $('#ok', el).addEventListener('click', () => {
      const f = $('#f', el); if (!f.reportValidity()) return;
      const x = Object.fromEntries(new FormData(f)); ['laenge', 'breite', 'tiefgang', 'gewicht_t'].forEach((k) => { x[k] = H.dez(x[k]) || 0; });
      if (Q.zuSchwer(x, 'kran') && !confirm('Das Boot wiegt mehr als ' + Q.maxTxt('kran') + ' und kann nicht gekrant werden' + (Q.zuSchwer(x, 'steg') ? '; über ' + Q.maxTxt('steg') + ' ist laut Hafenbetriebsordnung auch kein Wasserliegeplatz möglich' : '') + '. Trotzdem speichern?')) return;
      if (!neu && (x.versicherung !== (b.versicherung || '') || x.vers_bis !== (b.vers_bis || '')) && b.vers_status === 'geprueft') x.vers_status = null;   // neue Angaben → neu prüfen
      if (neu) d.boote.push({ id: H.uid('B'), vers_status: null, ...x }); else Object.assign(b, x);
      speichern('Boot gespeichert.'); zu(); zeige(tab);
    });
    if (!neu) {
      const stand = () => { $('#nw-stand', el).innerHTML = nachweisTag(b) + ' ' + (b.vers_status === 'geprueft' ? 'am ' + H.datum(b.vers_geprueft_am) + (b.vers_geprueft_von ? ' von ' + esc(b.vers_geprueft_von) : '') : b.vers_status === 'eingereicht' ? 'Das Mitglied hat einen Nachweis hochgeladen – bitte ansehen und prüfen.' : 'Angaben ohne geprüften Nachweis.'); };
      const liste = () => HF.dok.liste({ boot_id: b.id }).then((l) => {
        $('#nw-liste', el).innerHTML = l.length ? '<table class="tab"><tbody>' + l.map((x) => '<tr><td>' + esc(x.name) + '<br><small style="color:var(--muted)">' + H.datum(x.hochgeladen) + ' · ' + esc(x.von || '') + '</small></td><td class="r nw"><button class="btn klein" data-dok="' + x.id + '">Ansehen</button> <button class="btn klein gefahr" data-dok-weg="' + x.id + '">Löschen</button></td></tr>').join('') + '</tbody></table>' : '<p class="leer">Noch kein Nachweis hochgeladen.</p>';
      }).catch((e) => { $('#nw-liste', el).innerHTML = '<p class="hinweis warn">' + esc(e.message) + '</p>'; });
      stand(); liste();
      $('#nw-liste', el).addEventListener('click', (e) => {
        const a = e.target.closest('[data-dok]'); if (a) return HF.datei.oeffnen(a.dataset.dok).catch((x) => toast(x.message, 'fehler'));
        const w = e.target.closest('[data-dok-weg]'); if (w && confirm('Dokument löschen?')) HF.dok.loeschen(w.dataset.dokWeg).then(liste, (x) => toast(x.message, 'fehler'));
      });
      $('#nw-datei', el).addEventListener('change', async (e) => {
        try { const x = await HF.datei.lesen(e.target.files[0]); await HF.dok.hochladen({ ...x, boot_id: b.id, mitglied_id: b.eigner_id, art: 'versicherung' }, ROLLEN[rolle].name); toast('Nachweis gespeichert.'); liste(); }
        catch (x) { toast(x.message, 'fehler'); } e.target.value = '';
      });
      $('#foto-datei', el).addEventListener('change', async (e) => {
        try { const x = await HF.datei.lesen(e.target.files[0]); await HF.dok.hochladen({ ...x, boot_id: b.id, mitglied_id: b.eigner_id, art: 'foto', name: 'Foto ' + b.name + '.jpg' }, ROLLEN[rolle].name); toast('Foto gespeichert – erscheint im Hafenplan.'); liste(); }
        catch (x) { toast(x.message, 'fehler'); } e.target.value = '';
      });
      $('#nw-ok', el).addEventListener('click', () => { Object.assign(b, { vers_status: 'geprueft', vers_geprueft_am: heute, vers_geprueft_von: ROLLEN[rolle].name }); speichern('Nachweis als geprüft vermerkt.'); stand(); $('#nw-ok', el).hidden = true; });
      const bv = $('#b-verlauf', el); if (bv) bv.addEventListener('click', () => verlaufDialog('boote', b.id, b.name));
    }
    if (!neu) $('#weg', el).addEventListener('click', () => {
      if (d.belegungen.some((x) => x.boot_id === b.id)) return toast('Das Boot ist noch einem Platz zugeordnet – erst die Belegung lösen.', 'fehler');
      if (!confirm('„' + b.name + '“ abmelden (z. B. nach Verkauf)?')) return;
      d.boote = d.boote.filter((x) => x.id !== b.id); speichern('Boot abgemeldet.'); zu(); zeige(tab);
    });
  }

  /* ============================================================ Eigner & Mitglieder */
  V.eigner = (main) => {
    const mitgl = d.mitglieder.filter((m) => Q.istMitglied(m, heute)).length;
    main.innerHTML = kopf('Mitglieder', mitgl + ' Mitglieder · ' + (d.mitglieder.length - mitgl) + ' weitere (Saison-Gäste, Ausgetretene)',
      (bankSichtbar() ? '<button class="btn" id="import">Mitglieder importieren (CSV)</button>' : '') + '<button class="btn primaer" id="neu">+ Person</button>') +
      (bankSichtbar() ? '' : '<p class="hinweis">Bankdaten sind für deine Rolle ausgeblendet.</p>') +
      '<div class="filter"><input class="suche" id="such" placeholder="Name, Nr., Ort …"><select class="suche" id="artf" style="min-width:0"><option value="">Alle Arten</option>' +
      Object.entries(H.ART).map(([k, v]) => '<option value="' + k + '">' + v + '</option>').join('') + '</select></div>' +
      '<div class="panel"><table class="tab"><thead><tr><th>Nr.</th><th>Name</th><th>Art</th><th>Boot(e)</th><th>Telefon</th><th>Kfz</th><th>Lastschrift</th></tr></thead><tbody id="tb"></tbody></table></div>';
    const render = () => {
      const f = $('#such').value.toLowerCase(), af = $('#artf').value;
      $('#tb').innerHTML = d.mitglieder.slice().sort((a, b) => a.nachname.localeCompare(b.nachname, 'de')).filter((m) => (!f || (m.nr + ' ' + Q.name(m) + ' ' + m.ort).toLowerCase().includes(f)) && (!af || m.art === af)).map((m) =>
        '<tr class="klickbar' + (m.austritt && m.austritt <= heute ? ' blass' : '') + '" data-m="' + m.id + '"><td>' + esc(m.nr) + '</td><td><strong>' + esc(m.nachname) + '</strong>, ' + esc(m.vorname) + (m.austritt && m.austritt <= heute ? ' <span class="tag">ausgetreten</span>' : '') + '</td><td><span class="tag">' + (H.ART[m.art] || esc(m.art)) + '</span></td>' +
        '<td>' + Q.booteVon(m.id).map((b) => esc(b.name)).join(', ') + '</td><td class="nw">' + esc(m.tel || '') + '</td><td class="nw">' + esc(m.kfz || '') + '</td>' +
        '<td>' + (m.iban && m.mandat_ref ? '<span class="tag ok">Mandat ' + esc(m.mandat_ref) + '</span>' : '<span class="tag warn">kein Mandat</span>') + '</td></tr>').join('');
    };
    render(); $('#such').addEventListener('input', render); $('#artf').addEventListener('change', render);
    $('#tb').addEventListener('click', (e) => { const r = e.target.closest('[data-m]'); if (r) mitgliedAkte(Q.mitglied(r.dataset.m)); });
    $('#neu').addEventListener('click', () => mitgliedForm({ art: 'ausuebend' }));
    if ($('#import')) $('#import').addEventListener('click', importDialog);
  };
  /* Mitgliedsakte: alles zu einer Person auf einen Blick – Stammdaten, Boote, Plätze, Arbeitsdienst,
     Rechnungen (Hafen, Beitrag, Getränke), Dokumente und der Änderungsverlauf aller zugehörigen Datensätze */
  function mitgliedAkte(m) {
    if (!m) return;
    const bank = bankSichtbar(); const geld = darf('abrechnung'); const aus = m.austritt && m.austritt <= heute;
    const boote = Q.booteVon(m.id); const bootIds = boote.map((b) => b.id);
    const bel = d.belegungen.filter((x) => bootIds.includes(x.boot_id)).sort((a, b) => b.saison - a.saison || (a.periode === 'sommer' ? -1 : 1));
    const re = d.rechnungen.filter((r) => r.mitglied_id === m.id).sort((a, b) => (b.datum || '').localeCompare(a.datum || '') || b.nr.localeCompare(a.nr));
    const wl = d.warteliste.filter((w) => w.mitglied_id === m.id);
    const ad = (m.art === 'ausuebend' || m.art === 'probe') ? G.arbeitsdienst(d, SAISON, m) : null;
    const stunden = d.arbeitsdienst.filter((a) => a.mitglied_id === m.id);
    const gruppen = bereicheVon(m.id);
    const dl = (paare) => '<dl class="akte-dl">' + paare.filter(([, v]) => v).map(([k, v]) => '<dt>' + k + '</dt><dd>' + v + '</dd>').join('') + '</dl>';
    const offenSum = re.reduce((s, r) => s + Q.rest(r), 0);
    // Profil wie eine Kundenakte: alles zum Mitglied auf einer Seite – Kopf, Kennzahlen, Sprungleiste, dann die Abschnitte
    const per = (t) => d.belegungen.find((x) => bootIds.includes(x.boot_id) && x.saison === SAISON && x.periode === t);
    const sPl = per('sommer'), wPl = per('winter');
    const plTxt = (x) => x ? (x.platz_id ? esc(Q.platz(x.platz_id) && Q.platz(x.platz_id).bez ? x.platz_id : platzName(x.platz_id)) : esc(x.art || x.platz_typ || 'gebucht')) : '–';
    const schilder = d.abwesenheiten.filter((a) => bootIds.includes(a.boot_id) && a.bis >= heute).sort((a, b) => a.von.localeCompare(b.von));
    const zus = (d.zusagen || []).filter((z) => z.mitglied_id === m.id).map((z) => ({ z, v: (d.veranstaltungen || []).find((v) => v.id === z.veranstaltung_id) }))
      .filter((x) => x.v).sort((a, b) => b.v.datum.localeCompare(a.v.datum));
    const kachel = (wert, text, ziel, art) => '<a class="profil-kachel' + (art ? ' ' + art : '') + '" href="#' + ziel + '" data-sprung="' + ziel + '"><strong>' + wert + '</strong><span>' + text + '</span></a>';
    const merkmal = (ok, text) => '<span class="tag ' + (ok ? 'ok' : 'warn') + '">' + text + '</span>';
    const sprung = [['ak-kontakt', 'Kontakt'], ['ak-person', 'Persönliches'], bank ? ['ak-bank', 'Bank & Lastschrift'] : null, ['ak-boote', 'Boote & Plätze'], ['ak-schild', 'Grünes Schild'],
      ['ak-arbeit', 'Arbeitsdienst'], ['ak-veranst', 'Veranstaltungen'], geld ? ['ak-rechnungen', 'Rechnungen'] : null, ['ak-dok', 'Dokumente'], verlaufErlaubt() ? ['ak-verlauf', 'Verlauf'] : null].filter(Boolean);
    const el = modal('<div class="akte-kopf profil-kopf"><span class="profil-ava" aria-hidden="true">' + esc((m.vorname || '').charAt(0) + (m.nachname || '').charAt(0)) + '</span>' +
        '<div class="profil-titel"><h2>' + esc(Q.name(m)) + '</h2><p class="akte-unter">Nr. ' + esc(m.nr || '–') + ' · <span class="tag">' + (H.ART[m.art] || m.art) + '</span>' +
        (m.eintritt ? ' · Mitglied seit ' + H.datum(m.eintritt) : '') + (aus ? ' · <span class="tag rot">ausgetreten ' + H.datum(m.austritt) + '</span>' : m.austritt ? ' · <span class="tag warn">Austritt zum ' + H.datum(m.austritt) + '</span>' : '') + '</p>' +
        '<p class="profil-merkmale">' + (bank || geld ? merkmal(m.iban && m.mandat_ref, m.iban && m.mandat_ref ? 'Lastschrift' : 'kein Lastschriftmandat') + ' ' : '') +
          ('user_id' in m ? merkmal(!!m.user_id, m.user_id ? 'Mein SSV: angemeldet' : 'Mein SSV: noch nicht angemeldet') + ' ' : '') +
          '<span id="akte-code"></span>' + (wl.some((w) => w.status === 'wartend') ? ' <span class="tag gast">auf der Warteliste</span>' : '') + '</p></div>' +
        '<div class="profil-aktionen"><button class="btn primaer" id="akte-bearb">Bearbeiten</button>' +
          (m.email ? '<a class="btn" href="mailto:' + esc(m.email) + '">E-Mail schreiben</a>' : '') + (m.tel ? '<a class="btn" href="tel:' + esc(String(m.tel).replace(/[^\d+]/g, '')) + '">Anrufen</a>' : '') + '</div></div>' +
      '<div class="profil-kacheln">' +
        (geld ? kachel(H.geld(offenSum), 'offen (Hafen & Beitrag)', 'ak-rechnungen', offenSum > 0 ? 'warn' : 'ok') : '') +
        kachel(String(boote.length), boote.length === 1 ? 'Boot' : 'Boote', 'ak-boote') +
        kachel(plTxt(sPl), 'Sommer ' + SAISON, 'ak-boote') + kachel(plTxt(wPl), 'Winter ' + SAISON + '/' + String(SAISON + 1).slice(2), 'ak-boote') +
        (ad && !ad.befreit ? kachel(H.zahl(ad.ist, ad.ist % 1 ? 1 : 0) + ' / ' + ad.soll, 'Std. Arbeitsdienst', 'ak-arbeit', ad.fehl > 0 && ad.erfasst ? 'warn' : '') : '') +
        (geld ? '<span id="akte-getr-kachel"></span>' : '') + '</div>' +
      '<nav class="profil-nav" aria-label="Abschnitte der Akte">' + sprung.map(([id, t]) => '<a href="#' + id + '" data-sprung="' + id + '">' + t + '</a>').join('') + '</nav>' +
      '<div class="akte-raster">' +
        '<section class="akte-teil" id="ak-kontakt"><h3>Kontakt</h3>' + dl([['E-Mail', m.email ? '<a href="mailto:' + esc(m.email) + '">' + esc(m.email) + '</a>' : ''], ['Telefon', m.tel ? '<a href="tel:' + esc(m.tel) + '">' + esc(m.tel) + '</a>' : ''],
          ['Anschrift', esc([m.strasse, [m.plz, m.ort].filter(Boolean).join(' ')].filter(Boolean).join(', '))], ['Geboren', m.geburtsdatum ? H.datum(m.geburtsdatum) + ' (' + Q.alterAm(m, heute) + ')' : ''], ['Kfz', esc(m.kfz || '')]]) +
          (bank ? '<p style="margin:8px 0 0">' + (m.iban && m.mandat_ref ? '<span class="tag ok">Lastschrift · Mandat ' + esc(m.mandat_ref) + '</span>' : '<span class="tag warn">kein Lastschriftmandat – zahlt per Überweisung</span>') + '</p>' : '') + '</section>' +
        '<section class="akte-teil" id="ak-person"><h3>Persönliches</h3>' + dl([['Mitgliedsnr.', esc(m.nr || '')], ['Art', H.ART[m.art] || esc(m.art || '')], ['Geschlecht', H.GESCHLECHT[m.geschlecht] || ''],
          ['Eintritt', m.eintritt ? H.datum(m.eintritt) : ''], ['Austritt', m.austritt ? H.datum(m.austritt) : ''], ['Arbeitsdienst', m.arbeitsdienst_befreit ? 'befreit: ' + esc(m.arbeitsdienst_befreit) : ''],
          ['Notiz', m.notiz ? esc(m.notiz) : '']]) + '</section>' +
        (bank ? '<section class="akte-teil" id="ak-bank"><h3>Bank & Lastschrift</h3>' + (m.iban ? dl([['IBAN', iban(m.iban)], ['BIC', esc(m.bic || '')], ['Kontoinhaber', esc(m.kontoinhaber || Q.name(m))],
          ['Mandat', m.mandat_ref ? esc(m.mandat_ref) + (m.mandat_datum ? ' vom ' + H.datum(m.mandat_datum) : '') : '<span class="tag warn">fehlt</span>']]) : '<p class="leer" style="margin:0">Keine Bankverbindung – zahlt per Überweisung.</p>') + '</section>' : '') +
        '<section class="akte-teil" id="ak-boote"><h3>Boote & Plätze</h3>' + (boote.length ? boote.map((b) => '<p style="margin:0 0 6px"><strong>„' + esc(b.name) + '“</strong> ' + esc(b.typ || '') + '<br><small>' + masse(b) + ' · ' + H.zahl(b.gewicht_t, 1) + ' t' + (Q.zuSchwer(b) ? ' <span class="tag rot">über ' + Q.maxTxt() + ' (Kran)</span>' : '') + ' · Versicherung ' + versTag(b) + '</small></p>').join('') : '<p class="leer" style="margin:0">Kein Boot eingetragen.</p>') +
          (bel.length ? '<table class="tab kompakt"><tbody>' + bel.slice(0, 4).map((x) => '<tr><td>' + (x.periode === 'sommer' ? 'Sommer ' + x.saison : 'Winter ' + x.saison + '/' + String(x.saison + 1).slice(2)) + '</td><td>' + esc(x.platz_id ? platzName(x.platz_id) : (x.art || x.platz_typ || '')) + '</td></tr>').join('') + '</tbody></table>' : '') +
          (wl.length ? '<p style="margin:8px 0 0">' + wl.map((w) => '<span class="tag ' + (w.status === 'wartend' ? 'gast' : '') + '">Warteliste seit ' + H.datum(w.datum) + ' · ' + esc(w.status) + '</span>').join(' ') + '</p>' : '') + '</section>' +
        '<section class="akte-teil"><h3>Arbeitsdienst ' + SAISON + '</h3>' + (ad ? (ad.befreit ? '<p style="margin:0"><span class="tag">befreit</span> ' + esc(ad.befreit) + '</p>' : '<p style="margin:0"><strong>' + H.zahl(ad.ist, ad.ist % 1 ? 1 : 0) + ' von ' + ad.soll + ' Std.</strong>' + (ad.gemeldet ? ' · ' + H.zahl(ad.gemeldet, 1) + ' Std. gemeldet, noch nicht bestätigt' : '') + (ad.fehl > 0 && ad.erfasst ? ' · <span class="tag warn">fehlen ' + H.zahl(ad.fehl, 1) + '</span>' : '') + '</p>') : '<p class="leer" style="margin:0">nicht arbeitspflichtig (' + (H.ART[m.art] || m.art) + ')</p>') +
          (gruppen.length ? '<p style="margin:8px 0 0">' + gruppen.map(({ z, b }) => '<span class="tag' + (z.rolle === 'leitung' ? ' ok' : '') + '">' + esc(b.name) + (z.rolle === 'leitung' ? ' · Leitung' : '') + '</span>').join(' ') + '</p>' : '') +
          (stunden.length ? '<table class="tab kompakt"><tbody>' + stunden.slice().sort((a, b) => (b.datum || '').localeCompare(a.datum || '')).slice(0, 4).map((a) => '<tr><td class="nw">' + (a.datum ? H.datum(a.datum) : '') + '</td><td>' + esc(a.taetigkeit || a.notiz || '') + '</td><td class="r">' + H.zahl(a.stunden, a.stunden % 1 ? 1 : 0) + ' Std.</td></tr>').join('') + '</tbody></table>' : '') + '</section>' +
        '<section class="akte-teil" id="ak-schild"><h3>Grünes Schild</h3>' + (schilder.length ? '<table class="tab kompakt"><tbody>' + schilder.slice(0, 4).map((a) => '<tr><td class="nw">' + H.datum(a.von) + ' – ' + H.datum(a.bis) + '</td><td>' + esc(a.platz_id ? platzName(a.platz_id) : '') + '</td><td>' + (a.von <= heute ? '<span class="tag gruen">jetzt frei</span>' : '<span class="tag">geplant</span>') + '</td></tr>').join('') + '</tbody></table>'
          : '<p class="leer" style="margin:0">Kein grünes Schild gemeldet.</p>') + '</section>' +
        '<section class="akte-teil" id="ak-veranst"><h3>Veranstaltungen</h3>' + (zus.length ? '<table class="tab kompakt"><tbody>' + zus.slice(0, 5).map(({ z, v }) => '<tr><td class="nw">' + H.datum(v.datum) + '</td><td>' + esc(v.titel) + '</td><td>' + (z.antwort === 'ja' ? '<span class="tag ok">zugesagt' + (z.personen > 1 ? ' · ' + z.personen + ' Pers.' : '') + '</span>' : '<span class="tag">abgesagt</span>') + '</td></tr>').join('') + '</tbody></table>'
          : '<p class="leer" style="margin:0">Noch keine Zu- oder Absagen.</p>') + '</section>' +
        (geld ? '<section class="akte-teil akte-breit" id="ak-rechnungen"><h3>Rechnungen' + (offenSum > 0 ? ' · <span class="tag warn">offen ' + H.geld(offenSum) + '</span>' : '') + '</h3>' +
          (re.length ? '<table class="tab kompakt"><tbody>' + re.slice(0, 8).map((r) => { const st = Q.rstatus(r, heute); return '<tr' + (r.storniert_am ? ' class="blass"' : '') + '><td class="nw">' + esc(r.nr) + '</td><td>' + H.periodeText(r) + '</td><td class="r">' + H.geld(r.summe) + '</td><td>' + kette(r) + '<span class="tag ' + STUFE[stufe(r)][1] + '">' + (['ueberfaellig', 'teilbezahlt', 'ruecklastschrift'].includes(st) ? RSTATUS[st][0] : STUFE[stufe(r)][0]) + '</span></td><td class="r"><button class="btn klein" data-akte-re="' + r.id + '" aria-label="Rechnung ' + esc(r.nr) + ' ansehen">Rechnung ansehen</button></td></tr>'; }).join('') + '</tbody></table>' + (re.length > 8 ? '<p class="hinweis" style="margin:6px 0 0">… ' + (re.length - 8) + ' ältere unter Finanzen.</p>' : '') : '<p class="leer" style="margin:0">Noch keine Hafen- oder Beitragsrechnung.</p>') +
          '<div id="akte-getraenke"></div></section>' : '') +
        '<section class="akte-teil akte-breit" id="ak-dok"><h3>Dokumente und Verträge</h3><div id="m-dok"></div></section>' +
        (verlaufErlaubt() ? '<details class="akte-teil akte-breit akte-verlauf" id="ak-verlauf"><summary><h3>Änderungsverlauf</h3><span class="hinweis-klein">Mitglied, Bankdaten, Boote, Plätze, Rechnungen, Stunden</span></summary><div id="akte-vl"><p class="leer">Wird geladen …</p></div></details>' : '') +
      '</div><div class="modal-fuss"><button class="btn" data-zu>Schließen</button></div>', true);
    el.querySelector('.modal-karte').classList.add('akte');
    $('#akte-bearb', el).addEventListener('click', () => mitgliedForm(m));
    el.addEventListener('click', (e) => { const a = e.target.closest('[data-sprung]'); if (!a) return; e.preventDefault();
      const z = el.querySelector('#' + a.dataset.sprung); if (!z) return; if (z.tagName === 'DETAILS' && !z.open) z.open = true;
      z.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' }); });
    el.querySelectorAll('[data-akte-re]').forEach((b) => b.addEventListener('click', () => oeffnen('drucken.html?art=rechnungen&ids=' + b.dataset.akteRe)));
    dokumenteBereich($('#m-dok', el), { mitglied_id: m.id });
    const vl = el.querySelector('.akte-verlauf'); if (vl) vl.addEventListener('toggle', () => { if (!vl.open || vl.dataset.geladen) return; vl.dataset.geladen = '1';
      const ids = [m.id].concat(bootIds, bel.map((x) => x.id), re.map((r) => r.id), stunden.map((a) => a.id), wl.map((w) => w.id), gruppen.map(({ z }) => z.id), d.abwesenheiten.filter((a) => bootIds.includes(a.boot_id)).map((a) => a.id));
      HF.verlauf({ datensaetze: ids, limit: 200 }).then((l) => { $('#akte-vl', el).innerHTML = verlaufTabelle(l); }).catch((e) => { $('#akte-vl', el).innerHTML = '<p class="hinweis warn">' + esc(e.message) + '</p>'; });
    });
    const kasse = KASSE(); const kg = $('#akte-getraenke', el);
    // Getränke-Code: gesetzt oder nicht (der Code selbst ist nie sichtbar)
    if (kasse && kasse.mitglieder && $('#akte-code', el)) kasse.mitglieder().then((ml) => { const km = (ml || []).find((x) => x.id === m.id); const c = $('#akte-code', el); if (!c || !km) return;
      c.outerHTML = merkmal(km.hat_pin, km.hat_pin ? 'Getränke-Code festgelegt' : 'Getränke-Code fehlt'); }).catch(() => {});
    if (kg && kasse) Promise.all([kasse.rechnungen(), kasse.buchungen({ mitglied_id: m.id })]).then(([kr, kb]) => {
      const l = (kr || []).filter((r) => r.mitglied_id === m.id && !r.storniert_am).slice(0, 4); const frei = (kb || []).filter((b) => !b.rechnung_id && !b.storniert_am);
      const kk = $('#akte-getr-kachel', el); const fs = frei.reduce((s, b) => s + Number(b.betrag), 0) + l.filter((r) => !r.bezahlt_am).reduce((s, r) => s + Number(r.summe), 0);
      if (kk) kk.outerHTML = kachel(H.geld(fs), 'Getränke offen', 'ak-rechnungen', fs > 0 ? 'warn' : 'ok');
      kg.innerHTML = '<h4 style="margin:12px 0 4px">Getränkekasse</h4>' + (l.length ? '<table class="tab kompakt"><tbody>' + l.map((r) => '<tr><td class="nw">' + esc(r.nr) + '</td><td>' + H.datum(r.von) + ' – ' + H.datum(r.bis) + '</td><td class="r">' + H.geld(r.summe) + '</td><td>' + (r.bezahlt_am ? '<span class="tag ok">bezahlt</span>' : '<span class="tag warn">offen</span>') + '</td></tr>').join('') + '</tbody></table>' : '') +
        '<p class="hinweis" style="margin:6px 0 0">' + (frei.length ? frei.length + (frei.length === 1 ? ' Buchung (' : ' Buchungen (') + H.geld(frei.reduce((s, b) => s + Number(b.betrag), 0)) + ') noch nicht abgerechnet.' : 'Keine offenen Buchungen.') + '</p>';
    }).catch(() => { kg.innerHTML = ''; });
  }
  function mitgliedForm(m) {
    const neu = !m.id; const bank = bankSichtbar();
    const el = modal('<h2>' + (neu ? 'Neue Person' : esc(Q.name(m))) + '</h2><form id="f" class="form">' +
      '<label class="feld">Vorname<input name="vorname" required value="' + esc(m.vorname || '') + '"></label><label class="feld">Nachname<input name="nachname" required value="' + esc(m.nachname || '') + '"></label>' +
      '<label class="feld">Mitglieds-/Kundennr.<input name="nr" value="' + esc(m.nr || '') + '"></label>' +
      '<label class="feld">Art<select name="art">' + Object.entries(H.ART).map(([k, v]) => '<option value="' + k + '"' + (m.art === k ? ' selected' : '') + '>' + v + '</option>').join('') + '</select><small>bestimmt Beitrag und Liegeplatzgebühr</small></label>' +
      '<label class="feld">Geburtsdatum<input name="geburtsdatum" type="date" value="' + esc(m.geburtsdatum || '') + '"></label><label class="feld">Geschlecht<select name="geschlecht"><option value="">–</option>' +
      Object.entries(H.GESCHLECHT).map(([k, v]) => '<option value="' + k + '"' + (m.geschlecht === k ? ' selected' : '') + '>' + v + '</option>').join('') + '</select><small>für die Verbandsmeldung</small></label>' +
      '<label class="feld">Eintritt<input name="eintritt" type="date" value="' + esc(m.eintritt || '') + '"></label><label class="feld">Austritt zum<input name="austritt" type="date" value="' + esc(m.austritt || '') + '"><small>leer = Mitglied</small></label>' +
      '<label class="feld">E-Mail<input name="email" type="email" value="' + esc(m.email || '') + '"></label><label class="feld">Telefon<input name="tel" value="' + esc(m.tel || '') + '"></label>' +
      '<label class="feld voll">Straße<input name="strasse" value="' + esc(m.strasse || '') + '"></label><label class="feld">PLZ<input name="plz" value="' + esc(m.plz || '') + '"></label><label class="feld">Ort<input name="ort" value="' + esc(m.ort || '') + '"></label>' +
      '<label class="feld">Kfz-Kennzeichen<input name="kfz" value="' + esc(m.kfz || '') + '"><small>laut Hafenbetriebsordnung empfohlen</small></label>' +
      '<label class="feld">Arbeitsdienst befreit<input name="arbeitsdienst_befreit" value="' + esc(m.arbeitsdienst_befreit || '') + '" placeholder="Grund, z. B. Vorstandsamt"><small>leer = nicht befreit</small></label>' +
      (bank ? '<label class="feld voll">IBAN<input name="iban" value="' + esc(m.iban || '') + '" placeholder="DE…"></label><label class="feld">BIC (optional)<input name="bic" value="' + esc(m.bic || '') + '"></label><label class="feld">Kontoinhaber<input name="kontoinhaber" value="' + esc(m.kontoinhaber || '') + '"></label>' +
        '<label class="feld">Mandatsreferenz<input name="mandat_ref" value="' + esc(m.mandat_ref || '') + '"></label><label class="feld">Mandat unterschrieben am<input name="mandat_datum" type="date" value="' + esc(m.mandat_datum || '') + '"></label>' : '<p class="hinweis voll">Bankdaten: ' + (m.iban ? iban(m.iban) : 'keine') + ' – nur Kassenwart und Vorstand können sie ändern.</p>') +
      '</form><div class="modal-fuss">' + (neu ? '<button class="btn" data-zu>Abbrechen</button>' : '<button class="btn" id="m-zurueck">Zurück zur Akte</button>') + '<button class="btn primaer" id="ok">Speichern</button></div>');
    const mz = $('#m-zurueck', el); if (mz) mz.addEventListener('click', () => mitgliedAkte(m));
    $('#ok', el).addEventListener('click', () => {
      const f = $('#f', el); if (!f.reportValidity()) return;
      const x = Object.fromEntries(new FormData(f));
      if (bank && x.iban && !SEPA.ibanGueltig(x.iban)) return toast('Die IBAN ist ungültig (Prüfziffer stimmt nicht).', 'fehler');
      if (bank && x.iban) x.iban = x.iban.replace(/\s/g, '').toUpperCase();
      if (neu) d.mitglieder.push({ id: H.uid('M'), notiz: '', ...x, nr: x.nr || Q.naechsteNr() }); else Object.assign(m, x);
      speichern('Gespeichert.'); zeige(tab, true); if (neu) zu(); else mitgliedAkte(m);
    });
  }

  // Dokumente beim Mitglied (Liegeplatzvertrag, Mandat, Schriftverkehr …) – sieht auch das Mitglied in „Mein SSV“
  function dokumenteBereich(box, bezug) {
    const ART = { vertrag: 'Vertrag', versicherung: 'Versicherung', foto: 'Foto', sonstiges: 'Sonstiges' };
    const liste = () => HF.dok.liste(bezug).then((l) => {
      box.innerHTML = (l.length ? '<table class="tab"><tbody>' + l.map((x) => '<tr><td><span class="tag">' + (ART[x.art] || x.art) + '</span> ' + esc(x.name) + '<br><small style="color:var(--muted)">' + H.datum(x.hochgeladen) + ' · ' + esc(x.von || '') + '</small></td><td class="r nw"><button class="btn klein" type="button" data-dok="' + x.id + '">Ansehen</button> <button class="btn klein gefahr" type="button" data-dok-weg="' + x.id + '">Löschen</button></td></tr>').join('') + '</tbody></table>' : '<p class="leer">Noch keine Dokumente.</p>') +
        '<div class="aktionen" style="margin-top:8px"><select class="suche" id="dok-art" style="min-width:0"><option value="vertrag">Vertrag</option><option value="sonstiges">Sonstiges</option></select><label class="btn">Dokument hochladen<input type="file" id="dok-datei" accept="application/pdf,image/*" hidden></label></div>';
      box.querySelector('#dok-datei').addEventListener('change', async (e) => {
        try { const x = await HF.datei.lesen(e.target.files[0]); await HF.dok.hochladen({ ...x, ...bezug, art: box.querySelector('#dok-art').value }, ROLLEN[rolle].name); toast('Dokument gespeichert.'); liste(); }
        catch (er) { toast(er.message, 'fehler'); }
      });
    }).catch((e) => { box.innerHTML = '<p class="hinweis warn">' + esc(e.message) + '</p>'; });
    box.addEventListener('click', (e) => {
      const a = e.target.closest('[data-dok]'); if (a) return HF.datei.oeffnen(a.dataset.dok).catch((x) => toast(x.message, 'fehler'));
      const w = e.target.closest('[data-dok-weg]'); if (w && confirm('Dokument löschen?')) HF.dok.loeschen(w.dataset.dokWeg).then(liste, (x) => toast(x.message, 'fehler'));
    });
    liste();
  }

  /* ============================================================ Mitglieder-Import (CSV) */
  // Spaltennamen, wie sie in Exporten (easyVerein, Excel-Listen) typischerweise heißen
  const IMPORT_SPALTEN = {
    nr: ['mitgliedsnummer', 'mitgliedsnr', 'mitgliedsnr.', 'mitglieds-nr', 'mitglieds-nr.', 'mitglieds nr', 'mitgliedernummer', 'mitglied nr', 'nr', 'nr.', 'nummer'],
    vorname: ['vorname', 'first name', 'firstname'],
    nachname: ['nachname', 'familienname', 'last name', 'lastname', 'name'],
    email: ['e-mail', 'email', 'e-mail-adresse', 'emailadresse', 'e-mail privat', 'mail'],
    tel: ['telefon', 'telefonnummer', 'mobil', 'mobilnummer', 'handy', 'telefon privat', 'tel', 'tel.'],
    strasse: ['straße', 'strasse', 'straße und hausnummer', 'strasse und hausnummer', 'anschrift', 'adresse', 'str.'],
    plz: ['plz', 'postleitzahl'],
    ort: ['ort', 'wohnort', 'stadt'],
    geburtsdatum: ['geburtsdatum', 'geburtstag', 'geboren', 'geboren am', 'geb.-datum', 'geb.datum', 'geb.'],
    geschlecht: ['geschlecht', 'anrede'],
    art: ['mitgliedsart', 'beitragsgruppe', 'beitragsart', 'mitgliedschaft', 'mitgliedsstatus', 'art', 'status'],
    eintritt: ['eintritt', 'eintrittsdatum', 'beitritt', 'beitrittsdatum', 'mitglied seit'],
    austritt: ['austritt', 'austrittsdatum'],
    iban: ['iban'],
    bic: ['bic', 'swift', 'bic/swift'],
    kontoinhaber: ['kontoinhaber', 'kontoinhaber/in', 'inhaber', 'name des kontoinhabers'],
    mandat_ref: ['mandatsreferenz', 'sepa-mandatsreferenz', 'mandatsref', 'mandatsref.', 'mandat'],
    mandat_datum: ['mandatsdatum', 'datum der mandatserteilung', 'mandatserteilung', 'mandat vom', 'datum mandat', 'unterschrift mandat', 'mandat erteilt am'],
    kfz: ['kfz', 'kfz-kennzeichen', 'kennzeichen']
  };
  const IMPORT_LABEL = { nr: 'Mitgliedsnr.', vorname: 'Vorname', nachname: 'Nachname', email: 'E-Mail', tel: 'Telefon', strasse: 'Straße', plz: 'PLZ', ort: 'Ort', geburtsdatum: 'Geburtsdatum',
    geschlecht: 'Geschlecht', art: 'Mitgliedsart', eintritt: 'Eintritt', austritt: 'Austritt', iban: 'IBAN', bic: 'BIC', kontoinhaber: 'Kontoinhaber', mandat_ref: 'Mandatsreferenz', mandat_datum: 'Mandatsdatum', kfz: 'Kfz' };

  function csvLesen(text) {
    text = text.replace(/^﻿/, '');
    const erste = text.split(/\r?\n/)[0] || '';
    const trenner = [';', '\t', ','].map((t) => [t, erste.split(t).length]).sort((a, b) => b[1] - a[1])[0][0];
    const zeilen = []; let zeile = [], feld = '', inQ = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (inQ) { if (c === '"') { if (text[i + 1] === '"') { feld += '"'; i++; } else inQ = false; } else feld += c; continue; }
      if (c === '"') inQ = true;
      else if (c === trenner) { zeile.push(feld); feld = ''; }
      else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; zeile.push(feld); feld = ''; if (zeile.some((x) => x.trim())) zeilen.push(zeile); zeile = []; }
      else feld += c;
    }
    zeile.push(feld); if (zeile.some((x) => x.trim())) zeilen.push(zeile);
    return zeilen;
  }
  function spaltenZuordnen(kopfzeile) {
    const norm = kopfzeile.map((k) => k.trim().toLowerCase().replace(/\s+/g, ' '));
    const zu = {}; const belegt = new Set();
    Object.entries(IMPORT_SPALTEN).forEach(([feld, aliase]) => {           // 1. exakte Treffer
      for (const a of aliase) { const i = norm.findIndex((k, j) => k === a && !belegt.has(j)); if (i >= 0) { zu[feld] = i; belegt.add(i); break; } }
    });
    Object.entries(IMPORT_SPALTEN).forEach(([feld, aliase]) => {           // 2. „beginnt mit“ für längere Namen
      if (feld in zu) return;
      for (const a of aliase.filter((x) => x.length >= 5)) { const i = norm.findIndex((k, j) => k.startsWith(a) && !belegt.has(j)); if (i >= 0) { zu[feld] = i; belegt.add(i); break; } }
    });
    return { zu, unbekannt: kopfzeile.filter((k, i) => !belegt.has(i) && k.trim()) };
  }
  const datumIso = (v) => {
    v = String(v || '').trim(); let m;
    if ((m = v.match(/^(\d{4})-(\d{2})-(\d{2})/))) return m[1] + '-' + m[2] + '-' + m[3];
    if ((m = v.match(/^(\d{1,2})\.(\d{1,2})\.(\d{2}|\d{4})$/))) { let j = Number(m[3]); if (j < 100) j += j > 30 ? 1900 : 2000; return j + '-' + H.pad(m[2]) + '-' + H.pad(m[1]); }
    return '';
  };
  const geschlechtWert = (v) => { v = String(v || '').trim().toLowerCase(); if (/^(w|weiblich|frau|f|female)/.test(v)) return 'w'; if (/^(m|männlich|maennlich|herr|male)/.test(v)) return 'm'; if (/^d/.test(v)) return 'd'; return ''; };
  const artWert = (v) => {
    v = String(v || '').toLowerCase(); if (!v.trim()) return '';
    if (/förder|foerder|passiv/.test(v)) return 'foerdernd'; if (/probe/.test(v)) return 'probe'; if (/geschwister/.test(v)) return 'jugend_geschwister';
    if (/ausbild|azubi|student|schüler über|studier/.test(v)) return 'ausbildung'; if (/jugend|kind|junior/.test(v)) return 'jugend';
    if (/partner|ehe/.test(v)) return 'partner'; if (/gast/.test(v)) return 'gast'; return 'ausuebend';
  };

  function importAuswerten(text) {
    const zeilen = csvLesen(text); if (zeilen.length < 2) return { fehler: 'Keine Daten gefunden – erste Zeile muss die Spaltennamen enthalten.' };
    const { zu, unbekannt } = spaltenZuordnen(zeilen[0]);
    if (!('vorname' in zu) || !('nachname' in zu)) return { fehler: 'Spalten „Vorname“ und „Nachname“ nicht gefunden. Erkannt: ' + (Object.keys(zu).map((k) => IMPORT_LABEL[k]).join(', ') || 'nichts') };
    const zeilenNeu = zeilen.slice(1).map((z, i) => {
      const x = {}; Object.entries(zu).forEach(([f, j]) => { x[f] = String(z[j] == null ? '' : z[j]).trim(); });
      ['geburtsdatum', 'eintritt', 'austritt', 'mandat_datum'].forEach((f) => { if (f in x) x[f] = datumIso(x[f]); });
      if ('geschlecht' in x) x.geschlecht = geschlechtWert(x.geschlecht);
      if ('art' in x) x.art = artWert(x.art);
      if (x.iban) x.iban = x.iban.replace(/\s/g, '').toUpperCase();
      const hinweise = [];
      if (x.iban && !SEPA.ibanGueltig(x.iban)) { hinweise.push('IBAN ungültig – wird nicht übernommen'); delete x.iban; }
      if (x.mandat_ref && !x.mandat_datum) hinweise.push('Mandatsdatum fehlt – bis dahin kein Lastschrifteinzug');
      const gleich = (a, b) => String(a || '').toLowerCase() === String(b || '').toLowerCase();
      const vorh = (x.nr && d.mitglieder.find((m) => m.nr === x.nr)) ||
        (x.vorname && x.nachname && d.mitglieder.find((m) => gleich(m.vorname, x.vorname) && gleich(m.nachname, x.nachname) && (!x.geburtsdatum || !m.geburtsdatum || m.geburtsdatum === x.geburtsdatum)));
      if (!vorh && (!x.vorname || !x.nachname)) return { zeile: i + 2, x, status: 'fehler', hinweise: ['Vor- oder Nachname fehlt'] };
      if (vorh) { x.vorname = x.vorname || vorh.vorname; x.nachname = x.nachname || vorh.nachname; }
      return { zeile: i + 2, x, status: vorh ? 'aktualisieren' : 'neu', m: vorh, hinweise };
    });
    return { zu, unbekannt, zeilen: zeilenNeu };
  }

  function importDialog() {
    const el = modal('<h2>Mitglieder importieren</h2><p>CSV-Datei mit Spaltennamen in der ersten Zeile – z. B. der Mitglieder-Export aus easyVerein oder eine Excel-Liste (in Excel: <em>Speichern unter → CSV UTF-8</em>). ' +
      'Erkannt werden u. a. Mitgliedsnummer, Vorname, Nachname, Anschrift, Geburtsdatum, Geschlecht, Mitgliedsart, Eintritt, IBAN, BIC, Kontoinhaber, Mandatsreferenz und Mandatsdatum.</p>' +
      '<div class="aktionen"><label class="btn primaer">Datei wählen<input type="file" id="idatei" accept=".csv,.txt,text/csv" hidden></label><button class="btn" id="ivorlage">Vorlage herunterladen</button></div>' +
      '<details style="margin-top:10px"><summary style="cursor:pointer;color:var(--muted)">… oder Text einfügen</summary><textarea id="itext" rows="6" style="width:100%;margin-top:8px;font:12px monospace" placeholder="Mitgliedsnummer;Vorname;Nachname;…"></textarea><button class="btn klein" id="ipruefen" style="margin-top:6px">Prüfen</button></details>' +
      '<div id="ierg"></div><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="iok" disabled>Übernehmen</button></div>', true);
    let ergebnis = null;
    const zeigeErgebnis = (text) => {
      ergebnis = importAuswerten(text);
      const box = $('#ierg', el);
      if (ergebnis.fehler) { box.innerHTML = '<p class="hinweis warn">' + esc(ergebnis.fehler) + '</p>'; $('#iok', el).disabled = true; return; }
      const z = ergebnis.zeilen; const n = (st) => z.filter((r) => r.status === st).length;
      box.innerHTML = '<p style="margin-top:14px"><span class="tag ok">' + n('neu') + ' neu</span> <span class="tag">' + n('aktualisieren') + ' aktualisieren</span> ' + (n('fehler') ? '<span class="tag rot">' + n('fehler') + ' fehlerhaft (werden übersprungen)</span>' : '') + '</p>' +
        '<p style="font-size:12.5px;color:var(--muted)">Erkannte Spalten: ' + Object.keys(ergebnis.zu).map((k) => IMPORT_LABEL[k]).join(', ') + (ergebnis.unbekannt.length ? ' · ignoriert: ' + ergebnis.unbekannt.map(esc).join(', ') : '') + '</p>' +
        '<div style="max-height:320px;overflow:auto"><table class="tab"><thead><tr><th>Zeile</th><th>Nr.</th><th>Name</th><th>Art</th><th>Status</th><th>Hinweis</th></tr></thead><tbody>' +
        z.slice(0, 300).map((r) => '<tr' + (r.status === 'fehler' ? ' class="blass"' : '') + '><td>' + r.zeile + '</td><td>' + esc(r.x.nr || (r.m ? r.m.nr : '')) + '</td><td>' + esc((r.x.nachname || '') + ', ' + (r.x.vorname || '')) + '</td><td>' + (r.x.art ? H.ART[r.x.art] : (r.m ? H.ART[r.m.art] : 'ausübend')) + '</td>' +
          '<td>' + (r.status === 'neu' ? '<span class="tag ok">neu</span>' : r.status === 'aktualisieren' ? '<span class="tag">aktualisieren</span>' : '<span class="tag rot">Fehler</span>') + '</td><td style="font-size:12px">' + r.hinweise.map(esc).join('<br>') + '</td></tr>').join('') +
        '</tbody></table></div><p class="hinweis" style="margin-top:10px">Bestehende Mitglieder werden über die Mitgliedsnummer (sonst Name + Geburtsdatum) erkannt. Leere Zellen überschreiben nichts. Die Getränkekasse übernimmt neue Mitglieder automatisch.</p>';
      $('#iok', el).disabled = !(n('neu') + n('aktualisieren'));
    };
    $('#idatei', el).addEventListener('change', (e) => {
      const f = e.target.files[0]; if (!f) return;
      const lesen = (enc) => new Promise((ok) => { const r = new FileReader(); r.onload = () => ok(r.result); r.readAsText(f, enc); });
      lesen('utf-8').then((t) => (t.includes('�') ? lesen('windows-1252') : t)).then(zeigeErgebnis);   // ältere Excel-Exporte sind Windows-kodiert
    });
    $('#ipruefen', el).addEventListener('click', () => zeigeErgebnis($('#itext', el).value));
    $('#ivorlage', el).addEventListener('click', () => download('ssv-mitglieder-vorlage.csv', csv([['Mitgliedsnummer', 'Vorname', 'Nachname', 'Geburtsdatum', 'Geschlecht', 'Mitgliedsart', 'Eintritt', 'Straße', 'PLZ', 'Ort', 'E-Mail', 'Telefon', 'IBAN', 'BIC', 'Kontoinhaber', 'Mandatsreferenz', 'Mandatsdatum'],
      ['2101', 'Erika', 'Musterfrau', '14.03.1975', 'weiblich', 'ausübend', '01.04.2010', 'Hafenstraße 1', '23554', 'Lübeck', 'erika@beispiel.de', '0451 123456', 'DE02120300000000202051', '', 'Erika Musterfrau', 'SSV-2101', '01.04.2010']]), 'text/csv'));
    $('#iok', el).addEventListener('click', () => {
      if (!ergebnis || ergebnis.fehler) return;
      let neu = 0, akt = 0;
      ergebnis.zeilen.forEach((r) => {
        if (r.status === 'fehler') return;
        const werte = {}; Object.entries(r.x).forEach(([k, v]) => { if (v !== '' && v != null) werte[k] = v; });
        if (r.status === 'aktualisieren') { Object.assign(r.m, werte); akt++; return; }
        d.mitglieder.push({ id: H.uid('M'), art: 'ausuebend', email: '', tel: '', strasse: '', plz: '', ort: '', iban: '', bic: '', kontoinhaber: '', mandat_ref: '', mandat_datum: '', kfz: '', notiz: 'Import ' + H.datum(heute), austritt: '',
          ...werte, nr: werte.nr || Q.naechsteNr(), kontoinhaber: werte.kontoinhaber || (werte.iban ? werte.vorname + ' ' + werte.nachname : '') });
        neu++;
      });
      speichern(neu + ' Mitglieder angelegt, ' + akt + ' aktualisiert.'); zu(); zeige('eigner');
    });
  }

  /* ============================================================ Aufnahmeanträge */
  const beitragFuer = (art, jahr) => { const gb = G.gebuehrenFuer(d, jahr); const b = (gb.beitraege || HF.GEBUEHREN_2024.beitraege)[art]; if (!b) return 0; return Math.round((b.verein + b.verband + (art === 'probe' ? (gb.eintrittsgeld_probe || 0) : 0)) * 100) / 100; };
  V.antraege = (main) => {
    const alle = (d.antraege || []).slice().sort((a, b) => b.eingang.localeCompare(a.eingang));
    const neu = alle.filter((a) => a.status === 'neu'), erledigt = alle.filter((a) => a.status !== 'neu');
    const jahr = Number(heute.slice(0, 4));
    main.innerHTML = kopf('Aufnahmeanträge', 'Online gestellte Anträge – der Vorstand entscheidet auf Empfehlung des Aufnahmeausschusses (Satzung § 6). Danach ist das Mitglied mit Nummer und Lastschriftmandat angelegt.', '<a class="btn" href="aufnahme.html" target="_blank">Antragsformular öffnen ↗</a>') +
      (neu.length ? neu.map((a) => '<div class="panel"><div class="kopf" style="margin-bottom:6px"><div><h2 style="margin:0">' + esc(a.vorname + ' ' + a.nachname) + '</h2><p>' + esc(H.ART[a.art] || a.art) + ' · ' +
        (a.geburtsdatum ? Q.alterAm(a, heute) + ' Jahre · ' : '') + esc(a.plz + ' ' + a.ort) + ' · eingegangen ' + H.datum(a.eingang) + '</p></div><div class="aktionen"><button class="btn" data-ansehen="' + a.id + '">Ansehen</button>' +
        (darf('antraege') && rolle === 'vorstand' ? '<button class="btn gefahr" data-ab="' + a.id + '">Ablehnen</button><button class="btn primaer" data-auf="' + a.id + '">Aufnehmen</button>' : '') + '</div></div>' +
        '<p style="margin:0;color:var(--muted);font-size:13.5px">Beitrag ' + jahr + ': <strong>' + H.geld(beitragFuer(a.art, jahr)) + '</strong> pro Jahr · ' + (a.mandat ? 'SEPA-Mandat erteilt' : 'kein Mandat (Überweisung)') +
        (a.boot ? ' · Boot „' + esc(a.boot.name) + '“ (' + esc(a.boot.typ || '') + ', ' + H.zahl(a.boot.laenge) + ' m)' + (a.warteliste ? ' – möchte auf die Warteliste' : '') : '') +
        (a.erziehungsberechtigt ? ' · erziehungsberechtigt: ' + esc(a.erziehungsberechtigt) : '') + '</p>' + (a.nachricht ? '<p style="margin:8px 0 0">„' + esc(a.nachricht) + '“</p>' : '') + '</div>').join('')
        : '<div class="panel"><p class="leer">Keine offenen Anträge.</p></div>') +
      (rolle !== 'vorstand' && neu.length ? '<p class="hinweis">Über Aufnahmen entscheidet der Vorstand.</p>' : '') +
      (erledigt.length ? '<div class="panel"><h2>Erledigt</h2><table class="tab"><thead><tr><th>Eingang</th><th>Name</th><th>Art</th><th>Entscheidung</th></tr></thead><tbody>' + erledigt.map((a) =>
        '<tr><td>' + H.datum(a.eingang) + '</td><td>' + esc(a.vorname + ' ' + a.nachname) + '</td><td>' + esc(H.ART[a.art] || a.art) + '</td><td>' + (a.status === 'angenommen' ? '<span class="tag ok">aufgenommen</span> Nr. ' + esc((Q.mitglied(a.mitglied_id) || {}).nr || '') : '<span class="tag rot">abgelehnt</span> ' + esc(a.grund || '')) +
        ' <small style="color:var(--muted)">' + H.datum(a.entschieden) + '</small></td></tr>').join('') + '</tbody></table></div>' : '');
    main.querySelectorAll('[data-ansehen]').forEach((b) => b.addEventListener('click', () => antragZeigen(d.antraege.find((a) => a.id === b.dataset.ansehen))));
    main.querySelectorAll('[data-auf]').forEach((b) => b.addEventListener('click', () => antragAufnehmen(d.antraege.find((a) => a.id === b.dataset.auf))));
    main.querySelectorAll('[data-ab]').forEach((b) => b.addEventListener('click', () => {
      const a = d.antraege.find((x) => x.id === b.dataset.ab); const grund = prompt('Antrag von ' + a.vorname + ' ' + a.nachname + ' ablehnen – Grund (für die Akte):', ''); if (grund === null) return;
      Object.assign(a, { status: 'abgelehnt', grund, entschieden: heute, entschieden_von: ROLLEN[rolle].name }); speichern('Antrag abgelehnt.'); zeige('antraege');
    }));
  };
  function antragZeigen(a) {
    const z = (l, v) => v ? '<dt>' + l + '</dt><dd>' + v + '</dd>' : '';
    modal('<h2>Antrag ' + esc(a.vorname + ' ' + a.nachname) + '</h2><div class="detail" style="box-shadow:none;padding:0;position:static"><dl>' +
      z('Mitgliedsart', esc(H.ART[a.art] || a.art)) + z('Geburtsdatum', H.datum(a.geburtsdatum)) + z('Geschlecht', H.GESCHLECHT[a.geschlecht] || '') + z('Anschrift', esc(a.strasse) + ', ' + esc(a.plz + ' ' + a.ort)) +
      z('E-Mail', esc(a.email)) + z('Telefon', esc(a.tel)) + z('Erziehungsberechtigt', esc(a.erziehungsberechtigt)) +
      z('Boot', a.boot ? '„' + esc(a.boot.name) + '“ · ' + esc(a.boot.typ || '') + ' · ' + H.zahl(a.boot.laenge) + ' × ' + H.zahl(a.boot.breite || 0) + ' m' + (a.warteliste ? ' · Warteliste gewünscht' : '') : '') +
      z('Kontoinhaber', esc(a.kontoinhaber)) + z('IBAN', iban(a.iban)) + z('SEPA-Mandat', a.mandat ? 'erteilt am ' + H.datum(a.eingang) : 'nein') +
      z('Satzung / Datenschutz', (a.satzung ? 'Satzung anerkannt' : '–') + ' · ' + (a.datenschutz ? 'Datenschutz bestätigt' : '–')) + z('Nachricht', esc(a.nachricht)) +
      '</dl></div><div class="modal-fuss"><button class="btn" data-zu>Schließen</button></div>');
  }
  function antragAufnehmen(a) {
    const nr = Q.naechsteNr();
    if (!confirm(a.vorname + ' ' + a.nachname + ' als ' + H.ART[a.art] + ' aufnehmen? Mitgliedsnummer ' + nr + (a.mandat ? ', Mandatsreferenz SSV-' + nr : '') + (a.boot && a.warteliste ? ', Eintrag auf der Warteliste' : '') + '.')) return;
    const m = { id: H.uid('M'), nr, vorname: a.vorname, nachname: a.nachname, art: a.art, email: a.email, tel: a.tel, strasse: a.strasse, plz: a.plz, ort: a.ort,
      geburtsdatum: a.geburtsdatum, geschlecht: a.geschlecht, eintritt: heute, austritt: '', iban: a.iban || '', bic: a.bic || '', kontoinhaber: a.kontoinhaber || '',
      mandat_ref: a.mandat ? 'SSV-' + nr : '', mandat_datum: a.mandat ? a.eingang.slice(0, 10) : '', kfz: '',
      notiz: [a.erziehungsberechtigt ? 'Erziehungsberechtigt: ' + a.erziehungsberechtigt : '', 'Online-Antrag vom ' + H.datum(a.eingang)].filter(Boolean).join(' · ') };
    d.mitglieder.push(m);
    if (a.boot && a.warteliste) {
      const l = Number(a.boot.laenge) || 0;
      d.warteliste.push({ id: H.uid('W'), mitglied_id: m.id, datum: a.eingang.slice(0, 10), boot_laenge: l, boot_breite: Number(a.boot.breite) || 0, wunsch_box: l > 9 ? 'I' : l > 7 ? 'II' : 'III',
        notiz: 'Boot „' + a.boot.name + '“' + (a.boot.typ ? ' (' + a.boot.typ + ')' : '') + ' · aus Online-Antrag', status: 'wartend' });
    }
    Object.assign(a, { status: 'angenommen', mitglied_id: m.id, entschieden: heute, entschieden_von: ROLLEN[rolle].name });
    speichern(m.vorname + ' ist jetzt Mitglied Nr. ' + nr + '.'); zeige('antraege');
    const el = modal('<h2>Willkommen an Bord, ' + esc(m.vorname) + '!</h2><p>Mitglied Nr. <strong>' + nr + '</strong> ist angelegt' + (m.mandat_ref ? ' (Mandatsreferenz ' + esc(m.mandat_ref) + ')' : '') + '. Die erste Beitragsrechnung entsteht mit der nächsten Beitragsabrechnung.</p>' +
      '<p class="hinweis">Tipp: Begrüßungs-E-Mail mit Mitgliedsnummer und dem Hinweis auf „Mein SSV“ und den Getränke-Code verschicken.</p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Schließen</button><a class="btn primaer" id="mail" href="mailto:' + encodeURIComponent(m.email) + '?subject=' + encodeURIComponent('Willkommen im Schwartauer Segler-Verein') + '&body=' +
      encodeURIComponent('Moin ' + m.vorname + ',\n\nschön, dass du dabei bist! Deine Mitgliedsnummer ist ' + nr + '.\n\nDein Zugang „Mein SSV“: ' + new URL('mein-ssv.html', location.href).href + ' – leg dort dein Konto mit genau dieser E-Mail-Adresse an (' + m.email + ').\n\nIn „Mein SSV“ findest du deine Rechnungen und kannst dort deinen Code für die Getränkekasse festlegen – oder du legst ihn beim ersten Mal direkt am iPad im Vereinsheim fest (mit deiner Mitgliedsnummer).\n\nAllzeit gute Fahrt!\nDein Vorstand') + '">Begrüßungs-E-Mail schreiben</a></div>');
    $('#mail', el).addEventListener('click', () => setTimeout(zu, 300));
  }

  /* ============================================================ Verbandsmeldung */
  // Bestandserhebung: Mitglieder zum Stichtag 1.1. nach Altersgruppen und Geschlecht
  const ALTERSGRUPPEN = [['bis 6', 0, 6], ['7–14', 7, 14], ['15–18', 15, 18], ['19–26', 19, 26], ['27–40', 27, 40], ['41–60', 41, 60], ['über 60', 61, 999]];
  const verbandStand = { jahr: SAISON + 1 };
  V.verband = (main) => {
    const jahr = verbandStand.jahr, stichtag = jahr + '-01-01';
    const liste = d.mitglieder.filter((m) => Q.istMitglied(m, stichtag));
    const alterJ = (m) => m.geburtsdatum ? jahr - Number(m.geburtsdatum.slice(0, 4)) : null;   // Jahrgangsprinzip
    const G4 = ['m', 'w', 'd', ''];
    const tabelle = ALTERSGRUPPEN.map(([n, von, bis]) => { const inG = liste.filter((m) => { const a = alterJ(m); return a != null && a >= von && a <= bis; }); return [n, ...G4.map((g) => inG.filter((m) => (m.geschlecht || '') === g).length), inG.length]; });
    const ohneAlter = liste.filter((m) => alterJ(m) == null);
    if (ohneAlter.length) tabelle.push(['ohne Geburtsdatum', ...G4.map((g) => ohneAlter.filter((m) => (m.geschlecht || '') === g).length), ohneAlter.length]);
    const summe = ['Gesamt', ...G4.map((g, i) => tabelle.reduce((s, z) => s + z[i + 1], 0)), liste.length];
    const gb = G.gebuehrenFuer(d, jahr); const B = gb.beitraege || HF.GEBUEHREN_2024.beitraege;
    const nachArt = Object.keys(H.ART).filter((k) => k !== 'gast').map((k) => { const n = liste.filter((m) => m.art === k).length; return [H.ART[k], n, B[k] ? B[k].verband : 0, n * (B[k] ? B[k].verband : 0)]; }).filter((z) => z[1]);
    const luecken = liste.filter((m) => !m.geburtsdatum || !m.geschlecht);
    main.innerHTML = druckKopf() + kopf('Verbandsmeldung ' + jahr, 'Bestandserhebung zum Stichtag ' + H.datum(stichtag) + ' · ' + liste.length + ' Mitglieder (ohne Saison-Gäste)',
      [SAISON, SAISON + 1].map((j) => '<button class="btn' + (j === jahr ? ' aktiv' : '') + '" data-vj="' + j + '">' + j + '</button>').join('') + '<button class="btn" id="vcsv">CSV</button><button class="btn" id="vdruck">Drucken</button>') +
      '<div class="panel"><h2>Nach Alter und Geschlecht</h2><table class="tab"><thead><tr><th>Altersgruppe</th><th class="r">männlich</th><th class="r">weiblich</th><th class="r">divers</th><th class="r">ohne Angabe</th><th class="r">gesamt</th></tr></thead><tbody>' +
      tabelle.map((z) => '<tr><td>' + z[0] + '</td>' + z.slice(1).map((v, i) => '<td class="r">' + (i === 4 ? '<strong>' + v + '</strong>' : v || '–') + '</td>').join('') + '</tr>').join('') +
      '</tbody><tfoot><tr>' + summe.map((v, i) => '<td' + (i ? ' class="r"' : '') + '>' + v + '</td>').join('') + '</tr></tfoot></table>' +
      '<p class="hinweis" style="margin-top:12px">Alter nach Jahrgang (' + jahr + ' minus Geburtsjahr). Altersgruppen wie in der üblichen Bestandserhebung der Landessportverbände. [PLATZHALTER: Gruppen und Meldeweg mit dem Landessportverband Schleswig-Holstein / Segler-Verband abgleichen]</p></div>' +
      '<div class="panel"><h2>Nach Mitgliedsart</h2><table class="tab"><thead><tr><th>Art</th><th class="r">Anzahl</th><th class="r">Verbandsbeitrag je Person</th><th class="r">Verbandsbeitrag gesamt</th></tr></thead><tbody>' +
      nachArt.map((z) => '<tr><td>' + z[0] + '</td><td class="r">' + z[1] + '</td><td class="r">' + H.geld(z[2]) + '</td><td class="r">' + H.geld(z[3]) + '</td></tr>').join('') +
      '</tbody><tfoot><tr><td>Summe</td><td class="r">' + liste.length + '</td><td></td><td class="r">' + H.geld(nachArt.reduce((s, z) => s + z[3], 0)) + '</td></tr></tfoot></table>' +
      '<p class="hinweis" style="margin-top:12px">Der Verbandsbeitrag wird mit dem Mitgliedsbeitrag eingezogen und an den Verband weitergegeben (Gebührenordnung 2024).</p></div>' +
      (luecken.length ? '<div class="panel"><h2>Fehlende Angaben (' + luecken.length + ')</h2><p class="hinweis warn">Für eine vollständige Meldung bitte Geburtsdatum und Geschlecht ergänzen.</p><table class="tab"><tbody>' +
        luecken.map((m) => '<tr class="klickbar" data-m="' + m.id + '"><td>' + esc(m.nr) + '</td><td>' + esc(Q.name(m)) + '</td><td>' + (!m.geburtsdatum ? '<span class="tag warn">Geburtsdatum</span> ' : '') + (!m.geschlecht ? '<span class="tag warn">Geschlecht</span>' : '') + '</td></tr>').join('') + '</tbody></table></div>' : '');
    main.querySelectorAll('[data-vj]').forEach((b) => b.addEventListener('click', () => { verbandStand.jahr = Number(b.dataset.vj); zeige('verband'); }));
    main.querySelectorAll('[data-m]').forEach((r) => r.addEventListener('click', () => mitgliedAkte(Q.mitglied(r.dataset.m))));
    $('#vdruck').addEventListener('click', () => window.print());
    $('#vcsv').addEventListener('click', () => download('ssv-bestandserhebung-' + jahr + '.csv', csv([['Bestandserhebung ' + jahr + ', Stichtag ' + H.datum(stichtag)], ['Altersgruppe', 'männlich', 'weiblich', 'divers', 'ohne Angabe', 'gesamt']]
      .concat(tabelle, [summe], [[]], [['Mitgliedsart', 'Anzahl', 'Verbandsbeitrag je Person', 'Verbandsbeitrag gesamt']], nachArt.map((z) => [z[0], z[1], H.zahl(z[2]), H.zahl(z[3])]))), 'text/csv'));
  };

  /* ============================================================ Belegung */
  const belegungStand = { periode: imSommer ? 'sommer' : 'winter', such: '', lage: '' };
  // Freie Plätze kurz zusammenfassen: „P34–P36, P41–P48“ bzw. „41, 53, 75“ (aufeinanderfolgende Nummern als Bereich)
  function platzBereiche(l) {
    const teil = (p) => { const k = p.bez ? p.id : String(p.nr); const m = k.match(/^(.*?)(\d+)$/); return { k, pre: m ? m[1] : k, n: m ? Number(m[2]) : null }; };
    const gr = []; l.map(teil).forEach((t) => { const g = gr[gr.length - 1]; if (g && t.n != null && g.b.pre === t.pre && g.b.n + 1 === t.n) g.b = t; else gr.push({ a: t, b: t }); });
    return gr.map((g) => g.a === g.b ? g.a.k : g.a.k + (g.b.n === g.a.n + 1 ? ', ' : '–') + g.b.k).join(', ');
  }
  V.belegung = (main) => {
    const per = belegungStand.periode;
    const plaetze = per === 'sommer' ? d.liegeplaetze.concat(d.landplaetze) : d.landplaetze;
    const ohne = d.boote.filter((b) => !Q.belegungBoot(SAISON, per, b.id));
    // Hallenplätze (H1–H4) stehen nicht im Plan: sind sie alle leer, bleiben sie ausgeblendet, bis man sie einblendet
    const halle = d.landplaetze.filter((p) => p.art === 'halle'); const halleBelegt = halle.some((p) => Q.belegungPlatz(SAISON, per, p.id));
    const halleZeigen = halleBelegt || belegungStand.halle; const halleLeer = !halleBelegt && halle.length ? (halle.length > 1 ? halle[0].id + '–' + halle[halle.length - 1].id : halle[0].id) : '';
    const lageVon = (p) => p.bez ? Q.lage(p) : H.BRUECKE[p.bruecke];
    // Welche Plätze stehen überhaupt in der Liste (Sommer: Lagerplätze nur, wenn dort ein Boot bleibt; leere Halle nur auf Wunsch)
    const zeilen = plaetze.map((p) => { const bel = Q.belegungPlatz(SAISON, per, p.id); return { p, bel }; })
      .filter(({ p, bel }) => !(p.bez && per === 'sommer' && !bel) && !(p.art === 'halle' && !bel && !halleZeigen));
    const lagen = [...new Set(zeilen.map((z) => lageVon(z.p)).filter(Boolean))]; if (!lagen.includes(belegungStand.lage)) belegungStand.lage = '';
    main.innerHTML = kopf('Belegung', (per === 'sommer' ? 'Sommer ' + SAISON + ': Wasserliegeplätze (und Boote, die an Land bleiben)' : 'Winter ' + SAISON + '/' + String(SAISON + 1).slice(2) + ': Lagerplätze an Land (Nordlager, Winterlager West, Außenlager)'),
      '<button class="btn' + (per === 'sommer' ? ' aktiv' : '') + '" data-per="sommer">Sommer</button><button class="btn' + (per === 'winter' ? ' aktiv' : '') + '" data-per="winter">Winter</button>' +
      '<button class="btn" id="bel-druck" title="Winterlager: Liste zum Ein- und Auslagern mit Kran-Häkchen (A4 quer)">Belegungsplan Winter drucken</button>') +
      (ohne.length ? '<div class="hinweis warn">' + ohne.length + (ohne.length === 1 ? ' Boot hat' : ' Boote haben') + ' in dieser Periode noch keinen Platz: ' + ohne.slice(0, 8).map((b) => esc(b.name)).join(', ') + (ohne.length > 8 ? '<span class="ohne-komma">,</span> <details class="ohne-mehr"><summary>+ ' + (ohne.length - 8) + ' weitere anzeigen</summary>' + ohne.slice(8).map((b) => esc(b.name)).join(', ') + '</details>' : '') + '</div>' : '') +
      '<div class="filter"><input class="suche" id="bel-such" placeholder="Platz, Boot oder Eigner …" value="' + esc(belegungStand.such) + '" aria-label="Suchen: Platz, Boot oder Eigner">' +
        '<select class="suche" id="bel-lage" style="min-width:0" aria-label="' + (per === 'winter' ? 'Lager' : 'Brücke oder Lager') + '"><option value="">' + (per === 'winter' ? 'Lager: alle' : 'Alle Brücken und Lager') + '</option>' + lagen.map((l) => '<option' + (belegungStand.lage === l ? ' selected' : '') + '>' + esc(l) + '</option>').join('') + '</select></div>' +
      '<div class="panel"><table class="tab kt bel-tab"><thead><tr><th>Platz</th><th>Lage</th><th>Boot</th><th>Eigner</th><th class="r">' + (per === 'winter' ? 'Fläche' : 'Box') + '</th><th>Hinweis</th><th></th></tr></thead><tbody id="bel-tb"></tbody></table>' +
      (per === 'winter' && halleLeer && !belegungStand.halle ? '<p style="margin:8px 0 0"><button class="link-knopf" id="halle-zeigen">Hallenplätze ' + esc(halleLeer) + ' einblenden (zurzeit nicht belegt)</button></p>' : '') + '</div>' +
      (per === 'sommer' ? '<div class="panel"><h2>Nächste Saison vorbereiten</h2><p class="hinweis">Übernimmt alle Sommer-Belegungen von ' + SAISON + ' nach ' + (SAISON + 1) + ' – danach nur noch Änderungen eintragen.</p><button class="btn" id="uebernehmen">Belegung nach ' + (SAISON + 1) + ' übernehmen</button></div>' : '');
    const render = () => {
      const f = belegungStand.such.trim().toLowerCase(), lage = belegungStand.lage;
      const passt = ({ p, bel }) => { if (lage && lageVon(p) !== lage) return false; if (!f) return true; const b = bel && Q.boot(bel.boot_id); const m = b && Q.mitglied(b.eigner_id);
        return [p.nr, p.id, p.bez ? Q.platzName(p) : platzName(p.id), lageVon(p), b && b.name, m && Q.name(m)].filter(Boolean).join(' ').toLowerCase().includes(f); };
      const sicht = zeilen.filter(passt);
      const frei = sicht.filter(({ p, bel }) => !bel && !p.gesperrt).map((z) => z.p);
      const zeile = ({ p, bel }) => {
        const b = bel && Q.boot(bel.boot_id); const m = b && Q.mitglied(b.eigner_id);
        const prob = b && !p.bez ? Q.passt(b, p) : (Q.zuSchwer(b, 'kran') ? ['über ' + Q.maxTxt('kran') + ' (Kran)'] : []);
        const name = p.bez ? Q.platzName(p, 'kurz') : platzName(p.id);
        return '<tr' + (p.gesperrt ? ' class="blass"' : '') + '><td class="k-titel"><strong>' + esc(name) + '</strong><span class="k-nur"> · ' + esc(lageVon(p)) + '</span></td><td class="k-weg">' + esc(lageVon(p)) + '</td>' +
          '<td class="k-boot">' + (b ? esc(b.name) + ' <small class="nw" style="color:var(--muted)">' + masse(b) + '</small>' : (p.gesperrt ? '<span class="tag rot">gesperrt</span>' : '<span class="leer">frei</span>')) + '</td><td class="k-eigner">' + (m ? esc(Q.name(m)) + ' <span class="tag">' + H.ART[m.art] + '</span>' : '') + '</td>' +
          '<td class="r k-weg">' + (p.bez ? (b && p.art !== 'palette' ? '<span class="nw">' + G.flaeche(d, bel, b) + ' m²</span>' : '') : p.box) + '</td><td class="k-status">' + (prob.length ? '<span class="tag warn">' + prob.map(esc).join(', ') + '</span>' : '') + (bel && bel.art === 'saisongast' ? ' <span class="tag lila">Saison-Gast</span>' : '') + (bel && bel.nicht_kranen ? ' <span class="tag warn">nicht kranen</span>' : '') + '</td>' +
          '<td class="r k-aktion">' + (p.gesperrt ? '' : '<button class="btn klein" data-zuweisen="' + p.id + '">' + (b ? 'Ändern' : 'Zuweisen') + '</button>') + '</td></tr>';
      };
      // freie Plätze in einer Zeile; „Zuweisen ▾“ öffnet die Liste der freien Plätze
      const freiZeile = frei.length ? '<tr class="frei-zeile"><td colspan="7"><div class="frei-inhalt"><span><strong>Frei (' + frei.length + '):</strong> ' + esc(platzBereiche(frei)) + '</span>' +
        '<span class="zm"><button type="button" class="btn klein zm-knopf zm-text" id="frei-zuweisen" aria-haspopup="true" aria-expanded="false">Zuweisen ▾</button><span class="zm-liste frei-liste" role="menu" hidden>' +
        frei.map((p) => '<button type="button" class="zm-punkt" role="menuitem" data-zuweisen="' + p.id + '">' + esc(p.bez ? Q.platzName(p) : platzName(p.id) + ' · ' + H.BRUECKE[p.bruecke] + ' · bis ' + H.zahl(p.max_laenge, 1) + ' m') + '</button>').join('') + '</span></span></div></td></tr>' : '';
      $('#bel-tb').innerHTML = freiZeile + (sicht.filter(({ p, bel }) => bel || p.gesperrt).map(zeile).join('') || (frei.length ? '' : '<tr><td colspan="7" class="leer">Kein Platz gefunden.</td></tr>'));
    };
    render();
    $('#bel-such').addEventListener('input', (e) => { belegungStand.such = e.target.value; render(); });
    $('#bel-lage').addEventListener('change', (e) => { belegungStand.lage = e.target.value; render(); });
    $('#bel-tb').addEventListener('click', (e) => { const z = e.target.closest('[data-zuweisen]'); if (z) zuweisenForm(z.dataset.zuweisen, per); });
    main.querySelectorAll('[data-per]').forEach((b) => b.addEventListener('click', () => { if (belegungStand.periode !== b.dataset.per) belegungStand.lage = ''; belegungStand.periode = b.dataset.per; zeige('belegung'); }));
    $('#bel-druck').addEventListener('click', () => oeffnen('drucken.html?art=belegungsplan'));
    const hz = $('#halle-zeigen'); if (hz) hz.addEventListener('click', () => { belegungStand.halle = true; zeige('belegung', true); });
    const u = $('#uebernehmen'); if (u) u.addEventListener('click', () => {
      const schon = d.belegungen.some((x) => x.saison === SAISON + 1 && x.periode === 'sommer');
      if (schon) return toast('Für ' + (SAISON + 1) + ' gibt es schon Belegungen.', 'fehler');
      d.belegungen.filter((x) => x.saison === SAISON && x.periode === 'sommer').forEach((x) => d.belegungen.push({ ...x, id: H.uid('BL'), saison: SAISON + 1, sommer_an_land_jahr: x.platz_typ === 'land' ? (x.sommer_an_land_jahr || 1) + 1 : undefined }));
      speichern('Belegung für ' + (SAISON + 1) + ' angelegt.');
    });
  };
  function zuweisenForm(platzId, per) {
    const p = Q.platz(platzId); const bel = Q.belegungPlatz(SAISON, per, platzId);
    const el = modal('<h2>' + esc(platzName(platzId)) + ' – ' + (per === 'sommer' ? 'Sommer ' + SAISON : 'Winter ' + SAISON + '/' + String(SAISON + 1).slice(2)) + '</h2>' +
      (p.bez ? '' : '<p class="hinweis">Box ' + p.box + ' · max. ' + H.zahl(p.max_laenge, 1) + ' × ' + H.zahl(p.max_breite, 1) + ' m</p>') +
      '<form id="f" class="form"><label class="feld voll">Boot<select name="boot_id"><option value="">– Platz frei –</option>' + bOpt(bel && bel.boot_id) + '</select></label>' +
      (p.bez ? (p.art !== 'palette' ? '<label class="feld">Fläche (m²)<input name="flaeche_m2" type="number" step="0.1" min="1" value="' + (bel && bel.flaeche_m2 || '') + '" placeholder="automatisch L × B"></label>' : '') +
        '<label class="feld check"><input type="checkbox" name="nicht_kranen"' + (bel && bel.nicht_kranen ? ' checked' : '') + '> beim Auslagern nicht kranen</label>' +
        (per === 'sommer' ? '<label class="feld">Wievielter Sommer an Land?<input name="sommer_an_land_jahr" type="number" min="1" value="' + (bel && bel.sommer_an_land_jahr || 1) + '"><small>ab dem 2. verdoppelt sich die Gebühr</small></label>' : '')
        : '<label class="feld">Art<select name="art"><option value="dauer"' + (bel && bel.art === 'dauer' ? ' selected' : '') + '>Dauerlieger</option><option value="saisongast"' + (bel && bel.art === 'saisongast' ? ' selected' : '') + '>Saison-Gastlieger</option></select></label>') +
      '</form><p id="pruef"></p><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>');
    const pruef = () => { const b = Q.boot($('[name=boot_id]', el).value); const pr = b ? (p.bez ? (Q.zuSchwer(b, 'kran') ? ['über ' + Q.maxTxt('kran') + ' (Kran)'] : []) : Q.passt(b, p)) : [];
      const woanders = b && Q.belegungBoot(SAISON, per, b.id); $('#pruef', el).innerHTML = (pr.length ? '<span class="hinweis warn" style="display:block">Achtung: ' + pr.map(esc).join(', ') + '</span>' : '') + (woanders && woanders.platz_id !== platzId ? '<span class="hinweis" style="display:block">„' + esc(b.name) + '“ liegt bisher auf ' + esc(platzName(woanders.platz_id)) + ' – wird umgelegt.</span>' : ''); };
    $('[name=boot_id]', el).addEventListener('change', pruef); pruef();
    $('#ok', el).addEventListener('click', () => {
      const x = Object.fromEntries(new FormData($('#f', el)));
      d.belegungen = d.belegungen.filter((y) => !(y.saison === SAISON && y.periode === per && (y.platz_id === platzId || (x.boot_id && y.boot_id === x.boot_id))));
      if (x.boot_id) d.belegungen.push({ id: H.uid('BL'), saison: SAISON, periode: per, boot_id: x.boot_id, platz_typ: p.bez ? 'land' : 'wasser', platz_id: platzId, art: x.art || 'dauer',
        flaeche_m2: x.flaeche_m2 ? H.dez(x.flaeche_m2) : null, nicht_kranen: !!x.nicht_kranen, sommer_an_land_jahr: x.sommer_an_land_jahr ? Number(x.sommer_an_land_jahr) : undefined, notiz: '' });
      speichern('Belegung gespeichert.'); zu(); zeige(tab);
    });
  }

  /* ============================================================ Abwesenheiten */
  /* ============================================================ Gäste: Karte & Kalender („Wer liegt wann wo?“)
   * Eine Karte für einen Zeitraum (Anreise + Nächte): grüne Boje = im ganzen Zeitraum frei (unvergeben oder grünes Schild
   * aus „Mein SSV“ / vom Hafenmeister), rot = belegt. Platz antippen → Kalender des Platzes, Gast direkt eintragen.
   * Der Kalender zeigt dieselben Daten als Zeitleiste je Platz. */
  const gkStand = { von: null, n: 1, sicht: 'karte', l: '', b: '', platz: null, kalVon: null, wochen: 3, nurFrei: true, vb: null, monat: null };
  const tagNach = (t, n) => tagVor(t, -n);
  const WOTAG = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'], MONAT = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
  // Was ist an einem Tag auf einem Wasserplatz los?
  function tagLage(p, t) {
    if (p.gesperrt) return { k: 'sperr', txt: 'gesperrt' };
    const g = Q.gastAm(p.id, t); if (g) return { k: 'gast', txt: 'Gast „' + g.bootsname + '“', gast: g };
    const bel = Q.belegungPlatz(Number(t.slice(0, 4)), 'sommer', p.id); if (!bel) return { k: 'frei', txt: 'frei (kein Dauerlieger)' };
    const aw = Q.abwesendAm(p.id, t); if (aw) return { k: 'gruen', txt: 'grünes Schild bis ' + H.kurz(aw.bis) + (aw.gemeldet ? ' · gemeldet: ' + aw.gemeldet : ''), aw };
    const b = Q.boot(bel.boot_id); return { k: 'belegt', txt: b ? '„' + b.name + '“' : 'belegt', boot: b };
  }
  // … und im gewählten Zeitraum (für die Karte)
  function zeitraumLage(p, von, n, l, b) {
    const bel = Q.belegungPlatz(Number(von.slice(0, 4)), 'sommer', p.id); const boot = bel ? Q.boot(bel.boot_id) : null;
    if (p.gesperrt) return { status: 'gesperrt', boot, grund: p.notiz || 'gesperrt' };
    const gast = naechteVon(von, n).map((t) => Q.gastAm(p.id, t)).find(Boolean);
    if (gast) return { status: 'gast', gast, boot, grund: 'Gast „' + gast.bootsname + '“ bis ' + H.kurz(abreise(gast)) };
    const frei = platzPruefen(p, von, n, 0, 0, 0, null);
    if (!frei.ok) return { status: bel && bel.art === 'saisongast' ? 'saisongast' : 'belegt', boot, grund: frei.gruende[frei.gruende.length - 1] };
    const passt = platzPruefen(p, von, n, H.dez(gkStand.l) || 0, H.dez(gkStand.b) || 0, 0, null);
    if (!passt.ok) return { status: 'zuklein', boot, grund: passt.gruende[0] };
    const aw = frei.art === 'unterwegs' ? Q.abwesendAm(p.id, von) : null;
    return { status: frei.art === 'unterwegs' ? 'unterwegs' : 'frei', boot, aw };
  }
  V.gastkarte = (main) => {
    const S = gkStand; if (!S.von) S.von = imSommer ? heute : planStand.datum; if (S.von < sd.auslagern) S.von = sd.auslagern; if (S.von >= sd.einlagern) S.von = tagVor(sd.einlagern, 1);
    S.n = Math.max(1, Math.min(60, Number(S.n) || 1)); const bis = tagNach(S.von, S.n);
    const L = new Map(d.liegeplaetze.map((p) => [p.id, zeitraumLage(p, S.von, S.n)]));
    const zahl = (k) => [...L.values()].filter((x) => k.includes(x.status)).length;
    const zeitraum = H.kurz(S.von) + ' – ' + H.datum(bis) + ' (' + S.n + (S.n > 1 ? ' Nächte' : ' Nacht') + ')';
    main.innerHTML = kopf('Karte & Kalender', 'Wer liegt wann wo? Zeitraum wählen – grüne Bojen sind frei. Platz antippen und Gast eintragen.', darf('gaeste') ? '<button class="btn primaer" id="gk-neu">+ Gast eintragen</button>' : '') +
      '<div class="gk-leiste panel"><label class="feld">Anreise<input type="date" id="gk-von" value="' + S.von + '" min="' + sd.auslagern + '" max="' + tagVor(sd.einlagern, 1) + '"></label>' +
      '<div class="feld"><span>Nächte</span><div class="gk-zahl"><button type="button" class="btn" id="gk-m" aria-label="Eine Nacht weniger">−</button><input type="number" id="gk-n" min="1" max="60" value="' + S.n + '" aria-label="Nächte"><button type="button" class="btn" id="gk-p" aria-label="Eine Nacht mehr">+</button></div></div>' +
      '<div class="feld"><span>Schnellwahl</span><div class="gk-schnell">' + (imSommer ? '<button type="button" class="btn klein" data-gk-tag="' + heute + '">Heute</button><button type="button" class="btn klein" data-gk-tag="' + tagNach(heute, 1) + '">Morgen</button>' : '') + '<button type="button" class="btn klein" data-gk-schieb="-1" title="Anreise einen Tag früher">‹ Vortag</button><button type="button" class="btn klein" data-gk-schieb="1" title="Anreise einen Tag später">Folgetag ›</button></div></div>' +
      '<details class="gk-boot"' + (S.l || S.b ? ' open' : '') + '><summary>Passt das Boot? Maße eingeben</summary><div class="gk-masse"><label class="feld">Länge (m)<input id="gk-l" inputmode="decimal" value="' + esc(S.l) + '" placeholder="z. B. 9,5"></label><label class="feld">Breite (m)<input id="gk-b" inputmode="decimal" value="' + esc(S.b) + '" placeholder="z. B. 3,1"></label></div></details>' +
      '<div class="gk-sicht" role="tablist"><button type="button" class="btn' + (S.sicht === 'karte' ? ' aktiv' : '') + '" data-gk-sicht="karte" role="tab" aria-selected="' + (S.sicht === 'karte') + '">Karte</button><button type="button" class="btn' + (S.sicht === 'kalender' ? ' aktiv' : '') + '" data-gk-sicht="kalender" role="tab" aria-selected="' + (S.sicht === 'kalender') + '">Kalender</button></div></div>' +
      '<p class="gk-summe" id="gk-summe"><strong>' + zeitraum + ':</strong> <span class="pk-st gruen">' + zahl(['frei', 'unterwegs']) + ' frei</span> (davon ' + zahl(['unterwegs']) + ' mit grünem Schild)' + (zahl(['zuklein']) ? ' · ' + zahl(['zuklein']) + ' frei, aber zu klein' : '') +
      ' · <span class="pk-st rot">' + zahl(['belegt', 'saisongast']) + ' belegt</span> · ' + zahl(['gast']) + (zahl(['gast']) === 1 ? ' Gast' : ' Gäste') + '</p>' +
      (S.sicht === 'karte'
        ? '<div class="plan-layout"><div class="plan-box"><div class="plan-flaeche" id="gk-plan"></div><div class="legende"><span><i class="lg-boje gruen"></i>im ganzen Zeitraum frei</span><span><i class="lg-boje rot"></i>belegt (ganz oder an einzelnen Tagen)</span><span><i class="lg-boot gast"></i>Gastlieger</span><span><i class="lg-feld gruen"></i>grünes Schild</span>' + (S.l || S.b ? '<span><i class="lg-feld klein"></i>frei, aber zu klein</span>' : '') + '</div></div><aside class="detail" id="gk-detail"></aside></div>'
        : '<div class="panel gk-kal-panel"><div class="gk-kal-kopf"><button type="button" class="btn klein" data-kal="-7">‹ Woche</button><button type="button" class="btn klein" data-kal="0">Zum Zeitraum</button><button type="button" class="btn klein" data-kal="7">Woche ›</button>' +
          '<select id="gk-wochen" aria-label="Wie viele Wochen?">' + [2, 3, 4, 6].map((w) => '<option value="' + w + '"' + (S.wochen === w ? ' selected' : '') + '>' + w + ' Wochen</option>').join('') + '</select>' +
          '<label class="gk-nur"><input type="checkbox" id="gk-nur"' + (S.nurFrei ? ' checked' : '') + '> nur Plätze, an denen sich etwas tut (frei, grünes Schild, Gast)</label></div><div class="gk-kal" id="gk-kal"></div>' +
          '<div class="legende"><span><i class="kz z-belegt"></i>Dauerlieger da</span><span><i class="kz z-gruen"></i>grünes Schild – frei für Gäste</span><span><i class="kz z-frei"></i>frei (kein Dauerlieger)</span><span><i class="kz z-gast"></i>Gast</span><span><i class="kz z-sperr"></i>gesperrt</span><span>Freien Tag antippen = Gast eintragen · Platznummer antippen = Karte</span></div></div>');
    // ---- Bedienung
    const neu = () => zeige('gastkarte', true);
    $('#gk-von').addEventListener('change', (e) => { if (e.target.value) { S.von = e.target.value; S.kalVon = null; S.monat = null; neu(); } });
    $('#gk-n').addEventListener('change', (e) => { S.n = Number(e.target.value) || 1; neu(); });
    $('#gk-m').addEventListener('click', () => { S.n = Math.max(1, S.n - 1); neu(); }); $('#gk-p').addEventListener('click', () => { S.n = Math.min(60, S.n + 1); neu(); });
    main.querySelectorAll('[data-gk-tag]').forEach((b) => b.addEventListener('click', () => { S.von = b.dataset.gkTag; S.kalVon = null; S.monat = null; neu(); }));
    main.querySelectorAll('[data-gk-schieb]').forEach((b) => b.addEventListener('click', () => { S.von = tagNach(S.von, Number(b.dataset.gkSchieb)); S.kalVon = null; S.monat = null; neu(); }));
    main.querySelectorAll('[data-gk-sicht]').forEach((b) => b.addEventListener('click', () => { S.sicht = b.dataset.gkSicht; neu(); }));
    ['l', 'b'].forEach((k) => $('#gk-' + k).addEventListener('change', (e) => { S[k] = e.target.value.trim(); neu(); }));
    const gn = $('#gk-neu'); if (gn) gn.addEventListener('click', () => gastForm({ ankunft: S.von, naechte: S.n, laenge: S.l ? H.dez(S.l) : '', breite: S.b ? H.dez(S.b) : '', platz_id: S.platz && ['frei', 'unterwegs'].includes((L.get(S.platz) || {}).status) ? S.platz : '' }));
    if (S.sicht === 'karte') gkKarte(L); else gkKalender();
  };
  function gkKarte(L) {
    const S = gkStand;
    const svg = PLAN.zeichnen($('#gk-plan'), { namen: true, modus: 'sommer', saison: SAISON, datum: S.von, ansicht: S.vb || 'wasser', intro: !S.vb, markiere: S.platz, wasser: (p) => L.get(p.id) || { status: 'frei' },
      karte: (id) => { const p = Q.platz(id); if (!p || p.bez) return ''; const x = L.get(id); const frei = ['frei', 'unterwegs'].includes(x.status);
        return '<strong>' + (p.box === 'L' ? 'Längsseits ' : 'Platz ') + esc(p.nr) + '</strong><span class="pk-st ' + (frei ? 'gruen' : x.status === 'zuklein' || x.status === 'gesperrt' ? 'aus' : 'rot') + '">' + (frei ? 'frei im ganzen Zeitraum' : x.status === 'zuklein' ? 'frei, aber zu klein' : x.status === 'gast' ? 'Gastlieger' : esc(PLAN.STATUS_TEXT[x.status] || x.status)) + '</span>' +
          (x.aw ? '<p>grünes Schild bis ' + H.kurz(x.aw.bis) + '</p>' : '') + (x.grund ? '<p>' + esc(x.grund) + '</p>' : '') + (x.boot && !frei ? '' : x.boot ? '<p class="pk-leise">sonst: „' + esc(x.boot.name) + '“</p>' : '') + '<p class="pk-leise">bis ' + H.zahl(p.max_laenge, 1) + ' × ' + H.zahl(p.max_breite, 1) + ' m</p>'; },
      onKlick: (id) => { const p = Q.platz(id); if (!p || p.bez) return; S.platz = id; S.monat = null; svg.querySelectorAll('.markiert').forEach((x) => x.classList.remove('markiert')); const g = svg.querySelector('[data-platz="' + id + '"]'); if (g) g.classList.add('markiert'); gkDetail(L); } });
    PLAN.kamera(svg, { onAnsicht: (v) => { S.vb = v.slice(); } });
    gkDetail(L);
  }
  // Seitenleiste zur Karte: gewählter Platz mit Monatskalender – oder die Liste der freien Plätze
  function gkDetail(L) {
    const S = gkStand, el = $('#gk-detail'); if (!el) return; const p = S.platz && d.liegeplaetze.find((x) => x.id === S.platz);
    if (!p) {
      const frei = d.liegeplaetze.filter((x) => ['frei', 'unterwegs'].includes(L.get(x.id).status)).sort((a, b) => String(a.nr).localeCompare(String(b.nr), 'de', { numeric: true }));
      el.innerHTML = '<h2>Frei im Zeitraum</h2><p class="unter">' + H.kurz(S.von) + ' – ' + H.datum(tagNach(S.von, S.n)) + '</p>' + (frei.length ? '<ul class="gk-frei">' + frei.map((x) => { const l = L.get(x.id);
        return '<li><button type="button" data-gk-platz="' + x.id + '"><strong>' + esc(platzName(x.id)) + '</strong><span>' + (l.aw ? 'grünes Schild bis ' + H.kurz(l.aw.bis) : 'kein Dauerlieger') + ' · bis ' + H.zahl(x.max_laenge, 1) + ' × ' + H.zahl(x.max_breite, 1) + ' m</span></button></li>'; }).join('') + '</ul>'
        : '<p class="leer">In diesem Zeitraum ist kein Platz durchgehend frei. Im Kalender siehst du, an welchen Tagen etwas frei wird.</p>');
      el.querySelectorAll('[data-gk-platz]').forEach((b) => b.addEventListener('click', () => { S.platz = b.dataset.gkPlatz; S.vb = null; zeige('gastkarte', true); }));
      return;
    }
    const x = L.get(p.id); const frei = ['frei', 'unterwegs'].includes(x.status);
    const mon = S.monat || S.von.slice(0, 7); const [j, m] = mon.split('-').map(Number); const erster = new Date(j, m - 1, 1, 12); const tage = new Date(j, m, 0).getDate(); const vor = (erster.getDay() + 6) % 7;
    const zr = new Set(naechteVon(S.von, S.n)); let zellen = '<span></span>'.repeat(vor);
    for (let t = 1; t <= tage; t++) { const tg = mon + '-' + String(t).padStart(2, '0'); const in_saison = tg >= sd.auslagern && tg < sd.einlagern; const l = in_saison ? tagLage(p, tg) : { k: 'aus', txt: 'außerhalb der Saison' };
      zellen += '<button type="button" class="kt z-' + l.k + (zr.has(tg) ? ' gewaehlt' : '') + (tg === heute ? ' heute' : '') + '" data-kt="' + tg + '"' + (in_saison ? '' : ' disabled') + ' title="' + esc(H.datum(tg) + ': ' + l.txt) + '">' + t + '</button>'; }
    const kommende = d.abwesenheiten.filter((a) => a.platz_id === p.id && a.bis >= S.von).sort((a, b) => a.von.localeCompare(b.von));
    const gaeste = d.gaeste.filter((g) => g.platz_id === p.id && g.status !== 'storniert' && abreise(g) > S.von).sort((a, b) => a.ankunft.localeCompare(b.ankunft));
    el.innerHTML = '<button type="button" class="gk-zurueck" id="gk-liste">‹ alle freien Plätze</button><h2>' + (p.box === 'L' ? 'Längsseits ' : 'Platz ') + esc(p.nr) + '</h2><p class="unter">' + esc(H.BRUECKE[p.bruecke] || '') + ' · bis ' + H.zahl(p.max_laenge, 1) + ' × ' + H.zahl(p.max_breite, 1) + ' m' + (p.strom ? ' · Strom' : '') + '</p>' +
      '<p><span class="pk-st ' + (frei ? 'gruen' : x.status === 'zuklein' || x.status === 'gesperrt' ? 'aus' : 'rot') + '">' + (frei ? 'frei vom ' + H.kurz(S.von) + ' bis ' + H.kurz(tagNach(S.von, S.n)) : x.status === 'zuklein' ? 'frei, aber zu klein' : x.status === 'gast' ? 'Gastlieger' : esc(PLAN.STATUS_TEXT[x.status] || x.status)) + '</span></p>' +
      (x.grund ? '<p class="hinweis' + (frei ? '' : ' warn') + '" style="margin:6px 0">' + esc(x.grund.charAt(0).toUpperCase() + x.grund.slice(1)) + '.</p>' : '') +
      (x.boot ? '<p class="unter" style="margin-top:4px">Dauerlieger: „' + esc(x.boot.name) + '“ · ' + esc(Q.name(Q.mitglied(x.boot.eigner_id))) + '</p>' : '<p class="unter" style="margin-top:4px">Kein Dauerlieger in dieser Saison.</p>') +
      '<div class="gk-monat"><div class="gk-monat-kopf"><button type="button" class="btn klein" data-mon="-1" aria-label="Monat zurück">‹</button><strong>' + MONAT[m - 1] + ' ' + j + '</strong><button type="button" class="btn klein" data-mon="1" aria-label="Monat vor">›</button></div>' +
      '<div class="gk-tage"><b>Mo</b><b>Di</b><b>Mi</b><b>Do</b><b>Fr</b><b>Sa</b><b>So</b>' + zellen + '</div><p class="pk-leise">Tag antippen = Anreise auf diesen Tag setzen.</p></div>' +
      (kommende.length ? '<div class="abschnitt"><h3>Grünes Schild</h3><dl>' + kommende.map((a) => '<dt>' + H.kurz(a.von) + '–' + H.kurz(a.bis) + '</dt><dd>' + esc(a.notiz || 'unterwegs') + ' <small style="color:var(--muted)">' + esc(a.gemeldet === 'Mitglied' ? '· über Mein SSV' : a.gemeldet ? '· ' + a.gemeldet : '') + '</small></dd>').join('') + '</dl></div>' : '') +
      (gaeste.length ? '<div class="abschnitt"><h3>Gäste auf diesem Platz</h3><dl>' + gaeste.map((g) => '<dt>' + H.kurz(g.ankunft) + '–' + H.kurz(abreise(g)) + '</dt><dd><a href="#" data-gk-gast="' + g.id + '">„' + esc(g.bootsname) + '“</a> · ' + esc(g.skipper || '') + '</dd>').join('') + '</dl></div>' : '') +
      '<div class="aktionen">' + (frei && darf('gaeste') ? '<button class="btn primaer" id="gk-hier">Gast hier eintragen</button>' : '') + (x.boot && darf('abwesenheiten') ? '<button class="btn gruen" id="gk-aw">Grünes Schild eintragen</button>' : '') + '</div>';
    $('#gk-liste').addEventListener('click', () => { S.platz = null; const s = document.querySelector('#gk-plan .markiert'); if (s) s.classList.remove('markiert'); gkDetail(L); });
    el.querySelectorAll('[data-mon]').forEach((b) => b.addEventListener('click', () => { const dt = new Date(j, m - 1 + Number(b.dataset.mon), 1, 12); S.monat = dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0'); gkDetail(L); }));
    el.querySelectorAll('[data-kt]').forEach((b) => b.addEventListener('click', () => { S.von = b.dataset.kt; S.monat = mon; S.kalVon = null; zeige('gastkarte', true); }));
    el.querySelectorAll('[data-gk-gast]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); gastForm(d.gaeste.find((g) => g.id === a.dataset.gkGast)); }));
    const gh = $('#gk-hier'); if (gh) gh.addEventListener('click', () => gastForm({ platz_id: p.id, ankunft: S.von, naechte: S.n, laenge: S.l ? H.dez(S.l) : '', breite: S.b ? H.dez(S.b) : '' }));
    const ga = $('#gk-aw'); if (ga) ga.addEventListener('click', () => abwesenheitForm({ boot_id: x.boot.id, von: S.von }));
  }
  // Kalender: Zeitleiste je Platz
  function gkKalender() {
    const S = gkStand, el = $('#gk-kal'); const n = S.wochen * 7; let ab = S.kalVon || tagVor(S.von, 2); if (ab < sd.auslagern) ab = sd.auslagern;
    const tage = []; for (let i = 0; i < n; i++) { const t = tagNach(ab, i); if (t >= sd.einlagern) break; tage.push(t); }
    const zr = new Set(naechteVon(S.von, S.n));
    const plaetze = d.liegeplaetze.slice().sort((a, b) => String(a.nr).localeCompare(String(b.nr), 'de', { numeric: true }));
    const zeilen = plaetze.map((p) => ({ p, z: tage.map((t) => tagLage(p, t)) })).filter((r) => !S.nurFrei || r.z.some((x) => x.k !== 'belegt' && x.k !== 'sperr'));
    // Monatszeile
    let monate = '', i = 0; while (i < tage.length) { const mo = tage[i].slice(0, 7); let k = i; while (k < tage.length && tage[k].slice(0, 7) === mo) k++; monate += '<th colspan="' + (k - i) + '" class="kal-monat">' + MONAT[Number(mo.slice(5)) - 1] + ' ' + mo.slice(0, 4) + '</th>'; i = k; }
    el.innerHTML = !zeilen.length ? '<p class="leer" style="padding:18px">In diesen Wochen ist an keinem Platz etwas frei. Haken „nur Plätze, an denen sich etwas tut“ entfernen, um alle Plätze zu sehen.</p>'
      : '<table class="kal"><thead><tr><th rowspan="2" class="kal-platz">Platz</th>' + monate + '</tr><tr>' + tage.map((t) => { const w = new Date(t + 'T12:00:00').getDay(); return '<th class="kal-tag' + (w === 0 || w === 6 ? ' we' : '') + (t === heute ? ' heute' : '') + (zr.has(t) ? ' gewaehlt' : '') + '"><small>' + WOTAG[w] + '</small>' + Number(t.slice(8)) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      zeilen.map(({ p, z }) => { const bel = Q.belegungPlatz(SAISON, 'sommer', p.id); const b = bel && Q.boot(bel.boot_id);
        return '<tr><th class="kal-platz"><button type="button" data-kal-platz="' + p.id + '" title="Auf der Karte zeigen"><strong>' + esc(p.nr) + '</strong><small>' + (b ? esc(String(b.name).slice(0, 14)) : 'kein Dauerlieger') + '</small></button></th>' +
          z.map((x, k) => { const t = tage[k]; const start = x.k === 'gast' && (k === 0 || !z[k - 1].gast || z[k - 1].gast.id !== x.gast.id); const klickbar = x.k === 'gast' || ((x.k === 'frei' || x.k === 'gruen') && darf('gaeste'));
            return '<td class="z-' + x.k + (zr.has(t) ? ' gewaehlt' : '') + (klickbar ? ' klick' : '') + (start ? ' start' : '') + '" data-p="' + p.id + '" data-t="' + t + '"' + (x.gast ? ' data-g="' + x.gast.id + '"' : '') + ' title="' + esc((p.box === 'L' ? '' : 'Platz ') + p.nr + ' · ' + H.datum(t) + ': ' + x.txt) + '">' + (start ? '<span class="kal-name">' + esc(String(x.gast.bootsname).slice(0, 16)) + '</span>' : '') + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table>';
    document.querySelectorAll('[data-kal]').forEach((b) => b.addEventListener('click', () => { const k = Number(b.dataset.kal); S.kalVon = k === 0 ? null : tagNach(ab, k); if (S.kalVon && S.kalVon >= sd.einlagern) S.kalVon = tagVor(sd.einlagern, 7); zeige('gastkarte', true); }));
    $('#gk-wochen').addEventListener('change', (e) => { S.wochen = Number(e.target.value) || 3; zeige('gastkarte', true); });
    $('#gk-nur').addEventListener('change', (e) => { S.nurFrei = e.target.checked; zeige('gastkarte', true); });
    el.addEventListener('click', (e) => {
      const pk = e.target.closest('[data-kal-platz]'); if (pk) { S.platz = pk.dataset.kalPlatz; S.sicht = 'karte'; S.vb = null; return zeige('gastkarte', true); }
      const td = e.target.closest('td.klick'); if (!td) return;
      if (td.dataset.g) return gastForm(d.gaeste.find((g) => g.id === td.dataset.g));
      // freie Tage ab dem angetippten Tag zählen → als Vorschlag für die Nächte (höchstens der gewählte Zeitraum)
      gastForm({ platz_id: td.dataset.p, ankunft: td.dataset.t, naechte: 1, laenge: S.l ? H.dez(S.l) : '', breite: S.b ? H.dez(S.b) : '' });
    });
  }

  V.abwesenheiten = (main) => {
    const liste = d.abwesenheiten.slice().sort((a, b) => b.von.localeCompare(a.von));
    main.innerHTML = kopf('Grünes Schild', 'Mitglied ist mit dem Boot unterwegs – der Platz ist so lange frei für Gäste. Wer ablegt, hängt das grüne Schild (Hafenbetriebsordnung 2.2.3).', '<button class="btn gruen" id="neu">+ Grünes Schild eintragen</button>') +
      '<div class="panel"><table class="tab"><thead><tr><th>Zeitraum</th><th>Platz</th><th>Boot</th><th>Eigner</th><th>Ziel / Notiz</th><th>Status</th><th></th></tr></thead><tbody>' +
      liste.map((a) => { const b = Q.boot(a.boot_id); const m = b && Q.mitglied(b.eigner_id); const jetzt = a.von <= heute && a.bis >= heute;
        return '<tr' + (a.bis < heute && !jetzt ? ' class="blass"' : '') + '><td>' + H.kurz(a.von) + ' – ' + H.datum(a.bis) + '</td><td>' + esc(platzName(a.platz_id)) + '</td><td>' + (b ? esc(b.name) : '') + '</td><td>' + esc(Q.name(m)) + '</td><td>' + esc(a.notiz || '') + '</td>' +
          '<td>' + (jetzt ? '<span class="tag gruen">unterwegs (heute)</span>' : a.von > heute ? '<span class="tag">geplant</span>' : a.bis < heute ? '<span class="tag">vorbei</span>' : '') + ' <small style="color:var(--muted)">' + esc(a.gemeldet || '') + '</small></td>' +
          '<td class="r nw">' + (jetzt && a.von < heute ? '<button class="btn klein" data-zurueck="' + a.id + '">Früher zurück</button> ' : '') + '<button class="btn klein gefahr" data-weg="' + a.id + '">Löschen</button></td></tr>'; }).join('') + '</tbody></table></div>';
    $('#neu').addEventListener('click', () => abwesenheitForm({}));
    main.querySelectorAll('[data-weg]').forEach((b) => b.addEventListener('click', () => { if (!confirm('Grünes Schild löschen? Der Platz ist dann nicht mehr grün.')) return; d.abwesenheiten = d.abwesenheiten.filter((a) => a.id !== b.dataset.weg); speichern('Gelöscht.'); zeige(tab); }));
    main.querySelectorAll('[data-zurueck]').forEach((b) => b.addEventListener('click', () => {
      const a = d.abwesenheiten.find((x) => x.id === b.dataset.zurueck); if (!confirm('Eigner ist heute zurück? Das grüne Schild endet gestern.')) return;
      a.bis = tagVor(heute, 1); a.notiz = ((a.notiz || '') + ' (früher zurück)').trim(); speichern('Eingetragen – Konflikte mit Gästen stehen in der Übersicht.'); zeige(tab);
    }));
  };
  function abwesenheitForm(a) {
    const el = modal('<h2>Grünes Schild eintragen</h2><p class="hinweis ok">Der Platz wird für diesen Zeitraum im Hafenplan grün und kann an Gäste vergeben werden.</p><form id="f" class="form">' +
      '<label class="feld voll">Boot<select name="boot_id" required><option value="">bitte wählen</option>' + d.boote.filter((b) => { const bl = Q.belegungBoot(SAISON, 'sommer', b.id); return bl && bl.platz_typ === 'wasser'; }).map((b) => '<option value="' + b.id + '"' + (b.id === a.boot_id ? ' selected' : '') + '>' + esc(b.name) + ' – ' + esc(platzName(Q.belegungBoot(SAISON, 'sommer', b.id).platz_id)) + '</option>').join('') + '</select></label>' +
      '<label class="feld">von<input name="von" type="date" required value="' + (a.von || (imSommer ? heute : planStand.datum)) + '"></label><label class="feld">bis (Rückkehr)<input name="bis" type="date" required value="' + (a.bis || '') + '"></label>' +
      '<label class="feld voll">Ziel / Notiz<input name="notiz" placeholder="z. B. Dänische Südsee"></label></form><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn gruen" id="ok">Grünes Schild setzen</button></div>');
    $('#ok', el).addEventListener('click', () => {
      const f = $('#f', el); if (!f.reportValidity()) return; const x = Object.fromEntries(new FormData(f));
      if (x.bis < x.von) return toast('Rückkehr liegt vor der Abfahrt.', 'fehler');
      d.abwesenheiten.push({ id: H.uid('AW'), boot_id: x.boot_id, platz_id: Q.belegungBoot(SAISON, 'sommer', x.boot_id).platz_id, von: x.von, bis: x.bis, notiz: x.notiz, gemeldet: ROLLEN[rolle].name });
      speichern('Grünes Schild gesetzt.'); zu(); zeige(tab);
    });
  }

  /* ============================================================ Gastlieger */
  // Gast-Lage wird aus den Daten berechnet: Aufenthalt (Datum), Platz, Zahlung – je eine eigene Spalte
  const tageBis = (a, b) => Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 864e5);
  // Prüfhinweis zum Gast (kommt aus der Gast-Anmeldung) mit dem einheitlichen Begriff „grünes Schild“ zeigen –
  // auch ältere, schon gespeicherte Hinweise, die noch „Abwesenheit“ sagen
  const hinweisText = (t) => String(t || '').replace(/keine Abwesenheit \(grünes Schild\)/g, 'kein grünes Schild').replace(/keine Abwesenheit/g, 'kein grünes Schild');
  function gastLage(g) {
    const ab = abreise(g); const vorbei = g.status !== 'storniert' && g.status !== 'abgereist' && ab < heute && tageBis(ab, heute) > 14;   // längst weg, nur nie abgemeldet
    const zu = g.status === 'storniert' || g.status === 'abgereist' || vorbei;
    let auf;
    if (g.status === 'storniert') auf = { k: 'storniert', t: 'storniert', c: '' };
    else if (g.status === 'abgereist' || vorbei) auf = { k: 'abgereist', t: 'abgereist' + (vorbei ? ' (' + H.kurz(ab) + ')' : ''), c: '' };
    else if (g.ankunft > heute) auf = { k: 'kommt', t: 'kommt ' + H.kurz(g.ankunft), c: 'gast' };
    else if (ab === heute) auf = { k: 'abreise', t: 'reist heute ab', c: 'warn' };
    else if (ab < heute) auf = { k: 'ueberfaellig', t: 'Abreise prüfen (' + H.kurz(ab) + ')', c: 'warn' };
    else auf = { k: 'da', t: g.ankunft === heute ? 'kommt heute' : 'im Hafen bis ' + H.kurz(ab), c: 'ok' };
    const platz = g.status === 'storniert' ? { t: '–', c: '' } : g.platz_id ? { t: esc(platzName(g.platz_id)), c: 'ok' }
      : g.platz_angabe ? { t: 'Platz prüfen: ' + esc(angabe(g.platz_angabe)), c: 'warn', pruefen: true } : { t: 'Platz prüfen: keine Angabe', c: 'warn', pruefen: true };
    const zahl = g.status === 'storniert' ? { t: '–', c: '' } : g.bezahlt_am ? { t: 'bezahlt ' + H.kurz(g.bezahlt_am), c: 'ok' }
      : g.zahlung_gemeldet ? { t: 'gemeldet (' + esc(ZAHLART[g.zahlung] || g.zahlung) + ') – noch nicht geprüft', c: 'gast', melden: true } : { t: 'offen', c: g.ankunft <= heute ? 'warn' : '' };
    // Was ist zu tun? (in dieser Reihenfolge = Hauptaktion)
    const offen = [];
    if (g.status !== 'storniert' && zahl.melden) offen.push('eingang');
    if (!zu && platz.pruefen) offen.push('platz');
    if (!zu && (auf.k === 'abreise' || auf.k === 'ueberfaellig')) offen.push('abreise');
    if (g.status !== 'storniert' && !g.bezahlt_am && !g.zahlung_gemeldet && g.ankunft <= heute) offen.push('zahlen');
    const archiv = zu;
    const ansicht = archiv ? 'archiv' : auf.k === 'kommt' ? 'anreisen' : auf.k === 'abreise' || auf.k === 'ueberfaellig' ? 'abreisen' : 'hafen';
    const heuteDran = !!offen.length || g.ankunft === heute;
    return { auf, platz, zahl, offen, ansicht, heuteDran };
  }
  let gastAnsicht = '', gastAushangAuf = false;
  // Zeilen-Menü: eine Hauptaktion sichtbar, der Rest hinter „⋯“
  const zeilenMenue = (knoepfe) => !knoepfe.length ? '' : '<span class="zm"><button type="button" class="btn klein zm-knopf" aria-haspopup="true" aria-expanded="false" title="Weitere Aktionen">⋯</button><span class="zm-liste" role="menu" hidden>' + knoepfe.join('') + '</span></span>';
  V.gaeste = (main) => {
    const gb = G.gebuehrenFuer(d, SAISON);
    const L = new Map(d.gaeste.map((g) => [g.id, gastLage(g)]));
    const ANS = [['heute', 'Heute'], ['anreisen', 'Anreise'], ['hafen', 'Im Hafen'], ['abreisen', 'Abreise'], ['archiv', 'Archiv']];
    const ANS_TITEL = { heute: 'Heute und alles, was noch offen ist', anreisen: 'Angekündigte Gäste', hafen: 'Gäste, die gerade im Hafen liegen', abreisen: 'Gäste, die heute abreisen', archiv: 'Abgereiste und stornierte Gäste' };
    const drin = (g, a) => a === 'heute' ? L.get(g.id).heuteDran : L.get(g.id).ansicht === a;
    const anzahl = Object.fromEntries(ANS.map(([k]) => [k, d.gaeste.filter((g) => drin(g, k)).length]));
    if (!gastAnsicht) gastAnsicht = anzahl.heute ? 'heute' : anzahl.hafen ? 'hafen' : 'archiv';
    const liste = d.gaeste.filter((g) => drin(g, gastAnsicht)).sort((a, b) => gastAnsicht === 'archiv' ? b.ankunft.localeCompare(a.ankunft) : a.ankunft.localeCompare(b.ankunft));
    const HAUPT = { eingang: (g) => '<button class="btn klein primaer" data-eingang="' + g.id + '" title="Geld ist da – als bezahlt verbuchen, Quittungsnummer vergeben">Eingang bestätigen</button>',
      platz: (g) => '<button class="btn klein primaer" data-zuw="' + g.id + '">Platz eintragen</button>',
      abreise: (g) => '<button class="btn klein" data-weg="' + g.id + '" title="Gast ist abgereist – Platz wird wieder frei">Abgereist</button>',
      zahlen: (g) => '<button class="btn klein" data-zqr="' + g.id + '" title="GiroCode mit Betrag zum Scannen zeigen">Zahl-QR</button>' };
    const aktionen = (g) => { const l = L.get(g.id); const haupt = l.offen[0];
      const menue = [];
      l.offen.slice(1).forEach((k) => menue.push(HAUPT[k](g).replace(/btn klein( primaer)?/, 'zm-punkt')));
      if (haupt !== 'zahlen' && !l.offen.includes('zahlen') && !g.bezahlt_am && !g.zahlung_gemeldet && g.status !== 'storniert' && g.status !== 'abgereist') menue.push('<button class="zm-punkt" data-zqr="' + g.id + '">Zahl-QR zeigen</button>');
      if (haupt) menue.push('<button class="zm-punkt" data-bearb="' + g.id + '">Bearbeiten</button>');
      if (g.quittung_nr && g.bezahlt_am) menue.push('<button class="zm-punkt" data-quit="' + g.id + '">Quittung</button>');
      if (!l.offen.includes('abreise') && g.status !== 'abgereist' && g.status !== 'storniert' && g.ankunft <= heute) menue.push('<button class="zm-punkt" data-weg="' + g.id + '">Als abgereist markieren</button>');
      return (haupt ? HAUPT[haupt](g) : '<button class="btn klein" data-bearb="' + g.id + '">Bearbeiten</button>') + ' ' + zeilenMenue(menue); };
    const zeile = (g) => { const l = L.get(g.id);
      return '<tr' + (l.ansicht === 'archiv' ? ' class="blass"' : '') + ' data-gid="' + g.id + '"><td><strong>„' + esc(g.bootsname) + '“</strong><br><small style="color:var(--muted)"><span class="nw">' + H.zahl(g.laenge, 1) + (g.breite ? ' × ' + H.zahl(g.breite, 1) : '') + ' m</span>' + (g.tiefgang ? ' · <span class="nw">Tg. ' + H.zahl(g.tiefgang, 1) + ' m</span>' : '') + (g.quelle === 'qr' ? ' · QR' : '') + '<br><span class="nw">' + esc(g.skipper) + '</span>' + (g.tel ? '<br><a class="nw" href="tel:' + esc(g.tel) + '">' + esc(g.tel) + '</a>' : '') + '</small></td>' +
        '<td><span class="tag ' + l.auf.c + '">' + l.auf.t + '</span><br><small class="nw">' + H.datum(g.ankunft) + ' · ' + g.naechte + (g.naechte === 1 ? '&nbsp;Nacht' : '&nbsp;Nächte') + '</small></td>' +
        '<td><span class="tag ' + l.platz.c + '">' + l.platz.t + '</span>' + (l.platz.pruefen && g.platz_hinweis ? '<br><small>' + esc(hinweisText(g.platz_hinweis)) + '</small>' : '') + '</td>' +
        '<td><span class="tag ' + l.zahl.c + '">' + l.zahl.t + '</span><br><small>' + H.geld(g.betrag) + (g.zahlung && !g.zahlung_gemeldet && g.zahlung !== 'offen' ? ' · ' + esc(ZAHLART[g.zahlung] || g.zahlung) : '') + '</small></td>' +
        '<td class="r aktion">' + aktionen(g) + '</td></tr>'; };
    const leer = { heute: 'Heute ist bei den Gästen nichts zu tun.', anreisen: 'Keine angekündigten Gäste.', hafen: 'Gerade liegt kein Gast im Hafen.', abreisen: 'Heute reist niemand ab.', archiv: 'Noch keine abgereisten Gäste.' };
    // Liste zuerst; Aushang (QR-Plakat, Gast-Anmeldung) und Toilettencode stehen darunter in einem Abschnitt zum Aufklappen
    const wc = d.toilette || {};
    main.innerHTML = kopf('Gastlieger', 'Tageslieger: ' + H.geld(gb.gast_nacht) + ' pro Nacht · Hafenmeister ' + esc(d.einstellungen.hafenmeister_name), '<button class="btn primaer" id="neu">+ Gast einweisen</button>') +
      '<div class="ab-modus gast-modus" role="tablist">' + ANS.map(([k, t]) => '<button type="button" role="tab" title="' + ANS_TITEL[k] + '" aria-selected="' + (k === gastAnsicht) + '" class="' + (k === gastAnsicht ? 'aktiv' : '') + '" data-gans="' + k + '">' + t + (anzahl[k] ? ' <span class="zahl-leise">' + anzahl[k] + '</span>' : '') + '</button>').join('') + '</div>' +
      '<div class="panel">' + (liste.length ? '<table class="tab gast-tab"><thead><tr><th>Boot</th><th>Aufenthalt</th><th>Platz</th><th>Zahlung</th><th></th></tr></thead><tbody>' + liste.map(zeile).join('') + '</tbody></table>' : '<p class="leer">' + leer[gastAnsicht] + '</p>') + '</div>' +
      '<details class="panel gast-aushang" id="gast-aushang"' + (gastAushangAuf ? ' open' : '') + '><summary><span class="ga-titel">Aushang & Toilettencode</span><span class="ga-kurz">' + (wc.code ? 'Toilettencode <strong>' + esc(wc.code) + '</strong>' : 'kein Toilettencode') + '</span></summary>' +
        wcPanel() +
        '<div class="ga-aushang"><p><strong>Aushang am Steg:</strong> das QR-Plakat für die Gast-Anmeldung (Deutsch, Englisch, Dänisch).</p><div class="aktionen"><button class="btn" id="plakat">QR-Plakat für den Steg</button><a class="btn" href="gast.html" target="_blank">Gast-Anmeldung ansehen ↗</a></div></div>' +
        '<p class="ga-text">So läuft es: Gast sieht ein grünes Schild, macht fest, meldet sich per QR-Code mit der Platznummer an und bezahlt sofort (GiroCode, PayPal oder bar). Passt der Platz laut Plan, ist nichts zu tun – unter „Heute“ steht nur, was zu prüfen ist.</p></details>';
    $('#gast-aushang').addEventListener('toggle', (e) => { gastAushangAuf = e.target.open; });
    $('#neu').addEventListener('click', () => gastForm({}));
    $('#plakat').addEventListener('click', () => oeffnen('drucken.html?art=plakat'));
    main.querySelectorAll('[data-gans]').forEach((b) => b.addEventListener('click', () => { gastAnsicht = b.dataset.gans; zeige(tab, true); }));
    main.querySelectorAll('[data-zuw]').forEach((b) => b.addEventListener('click', () => gastForm(d.gaeste.find((x) => x.id === b.dataset.zuw))));
    main.querySelectorAll('[data-bearb]').forEach((b) => b.addEventListener('click', () => gastForm(d.gaeste.find((x) => x.id === b.dataset.bearb))));
    main.querySelectorAll('[data-quit]').forEach((b) => b.addEventListener('click', () => oeffnen('drucken.html?art=quittung&id=' + b.dataset.quit)));
    main.querySelectorAll('[data-zqr]').forEach((b) => b.addEventListener('click', () => zahlQr(d.gaeste.find((x) => x.id === b.dataset.zqr))));
    main.querySelectorAll('[data-weg]').forEach((b) => b.addEventListener('click', () => {
      const g = d.gaeste.find((x) => x.id === b.dataset.weg); g.status = 'abgereist';
      speichern('„' + g.bootsname + '“ ist abgereist' + (g.bezahlt_am || g.zahlung_gemeldet ? '.' : ' – Zahlung ist noch offen.')); zeige(tab, true);
    }));
    const wcb = $('#wc-aendern'); if (wcb) wcb.addEventListener('click', wcForm);
    main.querySelectorAll('[data-eingang]').forEach((b) => b.addEventListener('click', () => gastEingang(d.gaeste.find((x) => x.id === b.dataset.eingang))));
  };
  // Toilettencode für Gäste: eigener Wert (der Hafenmeister wechselt ihn selbst), Regel wann Gäste ihn sehen
  const WC_REGEL = { '': 'Gäste sehen keinen Code', gemeldet: 'Gäste sehen ihn gleich nach ihrer Zahlungsmeldung – auch bevor der Eingang geprüft ist', bestaetigt: 'Gäste sehen ihn erst, wenn der Eingang bestätigt ist' };
  const wcPanel = () => { const t = d.toilette || {};
    return '<div class="wc-panel"><div><small>Toilettencode für Gäste</small><strong>' + (t.code ? esc(t.code) : '–') + '</strong></div><p>' + esc(t.code ? WC_REGEL[t.regel || ''] : 'Noch kein Code hinterlegt.') + (t.hinweis ? '<br><small>' + esc(t.hinweis) + '</small>' : '') + '</p>' +
      '<button class="btn klein" id="wc-aendern">Code ändern</button></div>'; };
  function wcForm() {
    const t = d.toilette || {};
    const el = modal('<h2>Toilettencode für Gäste</h2><form id="f" class="form"><label class="feld">Code<input name="code" value="' + esc(t.code || '') + '" maxlength="12" autocomplete="off" inputmode="numeric" placeholder="z. B. 2580"></label>' +
      '<label class="feld">Wann sehen Gäste den Code?<select name="regel">' + Object.entries(WC_REGEL).map(([k, v]) => '<option value="' + k + '"' + ((t.regel || '') === k ? ' selected' : '') + '>' + (k === '' ? 'gar nicht (aus)' : k === 'gemeldet' ? 'sofort nach Zahlungsmeldung' : 'erst nach bestätigtem Eingang') + '</option>').join('') + '</select></label>' +
      '<label class="feld voll">Hinweis für Gäste<input name="hinweis" value="' + esc(t.hinweis || '') + '" maxlength="160" placeholder="z. B. WC & Duschen im Vereinsheim, Tastenfeld neben der Tür"></label></form>' +
      '<p class="hinweis">„Sofort nach Zahlungsmeldung“ ist das Vertrauensprinzip wie bei einer Kasse des Vertrauens – der Gast muss nicht warten. Code regelmäßig wechseln (z. B. monatlich); neue Gäste sehen dann automatisch den neuen Code. Der Code erscheint nur während des eigenen Aufenthalts.</p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>');
    $('#ok', el).addEventListener('click', async () => {
      const f = $('#f', el); if (f.regel.value && !f.code.value.trim()) return toast('Bitte einen Code eintragen – oder „gar nicht“ wählen.', 'fehler');
      try { await HF.toiletteSetzen({ code: f.code.value, regel: f.regel.value, hinweis: f.hinweis.value }); toast('Toilettencode gespeichert.'); zu(); zeige(tab, true); }
      catch (err) { toast('Speichern fehlgeschlagen: ' + err.message, 'fehler', 6000); }
    });
  }
  // GiroCode mit Betrag für einen Gast – am Steg zeigen, der Gast scannt mit seiner Banking-App
  function zahlQr(g) {
    const e = d.einstellungen; const iban = String(e.iban || '').replace(/\s/g, '');
    const zweck = 'Gast ' + g.bootsname + (g.platz_id ? ' P' + (Q.platz(g.platz_id) || {}).nr : '') + ' ' + H.kurz(g.ankunft);
    let qrHtml = '<p class="hinweis warn">Für den GiroCode fehlt die IBAN des Vereins (Verwaltung → Einstellungen).</p>';
    if (iban && window.qrcode) { const qr = qrcode(0, 'M'); qr.addData(H.epc({ name: e.verein_name, iban, bic: e.bic, betrag: g.betrag, zweck }), 'Byte'); qr.make(); qrHtml = '<div class="zqr">' + qr.createSvgTag({ cellSize: 4, margin: 4, scalable: true }) + '</div>'; }
    const t = d.toilette || {};
    const el = modal('<h2>„' + esc(g.bootsname) + '“ · ' + H.geld(g.betrag) + '</h2><p style="margin-top:0">Gast scannt mit seiner Banking-App – IBAN, Betrag und Verwendungszweck sind ausgefüllt.</p>' + qrHtml +
      '<p class="zqr-unter">' + esc(zweck) + '</p>' + (t.code && t.regel ? '<p class="zqr-unter">Toilettencode nach Zahlung: <strong>' + esc(t.code) + '</strong></p>' : '') +
      '<div class="modal-fuss"><button class="btn" data-zu>Schließen</button><button class="btn" id="zq-bar">Bar erhalten</button><button class="btn primaer" id="zq-ueb">Überweisung ist da</button></div>');
    const buchen = (art) => { g.zahlung = art; g.bezahlt_am = heute; if (!g.quittung_nr) g.quittung_nr = 'Q-' + g.ankunft.slice(0, 4) + '-' + String(++d.zaehler.quittung).padStart(3, '0'); speichern('Zahlung verbucht – Quittung ' + g.quittung_nr + '.'); zu(); zeige(tab, true); };
    $('#zq-bar', el).addEventListener('click', () => buchen('bar')); $('#zq-ueb', el).addEventListener('click', () => buchen('ueberweisung'));
  }
  function gastForm(g) {
    const neu = !g.id; const gb = G.gebuehrenFuer(d, SAISON);
    const x0 = { ankunft: imSommer ? heute : planStand.datum, naechte: 1, laenge: '', breite: '', tiefgang: '', zahlung: 'bar', bezahlt_am: '', ...g };
    const zahlOpt = Object.entries(ZAHLART).map(([k, v]) => '<option value="' + k + '"' + (x0.zahlung === k ? ' selected' : '') + '>' + (k === 'offen' ? 'noch nicht festgelegt' : v) + '</option>').join('');
    const el = modal('<h2>' + (neu ? 'Gast einweisen' : '„' + esc(g.bootsname) + '“') + '</h2><form id="f" class="form">' +
      '<label class="feld">Bootsname<input name="bootsname" required value="' + esc(x0.bootsname || '') + '"></label><label class="feld">Skipper<input name="skipper" required value="' + esc(x0.skipper || '') + '"></label>' +
      '<label class="feld">Heimathafen<input name="herkunft" value="' + esc(x0.herkunft || '') + '"></label><label class="feld">Telefon<input name="tel" type="tel" value="' + esc(x0.tel || '') + '"></label>' +
      '<label class="feld">Länge (m)<input name="laenge" type="number" step="0.1" min="2" max="40" required inputmode="decimal" value="' + x0.laenge + '"></label><label class="feld">Breite (m)<input name="breite" type="number" step="0.1" min="1" max="12" inputmode="decimal" value="' + (x0.breite || '') + '"></label>' +
      '<label class="feld">Tiefgang (m)<input name="tiefgang" type="number" step="0.1" min="0.2" max="6" inputmode="decimal" value="' + (x0.tiefgang || '') + '"></label><label class="feld">Ankunft<input name="ankunft" type="date" required value="' + x0.ankunft + '"></label>' +
      '<label class="feld">Nächte<input name="naechte" type="number" min="1" max="60" required value="' + x0.naechte + '"></label><label class="feld">Betrag<input name="betrag" id="betrag" readonly></label>' +
      (g.platz_angabe && !g.platz_id ? '<p class="hinweis warn voll" style="margin:0">Gast liegt laut eigener Angabe an <strong>' + esc(angabe(g.platz_angabe)) + '</strong>' + (g.platz_hinweis ? ' – ' + esc(hinweisText(g.platz_hinweis)) : '') + '</p>' : '') +
      '<label class="feld voll">Platz<select name="platz_id" id="platzwahl"></select><small id="platzinfo"></small></label><div class="voll" id="platzwarn" role="alert"></div>' +
      '<label class="feld">Zahlart<select name="zahlung">' + zahlOpt + '</select></label>' +
      '<label class="feld">Zahlung eingegangen am<input name="bezahlt_am" type="date" value="' + esc(x0.bezahlt_am || '') + '"><small>leer = noch nicht bezahlt · <a href="#" id="bez-heute">heute</a></small></label>' +
      (!neu ? '<label class="feld">Status<select name="status">' + [['angemeldet', 'angemeldet (noch ohne Platz)'], ['eingewiesen', 'im Hafen'], ['abgereist', 'abgereist'], ['storniert', 'storniert / nicht gekommen']].map(([k, v]) => '<option value="' + k + '"' + (x0.status === k ? ' selected' : '') + '>' + v + '</option>').join('') + '</select></label>' : '') +
      '</form>' + (planAnnahme() ? '<p class="hinweis" style="margin-top:10px">Die Boxmaße sind noch Annahmen – die Empfehlung ist eine Orientierung, vor Ort bitte prüfen.</p>' : '') +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok"></button></div>', true);
    const f = $('#f', el);
    let wahl = x0.status === 'storniert' ? '' : (x0.platz_id || '');
    const werte = () => ({ von: f.ankunft.value || x0.ankunft, n: Math.max(1, Number(f.naechte.value) || 1), l: H.dez(f.laenge.value) || 0, b: H.dez(f.breite.value) || 0, t: H.dez(f.tiefgang.value) || 0 });
    const knopf = () => { const st = f.status ? f.status.value : 'angemeldet'; $('#ok', el).textContent = st === 'storniert' ? 'Stornieren' : wahl ? ((neu || g.status === 'angemeldet') ? 'Einweisen' : 'Speichern') : (neu ? 'Ohne Platz speichern' : 'Speichern (ohne Platz)'); };
    const aktualisieren = () => {
      const w = werte(); $('#betrag', el).value = H.geld(w.n * gb.gast_nacht);
      const vf = verfuegbarePlaetze(w.von, w.n, w.l, w.b, w.t, g.id);
      let warn = '';
      if (wahl && !vf.some((v) => v.p.id === wahl)) {   // gewählter Platz passt nicht mehr → Auswahl aufheben und Grund nennen
        const p = Q.platz(wahl); const pr = p ? platzPruefen(p, w.von, w.n, w.l, w.b, w.t, g.id) : { gruende: ['unbekannter Platz'] };
        warn = '<p class="hinweis warn" style="margin:0"><strong>' + esc(platzName(wahl)) + ' passt nicht mehr:</strong> ' + pr.gruende.map(esc).join('; ') + '. Bitte einen anderen Platz wählen.</p>';
        wahl = '';
      }
      $('#platzwahl', el).innerHTML = '<option value="">– noch keinen –</option>' + vf.map((v) => '<option value="' + v.p.id + '"' + (v.p.id === wahl ? ' selected' : '') + '>' + esc(platzName(v.p.id)) + ' · ' + H.BRUECKE[v.p.bruecke] + ' · bis ' + H.zahl(v.p.max_laenge, 1) + ' m · ' + (v.art === 'frei' ? 'frei' : 'grünes Schild') + '</option>').join('');
      $('#platzinfo', el).textContent = vf.length ? (vf.length === 1 ? '1 passender Platz' : vf.length + ' passende Plätze') + ' für den ganzen Zeitraum (frei oder Eigner unterwegs)' : 'Kein Platz passt für diesen Zeitraum und diese Maße – Gast kann ohne Platz gespeichert werden.';
      if (warn) $('#platzwarn', el).innerHTML = warn;
      knopf();
    };
    $('#platzwahl', el).addEventListener('change', (e) => { wahl = e.target.value; $('#platzwarn', el).innerHTML = ''; knopf(); });
    ['naechte', 'ankunft', 'laenge', 'breite', 'tiefgang'].forEach((k) => f[k].addEventListener('input', aktualisieren));
    if (f.status) f.status.addEventListener('change', knopf);
    $('#bez-heute', el).addEventListener('click', (e) => { e.preventDefault(); f.bezahlt_am.value = heute; });
    aktualisieren();
    $('#ok', el).addEventListener('click', () => {
      if (!f.reportValidity()) return; const x = Object.fromEntries(new FormData(f)); const w = werte();
      const status = x.status === 'storniert' ? 'storniert' : x.platz_id ? (x.status === 'abgereist' ? 'abgereist' : 'eingewiesen') : (x.status === 'abgereist' ? 'abgereist' : 'angemeldet');
      if (x.platz_id && status !== 'storniert') { const pr = platzPruefen(Q.platz(x.platz_id), w.von, w.n, w.l, w.b, w.t, g.id); if (!pr.ok) { toast(platzName(x.platz_id) + ' passt nicht: ' + pr.gruende.join('; '), 'fehler', 6000); return aktualisieren(); } }
      const daten = { bootsname: x.bootsname, skipper: x.skipper, herkunft: x.herkunft, tel: x.tel, laenge: w.l, breite: w.b, tiefgang: w.t || null, ankunft: x.ankunft, naechte: w.n, platz_id: status === 'storniert' ? '' : x.platz_id,
        betrag: w.n * gb.gast_nacht, zahlung: x.zahlung, bezahlt_am: x.bezahlt_am || '', status };
      if (daten.bezahlt_am && !g.quittung_nr) daten.quittung_nr = 'Q-' + daten.ankunft.slice(0, 4) + '-' + String(++d.zaehler.quittung).padStart(3, '0');
      if (neu) d.gaeste.push({ id: H.uid('G'), quelle: 'hafenmeister', erstellt: new Date().toISOString(), email: '', quittung_nr: '', ...daten }); else Object.assign(g, daten);
      speichern(status === 'storniert' ? 'Storniert.' : daten.platz_id ? 'Gast auf ' + platzName(daten.platz_id) + ' eingewiesen.' : 'Gespeichert – noch ohne Platz.'); zu(); zeige(tab);
    });
  }

  /* ============================================================ Warteliste */
  V.warteliste = (main) => {
    const w = d.warteliste.slice().sort((a, b) => (a.status === 'wartend' ? 0 : 1) - (b.status === 'wartend' ? 0 : 1) || a.datum.localeCompare(b.datum));
    main.innerHTML = kopf('Warteliste', 'Jedes ausübende Mitglied hat im Rahmen der Möglichkeiten Anspruch auf einen Liegeplatz (Satzung § 10 I). Reihenfolge nach Eingang.', '<button class="btn primaer" id="neu">+ Eintrag</button>') +
      '<div class="panel"><table class="tab"><thead><tr><th>#</th><th>seit</th><th>Mitglied</th><th>Boot (L × B)</th><th>Wunsch</th><th>Passende freie Plätze ' + SAISON + '</th><th></th></tr></thead><tbody>' +
      w.map((x, i) => { const m = Q.mitglied(x.mitglied_id);
        const passend = d.liegeplaetze.filter((p) => !p.gesperrt && !Q.belegungPlatz(SAISON, 'sommer', p.id) && x.boot_laenge <= p.max_laenge && x.boot_breite <= p.max_breite);
        return '<tr' + (x.status !== 'wartend' ? ' class="blass"' : '') + '><td>' + (x.status === 'wartend' ? i + 1 : '') + '</td><td>' + H.datum(x.datum) + '</td><td><strong>' + esc(Q.name(m)) + '</strong> <span class="tag">' + H.ART[m.art] + '</span>' + (m.art === 'foerdernd' ? ' <small style="color:var(--muted)">(kein Anspruch)</small>' : '') + '</td>' +
          '<td>' + H.zahl(x.boot_laenge) + ' × ' + H.zahl(x.boot_breite) + ' m</td><td>Box ' + esc(x.wunsch_box) + '</td><td>' + (x.status === 'wartend' ? (passend.length ? passend.slice(0, 4).map((p) => '<button class="btn klein" data-vergeben="' + x.id + '|' + p.id + '">' + esc(platzName(p.id)) + '</button>').join(' ') : '<span class="leer">keiner frei</span>') : esc(x.status)) + '</td>' +
          '<td class="r"><button class="btn klein gefahr" data-weg="' + x.id + '">Entfernen</button></td></tr>'; }).join('') + '</tbody></table></div>';
    $('#neu').addEventListener('click', () => {
      const el = modal('<h2>Warteliste</h2><form id="f" class="form"><label class="feld voll">Mitglied<select name="mitglied_id" required>' + mOpt() + '</select></label><label class="feld">Bootslänge (m)<input name="boot_laenge" type="number" step="0.1" required></label><label class="feld">Bootsbreite (m)<input name="boot_breite" type="number" step="0.1" required></label><label class="feld">Wunsch-Box<select name="wunsch_box"><option>I</option><option selected>II</option><option>III</option></select></label><label class="feld">eingegangen am<input name="datum" type="date" value="' + heute + '"></label></form><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Eintragen</button></div>');
      $('#ok', el).addEventListener('click', () => { const f = $('#f', el); if (!f.reportValidity()) return; const x = Object.fromEntries(new FormData(f)); d.warteliste.push({ id: H.uid('W'), ...x, boot_laenge: H.dez(x.boot_laenge), boot_breite: H.dez(x.boot_breite), notiz: '', status: 'wartend' }); speichern('Eingetragen.'); zu(); zeige(tab); });
    });
    main.querySelectorAll('[data-weg]').forEach((b) => b.addEventListener('click', () => { if (confirm('Eintrag entfernen?')) { d.warteliste = d.warteliste.filter((x) => x.id !== b.dataset.weg); speichern('Entfernt.'); zeige(tab); } }));
    main.querySelectorAll('[data-vergeben]').forEach((b) => b.addEventListener('click', () => {
      const [wid, pid] = b.dataset.vergeben.split('|'); const x = d.warteliste.find((y) => y.id === wid); const m = Q.mitglied(x.mitglied_id);
      if (!confirm(platzName(pid) + ' an ' + Q.name(m) + ' vergeben? Das Boot wird angelegt bzw. zugeordnet.')) return;
      let b2 = Q.booteVon(m.id)[0];
      if (!b2) { b2 = { id: H.uid('B'), name: '[Bootsname eintragen]', typ: '', eigner_id: m.id, laenge: x.boot_laenge, breite: x.boot_breite, tiefgang: 0, gewicht_t: 0, segelnr: '', versicherung: '', vers_bis: '', notiz: 'aus Warteliste' }; d.boote.push(b2); }
      // Nach dem Einlagern gilt die Vergabe für den nächsten Sommer
      const ziel = heute > sd.einlagern ? SAISON + 1 : SAISON;
      d.belegungen.push({ id: H.uid('BL'), saison: ziel, periode: 'sommer', boot_id: b2.id, platz_typ: 'wasser', platz_id: pid, art: 'dauer', flaeche_m2: null, nicht_kranen: false, notiz: 'aus Warteliste' });
      if (ziel !== SAISON) toast('Platz für den Sommer ' + ziel + ' vergeben.');
      x.status = 'vergeben: ' + platzName(pid); speichern(platzName(pid) + ' vergeben.'); zeige(tab);
    }));
  };

  /* ============================================================ Kran & Termine (Bereich Hafen)
   * Saisontermine, Kran-Grenze und Kran-Einsätze außerhalb der Termine. Wer wo im Winterlager steht, zeigt Hafen → Belegung (Winter) –
   * dort steht auch „Belegungsplan Winter drucken“. Rollen ohne Belegung (Hafenmeister) öffnen den Plan von hier aus (nur lesen/drucken). */
  V.lagern = (main) => {
    const winter = Q.belegungen(SAISON, 'winter');
    const gb = G.gebuehrenFuer(d, SAISON);
    const naechste = (d.saisons || []).find((x) => x.jahr === SAISON + 1);
    const nichtKranen = winter.filter((bl) => bl.nicht_kranen).length;
    const schwer = winter.filter((bl) => Q.zuSchwer(Q.boot(bl.boot_id), 'kran')).length;
    const termin = (t, txt) => '<div class="kt-termin' + (t && t >= heute ? ' kommt' : '') + '"><small>' + txt + '</small><strong>' + (t ? H.datum(t) : 'noch offen') + '</strong>' + (t && t >= heute ? '<span class="tag gast">steht an</span>' : '') + '</div>';
    main.innerHTML = kopf('Kran & Termine', 'Ein- und Auslagern in Gemeinschaftsarbeit nach Belegungsplan · Kran-Einsätze außerhalb der Termine',
      '<button class="btn primaer" id="kran">+ Kran-Einsatz</button>') +
      '<div class="panel"><h2>Saisontermine</h2><div class="kt-termine">' + termin(sd.auslagern, 'Auslagern ' + SAISON) + termin(sd.einlagern, 'Einlagern ' + SAISON) +
        termin(naechste && naechste.auslagern, 'Auslagern ' + (SAISON + 1)) + '</div>' +
        '<p class="hinweis warn kt-grenze">Boote über ' + Q.maxTxt('kran') + ' werden nicht gekrant. „Nicht kranen“ muss spätestens eine Woche vor dem Auslagern gemeldet sein.</p>' +
        '<div class="kt-winter"><p><strong>Winterlager ' + SAISON + '/' + String(SAISON + 1).slice(2) + ':</strong> ' + winter.length + (winter.length === 1 ? ' Boot' : ' Boote') + ' an Land' +
          (nichtKranen ? ' · ' + nichtKranen + ' „nicht kranen“' : '') + (schwer ? ' · <span class="tag rot">' + schwer + ' über ' + Q.maxTxt('kran') + '</span>' : '') + '</p>' +
          (darf('belegung') ? '<button class="btn" id="zur-belegung">Belegung Winter ansehen →</button>' : '<button class="btn" id="druck2">Belegungsplan ansehen & drucken</button>') + '</div>' +
        (darf('einstellungen') ? '<p class="kt-aendern"><button type="button" class="link-knopf" data-gehe="einstellungen" data-sprung="[name=aus_' + (naechste ? SAISON : SAISON + 1) + ']">Termine ändern (Verwaltung → Einstellungen) →</button></p>' : '') + '</div>' +
      '<div class="panel"><h2>Kran-Einsätze außerhalb der Termine</h2><p class="hinweis">Schiffskran ' + H.geld(gb.schiffskran_std) + ', Mastenkran ' + H.geld(gb.mastenkran_std) + ' je angefangene Stunde – laufen automatisch in die nächste Abrechnung.</p>' +
      (d.kran.length ? '<table class="tab"><thead><tr><th>Datum</th><th>Boot</th><th>Kran</th><th class="r">Dauer</th><th>Abrechnung</th></tr></thead><tbody>' +
      d.kran.slice().sort((a, b) => b.datum.localeCompare(a.datum)).map((k) => { const b = Q.boot(k.boot_id);
        return '<tr><td>' + H.datum(k.datum) + '</td><td>' + esc(b ? b.name : '?') + '<br><small style="color:var(--muted)">' + esc(k.notiz || '') + '</small></td><td>' + (k.art === 'mast' ? 'Mast' : 'Schiff') + '</td><td class="r">' + k.minuten + ' Min.</td><td>' + (k.abgerechnet ? '<span class="tag ok">' + esc(k.abgerechnet) + '</span>' : '<span class="tag warn">offen</span>') + '</td></tr>'; }).join('') + '</tbody></table>'
        : '<p class="leer">Noch keine Kran-Einsätze erfasst.</p>') + '</div>';
    const plan = () => oeffnen('drucken.html?art=belegungsplan');
    const dr = $('#druck2'); if (dr) dr.addEventListener('click', plan);
    const zb = $('#zur-belegung'); if (zb) zb.addEventListener('click', () => { belegungStand.periode = 'winter'; zeige('belegung'); });
    main.querySelectorAll('[data-sprung]').forEach((z) => z.addEventListener('click', () => { sprung = z.dataset.sprung; }, true));
    $('#kran').addEventListener('click', () => {
      const el = modal('<h2>Kran-Einsatz</h2><form id="f" class="form"><label class="feld voll">Boot<select name="boot_id" required>' + bOpt() + '</select></label><label class="feld">Datum<input name="datum" type="date" value="' + heute + '" required></label><label class="feld">Kran<select name="art"><option value="schiff">Schiffskran</option><option value="mast">Mastenkran</option></select></label><label class="feld">Dauer (Minuten)<input name="minuten" type="number" min="1" value="60" required></label><label class="feld">Anlass<input name="notiz"></label></form><p class="hinweis">Kran nur durch eingewiesene Personen (Hafenbetriebsordnung 3.1.4).</p><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Erfassen</button></div>');
      $('#ok', el).addEventListener('click', () => { const f = $('#f', el); if (!f.reportValidity()) return; const x = Object.fromEntries(new FormData(f)); const b = Q.boot(x.boot_id);
        if (Q.zuSchwer(b, 'kran') && x.art === 'schiff' && !confirm('Boot über ' + Q.maxTxt('kran') + ' – wird nicht gekrant. Trotzdem erfassen?')) return;
        d.kran.push({ id: H.uid('K'), ...x, minuten: Number(x.minuten), abgerechnet: '' }); speichern('Kran-Einsatz erfasst.'); zu(); zeige(tab); });
    });
  };

  /* ============================================================ Arbeitsdienst
   * Oben, was zu tun ist (gemeldete Stunden bestätigen), die Regeln als eine Zeile zum Aufklappen,
   * dann die Arbeitseinsätze und der Stundenstand – vorgefiltert auf „Fehlen noch“, mit Suche. */
  const adStand = { filter: 'fehlt', such: '' };
  V.arbeitsdienst = (main) => {
    const e = d.einstellungen; const soll = Number(e.arbeitsdienst_soll || 0), mahn = Number(e.arbeitsdienst_mahnung_ab || 0), satz = Number(e.arbeitsdienst_satz || 0), abAlter = Number(e.arbeitsdienst_befreit_ab || 0);
    const liste = d.mitglieder.filter((m) => (m.art === 'ausuebend' || m.art === 'probe') && Q.istMitglied(m, heute)).map((m) => ({ m, a: G.arbeitsdienst(d, SAISON, m) }));
    const befreite = liste.filter((x) => x.a.befreit);
    const regelKurz = ['Soll ' + H.zahl(soll, soll % 1 ? 1 : 0) + ' Std.', mahn ? 'Aufforderung ab ' + mahn + ' Fehlstunden' : 'keine Aufforderung', satz ? H.geld(satz) + ' je Fehlstunde' : ''].filter(Boolean).join(' · ');
    const regeln = '<details class="panel ad-regeln"><summary><span><strong>Regeln ' + SAISON + ':</strong> ' + regelKurz + '</span><span class="ad-regeln-auf"><span class="auf">Regeln ansehen ▸</span><span class="zu">Regeln ausblenden ▾</span></span></summary><ul class="regeln">' +
      '<li><strong>Soll:</strong> ' + soll + ' Stunden je Jahr für ausübende und Probemitglieder (Satzung § 10 II).</li>' +
      '<li><strong>Befreit:</strong> ' + (abAlter ? 'ab ' + abAlter + ' Jahren (Stichtag 1.1.) sowie ' : '') + 'einzeln vermerkte Mitglieder – derzeit ' + befreite.length + '.</li>' +
      '<li><strong>Rückstand:</strong> ' + (e.arbeitsdienst_vorjahr ? 'Fehlstunden des Vorjahres zählen mit (nur ein Jahr zurück).' : 'Fehlstunden verfallen am Jahresende – kein Übertrag ins nächste Jahr.') + '</li>' +
      '<li><strong>Aufforderung:</strong> ' + (mahn ? 'ab ' + mahn + ' Fehlstunden schriftlich.' : 'keine automatische Aufforderung.') + '</li>' +
      '<li><strong>Ersatzzahlung:</strong> ' + (satz ? H.geld(satz) + ' je Fehlstunde – wird mit der Beitragsrechnung des Folgejahres berechnet.' : 'keine.') + '</li></ul>' +
      (darf('einstellungen') ? '<p class="ad-regeln-fuss"><button type="button" class="link-knopf" data-gehe="einstellungen" data-sprung="[name=arbeitsdienst_soll]">Regeln ändern (Verwaltung → Einstellungen) →</button></p>' : '') + '</details>' +
      (!e.arbeitsdienst_bestaetigt ? '<p class="hinweis warn">Diese Regeln sind noch <strong>Beispielwerte</strong> und nicht vom Vorstand beschlossen – deshalb wird auch nichts berechnet. ' + (darf('einstellungen') ? '<a href="#" data-gehe="einstellungen" data-sprung="[name=arbeitsdienst_soll]">Unter Einstellungen festlegen →</a>' : '') + '</p>' : '');
    const offen = d.arbeitsdienst.filter((a) => a.status === 'eingereicht').sort((x, y) => x.datum.localeCompare(y.datum));
    const einsaetze = (d.arbeitseinsaetze || []).slice().sort((x, y) => y.datum.localeCompare(x.datum));
    const codeVon = (id) => ((d.arbeitseinsatz_codes || []).find((c) => c.einsatz_id === id) || {}).code || '';
    // Stundenstand: „Fehlen noch“ (Vorgabe, nach Fehlstunden absteigend) · „Erfüllt“ (inkl. befreit) · „Alle“
    const fehlt = (x) => !x.a.befreit && x.a.fehl > 0;
    const zahl = { fehlt: liste.filter(fehlt).length, erfuellt: liste.filter((x) => !fehlt(x)).length, alle: liste.length };
    const sichtbar = liste.filter((x) => adStand.filter === 'alle' || (adStand.filter === 'fehlt') === fehlt(x))
      .sort((x, y) => y.a.fehl - x.a.fehl || x.m.nachname.localeCompare(y.m.nachname, 'de'));
    const leerText = { fehlt: 'Niemandem fehlen noch Stunden – alle haben ihr Soll erfüllt oder sind befreit.', erfuellt: 'Noch hat niemand sein Soll erfüllt.', alle: 'Keine arbeitspflichtigen Mitglieder.' };
    main.innerHTML = kopf('Arbeitsstunden ' + SAISON, liste.length + ' Mitglieder arbeitspflichtig · Mitglieder melden Stunden per QR-Code am Einsatztag oder in „Mein SSV“, der Verein bestätigt.', '<button class="btn" id="einsatz-neu">+ Arbeitseinsatz</button><button class="btn primaer" id="neu">+ Stunden erfassen</button>') +
      (offen.length ? '<div class="panel" style="border:2px solid var(--gast)"><h2>Gemeldete Stunden bestätigen (' + offen.length + ')</h2><table class="tab"><tbody>' + offen.map((a) => { const m = Q.mitglied(a.mitglied_id); const ein = a.einsatz_id && einsaetze.find((x) => x.id === a.einsatz_id);
        return '<tr><td><strong>' + esc(Q.name(m)) + '</strong><br><small style="color:var(--muted)">' + H.datum(a.datum) + ' · ' + esc(a.taetigkeit || '') + (ein ? ' · per QR beim Einsatz' : ' · selbst gemeldet') + '</small></td>' +
          '<td class="r nw"><input class="suche std" type="number" step="0.5" min="0.5" max="12" value="' + a.stunden + '" aria-label="Stunden" style="width:76px;min-width:0"> Std.</td>' +
          '<td class="r nw"><button class="btn klein gruen" data-ok="' + a.id + '">Bestätigen</button> <button class="btn klein gefahr" data-ab="' + a.id + '">Ablehnen</button></td></tr>'; }).join('') + '</tbody></table></div>' : '') +
      regeln +
      '<div class="panel"><h2>Arbeitseinsätze</h2>' + (einsaetze.length ? '<table class="tab"><tbody>' + einsaetze.map((x) => { const n = d.arbeitsdienst.filter((a) => a.einsatz_id === x.id && a.status !== 'abgelehnt').length;
        return '<tr' + (x.datum < heute ? ' class="blass"' : '') + '><td class="nw"><strong>' + H.datum(x.datum) + '</strong>' + (x.datum === heute ? ' <span class="tag gruen">heute</span>' : '') + '<br><small style="color:var(--muted)">' + esc([x.beginn, x.ende].filter(Boolean).join('–')) + '</small></td><td>' + esc(x.titel) + (x.bereich_id && bereichName(x.bereich_id) ? ' <span class="tag">' + esc(bereichName(x.bereich_id)) + '</span>' : '') + '<br><small style="color:var(--muted)">' + H.zahl(x.stunden, x.stunden % 1 ? 1 : 0) + ' Std. · Code ' + esc(codeVon(x.id)) + ' · ' + n + ' Check-in' + (n === 1 ? '' : 's') + '</small></td>' +
          '<td class="r aktion"><button class="btn klein" data-plakat="' + x.id + '">QR-Plakat</button> ' + zeilenMenue(['<button class="zm-punkt gefahr" data-einsatz-weg="' + x.id + '">Einsatz löschen</button>']) + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="leer">Noch keine Arbeitseinsätze geplant.</p>') +
      '<p class="hinweis" style="margin-top:10px">Am Einsatztag das QR-Plakat aushängen: Mitglieder scannen, melden sich in „Mein SSV“ an und tragen ihre Stunden ein. Der Code gilt nur am Einsatztag; bestätigt wird hier oben.</p></div>' +
      '<div class="panel"><h2>Stundenstand</h2><div class="filter ad-filter"><div class="ab-modus ad-modus" role="tablist" aria-label="Stundenstand filtern">' +
        [['fehlt', 'Fehlen noch'], ['erfuellt', 'Erfüllt'], ['alle', 'Alle']].map(([k, n]) => '<button type="button" role="tab" aria-selected="' + (adStand.filter === k) + '" class="' + (adStand.filter === k ? 'aktiv' : '') + '" data-ad-filter="' + k + '"' + (k === 'erfuellt' ? ' title="Soll erfüllt oder befreit"' : '') + '>' + n + ' <span class="zahl-leise">' + zahl[k] + '</span></button>').join('') + '</div>' +
        '<input id="ad-such" class="suche" type="search" placeholder="Name suchen …" value="' + esc(adStand.such) + '" aria-label="Mitglied suchen"></div>' +
      (sichtbar.length ? '<table class="tab ad-stand"><thead><tr><th>Mitglied</th><th class="r">bestätigt</th>' + (e.arbeitsdienst_vorjahr ? '<th class="r">Rest Vorjahr</th>' : '') + '<th class="r">Fehlstunden</th>' + (satz ? '<th class="r">Ersatz</th>' : '') + '<th>Stand</th></tr></thead><tbody>' +
      sichtbar.map(({ m, a }) =>
        '<tr class="klickbar" data-m="' + m.id + '" data-such="' + esc(norm(Q.name(m) + ' ' + m.vorname + ' ' + (m.nr || ''))) + '"><td>' + esc(Q.name(m)) + (bereicheVon(m.id).length ? '<br><small style="color:var(--muted)">' + esc(bereicheVon(m.id).map((x) => x.b.name + (x.z.rolle === 'leitung' ? ' (Leitung)' : '')).join(', ')) + '</small>' : '') + '</td><td class="r">' + H.zahl(a.ist, a.ist % 1 ? 1 : 0) + ' Std.' + (a.gemeldet ? '<br><small style="color:var(--muted)">+' + H.zahl(a.gemeldet, a.gemeldet % 1 ? 1 : 0) + ' gemeldet</small>' : '') + '</td>' + (e.arbeitsdienst_vorjahr ? '<td class="r">' + (a.vorjahr || '–') + '</td>' : '') +
        '<td class="r">' + (a.befreit ? '–' : H.zahl(a.fehl, a.fehl % 1 ? 1 : 0)) + '</td>' + (satz ? '<td class="r">' + (a.fehl && !a.befreit ? H.geld(a.fehl * satz) : '') + '</td>' : '') +
        '<td>' + (a.befreit ? '<span class="tag">befreit: ' + esc(a.befreit) + '</span>' : mahn && a.fehl >= mahn ? '<span class="tag rot">Aufforderung</span>' : a.fehl > 0 ? '<span class="tag warn">offen</span>' : '<span class="tag ok">erfüllt</span>') + '</td></tr>').join('') + '</tbody></table><p class="leer" id="ad-nichts" hidden>Niemand gefunden.</p>'
        : '<p class="leer">' + leerText[adStand.filter] + '</p>') +
      '<p class="hinweis" style="margin-top:10px">Befreiung je Mitglied: in der Zeile tippen und unter „Arbeitsdienst befreit“ den Grund eintragen.</p></div>';
    main.querySelectorAll('[data-ad-filter]').forEach((x) => x.addEventListener('click', () => { adStand.filter = x.dataset.adFilter; zeige(tab, true); }));
    const as = $('#ad-such'); const suchen = () => { adStand.such = as.value; const q = norm(as.value).split(' ').filter(Boolean); let n = 0;
      main.querySelectorAll('.ad-stand tbody tr').forEach((r) => { r.hidden = q.length > 0 && !q.every((w) => r.dataset.such.includes(w)); if (!r.hidden) n++; });
      const nx = $('#ad-nichts'); if (nx) nx.hidden = n > 0; };
    as.addEventListener('input', suchen); if (adStand.such) suchen();
    main.querySelectorAll('[data-sprung]').forEach((z) => z.addEventListener('click', () => { sprung = z.dataset.sprung; }, true));
    main.querySelectorAll('[data-ok],[data-ab]').forEach((bt) => bt.addEventListener('click', () => {
      const a = d.arbeitsdienst.find((x) => x.id === (bt.dataset.ok || bt.dataset.ab)); const std = Number(bt.closest('tr').querySelector('input.std').value);
      if (bt.dataset.ok && !(std > 0 && std <= 12)) return toast('Bitte 0,5 bis 12 Stunden.', 'fehler');
      const ein = a.einsatz_id && (d.arbeitseinsaetze || []).find((x) => x.id === a.einsatz_id);
      Object.assign(a, { status: bt.dataset.ok ? 'bestaetigt' : 'abgelehnt', stunden: bt.dataset.ok ? std : a.stunden, geprueft_von: ROLLEN[rolle].name, bereich_id: a.bereich_id || (ein && ein.bereich_id) || null });
      speichern(bt.dataset.ok ? 'Bestätigt.' : 'Abgelehnt.'); zeige(tab);
    }));
    main.querySelectorAll('[data-plakat]').forEach((bt) => bt.addEventListener('click', () => oeffnen('drucken.html?art=einsatz&id=' + bt.dataset.plakat)));
    main.querySelectorAll('[data-einsatz-weg]').forEach((bt) => bt.addEventListener('click', () => {
      if (!confirm('Arbeitseinsatz löschen? Bereits gemeldete Stunden bleiben erhalten.')) return;
      d.arbeitsdienst.forEach((a) => { if (a.einsatz_id === bt.dataset.einsatzWeg) a.einsatz_id = null; });
      d.arbeitseinsatz_codes = d.arbeitseinsatz_codes.filter((c) => c.einsatz_id !== bt.dataset.einsatzWeg); d.arbeitseinsaetze = d.arbeitseinsaetze.filter((x) => x.id !== bt.dataset.einsatzWeg);
      speichern('Gelöscht.'); zeige(tab);
    }));
    $('#einsatz-neu').addEventListener('click', () => {
      const el = modal('<h2>Arbeitseinsatz planen</h2><form id="f" class="form"><label class="feld voll">Was?<input name="titel" required maxlength="100" placeholder="z. B. Winterarbeitsdienst: Steg und Gelände"></label>' +
        '<label class="feld">Datum<input name="datum" type="date" required value="' + heute + '"></label><label class="feld">Stunden (Vorschlag)<input name="stunden" type="number" step="0.5" min="0.5" max="12" required value="4"></label>' +
        '<label class="feld">Beginn<input name="beginn" type="time" value="09:00"></label><label class="feld">Ende<input name="ende" type="time" value="13:00"></label><label class="feld voll">Hinweis<input name="notiz" placeholder="z. B. Treffpunkt Messe, Arbeitshandschuhe mitbringen"></label>' +
        ((d.arbeitsbereiche || []).length ? '<label class="feld voll">Arbeitsbereich<select name="bereich_id">' + bereichOpt('') + '</select><small>Stunden aus diesem Einsatz zählen dann für den Bereich.</small></label>' : '') + '</form>' +
        '<p class="hinweis">Mitglieder sehen den Termin in „Mein SSV“. Zum Check-in gibt es ein QR-Plakat mit Code, der nur am Einsatztag gilt.</p><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Anlegen</button></div>');
      $('#ok', el).addEventListener('click', () => {
        const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm));
        const id = H.uid('E'); const zeichen = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let code = ''; const zz = crypto.getRandomValues(new Uint32Array(6)); zz.forEach((n) => { code += zeichen[n % zeichen.length]; });
        d.arbeitseinsaetze.push({ id, datum: x.datum, titel: x.titel, beginn: x.beginn, ende: x.ende, stunden: H.dez(x.stunden), notiz: x.notiz, erstellt_von: ROLLEN[rolle].name, bereich_id: x.bereich_id || null });
        d.arbeitseinsatz_codes.push({ einsatz_id: id, code });
        speichern('Arbeitseinsatz angelegt – QR-Plakat drucken und am Einsatztag aushängen.'); zu(); zeige(tab);
      });
    });
    main.querySelectorAll('[data-m]').forEach((r) => r.addEventListener('click', () => mitgliedAkte(Q.mitglied(r.dataset.m))));
    $('#neu').addEventListener('click', () => {
      const el = modal('<h2>Arbeitsstunden</h2><form id="f" class="form"><label class="feld voll">Mitglied<select name="mitglied_id" required>' + mOpt(null, (m) => m.art === 'ausuebend' || m.art === 'probe') + '</select></label><label class="feld">Datum<input name="datum" type="date" required value="' + heute + '"></label><label class="feld">Stunden<input name="stunden" type="number" step="0.5" min="0.5" required value="4"></label><label class="feld voll">Tätigkeit<input name="taetigkeit" placeholder="z. B. Einlagern, Steg-Wartung"></label>' +
        ((d.arbeitsbereiche || []).length ? '<label class="feld voll">Arbeitsbereich<select name="bereich_id" id="ad-bereich">' + bereichOpt('') + '</select></label>' : '') + '</form><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Erfassen</button></div>');
      // Bereich des Mitglieds vorschlagen (bei mehreren den ersten)
      const mw = $('[name=mitglied_id]', el), bw = $('#ad-bereich', el);
      const vorschlag = () => { if (!bw) return; const b0 = bereicheVon(mw.value)[0]; bw.value = b0 ? b0.b.id : ''; };
      if (mw) { mw.addEventListener('change', vorschlag); vorschlag(); }
      $('#ok', el).addEventListener('click', () => { const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm)); d.arbeitsdienst.push({ id: H.uid('AD'), ...x, stunden: H.dez(x.stunden), bereich_id: x.bereich_id || null, status: 'bestaetigt', einsatz_id: null, gemeldet: null, geprueft_von: ROLLEN[rolle].name }); speichern('Erfasst.'); zu(); zeige(tab); });
    });
  };

  /* ============================================================ Arbeitsbereiche (Kran, Boote fahren, Lager, Steg …) */
  // Jeder Bereich hat eine Leitung, Mitglieder und eine Aufgabenliste; Stunden und Einsätze können einem Bereich zugeordnet werden.
  const bereiche = () => (d.arbeitsbereiche || []).slice().sort((a, b) => (a.sort || 0) - (b.sort || 0) || a.name.localeCompare(b.name, 'de'));
  const teamVon = (bid) => (d.arbeitsbereich_mitglieder || []).filter((z) => z.bereich_id === bid && Q.mitglied(z.mitglied_id))
    .sort((a, b) => (a.rolle === 'leitung' ? 0 : 1) - (b.rolle === 'leitung' ? 0 : 1) || Q.name(Q.mitglied(a.mitglied_id)).localeCompare(Q.name(Q.mitglied(b.mitglied_id)), 'de'));
  const bereichName = (bid) => { const b = (d.arbeitsbereiche || []).find((x) => x.id === bid); return b ? b.name : ''; };
  const bereicheVon = (mid) => (d.arbeitsbereich_mitglieder || []).filter((z) => z.mitglied_id === mid).map((z) => ({ z, b: (d.arbeitsbereiche || []).find((x) => x.id === z.bereich_id) })).filter((x) => x.b);
  const bereichOpt = (sel) => '<option value="">– ohne Bereich –</option>' + bereiche().filter((b) => b.aktiv !== false || b.id === sel).map((b) => '<option value="' + b.id + '"' + (b.id === sel ? ' selected' : '') + '>' + esc(b.name) + '</option>').join('');
  const stdBereich = (bid) => d.arbeitsdienst.filter((a) => a.bereich_id === bid && a.status !== 'abgelehnt' && a.status !== 'eingereicht' && String(a.datum).startsWith(String(SAISON))).reduce((s, a) => s + Number(a.stunden || 0), 0);
  // Aufgaben einer Gruppe: art 'aufgabe' (Standard) oder 'besorgen' (Einkaufsliste); erledigt = Datum oder ''
  const istBesorgen = (a) => a.art === 'besorgen';
  const offenZahl = (b) => (b.aufgaben || []).filter((a) => !istBesorgen(a) && !a.erledigt).length;
  const abStand = { modus: 'gruppen', gruppe: '', status: 'offen', such: '' };
  V.arbeitsbereiche = (main) => {
    const liste = bereiche();
    const pflichtig = d.mitglieder.filter((m) => (m.art === 'ausuebend' || m.art === 'probe') && Q.istMitglied(m, heute));
    const ohne = pflichtig.filter((m) => !bereicheVon(m.id).length && !G.arbeitsdienst(d, SAISON, m).befreit);
    const offenGesamt = liste.reduce((s, b) => s + offenZahl(b), 0);
    const besorgenGesamt = liste.reduce((s, b) => s + (b.aufgaben || []).filter((a) => istBesorgen(a) && !a.erledigt).length, 0);
    const umschalter = '<div class="ab-modus" role="tablist">' + [['gruppen', 'Gruppen', liste.filter((b) => b.aktiv !== false).length],   /* nur aktive Gruppen – wie im Ausdruck */ ['liste', 'Aufgabenliste', offenGesamt], ['einkauf', 'Einkaufsliste', besorgenGesamt]].map(([k, n, z]) =>
      '<button type="button" role="tab" aria-selected="' + (abStand.modus === k) + '" class="' + (abStand.modus === k ? 'aktiv' : '') + '" data-ab-modus="' + k + '">' + n + (z ? ' <span class="zahl-leise">' + z + '</span>' : '') + '</button>').join('') + '</div>';
    // Gruppen: seltene Knöpfe („Alle als PDF“, „Zuordnung aus Excel“) im Menü „Weitere“
    const weitere = '<span class="zm"><button type="button" class="btn zm-knopf zm-text" id="ab-weitere" aria-haspopup="true" aria-expanded="false">Weitere ▾</button><span class="zm-liste" role="menu" hidden>' +
      (liste.length ? '<button class="zm-punkt" id="ab-alle">Alle Gruppen als PDF</button>' : '') + '<button class="zm-punkt" id="ab-import">Zuordnung aus Excel</button></span></span>';
    const knoepfe = abStand.modus === 'gruppen' ? weitere + '<button class="btn primaer" id="ab-neu">+ Gruppe</button>'
      : abStand.modus === 'liste' ? '<button class="btn" id="ab-druck">Als PDF</button><button class="btn primaer" id="ab-aufgabe">+ Aufgabe</button>'
      : '<button class="btn" id="ab-druck">Als PDF</button><button class="btn primaer" id="ab-kauf">+ Eintrag</button>';
    main.innerHTML = kopf('Arbeitsgruppen', 'Wer kümmert sich um was? Gruppen mit Leitung, Mitgliedern und Aufgaben – als Gesamtliste zum Abhaken und je Gruppe als PDF.', knoepfe) + umschalter +
      (abStand.modus === 'gruppen' ? gruppenHtml(liste, ohne) : abStand.modus === 'liste' ? listeHtml(liste) : einkaufHtml(liste));
    main.querySelectorAll('[data-ab-modus]').forEach((x) => x.addEventListener('click', () => { abStand.modus = x.dataset.abModus; zeige(tab, true); }));
    const an = (id, fn) => { const x = $(id); if (x) x.addEventListener('click', fn); };
    an('#ab-neu', () => bereichForm(null)); an('#ab-import', importForm);
    an('#ab-alle', () => oeffnen('drucken.html?art=bereiche'));
    an('#ab-druck', () => oeffnen('drucken.html?art=' + (abStand.modus === 'liste' ? 'aufgabenliste&status=' + abStand.status + (abStand.gruppe ? '&id=' + abStand.gruppe : '') : 'einkauf')));
    an('#ab-aufgabe', () => neueAufgabe('aufgabe')); an('#ab-kauf', () => neueAufgabe('besorgen'));
    main.querySelectorAll('[data-ab-gruppe]').forEach((x) => x.addEventListener('click', () => gruppeAkte(d.arbeitsbereiche.find((b) => b.id === x.dataset.abGruppe))));
    an('#ab-ohne-auf', () => ohneDialog());
    // Aufgabenliste: Filter, abhaken, verschieben
    const fg = $('#ab-f-gruppe'); if (fg) fg.addEventListener('change', () => { abStand.gruppe = fg.value; zeige(tab, true); });
    const fs = $('#ab-f-status'); if (fs) fs.addEventListener('change', () => { abStand.status = fs.value; zeige(tab, true); });
    const fq = $('#ab-f-such'); if (fq) fq.addEventListener('input', () => { abStand.such = fq.value; main.querySelectorAll('[data-such]').forEach((r) => { r.hidden = abStand.such && !r.dataset.such.includes(abStand.such.toLowerCase()); }); });
    main.querySelectorAll('[data-erl]').forEach((c) => c.addEventListener('change', () => {
      const [bid, i] = c.dataset.erl.split('|'); const a = d.arbeitsbereiche.find((x) => x.id === bid).aufgaben[Number(i)];
      a.erledigt = c.checked ? heute : ''; speichern(c.checked ? (istBesorgen(a) ? 'Als besorgt abgehakt.' : 'Erledigt – danke!') : 'Wieder offen.'); zeige(tab, true);
    }));
    main.querySelectorAll('[data-schieb]').forEach((s) => s.addEventListener('change', () => {
      const [bid, i] = s.dataset.schieb.split('|'); const von = d.arbeitsbereiche.find((x) => x.id === bid), nach = d.arbeitsbereiche.find((x) => x.id === s.value); if (!nach || von === nach) return;
      const [a] = von.aufgaben.splice(Number(i), 1); nach.aufgaben = (nach.aufgaben || []).concat([a]); speichern('Nach „' + nach.name + '“ verschoben.'); zeige(tab, true);
    }));
    main.querySelectorAll('[data-a-bearb]').forEach((x) => x.addEventListener('click', () => bereichForm(d.arbeitsbereiche.find((b) => b.id === x.dataset.aBearb))));
    if (fq && abStand.such) fq.dispatchEvent(new Event('input'));
  };
  // Gruppen als Liste: eine Zeile je Gruppe (Leitung, offene Aufgaben, Stunden) – ein Klick öffnet die Gruppe
  const ohneGruppe = () => d.mitglieder.filter((m) => (m.art === 'ausuebend' || m.art === 'probe') && Q.istMitglied(m, heute) && !bereicheVon(m.id).length && !G.arbeitsdienst(d, SAISON, m).befreit)
    .sort((a, b) => a.nachname.localeCompare(b.nachname, 'de'));
  function gruppenHtml(liste, ohne) {
    return (ohne.length ? '<div class="hinweis ab-ohne-zeile"><span><strong>Noch ohne Gruppe (' + ohne.length + '):</strong> ' + (ohne.length === 1 ? 'ein arbeitspflichtiges Mitglied ist' : ohne.length + ' arbeitspflichtige Mitglieder sind') + ' noch keiner Gruppe zugeordnet.</span><button class="btn klein" id="ab-ohne-auf">Zuordnen</button></div>' : '') +
      '<div class="panel">' + (liste.length ? '<table class="tab ab-gruppen"><tbody>' + liste.map((b) => {
      const team = teamVon(b.id); const leit = team.filter((z) => z.rolle === 'leitung').map((z) => Q.name(Q.mitglied(z.mitglied_id)));
      const std = stdBereich(b.id); const auf = (b.aufgaben || []).filter((a) => !istBesorgen(a)); const offen = auf.filter((a) => !a.erledigt);
      return '<tr class="klickbar' + (b.aktiv === false ? ' blass' : '') + '" data-ab-gruppe="' + b.id + '"><td class="ab-g-name"><strong>' + esc(b.name) + '</strong>' + (b.aktiv === false ? ' <span class="tag">ruht</span>' : '') + '</td>' +
        '<td class="ab-g-leit">' + (leit.length ? 'Leitung: ' + esc(leit.join(', ')) : '<span class="tag rot">Leitung fehlt</span>') + '<br><small>' + team.length + (team.length === 1 ? ' Mitglied' : ' Mitglieder') + '</small></td>' +
        '<td class="ab-g-auf">' + (auf.length ? (offen.length ? offen.length + ' von ' + auf.length + ' Aufgaben offen' : '✓ alle ' + auf.length + ' Aufgaben erledigt') : '<span class="leer">keine Aufgaben</span>') + '</td>' +
        '<td class="r ab-g-std">' + H.zahl(std, std % 1 ? 1 : 0) + ' Std.<br><small>' + SAISON + '</small></td><td class="r ab-g-pfeil" aria-hidden="true">→</td></tr>';
    }).join('') + '</tbody></table>' : '<p class="leer">Noch keine Arbeitsgruppen. Lege z. B. „Krancrew“, „Brücken & Stege“ an.</p>') + '</div>';
  }
  // Eine Gruppe ansehen: Leitung, Aufgaben, Einkaufsliste, Mitglieder – dazu „Als PDF“, „Mitglieder“ und „Bearbeiten“
  function gruppeAkte(b) {
    if (!b) return;
    const team = teamVon(b.id); const auf = (b.aufgaben || []).filter((a) => !istBesorgen(a)); const offen = auf.filter((a) => !a.erledigt);
    const kauf = (b.aufgaben || []).filter((a) => istBesorgen(a) && !a.erledigt); const std = stdBereich(b.id);
    const leit = team.filter((z) => z.rolle === 'leitung').map((z) => Q.mitglied(z.mitglied_id));
    const el = modal('<h2>' + esc(b.name) + (b.aktiv === false ? ' <span class="tag">ruht</span>' : '') + '</h2>' + (b.beschreibung ? '<p class="ab-text" style="margin-top:0">' + esc(b.beschreibung) + '</p>' : '') +
      '<dl class="ab-akte-dl"><dt>Leitung</dt><dd>' + (leit.length ? leit.map((m) => esc(Q.name(m)) + (m.tel ? ' · <a href="tel:' + esc(m.tel) + '">' + esc(m.tel) + '</a>' : '')).join('<br>') : '<span class="tag rot">fehlt</span>') + '</dd>' +
        (b.treffpunkt ? '<dt>Treffpunkt</dt><dd>' + esc(b.treffpunkt) + '</dd>' : '') +
        '<dt>Stunden ' + SAISON + '</dt><dd>' + H.zahl(std, std % 1 ? 1 : 0) + ' Std. bestätigt</dd></dl>' +
      '<div class="akte-teil"><h3>Offene Aufgaben (' + offen.length + (auf.length ? ' von ' + auf.length : '') + ')</h3>' +
        (offen.length ? '<ul class="ab-aufgaben">' + offen.map((a) => '<li>' + esc(a.titel) + (a.zeitraum ? ' <small>· ' + esc(a.zeitraum) + '</small>' : '') + '</li>').join('') + '</ul>'
          : '<p class="leer">' + (auf.length ? '✓ Alle Aufgaben erledigt.' : 'Noch keine Aufgaben.') + '</p>') +
        (offen.length ? '<p style="margin:6px 0 0"><button type="button" class="link-knopf" id="ga-liste">In der Aufgabenliste abhaken →</button></p>' : '') + '</div>' +
      (kauf.length ? '<div class="akte-teil"><h3>Einkaufsliste (' + kauf.length + ')</h3><ul class="ab-aufgaben">' + kauf.map((a) => '<li>' + esc(a.titel) + '</li>').join('') + '</ul></div>' : '') +
      '<div class="akte-teil"><h3>Mitglieder (' + team.length + ')</h3>' + (team.length ? '<p class="ab-text" style="margin:0">' + team.map((z) => esc(Q.name(Q.mitglied(z.mitglied_id))) + (z.rolle === 'leitung' ? ' (Leitung)' : '')).join(', ') + '</p>' : '<p class="leer">Noch niemand in dieser Gruppe.</p>') + '</div>' +
      '<div class="modal-fuss"><button class="btn links" data-ab-pdf="' + b.id + '" title="Gruppenblatt als PDF">Als PDF</button><button class="btn" data-ab-team="' + b.id + '">Mitglieder</button><button class="btn primaer" data-ab-edit="' + b.id + '">Gruppe & Aufgaben bearbeiten</button></div>', true);
    $('[data-ab-pdf]', el).addEventListener('click', () => oeffnen('drucken.html?art=bereiche&id=' + b.id));
    $('[data-ab-team]', el).addEventListener('click', () => teamForm(b));
    $('[data-ab-edit]', el).addEventListener('click', () => bereichForm(b));
    const gl = $('#ga-liste', el); if (gl) gl.addEventListener('click', () => { zu(); abStand.modus = 'liste'; abStand.gruppe = b.id; abStand.status = 'offen'; zeige(tab, true); });
  }
  // „Noch ohne Gruppe“: Namen antippen und zuordnen; danach geht es hierher zurück, solange noch jemand übrig ist
  function ohneDialog() {
    const ohne = ohneGruppe(); if (!ohne.length) { zu(); return; }
    const el = modal('<h2>Noch ohne Gruppe (' + ohne.length + ')</h2><p style="margin-top:0">Arbeitspflichtige Mitglieder, die noch keiner Gruppe zugeordnet sind – Namen antippen, um zuzuordnen.</p><div class="ab-chips">' +
      ohne.map((m) => '<button class="chip-btn" data-ab-ohne="' + m.id + '">' + esc(Q.name(m)) + '</button>').join('') + '</div>' +
      '<div class="modal-fuss"><button class="btn links" id="ohne-import">Viele auf einmal: Zuordnung aus Excel</button><button class="btn primaer" data-zu>Fertig</button></div>', true);
    el.querySelectorAll('[data-ab-ohne]').forEach((x) => x.addEventListener('click', () => zuordnenForm(Q.mitglied(x.dataset.abOhne), ohneDialog)));
    $('#ohne-import', el).addEventListener('click', importForm);
  }
  // Gesamtliste wie die Excel-Aktionsliste: alle Aufgaben aller Gruppen, abhaken, verschieben
  function listeHtml(liste) {
    const zeilen = []; liste.forEach((b) => (b.aufgaben || []).forEach((a, i) => { if (istBesorgen(a)) return; if (abStand.gruppe && b.id !== abStand.gruppe) return;
      if (abStand.status === 'offen' && a.erledigt) return; if (abStand.status === 'erledigt' && !a.erledigt) return; zeilen.push({ b, a, i }); }));
    const opt = (sel) => liste.map((b) => '<option value="' + b.id + '"' + (b.id === sel ? ' selected' : '') + '>' + esc(b.name) + '</option>').join('');
    return '<div class="panel"><div class="filter ab-filter"><select id="ab-f-gruppe" aria-label="Gruppe"><option value="">Alle Gruppen</option>' + opt(abStand.gruppe) + '</select>' +
      '<select id="ab-f-status" aria-label="Stand">' + [['offen', 'offen'], ['erledigt', 'erledigt'], ['alle', 'alle']].map(([k, n]) => '<option value="' + k + '"' + (abStand.status === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>' +
      '<input id="ab-f-such" class="suche" type="search" placeholder="Aufgabe suchen …" value="' + esc(abStand.such) + '" aria-label="Aufgabe suchen"><span class="ab-anzahl">' + zeilen.length + ' Aufgaben</span></div>' +
      (zeilen.length ? '<table class="tab ab-liste"><thead><tr><th class="ab-ck">✓</th><th>Aufgabe</th><th>Gruppe</th><th>erledigt</th></tr></thead><tbody>' + zeilen.map(({ b, a, i }) =>
        '<tr data-such="' + esc((a.titel + ' ' + (a.hinweis || '') + ' ' + b.name).toLowerCase()) + '"' + (a.erledigt ? ' class="blass"' : '') + '><td class="ab-ck"><input type="checkbox" data-erl="' + b.id + '|' + i + '"' + (a.erledigt ? ' checked' : '') + ' aria-label="erledigt: ' + esc(a.titel) + '"></td>' +
        '<td><strong>' + esc(a.titel) + '</strong>' + (a.zeitraum || a.hinweis ? '<br><small style="color:var(--muted)">' + esc([a.zeitraum, a.hinweis].filter(Boolean).join(' · ')) + '</small>' : '') + '</td>' +
        '<td><select data-schieb="' + b.id + '|' + i + '" aria-label="Gruppe ändern" class="ab-schieb">' + opt(b.id) + '</select></td><td class="nw">' + (a.erledigt ? H.kurz(a.erledigt) : '') + '</td></tr>').join('') + '</tbody></table>'
        : '<p class="leer">' + (abStand.status === 'offen' ? 'Keine offenen Aufgaben – alles erledigt.' : 'Keine Aufgaben für diese Auswahl.') + '</p>') +
      '<p class="hinweis" style="margin-top:10px">Abhaken trägt das heutige Datum ein. Über die Gruppe rechts lässt sich eine Aufgabe in eine andere Gruppe verschieben. Bearbeiten, Wann und Richtwert-Stunden: unter „Gruppen“ → „Gruppe & Aufgaben“.</p></div>';
  }
  function einkaufHtml(liste) {
    const gruppen = liste.map((b) => ({ b, k: (b.aufgaben || []).map((a, i) => ({ a, i })).filter((x) => istBesorgen(x.a)) })).filter((x) => x.k.length);
    return gruppen.length ? '<div class="ab-karten">' + gruppen.map(({ b, k }) => '<div class="panel ab-karte"><h2>' + esc(b.name) + '</h2><ul class="ab-kauf">' + k.map(({ a, i }) =>
      '<li' + (a.erledigt ? ' class="blass"' : '') + '><label><input type="checkbox" data-erl="' + b.id + '|' + i + '"' + (a.erledigt ? ' checked' : '') + '> <span>' + esc(a.titel) + '</span></label>' + (a.erledigt ? ' <small>besorgt ' + H.kurz(a.erledigt) + '</small>' : '') + '</li>').join('') + '</ul></div>').join('') + '</div>'
      : '<div class="panel"><p class="leer">Die Einkaufsliste ist leer. Mit „+ Eintrag“ etwas hinzufügen.</p></div>';
  }
  // Neue Aufgabe oder neuer Einkaufslisten-Eintrag (Gruppe wählen)
  function neueAufgabe(art) {
    const kauf = art === 'besorgen';
    const el = modal('<h2>' + (kauf ? 'Auf die Einkaufsliste' : 'Neue Aufgabe') + '</h2><form id="f" class="form"><label class="feld voll">' + (kauf ? 'Was wird gebraucht?' : 'Aufgabe') + '<input name="titel" required maxlength="140" placeholder="' + (kauf ? 'z. B. 2 × 10 l Betonfarbe grau' : 'z. B. Rettungsleitern montieren') + '"></label>' +
      '<label class="feld">Gruppe<select name="gruppe" required>' + bereiche().map((b) => '<option value="' + b.id + '"' + (b.id === abStand.gruppe ? ' selected' : '') + '>' + esc(b.name) + '</option>').join('') + '</select></label>' +
      (kauf ? '' : '<label class="feld">Wann (optional)<input name="zeitraum" maxlength="40" placeholder="z. B. vor dem Auslagern"></label>') + '<label class="feld voll">Hinweis (optional)<input name="hinweis" maxlength="160"></label></form>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Hinzufügen</button></div>');
    $('#ok', el).addEventListener('click', () => { const f = $('#f', el); if (!f.reportValidity()) return; const b = d.arbeitsbereiche.find((x) => x.id === f.gruppe.value);
      b.aufgaben = (b.aufgaben || []).concat([{ titel: f.titel.value.trim(), zeitraum: f.zeitraum ? f.zeitraum.value.trim() : '', stunden: null, hinweis: f.hinweis.value.trim(), pos: null, art, erledigt: '' }]);
      speichern('Hinzugefügt.'); zu(); zeige(tab, true); });
  }
  // Viele Mitglieder auf einmal zuordnen: Zeilen aus Excel einfügen (Name ; Gruppe ; Leitung)
  function importForm() {
    const el = modal('<h2>Zuordnung aus Excel</h2><p style="margin-top:0">In Excel die Spalten <strong>Name</strong> und <strong>Gruppe</strong> (optional dritte Spalte „Leitung“) markieren, kopieren und hier einfügen. Name als „Vorname Nachname“, „Nachname, Vorname“ oder Mitgliedsnummer. Gruppe reicht als Anfang des Namens (z. B. „Kran“) oder als Nummer 1–' + bereiche().length + '.</p>' +
      '<textarea id="imp-text" rows="8" placeholder="Anna Albers&#9;Krancrew&#9;Leitung&#10;Brandt, Dirk&#9;Brücken"></textarea><div id="imp-vorschau"></div>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok" disabled>Übernehmen</button></div>', true);
    const norm = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ß/g, 'ss').replace(/[^a-z0-9]+/g, ' ').trim();
    const nachName = new Map(); d.mitglieder.forEach((m) => { [m.vorname + ' ' + m.nachname, m.nachname + ' ' + m.vorname, String(m.nr || '')].forEach((k) => { const n = norm(k); if (n) nachName.set(n, (nachName.get(n) || []).concat([m])); }); });
    const liste = bereiche(); let treffer = [];
    const finde = (g) => { const n = norm(g); if (!n) return null; if (/^\d+$/.test(n)) return liste[Number(n) - 1] || null; return liste.find((b) => norm(b.name) === n) || liste.find((b) => norm(b.name).startsWith(n)) || liste.find((b) => norm(b.name).includes(n)) || null; };
    $('#imp-text', el).addEventListener('input', (e) => {
      treffer = e.target.value.split(/\r?\n/).map((z) => z.trim()).filter(Boolean).map((z) => { const t = z.split(/\t|;/).map((x) => x.trim()); const ms = nachName.get(norm(t[0])) || [];
        return { z, m: ms.length === 1 ? ms[0] : null, mehrdeutig: ms.length > 1, b: finde(t[1]), leitung: /leit|chef|obmann/i.test(t[2] || '') }; });
      const ok = treffer.filter((x) => x.m && x.b); const neu = ok.filter((x) => !(d.arbeitsbereich_mitglieder || []).some((y) => y.mitglied_id === x.m.id && y.bereich_id === x.b.id));
      $('#imp-vorschau', el).innerHTML = treffer.length ? '<p><strong>' + ok.length + ' von ' + treffer.length + '</strong> Zeilen erkannt' + (ok.length - neu.length ? ', davon ' + (ok.length - neu.length) + ' schon zugeordnet' : '') + '.</p><table class="tab"><tbody>' +
        treffer.slice(0, 200).map((x) => '<tr><td>' + esc(x.z.replace(/\t/g, ' · ')) + '</td><td>' + (x.m ? '✓ ' + esc(Q.name(x.m)) : '<span class="tag warn">' + (x.mehrdeutig ? 'Name mehrdeutig' : 'Mitglied nicht gefunden') + '</span>') + '</td><td>' + (x.b ? '✓ ' + esc(x.b.name) + (x.leitung ? ' (Leitung)' : '') : '<span class="tag warn">Gruppe?</span>') + '</td></tr>').join('') + '</tbody></table>' : '';
      $('#ok', el).disabled = !neu.length; $('#ok', el).textContent = neu.length ? neu.length + ' übernehmen' : 'Übernehmen';
    });
    $('#ok', el).addEventListener('click', () => {
      let n = 0; treffer.filter((x) => x.m && x.b).forEach((x) => { const da = d.arbeitsbereich_mitglieder.find((y) => y.mitglied_id === x.m.id && y.bereich_id === x.b.id);
        if (da) { if (x.leitung) da.rolle = 'leitung'; return; } d.arbeitsbereich_mitglieder.push({ id: H.uid('AM'), bereich_id: x.b.id, mitglied_id: x.m.id, rolle: x.leitung ? 'leitung' : 'mitglied' }); n++; });
      speichern(n + ' Zuordnungen übernommen.'); zu(); zeige(tab, true);
    });
  }
  // Gruppe anlegen/bearbeiten: Aufgaben (abhaken, Wann, Richtwert, Hinweis) und Einkaufsliste
  function bereichForm(b) {
    const neu = !b; const x0 = b || { name: '', beschreibung: '', treffpunkt: '', aufgaben: [], aktiv: true, sort: (d.arbeitsbereiche || []).length };
    const vorher = (x0.aufgaben || []).map((a) => ({ ...a }));   // pos, art usw. bleiben beim Speichern erhalten
    const zeile = (a, k) => '<tr data-k="' + k + '"><td class="ab-ck"><input type="checkbox" name="a_erl"' + (a.erledigt ? ' checked' : '') + ' aria-label="erledigt"></td><td><input name="a_titel" value="' + esc(a.titel || '') + '" placeholder="z. B. Stege prüfen" aria-label="Aufgabe" maxlength="140"></td><td><input name="a_zeitraum" value="' + esc(a.zeitraum || '') + '" placeholder="z. B. April" aria-label="Zeitraum" maxlength="40"></td>' +
      '<td><input name="a_stunden" type="number" step="0.5" min="0" max="99" value="' + (a.stunden == null || a.stunden === '' ? '' : a.stunden) + '" aria-label="Richtwert Stunden" style="width:64px"></td><td><input name="a_hinweis" value="' + esc(a.hinweis || '') + '" placeholder="optional" aria-label="Hinweis" maxlength="160"></td>' +
      '<td class="r"><button type="button" class="btn klein gefahr" data-a-weg title="Entfernen" aria-label="Entfernen">✕</button></td></tr>';
    const kzeile = (a, k) => '<tr data-k="' + k + '"><td class="ab-ck"><input type="checkbox" name="a_erl"' + (a.erledigt ? ' checked' : '') + ' aria-label="besorgt"></td><td><input name="a_titel" value="' + esc(a.titel || '') + '" placeholder="z. B. Warnwesten" aria-label="Was wird gebraucht" maxlength="140"></td><td><input name="a_hinweis" value="' + esc(a.hinweis || '') + '" placeholder="optional" aria-label="Hinweis" maxlength="160"></td>' +
      '<td class="r"><button type="button" class="btn klein gefahr" data-a-weg title="Entfernen" aria-label="Entfernen">✕</button></td></tr>';
    const el = modal('<h2>' + (neu ? 'Neue Arbeitsgruppe' : esc(x0.name)) + '</h2><form id="f" class="form">' +
      '<label class="feld">Name<input name="name" required maxlength="60" value="' + esc(x0.name) + '" placeholder="z. B. Krancrew"></label>' +
      '<label class="feld">Treffpunkt / Hinweise<input name="treffpunkt" maxlength="160" value="' + esc(x0.treffpunkt || '') + '" placeholder="z. B. Kran, nur eingewiesene Mitglieder"></label>' +
      '<label class="feld voll">Worum geht es?<input name="beschreibung" maxlength="240" value="' + esc(x0.beschreibung || '') + '" placeholder="Ein Satz für das Gruppenblatt"></label>' +
      '<label class="feld check voll"><input type="checkbox" name="aktiv"' + (x0.aktiv !== false ? ' checked' : '') + '> Gruppe ist aktiv (ruhende Gruppen erscheinen nicht in „Mein SSV“)</label></form>' +
      '<h3 style="margin:16px 0 6px">Aufgaben</h3><div class="ab-scroll"><table class="tab ab-auf-tab"><thead><tr><th class="ab-ck">✓</th><th>Aufgabe</th><th>Wann</th><th>Std.</th><th>Hinweis</th><th></th></tr></thead><tbody id="a-liste">' +
      vorher.map((a, k) => istBesorgen(a) ? '' : zeile(a, k)).join('') + '</tbody></table></div><button type="button" class="btn klein" id="a-neu" style="margin-top:8px">+ Aufgabe</button>' +
      '<h3 style="margin:18px 0 6px">Einkaufsliste</h3><div class="ab-scroll"><table class="tab ab-auf-tab"><thead><tr><th class="ab-ck">✓</th><th>Was wird gebraucht?</th><th>Hinweis</th><th></th></tr></thead><tbody id="k-liste">' +
      vorher.map((a, k) => istBesorgen(a) ? kzeile(a, k) : '').join('') + '</tbody></table></div><button type="button" class="btn klein" id="k-neu" style="margin-top:8px">+ Eintrag</button>' +
      '<p class="hinweis" style="margin-top:10px">✓ = erledigt bzw. besorgt (das Datum wird gemerkt). „Std.“ ist ein Richtwert für die Planung; geleistete Stunden werden unter Arbeitsdienst erfasst.</p>' +
      '<div class="modal-fuss">' + (neu ? '' : '<button class="btn gefahr links" id="weg">Gruppe löschen</button>') + '<button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>', true);
    const liste = $('#a-liste', el), kliste = $('#k-liste', el);
    $('#a-neu', el).addEventListener('click', () => { liste.insertAdjacentHTML('beforeend', zeile({}, -1)); liste.lastElementChild.querySelector('[name=a_titel]').focus(); });
    $('#k-neu', el).addEventListener('click', () => { kliste.insertAdjacentHTML('beforeend', kzeile({}, -1)); kliste.lastElementChild.querySelector('[name=a_titel]').focus(); });
    el.addEventListener('click', (e) => { const w = e.target.closest('[data-a-weg]'); if (w) w.closest('tr').remove(); });
    if (neu) liste.insertAdjacentHTML('beforeend', zeile({}, -1));   // leere erste Zeile, Cursor bleibt im Namensfeld
    const weg = $('#weg', el);
    if (weg) weg.addEventListener('click', () => {
      const n = teamVon(b.id).length; if (!confirm('Gruppe „' + b.name + '“ löschen?' + (n ? ' Die Zuordnung von ' + n + ' Mitgliedern entfällt.' : '') + ' Erfasste Stunden bleiben erhalten (ohne Gruppe).')) return;
      d.arbeitsbereich_mitglieder = d.arbeitsbereich_mitglieder.filter((z) => z.bereich_id !== b.id);
      d.arbeitsdienst.forEach((a) => { if (a.bereich_id === b.id) a.bereich_id = null; }); (d.arbeitseinsaetze || []).forEach((a) => { if (a.bereich_id === b.id) a.bereich_id = null; });
      d.arbeitsbereiche = d.arbeitsbereiche.filter((x) => x.id !== b.id); speichern('Gruppe gelöscht.'); zu(); zeige(tab);
    });
    $('#ok', el).addEventListener('click', () => {
      const f = $('#f', el); if (!f.reportValidity()) return;
      const felder = [...el.querySelectorAll('#a-liste input, #k-liste input')]; if (felder.some((i) => !i.checkValidity())) { const i = felder.find((x) => !x.checkValidity()); i.reportValidity(); return; }
      const lesen = (tr, art) => { const g = (n) => { const i = tr.querySelector('[name="' + n + '"]'); return i ? i.value.trim() : ''; }; const alt = vorher[Number(tr.dataset.k)] || {};
        const st = H.dez(g('a_stunden')); const erl = tr.querySelector('[name=a_erl]').checked;
        return { ...alt, titel: g('a_titel'), zeitraum: art === 'besorgen' ? (alt.zeitraum || '') : g('a_zeitraum'), stunden: art === 'besorgen' ? null : (isNaN(st) ? null : st), hinweis: g('a_hinweis'), art, pos: alt.pos || null, erledigt: erl ? (alt.erledigt || heute) : '' }; };
      const aufgaben = [...liste.querySelectorAll('tr')].map((tr) => lesen(tr, 'aufgabe')).concat([...kliste.querySelectorAll('tr')].map((tr) => lesen(tr, 'besorgen'))).filter((a) => a.titel);
      const name = f.name.value.trim();
      if ((d.arbeitsbereiche || []).some((x) => x.name.toLowerCase() === name.toLowerCase() && (!b || x.id !== b.id))) return toast('Eine Gruppe „' + name + '“ gibt es schon.', 'fehler');
      const daten = { name, beschreibung: f.beschreibung.value.trim(), treffpunkt: f.treffpunkt.value.trim(), aufgaben, aktiv: f.aktiv.checked };
      if (neu) { const nb = { id: H.uid('AB'), sort: x0.sort, ...daten }; d.arbeitsbereiche.push(nb); speichern('Gruppe angelegt – jetzt Mitglieder zuordnen.'); zu(); zeige(tab); teamForm(nb); }
      else { Object.assign(b, daten); speichern('Gespeichert.'); zu(); zeige(tab); }
    });
  }
  // Mitglieder eines Bereichs: hinzufügen (Suche), Leitung festlegen, entfernen
  function teamForm(b) {
    const zeichnen = () => {
      const team = teamVon(b.id); const drin = new Set(team.map((z) => z.mitglied_id));
      const kandidaten = d.mitglieder.filter((m) => !drin.has(m.id) && Q.istMitglied(m, heute) && m.art !== 'foerdernd' && m.art !== 'gast').sort((x, y) => x.nachname.localeCompare(y.nachname, 'de'));
      el.querySelector('#t-inhalt').innerHTML =
        '<div class="ab-suche"><input id="t-such" class="suche" placeholder="Mitglied suchen und hinzufügen …" autocomplete="off" aria-label="Mitglied suchen"><div id="t-treffer" class="ab-treffer" role="listbox"></div></div>' +
        (team.length ? '<table class="tab"><tbody>' + team.map((z) => { const m = Q.mitglied(z.mitglied_id); const andere = bereicheVon(m.id).filter((x) => x.b.id !== b.id).map((x) => x.b.name);
          return '<tr><td><strong>' + esc(Q.name(m)) + '</strong>' + (m.tel ? '<br><small style="color:var(--muted)">' + esc(m.tel) + '</small>' : '') + (andere.length ? '<br><small style="color:var(--muted)">auch: ' + esc(andere.join(', ')) + '</small>' : '') + '</td>' +
            '<td><select data-t-rolle="' + z.id + '" aria-label="Rolle"><option value="mitglied"' + (z.rolle !== 'leitung' ? ' selected' : '') + '>Mitglied</option><option value="leitung"' + (z.rolle === 'leitung' ? ' selected' : '') + '>Leitung</option></select></td>' +
            '<td class="r"><button class="btn klein gefahr" data-t-weg="' + z.id + '">Entfernen</button></td></tr>'; }).join('') + '</tbody></table>' : '<p class="leer">Noch niemand in diesem Bereich.</p>');
      const such = el.querySelector('#t-such'), treffer = el.querySelector('#t-treffer');
      const zeigeTreffer = () => { const q = such.value.trim().toLowerCase(); if (!q) { treffer.innerHTML = ''; return; }
        const t = kandidaten.filter((m) => (m.vorname + ' ' + m.nachname + ' ' + m.nachname + ' ' + (m.nr || '')).toLowerCase().includes(q)).slice(0, 8);
        treffer.innerHTML = t.length ? t.map((m) => '<button type="button" data-t-neu="' + m.id + '">' + esc(Q.name(m)) + ' <small>' + esc(H.ART[m.art] || '') + (bereicheVon(m.id).length ? ' · ' + esc(bereicheVon(m.id).map((x) => x.b.name).join(', ')) : '') + '</small></button>').join('') : '<p class="leer" style="margin:6px 0">Niemand gefunden.</p>'; };
      such.addEventListener('input', zeigeTreffer);
      such.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); const t = treffer.querySelector('[data-t-neu]'); if (t) t.click(); } });
      setTimeout(() => such.focus(), 0);
    };
    const el = modal('<h2>' + esc(b.name) + ': Mitglieder</h2><div id="t-inhalt"></div><p class="hinweis" style="margin-top:12px">Ein Mitglied kann in mehreren Bereichen sein. Die Leitung steht mit Telefonnummer auf dem Bereichsblatt und in „Mein SSV“ der Bereichsmitglieder.</p>' +
      '<div class="modal-fuss"><button class="btn" data-ab-pdf-m>PDF</button><button class="btn primaer" data-zu>Fertig</button></div>', true);
    el.addEventListener('click', (e) => {
      const n = e.target.closest('[data-t-neu]'); if (n) { d.arbeitsbereich_mitglieder.push({ id: H.uid('AM'), bereich_id: b.id, mitglied_id: n.dataset.tNeu, rolle: teamVon(b.id).length ? 'mitglied' : 'leitung' }); speichern('Hinzugefügt.'); zeichnen(); zeige(tab, true); return; }
      const w = e.target.closest('[data-t-weg]'); if (w) { d.arbeitsbereich_mitglieder = d.arbeitsbereich_mitglieder.filter((z) => z.id !== w.dataset.tWeg); speichern('Entfernt.'); zeichnen(); zeige(tab, true); return; }
      if (e.target.closest('[data-ab-pdf-m]')) oeffnen('drucken.html?art=bereiche&id=' + b.id);
    });
    el.addEventListener('change', (e) => { const r = e.target.closest('[data-t-rolle]'); if (!r) return; const z = d.arbeitsbereich_mitglieder.find((x) => x.id === r.dataset.tRolle); z.rolle = r.value; speichern(r.value === 'leitung' ? 'Als Leitung eingetragen.' : 'Gespeichert.'); zeichnen(); zeige(tab, true); });
    zeichnen();
  }
  // Ein Mitglied einem oder mehreren Bereichen zuordnen (aus „Noch ohne Bereich“ oder der Mitgliederkarte)
  function zuordnenForm(m, danach) {
    const meine = new Set(bereicheVon(m.id).map((x) => x.b.id));
    const el = modal('<h2>' + esc(Q.name(m)) + '</h2><p>In welchen Bereichen hilft ' + esc(m.vorname) + ' mit?</p><div class="ab-wahl">' +
      bereiche().filter((b) => b.aktiv !== false).map((b) => '<label class="feld check"><input type="checkbox" value="' + b.id + '"' + (meine.has(b.id) ? ' checked' : '') + '> ' + esc(b.name) + '</label>').join('') + '</div>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>');
    $('#ok', el).addEventListener('click', () => {
      const wahl = new Set([...el.querySelectorAll('.ab-wahl input:checked')].map((i) => i.value));
      d.arbeitsbereich_mitglieder = d.arbeitsbereich_mitglieder.filter((z) => z.mitglied_id !== m.id || wahl.has(z.bereich_id));
      wahl.forEach((bid) => { if (!meine.has(bid)) d.arbeitsbereich_mitglieder.push({ id: H.uid('AM'), bereich_id: bid, mitglied_id: m.id, rolle: teamVon(bid).length ? 'mitglied' : 'leitung' }); });
      speichern('Zugeordnet.'); zu(); zeige(tab, true); if (danach) danach();
    });
  }

  /* ============================================================ Abrechnung */
  const abrStand = { periode: imSommer ? 'sommer' : 'winter', datum: heute, beitragJahr: SAISON + 1, wahl: null, nach: null };   // wahl/nach: welcher Schritt aufgeklappt ist
  // Weg einer Rechnung: Lastschrift = erstellt → zum Einzug vorgemerkt → an die Bank übergeben → bezahlt; Überweisung = erstellt → bezahlt
  const STUFE = { einzug: ['Zum Einzug vorgemerkt', 'warn', 'wartet auf die Lastschrift-Datei'], bank: ['An Bank übergeben', 'gast', 'Einzug läuft – Gutschrift abwarten'], ueberweisung: ['Wartet auf Überweisung', 'warn', 'kein Lastschriftmandat'],
    klaeren: ['Klären', 'rot', 'Rücklastschrift oder überfällig'], bezahlt: ['Bezahlt', 'ok', ''], storniert: ['Storniert', '', ''] };
  function stufe(r) {
    const st = Q.rstatus(r, heute);
    if (st === 'storniert') return 'storniert'; if (st === 'bezahlt') return 'bezahlt'; if (st === 'ruecklastschrift') return 'klaeren';
    if (r.sepa) return r.sepa_lauf ? 'bank' : 'einzug';
    return st === 'ueberfaellig' ? 'klaeren' : 'ueberweisung';
  }
  // kleine Kette ●●○○ in der Tabelle
  function kette(r) {
    const k = stufe(r); if (k === 'storniert') return '';
    const schritte = r.sepa ? ['erstellt', 'zum Einzug', 'an Bank', 'bezahlt'] : ['erstellt', 'Überweisung', 'bezahlt'];
    const bis = k === 'bezahlt' ? schritte.length : r.sepa ? (k === 'einzug' ? 2 : 3) : 2;
    return '<span class="kette' + (k === 'klaeren' ? ' rot' : '') + '" title="' + schritte.map((x, i) => (i < bis ? '✓ ' : '○ ') + x).join(' → ') + '">' + schritte.map((x, i) => '<i' + (i < bis ? ' class="an"' : '') + '></i>').join('') + '</span>';
  }
  let abrLaeuft = false;   // Schutz gegen doppeltes „Rechnungen erstellen“
  const RSTATUS = { offen: ['offen', 'warn'], ueberfaellig: ['überfällig', 'rot'], teilbezahlt: ['teilweise bezahlt', 'warn'], ruecklastschrift: ['Rücklastschrift', 'rot'], bezahlt: ['bezahlt', 'ok'], storniert: ['storniert', 'rot'] };
  /* ============================================================ Finanzen · Auf einen Blick
   * Monat: Was kam rein (nach Zahlungsdatum), was ist offen, was ist zu klären, was ist zu tun.
   * Jahr: „Abgerechnet für [Jahr]“ (nach Abrechnungsjahr) und „Eingänge im Geschäftsjahr“ (nach Zahlungsdatum) – zwei getrennte Tabellen,
   * im Kopf jeder Tabelle ein Satz, wonach gezählt wird. Rechenwege in gebuehren.js (HAFEN_GEBUEHREN.finanz), gleich für Bildschirm und Druck. */
  const FZ = G.finanz;
  const BER = Object.fromEntries(FZ.BEREICHE);
  const finStand = { modus: 'monat', monat: heute.slice(0, 7), jahr: Number(heute.slice(0, 4)) };
  const KASSE = () => (window.SSV && window.SSV.speicher) || null;
  const KASSE_URL = '../ssv-getraenke/kassenwart.html';
  // Getränkekasse lesen: Monatsrechnungen (+ noch nicht abgerechnete Buchungen der letzten Monate). Ohne Kasse: { status: 'aus' }
  function kasseLesen(mitBuchungen) {
    const k = KASSE(); if (!k) return Promise.resolve({ status: 'aus', re: [], bu: [] });
    return Promise.all([k.rechnungen(), mitBuchungen ? k.buchungen({ von: FZ.monatPlus(heute.slice(0, 7), -3) + '-01' }) : Promise.resolve([])])
      .then(([re, bu]) => ({ status: 'ok', re: re || [], bu: bu || [] })).catch((x) => ({ status: 'fehler', fehler: x.message, re: [], bu: [] }));
  }
  function hafenGezahlt(r) {   // Eingänge einer Hafen-/Beitragsrechnung mit Datum (Rücklastschrift zieht ab)
    const z = r.zahlungen || [];
    if (z.length) return z.map((x) => ({ datum: x.datum, betrag: (x.art === 'ruecklastschrift' ? -1 : 1) * Number(x.betrag || 0) }));
    return r.bezahlt_am ? [{ datum: r.bezahlt_am, betrag: Number(r.summe) }] : [];
  }
  const fgeld = (v) => v ? H.geld(v) : '–';
  // Monate/Jahre mit Daten (für die Auswahl)
  function finMonate() {
    const l = new Set([heute.slice(0, 7)]);
    d.rechnungen.forEach((r) => { if (r.datum) l.add(r.datum.slice(0, 7)); hafenGezahlt(r).forEach((z) => l.add(String(z.datum).slice(0, 7))); });
    d.gaeste.forEach((g) => { l.add(g.ankunft.slice(0, 7)); if (g.bezahlt_am) l.add(String(g.bezahlt_am).slice(0, 7)); });
    const a = [...l].filter((m) => /^\d{4}-\d{2}$/.test(m) && m <= heute.slice(0, 7)).sort();
    const r = []; for (let m = FZ.monatPlus(a[0], 0); m <= heute.slice(0, 7); m = FZ.monatPlus(m, 1)) r.push(m);   // lückenlos
    return r.reverse();
  }
  // Was ist diesen Monat zu tun? (höchstens 5, Dringendes zuerst) – je Punkt ein Sprungziel
  function finTodo() {
    const e = d.einstellungen; const l = [];
    const add = (tab, txt, art, extra) => { if (darf(tab)) l.push({ tab, txt, art, extra: extra || '' }); };
    const rueck = d.rechnungen.filter((r) => Q.rstatus(r, heute) === 'ruecklastschrift');
    const ueber = d.rechnungen.filter((r) => Q.rstatus(r, heute) === 'ueberfaellig');
    const gm = d.gaeste.filter((g) => g.zahlung_gemeldet && !g.bezahlt_am && g.status !== 'storniert');
    const pruefen = d.sepa_laeufe.filter((x) => (x.faellig || x.datum) <= heute && d.rechnungen.some((r) => r.sepa_lauf === x.id && !r.storniert_am && Q.rest(r) > 0 && Q.rstatus(r, heute) !== 'ruecklastschrift'));
    const sepaOffen = d.rechnungen.filter((r) => r.sepa && !r.sepa_lauf && Q.rest(r) > 0);
    const ka = e.kontoauszug_zuletzt; const offeneRe = d.rechnungen.filter((r) => Q.rest(r) > 0);
    if (rueck.length) add('rechnungen', rueck.length + ' Rücklastschrift' + (rueck.length > 1 ? 'en' : '') + ' – Mitglied ansprechen oder erneut einziehen', 'rot', 'data-re-filter="ruecklastschrift"');
    if (pruefen.length) add('kontoauszug', 'Lastschrift ' + pruefen.map((x) => esc(x.id)).join(', ') + ': Gutschrift auf dem Konto prüfen', 'warn');
    if (ueber.length) add('rechnungen', ueber.length + (ueber.length === 1 ? ' Rechnung ist' : ' Rechnungen sind') + ' überfällig', 'warn', 'data-re-filter="ueberfaellig"');
    if (gm.length) add('kontoauszug', gm.length + ' Gast-Zahlung' + (gm.length > 1 ? 'en' : '') + ' gemeldet, noch nicht geprüft', 'gast');
    if (!ka || ka < tagVor(heute, 30)) { if (offeneRe.length || d.sepa_laeufe.length) add('kontoauszug', ka ? 'Kontoauszug seit ' + H.datum(ka) + ' nicht abgeglichen' : 'Kontoauszug noch nie eingelesen', 'gast'); }
    if (sepaOffen.length) add('abrechnung', sepaOffen.length + ' Rechnungen warten auf die Lastschrift-Datei für die Bank', 'warn');
    const winterOffen = G.vorschau(d, SAISON, 'winter', heute).filter((x) => !x.schon_abgerechnet && x.summe > 0);
    if (!imSommer && winterOffen.length) add('abrechnung', 'Winterlager ' + SAISON + '/' + String(SAISON + 1).slice(2) + ' abrechnen (' + winterOffen.length + ' Mitglieder)', 'warn', 'data-abr-per="winter"');
    const RANG = { rot: 0, warn: 1, gast: 2 }; return l.sort((a, b) => RANG[a.art] - RANG[b.art]).slice(0, 5);
  }
  const finTodoHtml = (l) => '<table class="tab todo"><tbody>' + l.map((x) => '<tr class="klickbar" data-gehe="' + x.tab + '" ' + x.extra + '><td><span class="tag ' + x.art + '">Geld</span></td><td>' + x.txt + '</td><td class="r">→</td></tr>').join('') + '</tbody></table>';
  // Kopf mit Umschalter Monat | Jahr und Auswahl des Zeitraums
  function finLeiste() {
    const monat = finStand.modus === 'monat';
    const monate = finMonate(); const jahre = [...new Set(monate.map((m) => m.slice(0, 4)).concat(d.rechnungen.map((r) => String(r.saison))))].filter((j) => j <= String(Number(heute.slice(0, 4)) + 1)).sort().reverse();
    const auswahl = monat
      ? '<button type="button" class="btn klein fin-pfeil" data-fschritt="-1" aria-label="Monat davor"' + (finStand.monat <= monate[monate.length - 1] ? ' disabled' : '') + '>◀</button><select id="fin-monat" aria-label="Monat">' + monate.map((m) => '<option value="' + m + '"' + (m === finStand.monat ? ' selected' : '') + '>' + FZ.monatText(m) + '</option>').join('') + '</select>' +
        '<button type="button" class="btn klein fin-pfeil" data-fschritt="1" aria-label="Monat danach"' + (finStand.monat >= monate[0] ? ' disabled' : '') + '>▶</button>'
      : '<select id="fin-jahr" aria-label="Jahr">' + jahre.map((j) => '<option' + (j === String(finStand.jahr) ? ' selected' : '') + '>' + j + '</option>').join('') + '</select>';
    return '<div class="fin-leiste"><div class="ab-modus fin-modus" role="tablist" aria-label="Ansicht"><button type="button" role="tab" data-fmodus="monat" class="' + (monat ? 'aktiv' : '') + '" aria-selected="' + monat + '">Monat</button><button type="button" role="tab" id="fin-jahr-knopf" data-fmodus="jahr" class="' + (monat ? '' : 'aktiv') + '" aria-selected="' + !monat + '">Jahr</button></div>' +
      '<div class="fin-wahl">' + auswahl + '</div></div>';
  }
  V.finanzen = (main) => {
    const monat = finStand.modus === 'monat';
    main.innerHTML = kopf('Auf einen Blick', monat ? 'Was ist im Monat eingegangen, was ist offen, was ist zu tun?' : 'Was wurde für das Jahr abgerechnet, was ist im Geschäftsjahr eingegangen?',
      monat ? '<button class="btn primaer" id="fin-druck">Monatsbericht drucken</button>' : '<button class="btn primaer" id="fin-kp">Unterlagen Kassenprüfung</button>') + finLeiste() + '<div id="fin-inhalt"></div>';
    main.querySelectorAll('[data-fmodus]').forEach((b) => b.addEventListener('click', () => { finStand.modus = b.dataset.fmodus; zeige('finanzen', true); }));
    main.querySelectorAll('[data-fschritt]').forEach((b) => b.addEventListener('click', () => { finStand.monat = FZ.monatPlus(finStand.monat, Number(b.dataset.fschritt)); zeige('finanzen', true); }));
    const fm = $('#fin-monat'); if (fm) fm.addEventListener('change', () => { finStand.monat = fm.value; zeige('finanzen', true); });
    const fj = $('#fin-jahr'); if (fj) fj.addEventListener('change', () => { finStand.jahr = Number(fj.value); zeige('finanzen', true); });
    const fd = $('#fin-druck'); if (fd) fd.addEventListener('click', () => oeffnen('drucken.html?art=monatsbericht&monat=' + finStand.monat));
    const fk = $('#fin-kp'); if (fk) fk.addEventListener('click', () => kassenpruefungDialog(finStand.jahr));
    const zeichnen = (K) => { const z = $('#fin-inhalt'); if (z) z.innerHTML = monat ? finMonatHtml(K) : finJahrHtml(K); };
    zeichnen({ status: KASSE() ? 'laden' : 'aus', re: [], bu: [] });
    if (!KASSE()) return;
    const meinTab = tab, wann = monat ? finStand.monat : finStand.jahr;
    kasseLesen(monat).then((K) => { if (tab === meinTab && (monat ? finStand.monat : finStand.jahr) === wann && finStand.modus === (monat ? 'monat' : 'jahr')) zeichnen(K); });
  };
  const kasseZeile = (K, txt) => K.status === 'laden' ? '<small class="fin-leise">wird geladen …</small>' : K.status === 'aus' ? '<small class="fin-leise">Kasse nicht verbunden</small>' : K.status === 'fehler' ? '<small class="fin-leise">nicht lesbar: ' + esc(K.fehler) + '</small>' : txt;
  function finMonatHtml(K) {
    const m = finStand.monat, vm = FZ.monatPlus(m, -1), vj = FZ.monatPlus(m, -12);
    const eing = FZ.eingaenge(d, K.re);
    const sum = (mm) => FZ.summe(eing, mm + '-01', FZ.monatsEnde(mm));
    const S = sum(m), SV = sum(vm), SJ = sum(vj);
    const ende = FZ.monatsEnde(m); const laufend = ende >= heute; const stichtag = laufend ? heute : ende;
    const off = FZ.offenAm(d, K.re, stichtag);
    const kl = d.rechnungen.filter((r) => ['ueberfaellig', 'ruecklastschrift'].includes(Q.rstatus(r, heute)));
    const gm = d.gaeste.filter((g) => g.zahlung_gemeldet && !g.bezahlt_am && g.status !== 'storniert');
    const nBar = eing.filter((x) => x.bar && x.datum.startsWith(m)).length;
    const ok = K.status === 'ok';
    const krUeber = K.re.filter((r) => !r.storniert_am && !r.bezahlt_am && r.faellig && r.faellig < heute);
    const frei = K.bu.filter((b) => !b.rechnung_id && !b.storniert_am);
    const kurzM = (mm) => { const n = FZ.MONATE[Number(mm.slice(5, 7)) - 1]; return (n.length > 4 ? n.slice(0, 3) + '.' : n) + ' ' + mm.slice(0, 4); };
    const zelle = (s, k, mm, l) => '<td class="r" data-l="' + l + '">' + (k === 'getraenke' && !ok ? kasseZeile(K, '') : fgeld(s[k])) + '</td>';
    const todo = laufend ? finTodo() : [];
    return '<div class="karten fin-karten">' +
        '<div class="kz"><small>Eingegangen im ' + FZ.MONATE[Number(m.slice(5, 7)) - 1] + '</small><strong style="color:var(--ok)">' + H.geld(S.summe) + '</strong><span>Vorjahresmonat: ' + H.geld(SJ.summe) + (ok ? '' : ' · ohne Getränke') + '</span></div>' +
        '<div class="kz"><small>davon bar (Gäste)</small><strong>' + H.geld(S.bar) + '</strong><span>' + (nBar ? nBar + (nBar === 1 ? ' Gastzahlung' : ' Gastzahlungen') + ' bar – mit der Kasse abgleichen' : 'keine Barzahlung') + '</span></div>' +
        '<div class="kz"><small>Offen ' + (laufend ? 'heute' : 'am ' + H.datum(ende)) + '</small><strong>' + H.geld(off.summe) + '</strong><span>Hafen & Beiträge ' + H.geld(off.hafen) + ' · Gäste ' + H.geld(off.gast) + (ok ? ' · Getränke ' + H.geld(off.getraenke) : '') + '</span></div>' +
        '<div class="kz"><small>Zu klären · Hafen</small><strong style="color:' + (kl.length + gm.length ? 'var(--rot)' : 'inherit') + '">' + (kl.length + gm.length) + '</strong><span>' + kl.length + ' überfällig oder Rücklastschrift · ' + gm.length + ' Gastzahlung' + (gm.length === 1 ? '' : 'en') + ' gemeldet</span></div></div>' +
      '<p class="fin-getr"><strong>Getränke:</strong> ' + (ok ? (krUeber.length ? krUeber.length + ' Monatsrechnung' + (krUeber.length === 1 ? '' : 'en') + ' überfällig' : 'keine Monatsrechnung überfällig') + ' · ' + H.geld(frei.reduce((x, b) => x + Number(b.betrag), 0)) + ' in ' + frei.length + ' Buchungen noch nicht abgerechnet'
        : K.status === 'laden' ? 'wird geladen …' : K.status === 'aus' ? 'Getränkekasse nicht verbunden' : 'nicht lesbar: ' + esc(K.fehler)) + (KASSE() ? ' · <a href="' + KASSE_URL + '" target="_blank" rel="noopener">in der Getränkekasse klären ↗</a>' : '') + '</p>' +
      (laufend ? '<div class="panel"><h2>Diesen Monat zu tun</h2>' + (todo.length ? finTodoHtml(todo) : '<p class="leer">Nichts offen – alles abgeglichen.</p>') + '</div>' : '') +
      '<div class="panel"><h2>Eingänge nach Bereich</h2><p class="fin-wie">Gezählt nach Zahlungsdatum: Überweisung und Lastschrift am Tag der Buchung, Gäste am Tag der Zahlung, Getränke am „bezahlt am“. Rücklastschriften sind abgezogen.</p>' +
        '<table class="tab fin-tab fk"><thead><tr><th>Bereich</th><th class="r">' + kurzM(m) + '</th><th class="r">' + kurzM(vm) + '</th><th class="r">' + kurzM(vj) + '</th></tr></thead><tbody>' +
        FZ.BEREICHE.map(([k, t]) => '<tr><td><strong>' + t + '</strong></td>' + zelle(S, k, m, 'Dieser Monat') + zelle(SV, k, vm, 'Vormonat') + zelle(SJ, k, vj, 'Vorjahresmonat') + '</tr>').join('') +
        '</tbody><tfoot><tr><td>Summe</td><td class="r" data-l="Dieser Monat">' + H.geld(S.summe) + '</td><td class="r" data-l="Vormonat">' + H.geld(SV.summe) + '</td><td class="r" data-l="Vorjahresmonat">' + H.geld(SJ.summe) + '</td></tr></tfoot></table>' +
        '<p class="hinweis fin-ohne">Nicht enthalten: Ausgaben und Bankbestand – die stehen im Online-Banking.</p></div>' +
      finEinzelHtml(eing.filter((x) => x.datum.startsWith(m)), FZ.monatText(m));
  }
  // Einzelaufstellung (aufklappbar): jede Zahlung mit Beleg
  const finEinzelHtml = (l, wann) => !l.length ? '' : '<details class="panel fin-einzel"><summary><h2>Alle ' + l.length + ' Eingänge im ' + wann + ' einzeln</h2></summary><table class="tab fk"><thead><tr><th>Datum</th><th>Bereich</th><th>Rechnung / Beleg</th><th>Von</th><th>Zahlart</th><th class="r">Betrag</th></tr></thead><tbody>' +
    l.map((x) => '<tr><td class="nw" data-l="Datum">' + H.datum(x.datum) + '</td><td data-l="Bereich">' + BER[x.bereich] + '</td><td data-l="Beleg"><span class="nw">' + esc(x.nr || '–') + '</span>' + (x.beleg ? '<br><small class="fin-leise">' + esc(x.beleg) + '</small>' : '') + '</td><td data-l="Von">' + esc(x.wer) + '</td><td data-l="Zahlart">' + esc(x.zahlart) + '</td><td class="r nw" data-l="Betrag"><strong>' + H.geld(x.betrag) + '</strong></td></tr>').join('') + '</tbody></table></details>';
  function finJahrHtml(K) {
    const J = finStand.jahr; const ok = K.status === 'ok';
    const eing = FZ.eingaenge(d, K.re);
    const SJ = FZ.summe(eing, J + '-01-01', J + '-12-31'), SV = FZ.summe(eing, (J - 1) + '-01-01', (J - 1) + '-12-31');
    const ab = FZ.abgerechnet(d, K.re, J, heute);
    const TIT = { beitrag: 'Beiträge ' + J, sommer: 'Sommerliegeplatz ' + J, winter: 'Winterlager ' + J + '/' + String(J + 1).slice(2), gast: 'Gastlieger-Hafengeld', veranstaltung: 'Veranstaltungen ' + J, getraenke: 'Getränke' };
    const UNTER = { gast: 'Ankunft ' + J, getraenke: 'Monatsrechnungen ' + J };
    const abS = ab.filter((z) => z.k !== 'getraenke' || ok).reduce((a, z) => ({ n: a.n + z.n, soll: a.soll + z.soll, ist: a.ist + z.ist, offen: a.offen + z.offen }), { n: 0, soll: 0, ist: 0, offen: 0 });
    const kl = ab.filter((z) => z.k !== 'getraenke').reduce((s, z) => s + z.kl, 0);
    const monate = Array.from({ length: 12 }, (x, i) => { const mm = J + '-' + String(i + 1).padStart(2, '0'); return FZ.summe(eing, mm + '-01', FZ.monatsEnde(mm)); });
    const KURZ = { beitrag: 'Beiträge', sommer: 'Sommer', winter: 'Winter', gast: 'Gäste', veranstaltung: 'Veranst.', getraenke: 'Getränke' };
    const abZeile = (z) => { const getr = z.k === 'getraenke';
      return '<tr' + (!getr && darf('rechnungen') ? ' class="klickbar" data-gehe="rechnungen" data-re-bereich="' + z.k + '" data-re-jahr="' + J + '"' : '') + '><td><strong>' + TIT[z.k] + '</strong>' + (UNTER[z.k] ? '<br><small class="fin-leise">' + UNTER[z.k] + '</small>' : '') + '</td>' +
        (getr && !ok ? '<td colspan="5" data-l="Stand">' + kasseZeile(K, '') + '</td>' :
        '<td class="r" data-l="Anzahl">' + z.n + '</td><td class="r" data-l="Soll">' + H.geld(z.soll) + '</td><td class="r" data-l="Ist">' + H.geld(z.ist) + '</td><td class="r" data-l="Offen">' + (z.offen > 0 ? '<strong>' + H.geld(z.offen) + '</strong>' : H.geld(0)) + '</td><td data-l="Stand">' +
        (z.kl ? '<span class="tag ' + (z.k === 'gast' ? 'gast' : 'rot') + '">' + z.kl + ' ' + z.klText + '</span>' : z.offen > 0 ? '<span class="tag warn">offen</span>' : z.n ? '<span class="tag ok">erledigt</span>' : '') +
        (getr ? ' <a href="' + KASSE_URL + '" target="_blank" rel="noopener">Kasse ↗</a>' : '') + '</td>') + '</tr>'; };
    return '<div class="karten fin-karten">' +
        '<div class="kz"><small>Eingegangen ' + J + '</small><strong style="color:var(--ok)">' + H.geld(SJ.summe) + '</strong><span>Vorjahr ' + (J - 1) + ': ' + H.geld(SV.summe) + (ok ? '' : ' · ohne Getränke') + '</span></div>' +
        '<div class="kz"><small>Abgerechnet für ' + J + '</small><strong>' + H.geld(abS.soll) + '</strong><span>' + abS.n + ' Posten · davon offen ' + H.geld(abS.offen) + '</span></div>' +
        '<div class="kz"><small>Zu klären · Hafen</small><strong style="color:' + (kl ? 'var(--rot)' : 'inherit') + '">' + kl + '</strong><span>überfällig, Rücklastschrift oder Gastzahlung gemeldet</span></div></div>' +
      '<div class="panel"><h2>Abgerechnet für ' + J + '</h2><p class="fin-wie">Gezählt nach Abrechnungsjahr: Beitrag ' + J + ', Sommer ' + J + ', Winter ' + J + '/' + String(J + 1).slice(2) + ', Veranstaltungen ' + J + ' – egal, wann bezahlt. Gäste nach Ankunftsjahr, Getränke nach Rechnungsdatum. Stand heute.</p>' +
        '<table class="tab fin-tab fk"><thead><tr><th>Bereich</th><th class="r">Anzahl</th><th class="r">Soll</th><th class="r">Ist</th><th class="r">Offen</th><th>Stand</th></tr></thead><tbody>' + ab.map(abZeile).join('') +
        '</tbody><tfoot><tr><td>Summe' + (ok ? '' : ' (ohne Getränke)') + '</td><td class="r" data-l="Anzahl">' + abS.n + '</td><td class="r" data-l="Soll">' + H.geld(abS.soll) + '</td><td class="r" data-l="Ist">' + H.geld(abS.ist) + '</td><td class="r" data-l="Offen">' + H.geld(abS.offen) + '</td><td></td></tr></tfoot></table></div>' +
      '<div class="panel"><h2>Eingänge im Geschäftsjahr 1.1.–31.12.' + J + '</h2><p class="fin-wie">Gezählt nach Zahlungsdatum – die Grundlage für den Kassenbericht. Rücklastschriften sind abgezogen.</p>' +
        '<table class="tab fin-monate fk"><thead><tr><th>Monat</th>' + FZ.BEREICHE.map(([k]) => '<th class="r">' + KURZ[k] + '</th>').join('') + '<th class="r">Summe</th></tr></thead><tbody>' +
        monate.map((s, i) => '<tr' + (s.summe || s.n ? '' : ' class="blass"') + '><td><strong>' + FZ.MONATE[i] + '</strong></td>' + FZ.BEREICHE.map(([k]) => '<td class="r' + (s[k] ? '' : ' null') + '" data-l="' + BER[k] + '">' + (k === 'getraenke' && !ok ? '…' : fgeld(s[k])) + '</td>').join('') + '<td class="r summe-sp" data-l="Summe"><strong>' + fgeld(s.summe) + '</strong></td></tr>').join('') +
        '</tbody><tfoot><tr><td>Summe ' + J + '</td>' + FZ.BEREICHE.map(([k]) => '<td class="r" data-l="' + BER[k] + '">' + (k === 'getraenke' && !ok ? '…' : H.geld(SJ[k])) + '</td>').join('') + '<td class="r" data-l="Summe">' + H.geld(SJ.summe) + '</td></tr>' +
        '<tr class="fin-vorjahr"><td>Vorjahr ' + (J - 1) + '</td>' + FZ.BEREICHE.map(([k]) => '<td class="r" data-l="' + BER[k] + '">' + (k === 'getraenke' && !ok ? '…' : H.geld(SV[k])) + '</td>').join('') + '<td class="r" data-l="Summe">' + H.geld(SV.summe) + '</td></tr></tfoot></table>' +
        '<p class="hinweis fin-ohne">Nicht enthalten: Ausgaben und Bankbestand – die stehen im Online-Banking.</p></div>';
  }
  // Unterlagen für die Kassenprüfung: Bericht als PDF (Briefkopf) und alle Eingänge des Jahres als CSV
  function kassenpruefungDialog(J) {
    const el = modal('<h2>Unterlagen Kassenprüfung ' + J + '</h2><p style="margin-top:0">Für die Kassenprüfer und den Kassenbericht – alles nach Zahlungsdatum 1.1.–31.12.' + J + '.</p>' +
      '<ul class="kp-liste"><li><strong>Bericht (PDF, SSV-Briefkopf):</strong> Eingänge je Monat und Bereich mit Vorjahr, abgerechnet für ' + J + ' (Soll/Ist/Offen), offene Posten zum Jahresende und die Einzelaufstellung.</li>' +
      '<li><strong>Liste aller Eingänge (CSV für Excel):</strong> Datum, Betrag, Bereich, Rechnungsnummer, Mitglied/Boot, Zahlart, Beleg (Lastschrift-Datei, Umsatz, Quittung).</li></ul>' +
      '<p class="hinweis fin-ohne">Ausgaben und Bankbestand sind nicht enthalten.</p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Schließen</button><button class="btn" id="kp-csv">Alle Eingänge als CSV</button><button class="btn primaer" id="kp-pdf">Bericht als PDF</button></div>');
    $('#kp-pdf', el).addEventListener('click', () => oeffnen('drucken.html?art=kassenpruefung&jahr=' + J));
    $('#kp-csv', el).addEventListener('click', async (ev) => { const k = ev.currentTarget; k.disabled = true;
      const K = await kasseLesen(false); k.disabled = false;
      const l = FZ.eingaenge(d, K.re).filter((x) => x.datum.startsWith(String(J)));
      download('ssv-eingaenge-' + J + '.csv', csv([['Datum', 'Betrag', 'Bereich', 'Rechnungsnr./Quittung', 'Mitglied/Boot', 'Zahlart', 'Beleg']].concat(l.map((x) => [H.datum(x.datum), H.zahl(x.betrag), BER[x.bereich], x.nr, x.wer, x.zahlart, x.beleg]))
        .concat([[], ['Summe', H.zahl(l.reduce((s, x) => s + x.betrag, 0))]].concat(K.status === 'ok' ? [] : [['Hinweis', 'Getränkekasse nicht verbunden – Getränke fehlen']]))), 'text/csv');
      toast(l.length + ' Eingänge als CSV gespeichert.'); });
  }
  // Rechnungskette: Kästen mit Anzahl und Summe je Stufe. In „Abrechnen“ führt Antippen in die Liste, in „Rechnungen & Offenes“ filtert es.
  function ketteKopf(res, aktiv, hinweis) {
    const l = res.filter((r) => !r.storniert_am);
    const box = (k) => { const rs = l.filter((r) => stufe(r) === k); const sum = rs.reduce((x, r) => x + (k === 'bezahlt' ? Number(r.summe) : Q.rest(r)), 0);
      return '<button type="button" class="kette-box ' + k + (aktiv === k ? ' aktiv' : '') + '" data-stufe="' + k + '" aria-pressed="' + (aktiv === k) + '"><small>' + STUFE[k][0] + '</small><strong>' + rs.length + '</strong><span>' + H.geld(sum) + '</span></button>'; };
    return '<div class="kette-kopf"><div class="kette-weg">' + ['einzug', 'bank', 'bezahlt'].map(box).join('<span class="kette-pfeil" aria-hidden="true">→</span>') + '</div><div class="kette-neben">' + ['ueberweisung', 'klaeren'].map(box).join('') + '</div></div>' +
      '<p class="hinweis" style="margin:0 0 10px">' + (hinweis || 'Lastschrift: erstellt → zum Einzug vorgemerkt → mit der Lastschrift-Datei an die Bank → bezahlt („Gutschrift ist da“). Antippen filtert die Liste.') + '</p>';
  }
  // Lastschrift-Dateien mit Stand und „Gutschrift ist da“ (in „Zahlungseingang“ alle, in „Abrechnen“ Schritt 5 die des Zeitraums)
  function laeufeHtml(liste) {
    return '<table class="tab laeufe fk"><thead><tr><th>Lastschrift-Datei</th><th>erzeugt</th><th>Einzug am</th><th class="r">Posten</th><th class="r">Summe</th><th>Stand</th><th></th></tr></thead><tbody>' +
      liste.slice().sort((a, b) => (b.datum || '').localeCompare(a.datum || '') || b.id.localeCompare(a.id)).map((l) => { const rs = d.rechnungen.filter((r) => r.sepa_lauf === l.id && !r.storniert_am);
        const offenL = rs.filter((r) => Q.rest(r) > 0 && Q.rstatus(r, heute) !== 'ruecklastschrift'); const rueckL = rs.filter((r) => Q.rstatus(r, heute) === 'ruecklastschrift').length;
        const stand = !rs.length ? '<span class="tag">keine offenen Posten</span>' : !offenL.length ? '<span class="tag ok">gutgeschrieben</span>' : (l.faellig || l.datum) > heute ? '<span class="tag gast">Einzug am ' + H.kurz(l.faellig || l.datum) + '</span>' : '<span class="tag warn">Gutschrift prüfen</span>';
        return '<tr><td data-l="Datei"><strong class="nw">' + esc(l.id) + '</strong></td><td class="nw" data-l="erzeugt">' + H.datum(l.datum) + '</td><td class="nw" data-l="Einzug am">' + H.datum(l.faellig || l.datum) + '</td><td class="r" data-l="Posten">' + l.anzahl + '</td><td class="r nw" data-l="Summe">' + H.geld(l.summe) + '</td><td data-l="Stand">' + stand + (rueckL ? ' <span class="tag rot">' + rueckL + ' Rücklastschrift' + (rueckL > 1 ? 'en' : '') + '</span>' : '') + '</td>' +
          '<td class="r aktion">' + (offenL.length ? '<button class="btn klein' + ((l.faellig || l.datum) <= heute ? ' primaer' : '') + '" data-gutschrift="' + esc(l.id) + '" title="Sammellastschrift ist auf dem Vereinskonto – alle Posten als bezahlt buchen">Gutschrift ist da</button>' : '') + '</td></tr>'; }).join('') + '</tbody></table>';
  }
  function gutschriftBuchen(id, danach) {
    const l = d.sepa_laeufe.find((x) => x.id === id); if (!l) return; const tagG = (l.faellig || l.datum) <= heute ? (l.faellig || l.datum) : heute;
    const rs = d.rechnungen.filter((r) => r.sepa_lauf === l.id && !r.storniert_am && Q.rest(r) > 0 && Q.rstatus(r, heute) !== 'ruecklastschrift');
    if (!rs.length) return;
    if (!confirm('Ist die Sammellastschrift ' + l.id + ' auf dem Vereinskonto gutgeschrieben?\n\n' + rs.length + ' Rechnungen (' + H.geld(rs.reduce((x, r) => x + Q.rest(r), 0)) + ') werden als bezahlt am ' + H.datum(tagG) + ' gebucht. Kommt später eine Rücklastschrift, vermerkst du sie bei der einzelnen Rechnung unter „Zahlung“.')) return;
    rs.forEach((r) => { r.zahlungen = (r.zahlungen || []).concat([{ datum: tagG, betrag: Q.rest(r), art: 'eingang', notiz: 'Lastschrift ' + l.id }]); r.bezahlt_am = tagG; });
    speichern(rs.length + ' Rechnungen als bezahlt gebucht.'); if (danach) danach(); zeige(tab, true);
  }
  /* ============================================================ Abrechnen
   * Zeitraum wählen (Beitrag, Sommer, Winter, Veranstaltungen), dann fünf echte Schritte: nur der gewählte ist aufgeklappt,
   * erledigte stehen als Zeile mit Haken. Die Rechnungsliste steht in „Rechnungen & Offenes“ (Link „Rechnungen dieses Laufs ansehen“). */
  V.abrechnung = (main) => {
    const per = abrStand.periode, e = d.einstellungen; const ver = per === 'veranstaltung';
    const jahr = per === 'beitrag' ? abrStand.beitragJahr : ver ? Number(heute.slice(0, 4)) : SAISON;
    const vs = ver ? [] : G.vorschau(d, jahr, per, abrStand.datum).filter((x) => x.summe > 0);
    const offen = vs.filter((x) => !x.schon_abgerechnet);
    // Veranstaltungen mit Kosten aus diesem Jahr – und ältere, bei denen noch Zusagen abzurechnen sind
    const vers = ver ? (d.veranstaltungen || []).filter((v) => Number(v.kosten) > 0 && !v.abgesagt && (String(v.datum).startsWith(String(jahr)) || verAbrechenbar(v).length)).sort((a, b) => a.datum.localeCompare(b.datum)) : [];
    const offenM = ver ? [].concat(...vers.map((v) => verAbrechenbar(v).map((z) => ({ m: Q.mitglied(z.mitglied_id) })))) : offen;
    const nOffen = offenM.length;
    const ohneMandat = offenM.filter((x) => !(x.m.iban && x.m.mandat_ref && x.m.mandat_datum));
    const sepaBereit = d.rechnungen.filter((r) => r.sepa && !r.sepa_lauf && Q.rest(r) > 0);
    const sepaOk = SEPA.ibanGueltig(e.iban) && SEPA.glaeubigerGueltig(e.glaeubiger_id);
    const label = ver ? 'Veranstaltungen ' + jahr : H.periodeText({ periode: per, saison: jahr });
    const pKey = per + '-' + jahr;
    const rsP = d.rechnungen.filter((r) => !r.storniert_am && r.periode === per && r.saison === jahr);
    const zugestellt = (e.abrechnung_zugestellt || {})[pKey];
    const sepaP = rsP.filter((r) => r.sepa); const einzugOffen = sepaP.filter((r) => !r.sepa_lauf && Q.rest(r) > 0);
    const unbezahlt = rsP.filter((r) => Q.rest(r) > 0);
    const fassung = fassungen().filter((x) => x <= jahr).pop() ?? fassungen()[0];
    const saisonT = (d.saisons || []).find((x) => x.jahr === jahr);
    const ohneAnschrift = offenM.filter((x) => !(x.m.strasse && x.m.plz && x.m.ort));
    const namen = (l) => l.slice(0, 3).map((x) => esc(Q.name(x.m))).join(', ') + (l.length > 3 ? ' …' : '');
    const pruef = [
      [sepaOk ? 'ok' : 'warn', 'Vereinskonto und Gläubiger-ID', sepaOk ? 'gültig' : 'fehlen – ohne sie keine Lastschrift-Datei', 'einstellungen'],
      [e.steuer_hinweis ? 'ok' : 'warn', 'Steuerhinweis auf Rechnungen', e.steuer_hinweis ? 'festgelegt' : 'noch nicht festgelegt (mit dem Steuerberater klären)', 'einstellungen'],
      ver ? null : ['ok', 'Gebührenordnung', 'Fassung ab ' + fassung + (d.gebuehren[fassung].stand ? ' · ' + esc(d.gebuehren[fassung].stand) : ''), 'gebuehren'],
      per === 'sommer' || per === 'winter' ? [saisonT ? 'ok' : 'warn', 'Saisontermine ' + jahr, saisonT ? 'Auslagern ' + H.datum(saisonT.auslagern) + ' · Einlagern ' + H.datum(saisonT.einlagern) : 'nicht eingetragen – es gelten Annahmen', 'einstellungen'] : null,
      [ohneAnschrift.length ? 'warn' : 'ok', 'Anschriften', ohneAnschrift.length ? ohneAnschrift.length + ' ohne vollständige Anschrift: ' + namen(ohneAnschrift) : 'vollständig', 'eigner'],
      [ohneMandat.length ? 'info' : 'ok', 'Lastschriftmandate', ohneMandat.length ? ohneMandat.length + ' ohne Mandat – zahlen per Überweisung: ' + namen(ohneMandat) : 'alle mit Mandat', 'eigner'],
      per === 'beitrag' ? [e.arbeitsdienst_bestaetigt ? 'ok' : 'info', 'Ersatz für fehlenden Arbeitsdienst', e.arbeitsdienst_bestaetigt ? (Number(e.arbeitsdienst_satz) ? H.geld(e.arbeitsdienst_satz) + ' je Fehlstunde' : 'kein Betrag festgelegt') : 'Regeln noch nicht beschlossen – wird nicht berechnet', 'einstellungen'] : null
    ].filter(Boolean);
    const nWarn = pruef.filter((x) => x[0] === 'warn').length;
    const schritte = [
      ['Prüfen', nWarn ? 'warn' : 'ok', nWarn ? nWarn + (nWarn === 1 ? ' Hinweis' : ' Hinweise') : 'alles da'],
      ['Erstellen', nOffen ? 'aktiv' : rsP.length ? 'ok' : 'leer', nOffen ? nOffen + (ver ? ' Zusagen offen' : ' offen') : rsP.length ? rsP.length + ' erstellt' : 'nichts abzurechnen'],
      ['Zustellen', !rsP.length ? 'offen' : zugestellt ? 'ok' : 'aktiv', zugestellt ? 'am ' + H.kurz(zugestellt) : rsP.length ? 'Mein SSV / PDF' : ''],
      ['Lastschrift', !rsP.length ? 'offen' : !sepaP.length ? 'leer' : einzugOffen.length ? 'aktiv' : 'ok', !sepaP.length ? (rsP.length ? 'keine Mandate' : '') : einzugOffen.length ? einzugOffen.length + ' bereit' : 'an Bank'],
      ['Zahlungseingang', !rsP.length ? 'offen' : unbezahlt.length ? 'aktiv' : 'ok', !rsP.length ? '' : unbezahlt.length ? unbezahlt.length + ' offen · ' + H.geld(unbezahlt.reduce((x, r) => x + Q.rest(r), 0)) : 'alles bezahlt']
    ];
    const erstAktiv = schritte.findIndex((x) => x[1] === 'aktiv');
    // Welcher Schritt ist aufgeklappt? Gewählt > nach einer Aktion der nächste offene > der erste offene
    let auf;
    if (abrStand.nach && abrStand.nach.key === pKey) { const n = abrStand.nach.n; abrStand.nach = null;
      auf = schritte[n - 1][1] === 'aktiv' ? n : (schritte.findIndex((x, i) => i >= n && x[1] === 'aktiv') + 1 || n); abrStand.wahl = { key: pKey, n: auf }; }
    else if (abrStand.wahl && abrStand.wahl.key === pKey) auf = abrStand.wahl.n;
    else auf = erstAktiv >= 0 ? erstAktiv + 1 : rsP.length ? 5 : 1;
    const pruefHtml = '<ul class="pruefliste">' + pruef.map(([st, t, info, z]) => '<li class="' + st + '"><span class="pl-icon" aria-hidden="true">' + (st === 'ok' ? '✓' : st === 'warn' ? '!' : 'i') + '</span><span><strong>' + t + '</strong> – ' + info + '</span>' + (st !== 'ok' && darf(z) ? '<a href="#" data-gehe="' + z + '">ändern →</a>' : '') + '</li>').join('') + '</ul>';
    const erstellHtml = ver
      ? (vers.length ? '<table class="tab fk abr-ver"><thead><tr><th>Veranstaltung</th><th class="r">Kosten</th><th class="r">Zusagen offen</th><th class="r">Rechnungen</th><th></th></tr></thead><tbody>' + vers.map((v) => { const n = verAbrechenbar(v).length; const rv = verRechnungen(v);
          return '<tr><td data-l="Veranstaltung"><strong>' + esc(v.titel) + '</strong><br><small class="nw">' + H.datum(v.datum) + '</small></td><td class="r nw" data-l="Kosten">' + H.geld(v.kosten) + ' je Person</td><td class="r" data-l="Zusagen offen">' + (n ? '<strong>' + n + '</strong>' : '–') + '</td><td class="r" data-l="Rechnungen">' + (rv.length || '–') + '</td>' +
            '<td class="r aktion">' + (n ? '<button class="btn klein primaer" data-ver-abr="' + v.id + '">Kosten abrechnen (' + n + ')</button>' : '<span class="tag ok">abgerechnet</span>') + '</td></tr>'; }).join('') + '</tbody></table>' +
          '<p class="hinweis" style="margin:10px 0 0">Je Zusage eine Rechnung: Personen × Kosten. Die Veranstaltung selbst bleibt unter „Mitteilungen & Veranstaltungen“.</p>'
        : '<p class="leer" style="margin:0">Keine Veranstaltung mit Kosten in ' + jahr + '. Kosten trägt man beim Anlegen der Veranstaltung ein.</p>')
      : (offen.length ? '<p style="margin-top:0">' + offen.length + ' Mitglieder · <strong>' + H.geld(offen.reduce((s, x) => s + x.summe, 0)) + '</strong>' + (vs.length > offen.length ? ' · ' + (vs.length - offen.length) + ' bereits abgerechnet' : '') + '</p>' : '<p class="hinweis ok">' + label + ' ist vollständig abgerechnet.</p>') +
        (ohneMandat.length ? '<p class="hinweis warn">' + ohneMandat.length + ' ohne SEPA-Mandat – ihre Rechnung nennt die Bankverbindung zur Überweisung.</p>' : '') +
        (offen.length ? '<details class="vorschau"' + (offen.length <= 12 ? ' open' : '') + '><summary>Vorschau je Mitglied anzeigen (' + offen.length + ')</summary><table class="tab fk"><thead><tr><th>Mitglied</th><th>Art</th><th>Positionen</th><th class="r">Betrag</th></tr></thead><tbody>' + offen.map((x) =>
          '<tr><td data-l="Mitglied">' + esc(Q.name(x.m)) + '</td><td data-l="Art"><span class="tag">' + H.ART[x.m.art] + '</span></td><td data-l="Positionen" style="font-size:15px;color:var(--muted)">' + x.positionen.map((p) => esc(p.text.split(' · ')[0].replace(/ \(wird an den Segler-Verband weitergegeben\)/, '')) + (per === 'beitrag' ? ' · ' + H.geld(p.betrag) : '')).join('<br>') + '</td><td class="r" data-l="Betrag">' + H.geld(x.summe) + '</td></tr>').join('') +
          '</tbody><tfoot><tr><td colspan="3">Summe</td><td class="r">' + H.geld(offen.reduce((s, x) => s + x.summe, 0)) + '</td></tr></tfoot></table></details>' +
          '<div class="filter" style="margin-top:14px"><label class="feld">Rechnungsdatum<input type="date" id="rdat" value="' + abrStand.datum + '"></label><button class="btn primaer" id="los">' + offen.length + ' Rechnungen erstellen</button></div>' : '');
    const zustellHtml = rsP.length ? '<p style="margin-top:0">' + rsP.length + ' Rechnungen ' + label + ' – sie stehen sofort in „Mein SSV“. Wer dort kein Konto hat, bekommt sie als PDF per E-Mail oder Brief.</p>' +
        '<div class="aktionen"><button class="btn primaer" id="abl-mail">Per E-Mail senden' + (rsP.filter((r) => !versandVon('hafen', r.id)).length < rsP.length ? ' (' + rsP.filter((r) => versandVon('hafen', r.id)).length + ' von ' + rsP.length + ' gesendet)' : '') + '</button><button class="btn" id="abl-pdf">Alle ' + rsP.length + ' als PDF öffnen</button>' + (zugestellt ? '<span class="tag ok">zugestellt am ' + H.datum(zugestellt) + '</span> <button class="btn klein" id="abl-zu-weg">Vermerk entfernen</button>' : '<button class="btn" id="abl-zu">Als zugestellt vermerken</button>') + '</div>' +
        '<p class="hinweis" style="margin:10px 0 0">Die Rechnung ist zugleich die Ankündigung der Lastschrift: eingezogen wird frühestens am Fälligkeitstag (' + Number(e.zahlungsziel_tage || 14) + ' Tage nach Rechnungsdatum).</p>'
      : '<p class="leer" style="margin:0">Erst nach dem Erstellen.</p>';
    const lastHtml = (!sepaOk ? '<p class="hinweis warn">Für die Lastschrift-Datei fehlen gültige Vereinsdaten (IBAN und Gläubiger-ID) unter Einstellungen.</p>' : '') +
      '<p style="margin-top:0">' + (sepaP.length ? sepaP.length + ' Rechnungen ' + label + ' haben ein Lastschriftmandat, ' + einzugOffen.length + ' davon warten auf die Datei.' : rsP.length ? 'Keine Rechnung ' + label + ' hat ein Lastschriftmandat – alle zahlen per Überweisung.' : 'Erst nach dem Erstellen.') +
        (sepaBereit.length > einzugOffen.length ? ' Die Datei enthält alle ' + sepaBereit.length + ' vorgemerkten Rechnungen, auch aus anderen Zeiträumen.' : '') + '</p>' +
      '<div class="aktionen"><button class="btn primaer" id="sepa"' + (sepaBereit.length && sepaOk ? '' : ' disabled') + '>Lastschrift-Datei erzeugen (' + sepaBereit.length + ')</button></div>' +
      (sepaOk ? '<p class="hinweis" style="margin:10px 0 0">Sammellastschrift im Bankformat <strong>pain.008.001.08</strong>. Die Datei im Online-Banking des Vereins hochladen; Einzug am Fälligkeitstag der Rechnungen.</p>' : '');
    const laeufeP = d.sepa_laeufe.filter((l) => rsP.some((r) => r.sepa_lauf === l.id));
    const eingangHtml = (rsP.length ? '<p style="margin-top:0">' + (unbezahlt.length ? unbezahlt.length + ' Rechnungen sind noch offen (' + H.geld(unbezahlt.reduce((x, r) => x + Q.rest(r), 0)) + ').' : 'Alle Rechnungen ' + label + ' sind bezahlt.') +
        ' Lastschrift: „Gutschrift ist da“, sobald die Sammellastschrift auf dem Konto ist. Überweisungen: Kontoauszug unter „Zahlungseingang“ einlesen.</p>' : '<p class="leer" style="margin:0">Erst nach dem Erstellen.</p>') +
      (laeufeP.length ? laeufeHtml(laeufeP) : '') +
      (rsP.length ? '<div class="aktionen" style="margin-top:10px">' + (darf('kontoauszug') ? '<button class="btn" data-gehe="kontoauszug">Zum Zahlungseingang →</button>' : '') + (unbezahlt.length ? '<button class="btn" id="abl-offen">Offene Rechnungen dieses Laufs →</button>' : '') + '</div>' : '');
    const INHALT = [pruefHtml, erstellHtml, zustellHtml, lastHtml, eingangHtml];
    const schrittHtml = (i) => { const [t, st, info] = schritte[i]; const a = i + 1 === auf;
      return '<li class="panel schritt ' + st + (i === erstAktiv ? ' jetzt' : '') + (a ? ' auf' : '') + '" id="abl-' + (i + 1) + '"' + (a ? ' aria-current="step"' : '') + '><button type="button" class="schritt-kopf" data-schritt="' + (i + 1) + '" aria-expanded="' + a + '"><span class="ablauf-nr">' + (st === 'ok' ? '✓' : i + 1) + '</span>' +
        '<span class="schritt-titel"><strong>' + (i + 1) + ' · ' + t + (i === 1 ? ' · ' + label : '') + '</strong>' + (info ? '<small>' + info + '</small>' : '') + '</span>' + (a ? '' : '<span class="schritt-auf">' + (st === 'ok' ? 'ansehen' : 'öffnen') + ' ▸</span>') + '</button>' +
        '<div class="schritt-inhalt"' + (a ? '' : ' hidden') + '>' + INHALT[i] + '<div class="schritt-fuss">' + (i ? '<button type="button" class="btn" data-schritt="' + i + '">← Zurück</button>' : '') +
          (i < 4 ? '<button type="button" class="btn' + (st === 'ok' || st === 'leer' ? ' dunkel' : '') + '" data-schritt="' + (i + 2) + '">Weiter: ' + schritte[i + 1][0] + ' →</button>' : '') + '</div></div></li>'; };
    const zeitraum = [SAISON, SAISON + 1].map((j) => ['beitrag', 'Beitrag ' + j, j]).concat([['sommer', 'Sommer ' + SAISON], ['winter', 'Winter ' + SAISON + '/' + String(SAISON + 1).slice(2)], ['veranstaltung', 'Veranstaltungen ' + heute.slice(0, 4)]]);
    main.innerHTML = kopf('Abrechnen', 'Mitgliedsbeitrag einmal im Jahr · Sommer nach dem Auslagern, Winter nach dem Einlagern · Veranstaltungen nach dem Termin.') +
      '<div class="ab-modus abr-zeitraum" role="tablist" aria-label="Zeitraum">' + zeitraum.map(([p, t, j]) => { const an = per === p && (p !== 'beitrag' || jahr === j);
        return '<button type="button" role="tab" class="' + (an ? 'aktiv' : '') + '" aria-selected="' + an + '" data-per="' + p + '"' + (j ? ' data-jahr="' + j + '"' : '') + '>' + t + '</button>'; }).join('') + '</div>' +
      '<ol class="ablauf schritte" aria-label="Ablauf ' + label + ' in fünf Schritten">' + schritte.map((x, i) => schrittHtml(i)).join('') + '</ol>' +
      (rsP.length ? '<div class="panel abr-stand"><div class="abr-stand-kopf"><h2>Stand der Rechnungen ' + label + '</h2><button type="button" class="link-knopf" id="abl-liste">Rechnungen dieses Laufs ansehen →</button></div>' +
        ketteKopf(rsP, '', 'Antippen zeigt die Rechnungen dieser Stufe in „Rechnungen & Offenes“.') + '</div>' : '');
    const zurListe = (extra) => { Object.assign(reStand, { bereich: per, jahr: String(jahr), monat: '', status: '', stufe: '', such: '', mehr: false }, extra || {}); zeige('rechnungen'); };
    main.querySelectorAll('[data-schritt]').forEach((b) => b.addEventListener('click', () => { abrStand.wahl = { key: pKey, n: Number(b.dataset.schritt) }; zeige('abrechnung', true);
      const z = $('#abl-' + b.dataset.schritt); if (z && (z.getBoundingClientRect().top < 0 || z.getBoundingClientRect().top > innerHeight * .6)) z.scrollIntoView({ block: 'start' }); const k = z && z.querySelector('.schritt-kopf'); if (k) k.focus({ preventScroll: true }); }));
    main.querySelectorAll('.abr-stand [data-stufe]').forEach((b) => b.addEventListener('click', () => zurListe({ stufe: b.dataset.stufe })));
    const al = $('#abl-liste'); if (al) al.addEventListener('click', () => zurListe());
    const ao = $('#abl-offen'); if (ao) ao.addEventListener('click', () => zurListe({ status: 'nicht_bezahlt' }));
    main.querySelectorAll('[data-gutschrift]').forEach((b) => b.addEventListener('click', () => gutschriftBuchen(b.dataset.gutschrift, () => { abrStand.nach = { key: pKey, n: 5 }; })));
    main.querySelectorAll('[data-ver-abr]').forEach((b) => b.addEventListener('click', () => verAbrechnenDialog(d.veranstaltungen.find((v) => v.id === b.dataset.verAbr), () => { abrStand.nach = { key: pKey, n: 2 }; zeige('abrechnung'); })));
    const ap = $('#abl-pdf'); if (ap) ap.addEventListener('click', () => oeffnen('drucken.html?art=rechnungen&ids=' + rsP.map((r) => r.id).join(',')));
    const am = $('#abl-mail'); if (am) am.addEventListener('click', () => mailVersandDialog('hafen', rsP, label, () => {
      const alle = rsP.every((r) => versandVon('hafen', r.id));
      if (alle && !(e.abrechnung_zugestellt || {})[pKey]) { e.abrechnung_zugestellt = { ...(e.abrechnung_zugestellt || {}), [pKey]: heute }; speichern('Alle Rechnungen sind per E-Mail raus – als zugestellt vermerkt.'); }
      abrStand.nach = { key: pKey, n: 3 }; zeige('abrechnung', true); }));
    const az = $('#abl-zu'); if (az) az.addEventListener('click', () => { e.abrechnung_zugestellt = { ...(e.abrechnung_zugestellt || {}), [pKey]: heute }; speichern('Als zugestellt vermerkt.'); abrStand.nach = { key: pKey, n: 3 }; zeige('abrechnung', true); });
    const azw = $('#abl-zu-weg'); if (azw) azw.addEventListener('click', () => { const z = { ...(e.abrechnung_zugestellt || {}) }; delete z[pKey]; e.abrechnung_zugestellt = z; speichern('Vermerk entfernt.'); zeige('abrechnung', true); });
    main.querySelectorAll('[data-per]').forEach((b) => b.addEventListener('click', () => { abrStand.periode = b.dataset.per; if (b.dataset.jahr) abrStand.beitragJahr = Number(b.dataset.jahr); zeige('abrechnung', true); }));
    const rdat = $('#rdat'); if (rdat) rdat.addEventListener('change', () => { abrStand.datum = rdat.value; });
    const los = $('#los'); if (los) los.addEventListener('click', async () => {
      if (abrLaeuft) return;
      if (!confirm(offen.length + ' Rechnungen für ' + label + ' erstellen?')) return;
      abrLaeuft = true; los.disabled = true; los.textContent = 'Rechnungen werden erstellt …';
      try {
        // Vereinsdatenbank: erst den neuesten Stand holen – hat jemand anderes gerade abgerechnet, entstehen keine doppelten Rechnungen
        if (DB) { await HF.neuLaden(); d = HF.d; }
        const neu = G.saisonAbrechnen(d, jahr, per, abrStand.datum);
        if (!neu.length) { toast('Keine neuen Rechnungen – ' + label + ' ist bereits abgerechnet.'); return zeige('abrechnung', true); }
        const ok = await speichern();
        if (ok === false) return;   // Fehlermeldung kam schon, Stand wurde neu geladen
        toast(neu.length + ' Rechnungen erstellt.'); abrStand.nach = { key: pKey, n: 2 }; zeige('abrechnung', true);
        if (confirm('Rechnungen jetzt ansehen / als PDF sichern?')) oeffnen('drucken.html?art=rechnungen&ids=' + neu.map((r) => r.id).join(','));
      } catch (x) { toast('Rechnungen nicht erstellt: ' + x.message, 'fehler', 7000); zeige('abrechnung', true); }
      finally { abrLaeuft = false; }
    });
    $('#sepa').addEventListener('click', () => {
      const ersterEinzug = sepaBereit.map((r) => r.faellig).sort()[0];
      const nichtZu = [...new Set(sepaBereit.filter((r) => r.periode !== 'veranstaltung' && !(e.abrechnung_zugestellt || {})[r.periode + '-' + r.saison]).map((r) => H.periodeText(r)))];
      if (!confirm('Lastschrift-Datei für ' + sepaBereit.length + ' Rechnungen erzeugen?\n\nDie Rechnung ist zugleich die Ankündigung des Einzugs (frühester Einzug ' + H.datum(ersterEinzug) + ').' +
        (nichtZu.length ? '\n\nAchtung: Für ' + nichtZu.join(', ') + ' ist noch nicht vermerkt, dass die Rechnungen zugestellt sind (Schritt 3). Haben alle Mitglieder ihre Rechnung bekommen – in „Mein SSV“, per E-Mail oder als Brief?' : '\n\nAlle Rechnungen sind als zugestellt vermerkt.'))) return;
      const ungueltig = [];
      const posten = sepaBereit.map((r) => { const m = Q.mitglied(r.mitglied_id);
        if (!SEPA.ibanGueltig(m.iban)) { ungueltig.push(r.nr); return null; }
        return { betrag: Q.rest(r), mandat_ref: r.mandat_ref, mandat_datum: r.mandat_datum, name: m.kontoinhaber || Q.name(m), iban: m.iban, bic: m.bic, zweck: (r.periode === 'beitrag' ? 'Mitgliedsbeitrag ' + r.saison + ' ' + r.nr : r.periode === 'veranstaltung' ? r.nr + ' ' + H.periodeText(r) : 'Hafengeld ' + r.nr + ' ' + H.periodeText(r)), e2e: r.nr, re: r }; }).filter(Boolean);
      if (!posten.length) return toast('Keine gültigen Posten.', 'fehler');
      // je Fälligkeitstag eine Datei, damit der Einzugstermin stimmt
      const nachTag = new Map(); posten.forEach((p) => { const t = p.re.faellig; if (!nachTag.has(t)) nachTag.set(t, []); nachTag.get(t).push(p); });
      nachTag.forEach((liste, faellig) => {
        const id = 'SEPA-' + heute + '-' + (d.sepa_laeufe.length + 1);
        const xml = SEPA.erzeugen({ name: e.verein_name, iban: e.iban, bic: e.bic, glaeubiger_id: e.glaeubiger_id }, liste, faellig < heute ? heute : faellig, 'SSV-' + id);
        download(id + '.xml', xml, 'application/xml');
        const summe = liste.reduce((s, p) => s + Math.round(p.betrag * 100), 0) / 100;
        d.sepa_laeufe.push({ id, datum: heute, faellig, anzahl: liste.length, summe });
        liste.forEach((p) => { p.re.sepa_lauf = id; });
      });
      speichern(posten.length + ' Lastschriften in ' + nachTag.size + ' Datei(en) erzeugt.' + (ungueltig.length ? ' Übersprungen (IBAN ungültig): ' + ungueltig.join(', ') : '')); abrStand.nach = { key: pKey, n: 4 }; zeige('abrechnung', true);
    });
  };

  /* ============================================================ Rechnungen & Offenes
   * Alle Rechnungen (Beitrag, Sommer, Winter, Veranstaltungen), dazu Gastlieger mit Betrag und – nur zum Lesen – die Getränke-Monatsrechnungen.
   * Vorgabe „noch nicht bezahlt“; Hauptaktion je Zeile „Zahlung“. */
  const reStand = { such: '', bereich: '', jahr: '', monat: '', status: 'nicht_bezahlt', stufe: '', mehr: false };
  let reKasse = null;   // Getränke-Rechnungen (einmal gelesen, bei „neu laden“ erneut)
  const GSTAND = { bezahlt: ['bezahlt', 'ok'], gemeldet: ['vom Gast gemeldet – prüfen', 'gast'], offen: ['noch nicht bezahlt', 'warn'], kommt: ['angekündigt', ''] };
  const RBEREICH = [['beitrag', 'Beitrag'], ['sommer', 'Sommer'], ['winter', 'Winter'], ['veranstaltung', 'Veranstaltung'], ['gast', 'Gastlieger'], ['getraenke', 'Getränke (nur lesen)']];
  function postenListe(kr) {
    const l = d.rechnungen.map((r) => ({ typ: 'hafen', r, id: r.id, nr: r.nr, datum: r.datum || '', jahr: String(r.saison), bereich: r.periode, wer: r.empfaenger.vorname + ' ' + r.empfaenger.nachname, wnr: r.empfaenger.nr || '', betrag: Number(r.summe), offen: Q.rest(r), st: Q.rstatus(r, heute) }));
    d.gaeste.filter((g) => g.status !== 'storniert').forEach((g) => { const st = g.bezahlt_am ? 'bezahlt' : g.zahlung_gemeldet ? 'gemeldet' : g.ankunft > heute ? 'kommt' : 'offen';
      l.push({ typ: 'gast', g, id: g.id, nr: g.quittung_nr || '', datum: g.ankunft, jahr: g.ankunft.slice(0, 4), bereich: 'gast', wer: '„' + g.bootsname + '“', wnr: 'Gast', betrag: Number(g.betrag || 0), offen: g.bezahlt_am ? 0 : Number(g.betrag || 0), st }); });
    (kr || []).forEach((r) => { const st = r.storniert_am ? 'storniert' : r.bezahlt_am ? 'bezahlt' : r.faellig && r.faellig < heute ? 'ueberfaellig' : 'offen';
      l.push({ typ: 'getraenke', k: r, id: r.id, nr: r.nr, datum: String(r.datum || '').slice(0, 10), jahr: String(r.datum || '').slice(0, 4), bereich: 'getraenke', wer: r.empfaenger ? r.empfaenger.vorname + ' ' + r.empfaenger.nachname : '', wnr: (r.empfaenger && r.empfaenger.nr) || '', betrag: Number(r.summe), offen: st === 'offen' || st === 'ueberfaellig' ? Number(r.summe) : 0, st }); });
    return l.sort((a, b) => b.datum.localeCompare(a.datum) || String(b.nr).localeCompare(String(a.nr)));
  }
  const passtStatus = (p, s) => !s || (s === 'nicht_bezahlt' ? p.offen > 0 && p.st !== 'kommt' && p.st !== 'storniert' : p.st === s);
  V.rechnungen = (main) => {
    const s = reStand;
    const mitGetr = s.bereich === 'getraenke';
    const alle = postenListe(mitGetr ? reKasse : null);
    const jahre = [...new Set(alle.map((p) => p.jahr).filter(Boolean))].sort().reverse();
    const monate = [...new Set(alle.map((p) => p.datum.slice(0, 7)).filter(Boolean))].sort().reverse();
    if (s.jahr && !jahre.includes(s.jahr)) jahre.unshift(s.jahr);
    const opt = (v, t, sel) => '<option value="' + v + '"' + (v === sel ? ' selected' : '') + '>' + t + '</option>';
    main.innerHTML = kopf('Rechnungen & Offenes', 'Alle Rechnungen, offene Gastlieger und – nur zum Lesen – die Getränke-Rechnungen. Vorgabe: was noch nicht bezahlt ist.',
      '<button class="btn" id="csvr">Liste als CSV</button><button class="btn primaer" id="re-druck">Offene Posten drucken</button>') +
      '<div class="panel re-panel"><div id="re-kette"></div><div class="filter re-filter"><input class="suche" id="r-such" placeholder="Name, Boot oder Nummer …" aria-label="Name, Bootsname, Mitgliedsnummer oder Rechnungsnummer suchen" value="' + esc(s.such) + '">' +
      '<label class="feld">Bereich<select id="r-art">' + opt('', 'alle Bereiche', s.bereich) + RBEREICH.map(([k, t]) => opt(k, t, s.bereich)).join('') + '</select></label>' +
      '<label class="feld">Abrechnungsjahr<select id="r-jahr">' + opt('', 'alle Jahre', s.jahr) + jahre.map((j) => opt(j, j, s.jahr)).join('') + '</select></label>' +
      '<label class="feld">Monat (Datum)<select id="r-monat">' + opt('', 'alle Monate', s.monat) + monate.map((m) => opt(m, FZ.monatText(m), s.monat)).join('') + '</select></label>' +
      '<label class="feld">Stand<select id="r-status">' + opt('', 'jeder Stand', s.status) + opt('nicht_bezahlt', 'noch nicht bezahlt', s.status) + Object.entries(RSTATUS).map(([k, [t]]) => opt(k, t, s.status)).join('') + opt('gemeldet', 'Gast hat Zahlung gemeldet', s.status) + '</select></label></div>' +
      '<p id="r-summe" class="re-summe"></p>' +
      '<table class="tab re-tab fk"><thead><tr><th>Nr. · Datum</th><th>Mitglied / Boot</th><th>Bereich</th><th class="r">Betrag</th><th>Stand</th><th></th></tr></thead><tbody id="r-liste"></tbody></table><div id="r-mehr"></div></div>';
    let gefiltert = [];
    const rListe = () => {
      const q = norm(s.such);
      const basis = alle.filter((p) => (!q || norm(p.nr + ' ' + p.wnr + ' ' + p.wer).includes(q)) && (s.bereich ? p.bereich === s.bereich : p.typ !== 'getraenke') && (!s.jahr || p.jahr === s.jahr) && (!s.monat || p.datum.startsWith(s.monat)));
      gefiltert = basis.filter((p) => passtStatus(p, s.status) && (!s.stufe || (p.typ === 'hafen' && stufe(p.r) === s.stufe)));
      const hafen = basis.filter((p) => p.typ === 'hafen').map((p) => p.r);
      $('#re-kette').innerHTML = hafen.length ? ketteKopf(hafen, s.stufe) : '';
      $('#re-kette').querySelectorAll('[data-stufe]').forEach((b) => b.addEventListener('click', () => { s.stufe = s.stufe === b.dataset.stufe ? '' : b.dataset.stufe; if (s.stufe) { s.status = ''; $('#r-status').value = ''; } s.mehr = false; rListe(); }));
      const zeig = s.mehr ? gefiltert : gefiltert.slice(0, 40);
      $('#r-summe').textContent = gefiltert.length + (gefiltert.length === 1 ? ' Posten' : ' Posten') + ' · ' + H.geld(gefiltert.reduce((x, p) => x + (p.st === 'storniert' ? 0 : p.betrag), 0)) + ' · davon offen ' + H.geld(gefiltert.reduce((x, p) => x + (p.st === 'kommt' ? 0 : p.offen), 0)) +
        (mitGetr && !KASSE() ? ' · Getränkekasse nicht verbunden' : mitGetr && !reKasse ? ' · Getränke werden geladen …' : !s.bereich ? ' · Getränke: Bereich „Getränke“ wählen' : '');
      $('#r-liste').innerHTML = zeig.map(reZeile).join('') || '<tr><td colspan="6" class="leer">' + (s.status === 'nicht_bezahlt' && !s.such ? 'Nichts offen – alles bezahlt. „Stand: jeder Stand“ zeigt alle.' : 'Keine Rechnung passt zu den Filtern.') + '</td></tr>';
      $('#r-mehr').innerHTML = gefiltert.length > zeig.length ? '<button class="btn klein" style="margin-top:10px">Alle ' + gefiltert.length + ' anzeigen</button>' : '';
      const mb = $('#r-mehr button'); if (mb) mb.addEventListener('click', () => { s.mehr = true; rListe(); });
    };
    $('#r-such').addEventListener('input', (ev) => { s.such = ev.target.value; s.mehr = false; rListe(); });
    [['art', 'bereich'], ['jahr', 'jahr'], ['monat', 'monat'], ['status', 'status']].forEach(([id, k]) => $('#r-' + id).addEventListener('change', (ev) => { s[k] = ev.target.value; s.mehr = false; if (k === 'status') s.stufe = '';
      if (k === 'bereich' && (s.bereich === 'getraenke') !== mitGetr) return zeige('rechnungen', true); rListe(); }));
    rListe();
    if (mitGetr && !reKasse && KASSE()) kasseLesen(false).then((K) => { reKasse = K.re; if (tab === 'rechnungen' && reStand.bereich === 'getraenke') zeige('rechnungen', true); });
    $('#r-liste').addEventListener('click', (ev) => {
      const z = ev.target.closest('[data-zeige]'); if (z) return oeffnen('drucken.html?art=rechnungen&ids=' + z.dataset.zeige);
      const m1 = ev.target.closest('[data-mail1]'); if (m1) { const r1 = d.rechnungen.find((r) => r.id === m1.dataset.mail1); return mailVersandDialog('hafen', [r1], r1.nr + ' · ' + H.periodeText(r1)); }
      const zb = ev.target.closest('[data-zahl]'); if (zb) return zahlungDialog(d.rechnungen.find((r) => r.id === zb.dataset.zahl));
      const ge = ev.target.closest('[data-g-eingang]'); if (ge) return gastEingang(d.gaeste.find((g) => g.id === ge.dataset.gEingang));
      const gz = ev.target.closest('[data-g-zahl]'); if (gz) return gastZahlung(d.gaeste.find((g) => g.id === gz.dataset.gZahl));
      const gq = ev.target.closest('[data-g-quit]'); if (gq) return oeffnen('drucken.html?art=quittung&id=' + gq.dataset.gQuit);
      const sb = ev.target.closest('[data-storno]'); if (sb) { if (!confirm('Rechnung stornieren? Das Mitglied erscheint danach wieder in der Vorschau – so lässt sich eine falsche Rechnung korrigieren.')) return; G.stornieren(d, sb.dataset.storno); speichern('Storniert.'); zeige('rechnungen', true); }
    });
    $('#re-druck').addEventListener('click', () => oeffnen('drucken.html?art=offeneposten' + ['bereich', 'jahr', 'monat'].map((k) => s[k] ? '&' + k + '=' + encodeURIComponent(s[k]) : '').join('')));
    $('#csvr').addEventListener('click', () => download('ssv-rechnungen-' + heute + '.csv', csv([['Nr', 'Datum', 'Fällig', 'Mitgliedsnr', 'Name / Boot', 'Bereich', 'Betrag', 'Offen', 'Stand', 'Zahlart', 'SEPA-Datei', 'Bezahlt am', 'Storniert']].concat(gefiltert.map((p) => {
      if (p.typ === 'hafen') { const r = p.r; return [r.nr, H.datum(r.datum), H.datum(r.faellig), r.empfaenger.nr, p.wer, H.periodeText(r), H.zahl(r.summe), H.zahl(Q.rest(r)), RSTATUS[p.st][0], r.sepa ? 'Lastschrift' : 'Überweisung', r.sepa_lauf || '', H.datum(r.bezahlt_am), r.storniert_am ? 'ja' : '']; }
      if (p.typ === 'gast') { const g = p.g; return [g.quittung_nr || '', H.datum(g.ankunft), '', 'Gast', p.wer, 'Gastlieger ' + g.naechte + (g.naechte === 1 ? ' Nacht' : ' Nächte'), H.zahl(p.betrag), H.zahl(p.offen), GSTAND[p.st][0], ZAHLART[g.zahlung] || '', '', H.datum(g.bezahlt_am), '']; }
      const r = p.k; return [r.nr, H.datum(p.datum), H.datum(r.faellig), p.wnr, p.wer, 'Getränke', H.zahl(p.betrag), H.zahl(p.offen), p.st === 'ueberfaellig' ? 'überfällig' : p.st === 'bezahlt' ? 'bezahlt' : p.st === 'storniert' ? 'storniert' : 'offen', r.sepa ? 'Lastschrift' : 'Überweisung', '', H.datum(r.bezahlt_am), r.storniert_am ? 'ja' : '']; }))), 'text/csv'));
  };
  function reZeile(p) {
    if (p.typ === 'hafen') { const r = p.r; const st = p.st; const rest = p.offen; const z = r.zahlungen || []; const vs = versandVon('hafen', r.id);
      return '<tr' + (r.storniert_am ? ' class="blass"' : '') + '><td data-l="Nr."><strong class="nw">' + esc(r.nr) + '</strong><br><small class="nw re-datum">' + H.datum(r.datum) + '</small></td><td data-l="Mitglied">' + esc(p.wer) + ' <small class="fin-leise nw">' + esc(p.wnr) + '</small></td><td class="nw" data-l="Bereich">' + H.periodeText(r) + '</td>' +
        '<td class="r nw" data-l="Betrag">' + H.geld(r.summe) + (rest > 0 && rest < r.summe ? '<br><small>offen ' + H.geld(rest) + '</small>' : '') + '</td>' +
        '<td data-l="Stand">' + kette(r) + '<span class="tag ' + STUFE[stufe(r)][1] + '">' + (st === 'ueberfaellig' || st === 'teilbezahlt' || st === 'ruecklastschrift' ? RSTATUS[st][0] : STUFE[stufe(r)][0]) + '</span>' + (r.bezahlt_am ? ' <small class="nw fin-leise">' + H.kurz(r.bezahlt_am) + '</small>' : '') +
          (vs ? ' <small class="mv-gesendet nw" title="per E-Mail an ' + esc(vs.email) + '">✉ ' + H.kurz(String(vs.gesendet).slice(0, 10)) + '</small>' : '') +
          '<br><small class="fin-leise">' + (r.sepa ? 'Lastschrift' + (r.sepa_lauf ? ' <span class="nw">' + esc(r.sepa_lauf) + '</span>' : '') : 'Überweisung') + (z.length > 1 ? ' · <span title="' + esc(z.map((x) => H.datum(x.datum) + ' ' + (x.art === 'ruecklastschrift' ? 'Rücklastschrift' : 'Eingang') + ' ' + H.geld(x.betrag) + (x.notiz ? ' – ' + x.notiz : '')).join('\n')) + '">' + z.length + ' Buchungen</span>' : '') + '</small></td>' +
        '<td class="r aktion">' + (r.storniert_am ? '<button class="btn klein" data-zeige="' + r.id + '">Ansehen</button>' : '<button class="btn klein' + (rest > 0 ? ' primaer' : '') + '" data-zahl="' + r.id + '">Zahlung</button> ' +
          zeilenMenue(['<button class="zm-punkt" data-zeige="' + r.id + '">Rechnung ansehen</button>', '<button class="zm-punkt" data-mail1="' + r.id + '">Per E-Mail senden</button>'].concat(!r.bezahlt_am && !Q.gezahlt(r) ? ['<button class="zm-punkt gefahr" data-storno="' + r.id + '">Stornieren</button>'] : []))) + '</td></tr>'; }
    if (p.typ === 'gast') { const g = p.g; const [t, c] = GSTAND[p.st];
      return '<tr><td data-l="Quittung"><strong class="nw">' + esc(g.quittung_nr || 'Gastlieger') + '</strong><br><small class="nw re-datum">' + H.datum(g.ankunft) + '</small></td><td data-l="Boot">' + esc(p.wer) + ' <small class="fin-leise">Gast</small></td><td class="nw" data-l="Bereich">Gastlieger · ' + g.naechte + (g.naechte === 1 ? '&nbsp;Nacht' : '&nbsp;Nächte') + '</td>' +
        '<td class="r nw" data-l="Betrag">' + H.geld(g.betrag) + '</td><td data-l="Stand"><span class="tag ' + c + '">' + t + '</span>' + (g.bezahlt_am ? ' <small class="nw fin-leise">' + H.kurz(g.bezahlt_am) + '</small>' : '') + (g.zahlung && g.zahlung !== 'offen' ? '<br><small class="fin-leise">' + esc(ZAHLART[g.zahlung] || g.zahlung) + '</small>' : '') + '</td>' +
        '<td class="r aktion">' + (p.st === 'gemeldet' ? '<button class="btn klein primaer" data-g-eingang="' + g.id + '">Ist eingegangen</button>' : p.st !== 'bezahlt' ? '<button class="btn klein' + (p.st === 'offen' ? ' primaer' : '') + '" data-g-zahl="' + g.id + '">Zahlung</button>' : g.quittung_nr ? '<button class="btn klein" data-g-quit="' + g.id + '">Quittung</button>' : '') + '</td></tr>'; }
    const r = p.k; const ST = { bezahlt: ['bezahlt', 'ok'], ueberfaellig: ['überfällig', 'rot'], offen: ['offen', 'warn'], storniert: ['storniert', ''] }[p.st];
    return '<tr' + (p.st === 'storniert' ? ' class="blass"' : '') + '><td data-l="Nr."><strong class="nw">' + esc(r.nr) + '</strong><br><small class="nw re-datum">' + H.datum(p.datum) + '</small></td><td data-l="Mitglied">' + esc(p.wer) + ' <small class="fin-leise nw">' + esc(p.wnr) + '</small></td><td class="nw" data-l="Bereich">Getränke' + (r.von ? ' ' + FZ.monatText(String(r.von).slice(0, 7)) : '') + '</td>' +
      '<td class="r nw" data-l="Betrag">' + H.geld(r.summe) + '</td><td data-l="Stand"><span class="tag ' + ST[1] + '">' + ST[0] + '</span>' + (r.bezahlt_am ? ' <small class="nw fin-leise">' + H.kurz(String(r.bezahlt_am).slice(0, 10)) + '</small>' : '') + '<br><small class="fin-leise">' + (r.sepa ? 'Lastschrift' : 'Überweisung') + '</small></td>' +
      '<td class="r aktion"><a class="btn klein" href="' + KASSE_URL + '" target="_blank" rel="noopener" title="Getränke-Rechnungen bearbeitet der Kassenwart in der Getränkekasse">In der Kasse ↗</a></td></tr>';
  }
  // Gastlieger: Zahlung von Hand buchen (bar, Überweisung, PayPal, Karte) bzw. gemeldete Zahlung bestätigen – vergibt die Quittungsnummer
  const quittungNr = (g) => { if (!g.quittung_nr) g.quittung_nr = 'Q-' + g.ankunft.slice(0, 4) + '-' + String(++d.zaehler.quittung).padStart(3, '0'); return g.quittung_nr; };
  function gastEingang(g) {
    if (!g || !confirm(H.geld(g.betrag) + ' von „' + g.bootsname + '“ per ' + (ZAHLART[g.zahlung] || g.zahlung) + ' eingegangen?')) return;
    g.bezahlt_am = heute; quittungNr(g); speichern('Zahlung verbucht – Quittung ' + g.quittung_nr + '.'); zeige(tab, true);
  }
  function gastZahlung(g) {
    const el = modal('<h2>Zahlung · „' + esc(g.bootsname) + '“</h2><p style="margin-top:0">Gastlieger ab ' + H.datum(g.ankunft) + ' · ' + g.naechte + (g.naechte === 1 ? ' Nacht' : ' Nächte') + ' · <strong>' + H.geld(g.betrag) + '</strong></p>' +
      '<form id="f" class="form"><label class="feld">Eingang am<input name="datum" type="date" required max="' + heute + '" value="' + heute + '"></label><label class="feld">Zahlart<select name="zahlung">' +
        ['bar', 'ueberweisung', 'paypal', 'karte'].map((k) => '<option value="' + k + '"' + (g.zahlung === k ? ' selected' : '') + '>' + ZAHLART[k] + '</option>').join('') + '</select></label></form>' +
      '<p class="hinweis">Der Gast bekommt eine Quittungsnummer. Alles andere zum Gast (Platz, Nächte) steht im Bereich „Gäste“.</p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Als bezahlt buchen</button></div>');
    $('#ok', el).addEventListener('click', () => { const fm = $('#f', el); if (!fm.reportValidity()) return;
      g.bezahlt_am = fm.datum.value; g.zahlung = fm.zahlung.value; quittungNr(g); speichern('Zahlung verbucht – Quittung ' + g.quittung_nr + '.'); zu(); zeige(tab, true); });
  }
  /* ============================================================ Kontoauszug
   * Umsätze aus dem Online-Banking einlesen (CAMT/XML oder CSV) und Zahlungen zuordnen (js/kontoauszug.js).
   * Die Datei selbst wird nicht gespeichert – nur, was gebucht wird (mit Umsatz-Schlüssel gegen doppeltes Buchen). */
  const KA = window.HAFEN_KONTO;
  const kaStand = { datei: '', umsaetze: null, zu: null, wahl: {}, manuell: {}, gebucht: new Set(), getraenke: [], fehler: '' };
  const kaKtx = () => ({ rechnungen: d.rechnungen, getraenke: kaStand.getraenke, gaeste: d.gaeste, laeufe: d.sepa_laeufe, mitglieder: d.mitglieder, rest: Q.rest, rstatus: (r) => Q.rstatus(r, heute), heute });
  const kaZuordnen = () => { kaStand.zu = KA.zuordnen(kaStand.umsaetze, kaKtx()); kaStand.umsaetze.forEach((u, i) => { const z = kaStand.zu[i]; if (!(u.key in kaStand.wahl)) kaStand.wahl[u.key] = z.sicher; }); };
  async function kaDatei(file) {
    if (!file) return;
    try {
      const buf = await file.arrayBuffer(); let text;
      try { text = new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (e) { text = new TextDecoder('windows-1252').decode(buf); }   // Sparkasse & Co. liefern CSV oft in Windows-1252
      const l = KA.lesen(text, file.name);
      const kasse = KASSE(); kaStand.getraenke = kasse ? await kasse.rechnungen().catch(() => []) : [];
      if (DB) { await HF.neuLaden(); d = HF.d; }   // neuester Stand, bevor zugeordnet wird
      Object.assign(kaStand, { datei: file.name, umsaetze: l, wahl: {}, manuell: {}, gebucht: new Set(), fehler: '' }); kaZuordnen();
    } catch (er) { Object.assign(kaStand, { datei: file.name, umsaetze: null, zu: null, fehler: er.message }); }
    zeige('kontoauszug', true);
  }
  // offene Posten für die manuelle Zuordnung (Klärliste)
  function kaOptionen(u, z) {
    const vorne = new Set(z.mitglieder || []);
    const nm = (id) => { const m = Q.mitglied(id); return m ? m.nachname + ', ' + m.vorname : ''; };
    const hafen = d.rechnungen.filter((r) => Q.rest(r) > 0).sort((a2, b2) => (vorne.has(b2.mitglied_id) - vorne.has(a2.mitglied_id)) || a2.nr.localeCompare(b2.nr));
    const getr = kaStand.getraenke.filter((r) => !r.bezahlt_am && !r.storniert_am).sort((a2, b2) => (vorne.has(b2.mitglied_id) - vorne.has(a2.mitglied_id)) || a2.nr.localeCompare(b2.nr));
    const gaeste = d.gaeste.filter((g) => !g.bezahlt_am && g.status !== 'storniert');
    const sel = kaStand.manuell[u.key] || '';
    const o = (v, t) => '<option value="' + v + '"' + (v === sel ? ' selected' : '') + '>' + esc(t) + '</option>';
    return '<select class="ka-wahl" data-ka-man="' + esc(u.key) + '" aria-label="Zuordnung wählen"><option value="">– nicht buchen –</option>' +
      (hafen.length ? '<optgroup label="Hafen, Beiträge, Veranstaltungen">' + hafen.map((r) => o('hafen:' + r.id, r.nr + ' · ' + nm(r.mitglied_id) + ' · offen ' + H.geld(Q.rest(r)))).join('') + '</optgroup>' : '') +
      (getr.length ? '<optgroup label="Getränke">' + getr.map((r) => o('getraenke:' + r.id, r.nr + ' · ' + nm(r.mitglied_id) + ' · ' + H.geld(r.summe))).join('') + '</optgroup>' : '') +
      (gaeste.length ? '<optgroup label="Gastlieger">' + gaeste.map((g) => o('gast:' + g.id, '„' + g.bootsname + '“ · ' + H.datum(g.ankunft) + ' · ' + H.geld(g.betrag))).join('') + '</optgroup>' : '') + '</select>';
  }
  const kaManuellZiel = (u, wert) => { const [typ, id] = wert.split(':'); return { art: typ === 'hafen' ? 'rechnung' : typ, sicher: true, text: 'von Hand zugeordnet', ziele: [{ typ, id, betrag: u.betrag }], hinweis: '' }; };
  // Zahlungseingang: unter dem Kontoauszug die Lastschrift-Dateien („Gutschrift ist da“) und die von Gästen gemeldeten Zahlungen –
  // alles, was Geld als eingegangen bucht, an einer Stelle. Ganz unten: wann zuletzt abgeglichen wurde.
  function zeExtras() {
    const e = d.einstellungen;
    const gm = d.gaeste.filter((g) => g.zahlung_gemeldet && !g.bezahlt_am && g.status !== 'storniert').sort((a, b) => a.ankunft.localeCompare(b.ankunft));
    return '<div class="panel" id="ze-lastschrift"><h2>Lastschriften</h2>' + (d.sepa_laeufe.length
        ? '<p class="fin-wie">Ist eine Sammellastschrift auf dem Vereinskonto, „Gutschrift ist da“ drücken – alle Posten der Datei gelten dann als bezahlt. Steht sie im Kontoauszug, erkennt das Einlesen sie auch selbst.</p>' + laeufeHtml(d.sepa_laeufe)
        : '<p class="leer" style="margin:0">Noch keine Lastschrift-Datei – die entsteht unter „Abrechnen“, Schritt 4.</p>') + '</div>' +
      '<div class="panel" id="ze-gaeste"><h2>Gemeldete Zahlungen von Gästen</h2>' + (gm.length
        ? '<p class="fin-wie">Diese Gäste haben auf der Gast-Seite angegeben, dass sie bezahlt haben. Ist das Geld da (Konto, PayPal, Briefkasten), „Ist eingegangen“ drücken.</p><table class="tab fk"><thead><tr><th>Boot</th><th>Ankunft</th><th>Platz</th><th class="r">Betrag</th><th>Zahlart</th><th></th></tr></thead><tbody>' +
          gm.map((g) => '<tr><td data-l="Boot"><strong>„' + esc(g.bootsname) + '“</strong></td><td class="nw" data-l="Ankunft">' + H.datum(g.ankunft) + ' · ' + g.naechte + (g.naechte === 1 ? '&nbsp;Nacht' : '&nbsp;Nächte') + '</td>' +
            '<td data-l="Platz">' + (g.platz_id ? esc(platzName(g.platz_id)) : g.platz_angabe ? esc(angabe(g.platz_angabe)) + ' <small class="fin-leise">(laut Gast)</small>' : '–') + '</td><td class="r nw" data-l="Betrag"><strong>' + H.geld(g.betrag) + '</strong></td><td data-l="Zahlart">' + esc(ZAHLART[g.zahlung] || g.zahlung || '') + '</td>' +
            '<td class="r aktion"><button class="btn klein primaer" data-g-eingang="' + g.id + '">Ist eingegangen</button></td></tr>').join('') + '</tbody></table>'
        : '<p class="leer" style="margin:0">Keine gemeldete Gast-Zahlung offen.</p>') + '</div>' +
      '<p class="ze-zuletzt">Zuletzt abgeglichen am <strong>' + (e.kontoauszug_zuletzt ? H.datum(e.kontoauszug_zuletzt) : '– (noch nie)') + '</strong>' + (e.kontoauszug_zuletzt && e.kontoauszug_zuletzt < tagVor(heute, 30) ? ' – bitte den neuen Kontoauszug einlesen.' : '') + '</p>';
  }
  V.kontoauszug = (main) => {
    const e = d.einstellungen; const s = kaStand;
    const anleitung = '<ol class="ka-schritte"><li>Im Online-Banking die <strong>Umsätze exportieren</strong>: am besten als <strong>CAMT</strong> (XML), sonst als <strong>CSV</strong> – bei der Sparkasse „CSV-CAMT“. Zeitraum: seit dem letzten Abgleich' + (e.kontoauszug_zuletzt ? ' (' + H.datum(e.kontoauszug_zuletzt) + ')' : '') + '.</li>' +
      '<li>Die Datei hier hineinziehen oder „Datei wählen“.</li><li>Zuordnungen prüfen, Häkchen setzen, <strong>„Buchen“</strong>. Was nicht zuzuordnen ist, steht auf der Klärliste.</li></ol>' +
      '<p class="hinweis">Erkannt werden Rechnungsnummern im Verwendungszweck (' + esc(e.rechnung_praefix || 'SSV-H') + '-…, ' + esc(e.beitrag_praefix || 'SSV-B') + '-…, ' + esc(e.veranstaltung_praefix || 'SSV-V') + '-…, Getränke SSV-G-…), die Sammellastschriften des Vereins, Rücklastschriften und Gastlieger (Bootsname + Betrag). Die Datei bleibt auf diesem Gerät; gespeichert wird nur, was gebucht wird. Derselbe Auszug kann gefahrlos noch einmal eingelesen werden – schon Gebuchtes wird erkannt.</p>';
    const knopf = '<label class="btn primaer ka-knopf">Datei wählen …<input type="file" id="ka-datei" accept=".xml,.csv,.txt,.sta" hidden></label>';
    if (!s.umsaetze) {
      main.innerHTML = kopf('Zahlungseingang', 'Kontoauszug einlesen, Lastschriften gutschreiben, Gast-Zahlungen bestätigen – alles, was Geld als eingegangen bucht.', knopf) +
        (s.fehler ? '<p class="hinweis warn">„' + esc(s.datei) + '“ ließ sich nicht lesen: ' + esc(s.fehler) + '</p>' : '') +
        '<div class="panel ka-ablage" id="ka-ablage"><h2>Kontoauszug einlesen</h2><div class="ka-ziel">Kontoauszug hierher ziehen<small>CAMT (.xml) oder CSV</small></div>' + anleitung + '</div>';
    } else {
      const zeilen = s.umsaetze.map((u, i) => ({ u, z: s.gebucht.has(u.key) ? { art: 'gebucht', text: 'gebucht ✓', ziele: [] } : (s.manuell[u.key] ? kaManuellZiel(u, s.manuell[u.key]) : s.zu[i]), auto: s.zu[i] }));
      const zug = zeilen.filter((x) => ['rechnung', 'lauf', 'gast', 'getraenke', 'rueck'].includes(x.z.art) && !s.manuell[x.u.key]);
      const klaer = zeilen.filter((x) => x.auto.art === 'unklar' && !s.gebucht.has(x.u.key));
      const rest = zeilen.filter((x) => ['ausgabe', 'doppelt', 'gebucht'].includes(x.z.art) && !(x.auto.art === 'unklar' && !s.gebucht.has(x.u.key)));
      const ein = s.umsaetze.filter((u) => u.betrag > 0); const summeEin = ein.reduce((x, u) => x + u.betrag, 0);
      const waehlbar = zeilen.filter((x) => x.z.ziele && x.z.ziele.length && !s.gebucht.has(x.u.key));
      const gewaehlt = waehlbar.filter((x) => s.wahl[x.u.key]);
      const kurzZweck = (t) => { t = String(t || ''); return t.length > 90 ? t.slice(0, 88) + '…' : t; };
      const ARTTAG = { rechnung: 'Rechnung', lauf: 'Lastschrift', gast: 'Gast', getraenke: 'Getränke', rueck: 'Rücklastschrift' };
      const zeile = (x, klaerung) => { const { u, z } = x; const kann = z.ziele && z.ziele.length && !s.gebucht.has(u.key);
        return '<tr class="' + (s.gebucht.has(u.key) ? 'blass' : '') + '"><td class="ka-cb">' + (kann ? '<input type="checkbox" data-ka-wahl="' + esc(u.key) + '"' + (s.wahl[u.key] ? ' checked' : '') + ' aria-label="buchen">' : '') + '</td>' +
          '<td class="nw">' + H.datum(u.datum) + '</td><td>' + esc(u.name || '–') + (u.iban ? '<br><small style="color:var(--muted)">•••• ' + esc(u.iban.slice(-4)) + '</small>' : '') + '</td>' +
          '<td><small>' + esc(kurzZweck(u.zweck)) + '</small></td><td class="r nw' + (u.betrag < 0 ? ' ka-minus' : '') + '"><strong>' + H.geld(u.betrag) + '</strong></td>' +
          '<td>' + (klaerung ? kaOptionen(u, x.auto) + (x.auto.text && x.auto.text !== 'nicht zugeordnet' ? '<br><small style="color:var(--muted)">' + esc(x.auto.text) + (x.auto.hinweis ? ' – ' + esc(x.auto.hinweis) : '') + '</small>' : '')
            : (ARTTAG[z.art] ? '<span class="tag ' + (z.art === 'rueck' ? 'rot' : z.sicher ? 'ok' : 'warn') + '">' + ARTTAG[z.art] + (z.sicher ? '' : ' · Vorschlag') + '</span> ' : '') + esc(z.text) + (z.hinweis ? '<br><small style="color:var(--muted)">' + esc(z.hinweis) + '</small>' : '')) + '</td></tr>'; };
      const tab = (l, klaerung) => '<table class="tab ka-tab"><thead><tr><th></th><th>Datum</th><th>Von / an</th><th>Verwendungszweck</th><th class="r">Betrag</th><th>Zuordnung</th></tr></thead><tbody>' + l.map((x) => zeile(x, klaerung)).join('') + '</tbody></table>';
      const nSicher = zug.filter((x) => x.z.sicher).length, nVor = zug.length - nSicher;
      main.innerHTML = kopf('Zahlungseingang', 'Kontoauszug ' + esc(s.datei) + ' · ' + s.umsaetze.length + ' Umsätze vom ' + H.datum(s.umsaetze[0].datum) + ' bis ' + H.datum(s.umsaetze[s.umsaetze.length - 1].datum), '<button class="btn" id="ka-neu">Andere Datei</button>' + knopf) +
        '<div class="karten ka-karten"><div class="kz"><small>Eingänge</small><strong>' + H.geld(summeEin) + '</strong><span>' + ein.length + ' Umsätze</span></div>' +
        '<div class="kz"><small>Zugeordnet</small><strong>' + nSicher + '</strong><span>' + (nVor ? nVor + ' Vorschl' + (nVor === 1 ? 'ag' : 'äge') + ' zum Prüfen' : 'sicher erkannt') + '</span></div>' +
        '<div class="kz"><small>Klärliste</small><strong' + (klaer.length ? ' style="color:#8a5e05"' : '') + '>' + klaer.length + '</strong><span>' + (klaer.length ? 'von Hand zuordnen oder klären' : 'nichts offen') + '</span></div>' +
        '<div class="kz"><small>Gebucht</small><strong>' + s.gebucht.size + '</strong><span>' + rest.filter((x) => x.z.art === 'doppelt').length + ' schon früher · ' + rest.filter((x) => x.z.art === 'ausgabe').length + (rest.filter((x) => x.z.art === 'ausgabe').length === 1 ? ' Ausgabe' : ' Ausgaben') + '</span></div></div>' +
        (zug.length ? '<div class="panel"><h2>Zugeordnet</h2>' + tab(zug, false) + '</div>' : '') +
        (klaer.length ? '<div class="panel"><h2>Klärliste</h2><p class="hinweis" style="margin-top:0">Diese Eingänge passen zu keiner Rechnung. Von Hand zuordnen – oder nachfragen (z. B. Spende, falscher Verwendungszweck, doppelt überwiesen).</p>' + tab(klaer, true) + '</div>' : '') +
        (rest.length ? '<details class="panel"><summary><h2 style="display:inline">Ausgaben und schon Gebuchtes (' + rest.length + ')</h2></summary>' + tab(rest, false) + '</details>' : '') +
        '<div class="ka-fuss"><button class="btn primaer" id="ka-buchen"' + (gewaehlt.length ? '' : ' disabled') + '>' + (gewaehlt.length ? gewaehlt.length + (gewaehlt.length === 1 ? ' Zahlung' : ' Zahlungen') + ' buchen' : 'Nichts ausgewählt') + '</button>' +
        (klaer.length ? '<button class="btn" id="ka-csv">Klärliste als CSV</button>' : '') + '</div>';
      main.querySelectorAll('[data-ka-wahl]').forEach((c) => c.addEventListener('change', () => { s.wahl[c.dataset.kaWahl] = c.checked; zeige('kontoauszug', true); }));
      main.querySelectorAll('[data-ka-man]').forEach((c) => c.addEventListener('change', () => { if (c.value) { s.manuell[c.dataset.kaMan] = c.value; s.wahl[c.dataset.kaMan] = true; } else { delete s.manuell[c.dataset.kaMan]; s.wahl[c.dataset.kaMan] = false; } zeige('kontoauszug', true); }));
      $('#ka-neu').addEventListener('click', () => { Object.assign(s, { umsaetze: null, zu: null, datei: '', fehler: '' }); zeige('kontoauszug'); });
      const kc = $('#ka-csv'); if (kc) kc.addEventListener('click', () => download('klaerliste-' + heute + '.csv', csv([['Datum', 'Name', 'IBAN', 'Verwendungszweck', 'Betrag', 'Hinweis']].concat(klaer.map(({ u, auto }) => [H.datum(u.datum), u.name, u.iban, u.zweck, H.zahl(u.betrag), [auto.text, auto.hinweis].filter(Boolean).join(' – ')]))), 'text/csv'));
      $('#ka-buchen').addEventListener('click', () => kaBuchen(gewaehlt));
    }
    main.insertAdjacentHTML('beforeend', zeExtras());
    main.querySelectorAll('[data-gutschrift]').forEach((b) => b.addEventListener('click', () => gutschriftBuchen(b.dataset.gutschrift)));
    main.querySelectorAll('[data-g-eingang]').forEach((b) => b.addEventListener('click', () => gastEingang(d.gaeste.find((g) => g.id === b.dataset.gEingang))));
    $('#ka-datei').addEventListener('change', (ev) => kaDatei(ev.target.files[0]));
    const ab = $('#ka-ablage');
    if (ab) { ['dragenter', 'dragover'].forEach((t) => ab.addEventListener(t, (ev) => { ev.preventDefault(); ab.classList.add('ueber'); }));
      ab.addEventListener('dragleave', () => ab.classList.remove('ueber')); ab.addEventListener('drop', (ev) => { ev.preventDefault(); ab.classList.remove('ueber'); kaDatei(ev.dataTransfer.files[0]); }); }
  };
  let kaLaeuft = false;
  async function kaBuchen(liste) {
    if (kaLaeuft || !liste.length) return;
    const summe = liste.reduce((x, { u }) => x + u.betrag, 0);
    if (!confirm(liste.length + (liste.length === 1 ? ' Zahlung' : ' Zahlungen') + ' (' + H.geld(summe) + ') buchen?')) return;
    kaLaeuft = true; const kasse = KASSE(); const fehler = []; let n = 0;
    try {
      for (const { u, z } of liste) {
        try {
          for (const ziel of z.ziele) {
            if (ziel.typ === 'hafen') {
              const r = d.rechnungen.find((x) => x.id === ziel.id); if (!r) continue;
              if (z.art === 'rueck') {
                const zs = (r.zahlungen || []).slice(); if (r.bezahlt_am && !zs.length) zs.push({ datum: r.bezahlt_am, betrag: r.summe, art: 'eingang', notiz: 'Lastschrift ' + (r.sepa_lauf || '') });
                let war = r.bezahlt_am ? r.summe : Q.gezahlt(r);
                if (!war) { zs.push({ datum: u.datum, betrag: r.summe, art: 'eingang', notiz: 'Lastschrift ' + (r.sepa_lauf || '') + ' (Kontoauszug)', ref: u.key + '#e' }); war = r.summe; }
                zs.push({ datum: u.datum, betrag: war, art: 'ruecklastschrift', notiz: 'laut Kontoauszug' + (u.rueckGrund ? ' (Grund ' + u.rueckGrund + ')' : '') + (z.hinweis ? ', ' + z.hinweis : ''), ref: u.key });
                r.zahlungen = zs; r.bezahlt_am = null;
              } else {
                r.zahlungen = (r.zahlungen || []).concat([{ datum: u.datum, betrag: ziel.betrag, art: 'eingang', notiz: (z.art === 'lauf' ? 'Lastschrift ' + (r.sepa_lauf || '') : 'Überweisung' + (u.name ? ' ' + u.name : '')) + ' (Kontoauszug)', ref: u.key }]);
                if (Q.gezahlt(r) >= r.summe - 0.001) r.bezahlt_am = u.datum;
              }
            } else if (ziel.typ === 'gast') {
              const g = d.gaeste.find((x) => x.id === ziel.id); if (!g) continue;
              g.bezahlt_am = u.datum; if (!g.zahlung || g.zahlung === 'offen') g.zahlung = 'ueberweisung';
              if (!g.quittung_nr) g.quittung_nr = 'Q-' + g.ankunft.slice(0, 4) + '-' + String(++d.zaehler.quittung).padStart(3, '0');
            } else if (ziel.typ === 'getraenke') {
              if (!kasse) throw new Error('Getränkekasse nicht erreichbar');
              await kasse.rechnungBezahlt(ziel.id, u.datum); const gr = kaStand.getraenke.find((x) => x.id === ziel.id); if (gr) gr.bezahlt_am = u.datum;
            }
          }
          kaStand.gebucht.add(u.key); n++;
        } catch (er) { fehler.push(H.datum(u.datum) + ' ' + H.geld(u.betrag) + ': ' + er.message); }
      }
      d.einstellungen.kontoauszug_zuletzt = heute;
      const ok = await speichern(); if (ok === false) return;
      toast(n + (n === 1 ? ' Zahlung' : ' Zahlungen') + ' gebucht.' + (fehler.length ? ' Nicht gebucht: ' + fehler.join('; ') : ''), fehler.length ? 'fehler' : '', fehler.length ? 8000 : 3200);
    } finally { kaLaeuft = false; zeige('kontoauszug', true); }
  }

  /* ============================================================ Rechnungen per E-Mail
   * Ablauf: Prüfen (Server sagt, an welche Adresse jede Rechnung ginge) → Kassenwart bestätigt → Senden.
   * Sicherheit: Der Browser schickt nur Rechnungs-IDs; die Adresse liest die Edge Function „rechnung-mail“ selbst aus dem
   * Mitglied, dem die Rechnung gehört. Mitgeschickt werden nur die beim Prüfen gesehenen Adressen – weicht eine ab, geht
   * diese Rechnung nicht raus. Jede Mail: genau ein Empfänger, genau eine Rechnung als PDF. */
  const versandVon = (art, id) => (d.rechnung_versand || []).filter((v) => v.art === art && v.rechnung_id === id).sort((x, y) => String(y.gesendet).localeCompare(String(x.gesendet)))[0];
  const mailOk = (s) => /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$/.test(String(s || '').trim()) && !/\.\./.test(String(s));
  const MSTAND = { bereit: ['bereit', 'ok'], keine_email: ['keine E-Mail-Adresse', 'warn'], ungueltig: ['Adresse ungültig', 'rot'], schon_gesendet: ['schon gesendet', ''], storniert: ['storniert', ''], kein_mitglied: ['Mitglied fehlt', 'rot'], nicht_gefunden: ['nicht gefunden', 'rot'],
    gesendet: ['gesendet', 'ok'], fehler: ['Fehler', 'rot'], adresse_geaendert: ['Adresse inzwischen geändert – nicht gesendet', 'warn'] };
  async function mailFunktion(body) { return window.SSV_SB.req('/functions/v1/rechnung-mail', { method: 'POST', body }); }
  // Demo: dieselben Regeln im Browser, ohne echten Versand
  function mailPruefenDemo(art, ids) {
    return { eingerichtet: true, demo: true, liste: ids.map((id) => { const r = d.rechnungen.find((x) => x.id === id); if (!r) return { id, status: 'nicht_gefunden' };
      const m = Q.mitglied(r.mitglied_id); const basis = { id, nr: r.nr, betrag: r.summe, mitglied_id: r.mitglied_id, mitglied: m ? { nr: m.nr, name: m.vorname + ' ' + m.nachname } : null };
      if (r.storniert_am) return { ...basis, status: 'storniert' }; if (!m) return { ...basis, status: 'kein_mitglied' };
      const email = String(m.email || '').trim(); if (!email) return { ...basis, status: 'keine_email' }; if (!mailOk(email)) return { ...basis, email, status: 'ungueltig' };
      const v = versandVon(art, id); return { ...basis, email, status: v ? 'schon_gesendet' : 'bereit', gesendet: v && v.gesendet, gesendet_an: v && v.email }; }) };
  }
  let mailLaeuft = false;
  async function mailVersandDialog(art, rechnungen, titel, nachher) {
    const ids = rechnungen.filter((r) => !r.storniert_am).map((r) => r.id);
    if (!ids.length) return toast('Keine Rechnungen zum Versenden.');
    const el = modal('<h2>Rechnungen per E-Mail</h2><p style="margin-top:0">' + esc(titel) + ' · ' + ids.length + ' Rechnung' + (ids.length === 1 ? '' : 'en') + '</p><div id="mv-inhalt"><p class="leer">Adressen werden geprüft …</p></div>', true);
    const box = $('#mv-inhalt', el);
    let pr;
    try { pr = DB ? await mailFunktion({ aktion: 'pruefen', art, ids }) : mailPruefenDemo(art, ids); }
    catch (er) { box.innerHTML = '<p class="hinweis fehler">Prüfen nicht möglich: ' + esc(er.message) + (/404|nicht gefunden|Failed/i.test(er.message) ? ' – ist die Funktion „rechnung-mail“ eingerichtet?' : '') + '</p>'; return; }
    const l = pr.liste; const zahl = (s) => l.filter((x) => x.status === s).length;
    const zeige2 = () => {
      const erneut = !!($('#mv-erneut', el) && $('#mv-erneut', el).checked);
      const raus = l.filter((x) => x.status === 'bereit' || (erneut && x.status === 'schon_gesendet'));
      box.innerHTML = (!pr.eingerichtet ? '<p class="hinweis warn">Der E-Mail-Versand ist noch nicht eingerichtet: Es fehlen der Schlüssel des Mail-Dienstes und die Absender-Adresse (siehe Anleitung „Inbetriebnahme“, Schritt Mail-Versand). Prüfen geht trotzdem.</p>' : '') +
        (pr.demo ? '<p class="hinweis">Demo: Es wird keine echte E-Mail verschickt – der Versand wird nur in diesem Browser vermerkt.</p>' : '') +
        '<div class="mv-zahlen"><span class="tag ok">' + zahl('bereit') + ' bereit</span>' + (zahl('keine_email') + zahl('ungueltig') ? '<span class="tag warn">' + (zahl('keine_email') + zahl('ungueltig')) + ' ohne gültige Adresse</span>' : '') +
          (zahl('schon_gesendet') ? '<span class="tag">' + zahl('schon_gesendet') + ' schon gesendet</span>' : '') + (zahl('storniert') ? '<span class="tag">' + zahl('storniert') + ' storniert</span>' : '') + '</div>' +
        '<div class="mv-liste"><table class="tab"><thead><tr><th>Rechnung</th><th>Mitglied</th><th class="r">Betrag</th><th>geht an</th></tr></thead><tbody>' +
          l.map((x) => '<tr><td class="nw">' + esc(x.nr || '–') + '</td><td>' + esc(x.mitglied ? x.mitglied.name : '–') + '</td><td class="r nw">' + H.geld(x.betrag || 0) + '</td><td>' +
            (x.email ? '<strong class="mv-adr">' + esc(x.email) + '</strong>' : '') + ' <span class="tag ' + MSTAND[x.status][1] + '">' + MSTAND[x.status][0] + (x.gesendet ? ' ' + H.kurz(String(x.gesendet).slice(0, 10)) : '') + '</span></td></tr>').join('') + '</tbody></table></div>' +
        (zahl('keine_email') + zahl('ungueltig') ? '<p class="hinweis warn">Ohne gültige Adresse geht nichts raus. Diese Mitglieder sehen die Rechnung in „Mein SSV“ – oder bekommen sie als Brief. Die Adresse lässt sich in der Mitgliedsakte nachtragen.</p>' : '') +
        (zahl('schon_gesendet') ? '<label class="feld check"><input type="checkbox" id="mv-erneut"' + (erneut ? ' checked' : '') + '> Schon gesendete noch einmal senden</label>' : '') +
        '<p class="hinweis ok mv-sicher">Jede Rechnung geht <strong>nur an die Adresse, die beim jeweiligen Mitglied eingetragen ist</strong> – einzeln, mit genau dieser einen Rechnung als PDF. Ändert sich eine Adresse nach dem Prüfen, bleibt diese Rechnung liegen.</p>' +
        '<label class="feld check mv-ok"><input type="checkbox" id="mv-geprueft"> Ich habe die Liste geprüft – Mitglieder und Adressen passen.</label>' +
        '<div class="modal-fuss"><button class="btn links" id="mv-test"' + (pr.eingerichtet && raus.length ? '' : ' disabled') + '>Test-Mail an mich</button><button class="btn" data-zu>Abbrechen</button>' +
          '<button class="btn primaer" id="mv-los" disabled>' + raus.length + ' Rechnung' + (raus.length === 1 ? '' : 'en') + ' senden</button></div>';
      const er = $('#mv-erneut', el); if (er) er.addEventListener('change', zeige2);
      const gp = $('#mv-geprueft', el), los = $('#mv-los', el);
      gp.addEventListener('change', () => { los.disabled = !gp.checked || !raus.length || !pr.eingerichtet; });
      $('#mv-test', el).addEventListener('click', async (ev) => {
        const k = ev.currentTarget; k.disabled = true;
        try { if (DB) { const t = await mailFunktion({ aktion: 'test', art, ids: [raus[0].id] }); toast('Test-Mail an ' + t.an + ' gesendet – bitte ansehen.'); } else toast('Demo: Die Test-Mail ginge an deine Anmelde-Adresse.'); }
        catch (x2) { toast('Test-Mail nicht gesendet: ' + x2.message, 'fehler', 7000); } finally { k.disabled = false; }
      });
      los.addEventListener('click', async () => {
        if (mailLaeuft || !gp.checked) return; mailLaeuft = true;
        el.querySelectorAll('.modal-fuss .btn, input').forEach((b) => { b.disabled = true; });
        const erg = []; const erwartet = Object.fromEntries(raus.map((x) => [x.id, x.email]));
        try {
          for (let i = 0; i < raus.length; i += 20) {
            const teil = raus.slice(i, i + 20).map((x) => x.id);
            los.textContent = 'Wird gesendet … ' + Math.min(i + 20, raus.length) + ' von ' + raus.length;
            if (DB) { const a2 = await mailFunktion({ aktion: 'senden', art, ids: teil, erwartet: Object.fromEntries(teil.map((id) => [id, erwartet[id]])), erneut }); erg.push(...a2.ergebnis); }
            else teil.forEach((id) => { const x = raus.find((y) => y.id === id); d.rechnung_versand.push({ art, rechnung_id: id, email: x.email, gesendet: new Date().toISOString() }); erg.push({ id, nr: x.nr, status: 'gesendet', email: x.email }); });
          }
        } catch (x3) { erg.push({ status: 'fehler', fehler: x3.message }); }
        if (!DB) HF.sichern();
        mailLaeuft = false;
        const ok = erg.filter((x) => x.status === 'gesendet'); const nicht = erg.filter((x) => x.status !== 'gesendet');
        box.innerHTML = '<p class="hinweis ' + (nicht.length ? 'warn' : 'ok') + '"><strong>' + ok.length + ' Rechnung' + (ok.length === 1 ? '' : 'en') + ' gesendet.</strong>' + (nicht.length ? ' ' + nicht.length + ' nicht gesendet:' : ' Jede an die eingetragene Adresse des Mitglieds.') + '</p>' +
          (nicht.length ? '<ul>' + nicht.map((x) => '<li>' + esc(x.nr || '') + ' – ' + esc(MSTAND[x.status] ? MSTAND[x.status][0] : x.status) + (x.fehler ? ': ' + esc(x.fehler) : '') + '</li>').join('') + '</ul><p class="hinweis">Nicht Gesendetes einfach noch einmal prüfen und senden – schon Gesendetes geht nicht doppelt raus.</p>' : '') +
          '<div class="modal-fuss"><button class="btn primaer" id="mv-fertig">Fertig</button></div>';
        $('#mv-fertig', el).addEventListener('click', async () => { zu(); if (DB) { await HF.neuLaden().catch(() => {}); d = HF.d; } if (nachher) nachher(ok.length, nicht.length); else zeige(tab, true); });
      });
    };
    zeige2();
  }

  // Zahlungseingang (auch Teilzahlung) und Rücklastschrift je Rechnung
  function zahlungDialog(r) {
    if (!r.zahlungen) r.zahlungen = [];
    const rest = Q.rest(r); const st = Q.rstatus(r, heute);
    const el = modal('<h2>Zahlung · ' + esc(r.nr) + '</h2><p>' + esc(r.empfaenger.vorname + ' ' + r.empfaenger.nachname) + ' · ' + H.periodeText(r) + ' · Betrag <strong>' + H.geld(r.summe) + '</strong> · offen <strong>' + H.geld(rest) + '</strong></p>' +
      (r.zahlungen.length || r.bezahlt_am ? '<table class="tab"><tbody>' + r.zahlungen.map((z) => '<tr><td>' + H.datum(z.datum) + '</td><td>' + (z.art === 'ruecklastschrift' ? '<span class="tag rot">Rücklastschrift</span>' : 'Eingang') + '</td><td class="r">' + H.geld(z.betrag) + '</td><td>' + esc(z.notiz || '') + '</td></tr>').join('') +
        (r.bezahlt_am && !r.zahlungen.length ? '<tr><td>' + H.datum(r.bezahlt_am) + '</td><td>Eingang</td><td class="r">' + H.geld(r.summe) + '</td><td>vollständig</td></tr>' : '') + '</tbody></table>' : '<p class="leer">Noch keine Zahlung gebucht.</p>') +
      (rest > 0 ? '<form id="f" class="form" style="margin-top:12px"><label class="feld">Eingang am<input name="datum" type="date" required value="' + heute + '"></label><label class="feld">Betrag (€)<input name="betrag" type="number" step="0.01" min="0.01" required value="' + rest.toFixed(2) + '"><small>weniger als offen = Teilzahlung</small></label><label class="feld voll">Notiz<input name="notiz" placeholder="z. B. Kontoauszug 12/2026"></label></form>' : '') +
      (st === 'ruecklastschrift' && r.sepa ? '<p class="hinweis warn" style="margin-top:12px">Die Lastschrift ist zurückgekommen. Erst mit dem Mitglied sprechen (Konto gedeckt? neue Bankverbindung?) – dann erneut einziehen oder Überweisung abwarten.</p>' : '') +
      '<div class="modal-fuss">' + (r.sepa && r.sepa_lauf && st !== 'ruecklastschrift' ? '<button class="btn gefahr links" id="rueck">Rücklastschrift</button>' : '') + (st === 'ruecklastschrift' && r.sepa ? '<button class="btn links" id="erneut">Erneut einziehen</button>' : '') +
      '<button class="btn" data-zu>Schließen</button>' + (rest > 0 ? '<button class="btn primaer" id="ok">Zahlung buchen</button>' : '') + '</div>');
    const ok = $('#ok', el); if (ok) ok.addEventListener('click', () => {
      const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm)); const betrag = Math.round(H.dez(x.betrag) * 100) / 100;
      if (betrag > rest + 0.001 && !confirm('Der Betrag ist höher als der offene Rest (' + H.geld(rest) + '). Trotzdem buchen?')) return;
      r.zahlungen = r.zahlungen.concat([{ datum: x.datum, betrag, art: 'eingang', notiz: x.notiz || '' }]);
      if (Q.gezahlt(r) >= r.summe - 0.001) r.bezahlt_am = x.datum;
      speichern(r.bezahlt_am ? 'Vollständig bezahlt.' : 'Teilzahlung gebucht – offen ' + H.geld(Q.rest(r)) + '.'); zu(); zeige(tab, true);
    });
    const rb = $('#rueck', el); if (rb) rb.addEventListener('click', () => {
      const grund = prompt('Rücklastschrift für ' + r.nr + ' – Grund laut Bank (z. B. Konto erloschen, Widerspruch, mangelnde Deckung):', ''); if (grund === null) return;
      const war = r.bezahlt_am ? r.summe : Q.gezahlt(r);   // wurde der Einzug schon als Eingang gebucht, wird er zurückgenommen
      const z = r.zahlungen.slice(); if (r.bezahlt_am && !z.length) z.push({ datum: r.bezahlt_am, betrag: r.summe, art: 'eingang', notiz: 'Lastschrift ' + (r.sepa_lauf || '') });
      z.push({ datum: heute, betrag: war, art: 'ruecklastschrift', notiz: grund });
      r.zahlungen = z; r.bezahlt_am = null; speichern('Rücklastschrift vermerkt.'); zu(); zeige(tab, true);
    });
    const eb = $('#erneut', el); if (eb) eb.addEventListener('click', () => { if (!confirm('Beim nächsten Lastschrift-Lauf erneut einziehen? (Rest ' + H.geld(rest) + ')')) return; r.sepa_lauf = null; speichern('Wird beim nächsten Lauf erneut eingezogen.'); zu(); zeige(tab, true); });
  }

  /* ============================================================ Hafengeld
   * Liegegebühren (Sommer/Winter, nach Abrechnungsjahr) und Gastlieger nach Monat oder Saison.
   * Gäste zählen im Monat ihrer Ankunft (ein Aufenthalt über den Monatswechsel zählt ganz zum Ankunftsmonat). Barbestand gibt es hier nicht. */
  const hgStand = { modus: 'monat', monat: heute.slice(0, 7), saison: SAISON };
  const hgSaisonVon = (m) => Number(m.slice(5, 7)) < 4 ? Number(m.slice(0, 4)) - 1 : Number(m.slice(0, 4));   // Januar–März gehören zum Winter der Vorsaison
  function hgDaten(modus, wert) {
    const monat = modus === 'monat'; const S = monat ? hgSaisonVon(wert) : Number(wert);
    const gs = d.gaeste.filter((g) => g.status !== 'storniert' && String(g.ankunft).startsWith(monat ? wert : String(S))).sort((a, b) => a.ankunft.localeCompare(b.ankunft) || a.bootsname.localeCompare(b.bootsname, 'de'));
    const bez = gs.filter((g) => g.bezahlt_am); const gm = gs.filter((g) => !g.bezahlt_am && g.zahlung_gemeldet); const off = gs.filter((g) => !g.bezahlt_am && !g.zahlung_gemeldet);
    const sum = (l) => Math.round(l.reduce((s, g) => s + Number(g.betrag || 0), 0) * 100) / 100;
    const je = {}; ['bar', 'ueberweisung', 'paypal', 'karte'].forEach((k) => { je[k] = sum(bez.filter((g) => g.zahlung === k)); });
    const liege = [['sommer', 'Sommerliegeplatz ' + S], ['winter', 'Winterlager ' + S + '/' + String(S + 1).slice(2)]].map(([k, t]) => { const rs = d.rechnungen.filter((r) => !r.storniert_am && r.periode === k && r.saison === S);
      const soll = rs.reduce((s, r) => s + Number(r.summe), 0), offen = rs.reduce((s, r) => s + Q.rest(r), 0); return { k, t, n: rs.length, soll, ist: soll - offen, offen }; });
    return { S, gs, bez, gm, off, sum, je, liege, naechte: gs.reduce((s, g) => s + Number(g.naechte || 0), 0) };
  }
  V.hafengeld = (main) => {
    const monat = hgStand.modus === 'monat'; const wert = monat ? hgStand.monat : hgStand.saison;
    const x = hgDaten(hgStand.modus, wert);
    const monate = finMonate(); const saisons = [...new Set(d.gaeste.map((g) => Number(g.ankunft.slice(0, 4))).concat(d.rechnungen.filter((r) => r.periode === 'sommer' || r.periode === 'winter').map((r) => r.saison), [SAISON]))].sort((a, b) => b - a);
    const eingM = monat ? FZ.summe(FZ.eingaenge(d, []), wert + '-01', FZ.monatsEnde(wert)) : null;
    const wann = monat ? FZ.monatText(wert) : 'Saison ' + wert;
    const platzT = (g) => g.platz_id ? esc(platzName(g.platz_id)) : g.platz_angabe ? esc(angabe(g.platz_angabe)) + ' <small class="fin-leise">(laut Gast)</small>' : '–';
    const stand = (g) => g.bezahlt_am ? '<span class="tag ok">bezahlt ' + H.kurz(g.bezahlt_am) + '</span>' : g.zahlung_gemeldet ? '<span class="tag gast">gemeldet – prüfen</span>' : '<span class="tag ' + (g.ankunft <= heute ? 'warn' : '') + '">' + (g.ankunft > heute ? 'angekündigt' : 'offen') + '</span>';
    const boot = (g) => darf('gaeste') ? '<a href="#" data-hg-gast="' + g.id + '"><strong>„' + esc(g.bootsname) + '“</strong></a>' : '<strong>„' + esc(g.bootsname) + '“</strong>';
    main.innerHTML = kopf('Hafengeld', 'Liegegebühren und Gastlieger nach Monat oder Saison.', '<button class="btn primaer" id="hg-druck">Gästeliste drucken</button>') +
      '<div class="fin-leiste"><div class="ab-modus" role="tablist" aria-label="Ansicht"><button type="button" role="tab" data-hgmodus="monat" class="' + (monat ? 'aktiv' : '') + '" aria-selected="' + monat + '">Monat</button><button type="button" role="tab" data-hgmodus="saison" class="' + (monat ? '' : 'aktiv') + '" aria-selected="' + !monat + '">Saison</button></div>' +
        '<div class="fin-wahl">' + (monat ? '<button type="button" class="btn klein fin-pfeil" data-hgschritt="-1" aria-label="Monat davor"' + (wert <= monate[monate.length - 1] ? ' disabled' : '') + '>◀</button><select id="hg-monat" aria-label="Monat">' + monate.map((m) => '<option value="' + m + '"' + (m === wert ? ' selected' : '') + '>' + FZ.monatText(m) + '</option>').join('') + '</select><button type="button" class="btn klein fin-pfeil" data-hgschritt="1" aria-label="Monat danach"' + (wert >= monate[0] ? ' disabled' : '') + '>▶</button>'
          : '<select id="hg-saison" aria-label="Saison">' + saisons.map((j) => '<option' + (j === wert ? ' selected' : '') + '>' + j + '</option>').join('') + '</select>') + '</div></div>' +
      '<div class="panel"><h2>Liegegebühren · Saison ' + x.S + '</h2><p class="fin-wie">Abgerechnet nach Saison (Sommer ' + x.S + ', Winter ' + x.S + '/' + String(x.S + 1).slice(2) + '), Stand heute. Saison-Gastlieger zählen hier mit, wenn sie über die Sommerabrechnung laufen.' + (monat ? ' Liegegebühren gibt es nur je Saison – darunter, was davon im ' + FZ.MONATE[Number(wert.slice(5, 7)) - 1] + ' eingegangen ist.' : '') + '</p>' +
        '<table class="tab fin-tab fk"><thead><tr><th>Bereich</th><th class="r">Rechnungen</th><th class="r">Soll</th><th class="r">Ist</th><th class="r">Offen</th>' + (monat ? '<th class="r">Eingang ' + FZ.MONATE[Number(wert.slice(5, 7)) - 1] + '</th>' : '') + '<th></th></tr></thead><tbody>' +
        x.liege.map((z) => '<tr><td><strong>' + z.t + '</strong></td><td class="r" data-l="Rechnungen">' + z.n + '</td><td class="r" data-l="Soll">' + H.geld(z.soll) + '</td><td class="r" data-l="Ist">' + H.geld(z.ist) + '</td><td class="r" data-l="Offen">' + (z.offen > 0 ? '<strong>' + H.geld(z.offen) + '</strong>' : H.geld(0)) + '</td>' +
          (monat ? '<td class="r" data-l="Eingang im Monat">' + fgeld(eingM[z.k]) + '</td>' : '') + '<td class="r aktion">' + (z.n && darf('rechnungen') ? '<button type="button" class="link-knopf" data-gehe="rechnungen" data-re-bereich="' + z.k + '" data-re-jahr="' + x.S + '">Rechnungen ansehen →</button>' : '') + '</td></tr>').join('') + '</tbody></table></div>' +
      '<div class="panel"><h2>Gastlieger · ' + wann + '</h2><p class="fin-wie">Gäste zählen im ' + (monat ? 'Monat' : 'Jahr') + ' ihrer Ankunft – auch ihre Nächte: ein Aufenthalt vom 30.6. bis 2.7. zählt ganz zum Juni.</p>' +
        '<div class="karten fin-karten hg-karten"><div class="kz"><small>Gäste · Nächte</small><strong>' + x.gs.length + ' · ' + x.naechte + '</strong><span>' + (x.gs.length === 1 ? 'Gast' : 'Gäste') + ', Nächte nach Ankunftstag</span></div>' +
          '<div class="kz"><small>Einnahmen (bezahlt)</small><strong style="color:var(--ok)">' + H.geld(x.sum(x.bez)) + '</strong><span>' + (['bar', 'ueberweisung', 'paypal', 'karte'].filter((k) => x.je[k]).map((k) => (k === 'bar' ? 'davon bar ' : ZAHLART[k] + ' ') + H.geld(x.je[k])).join(' · ') || 'noch nichts bezahlt') + '</span></div>' +
          '<div class="kz"><small>Offen</small><strong>' + H.geld(x.sum(x.off)) + '</strong><span>' + x.off.length + (x.off.length === 1 ? ' Gast' : ' Gäste') + ' ohne Zahlung</span></div>' +
          '<div class="kz"><small>Gemeldet, ungeprüft</small><strong style="color:' + (x.gm.length ? '#8a5e05' : 'inherit') + '">' + H.geld(x.sum(x.gm)) + '</strong><span>' + x.gm.length + (x.gm.length === 1 ? ' Zahlung' : ' Zahlungen') + (x.gm.length && darf('kontoauszug') ? ' – unter „Zahlungseingang“ bestätigen' : '') + '</span></div></div>' +
        (x.gs.length ? '<table class="tab hg-tab fk"><thead><tr><th>Ankunft</th><th>Boot</th><th>Platz</th><th class="r">Nächte</th><th class="r">Betrag</th><th>Zahlart</th><th>Stand</th></tr></thead><tbody>' +
          x.gs.map((g) => '<tr><td class="nw" data-l="Ankunft">' + H.datum(g.ankunft) + '</td><td data-l="Boot">' + boot(g) + '</td><td data-l="Platz">' + platzT(g) + '</td><td class="r" data-l="Nächte">' + g.naechte + '</td><td class="r nw" data-l="Betrag">' + H.geld(g.betrag) + '</td><td data-l="Zahlart">' + (g.zahlung && g.zahlung !== 'offen' ? esc(ZAHLART[g.zahlung] || g.zahlung) : '–') + '</td><td data-l="Stand">' + stand(g) + '</td></tr>').join('') +
          '</tbody><tfoot><tr><td colspan="3">Summe</td><td class="r" data-l="Nächte">' + x.naechte + '</td><td class="r" data-l="Betrag">' + H.geld(x.sum(x.gs)) + '</td><td colspan="2"></td></tr></tfoot></table>'
          : '<p class="leer">Keine Gastlieger ' + (monat ? 'im ' + FZ.monatText(wert) : 'in der Saison ' + wert) + '.</p>') +
        '<p class="hinweis fin-ohne">' + (darf('gaeste') ? 'Bearbeitet wird ein Gast im Bereich „Gäste“ – Bootsname antippen. ' : '') + 'Barbestand und Abgabe an den Kassenwart stehen nicht in den Daten.</p></div>';
    main.querySelectorAll('[data-hgmodus]').forEach((b) => b.addEventListener('click', () => { hgStand.modus = b.dataset.hgmodus; zeige('hafengeld', true); }));
    main.querySelectorAll('[data-hgschritt]').forEach((b) => b.addEventListener('click', () => { hgStand.monat = FZ.monatPlus(hgStand.monat, Number(b.dataset.hgschritt)); zeige('hafengeld', true); }));
    const hm = $('#hg-monat'); if (hm) hm.addEventListener('change', () => { hgStand.monat = hm.value; zeige('hafengeld', true); });
    const hs = $('#hg-saison'); if (hs) hs.addEventListener('change', () => { hgStand.saison = Number(hs.value); zeige('hafengeld', true); });
    main.querySelectorAll('[data-hg-gast]').forEach((a) => a.addEventListener('click', (ev) => { ev.preventDefault(); const g = d.gaeste.find((y) => y.id === a.dataset.hgGast); zeige('gaeste'); gastForm(g); }));
    $('#hg-druck').addEventListener('click', () => oeffnen('drucken.html?art=gaesteliste&' + (monat ? 'monat=' + wert : 'saison=' + wert)));
  };

  /* ============================================================ Gebühren */
  /* Gebührenordnung in Fassungen: jede gilt ab einer Saison bis zur nächsten Fassung
     (Beitrag ab 1.1., Sommerliegeplatz ab Sommer, Winterlager ab Winter dieses Jahres) */
  const gebStand = { jahr: null, bearbeiten: null };
  const fassungen = () => Object.keys(d.gebuehren).map(Number).sort((a, b) => a - b);
  function fassungBereich(j) { const f = fassungen(); const n = f.find((x) => x > j); return { von: j, bis: n ? n - 1 : null }; }
  function fassungRechnungen(j) { const { von, bis } = fassungBereich(j); return d.rechnungen.filter((r) => !r.storniert_am && r.saison >= von && (bis == null || r.saison <= bis)); }
  const fassungText = (j) => { const { bis } = fassungBereich(j); return 'gültig ab Saison ' + j + (bis == null ? '' : ' bis ' + bis); };
  // Erst lesen, dann gezielt ändern: Die Seite zeigt die Preise als Text („18,43 €“). „Diese Fassung ändern“ öffnet die Eingabe (mit Warnung,
  // wenn schon Rechnungen erstellt sind), „+ Neue Fassung“ legt eine Kopie ab einer späteren Saison an. Eingabe nimmt Komma und Punkt.
  const betragFeld = (v) => (Math.round(Number(v || 0) * 100) / 100).toFixed(2).replace('.', ',');
  V.gebuehren = (main) => {
    const f = fassungen(); const aktuell = f.filter((x) => x <= SAISON).pop() ?? f[0];   // Fassung, die für die laufende Saison gilt
    if (gebStand.jahr == null || !d.gebuehren[gebStand.jahr]) gebStand.jahr = f[f.length - 1];
    const jahr = gebStand.jahr; const gb = d.gebuehren[jahr]; const benutzt = fassungRechnungen(jahr);
    const edit = gebStand.bearbeiten === jahr && darf('gebuehren');
    const wert = (key, v, einheit) => edit ? '<input class="suche geb-feld" inputmode="decimal" autocomplete="off" data-k="' + key + '" value="' + betragFeld(v) + '">' + (einheit && einheit !== '€' ? ' <small class="fin-leise">' + einheit.replace('€ ', '') + '</small>' : '')
      : '<span class="nw">' + H.geld(v) + '</span>' + (einheit && einheit !== '€' ? ' <small class="fin-leise nw">' + einheit.replace('€ ', '') + '</small>' : '');
    const zeile = (titel, key) => '<tr><td><strong>' + titel + '</strong></td>' + ['I', 'II', 'III'].map((b) => '<td class="r" data-l="Box ' + b + '">' + wert(key + '.' + b, gb[key][b]) + '</td>').join('') + '</tr>';
    const einzel = (titel, key, einheit) => '<tr><td>' + titel + '</td><td class="r" data-l="Betrag">' + wert(key, gb[key], einheit) + '</td></tr>';
    main.innerHTML = druckKopf() + kopf('Gebührenordnung', 'Jede Fassung gilt ab einer Saison bis zur nächsten. Bereits erstellte Rechnungen ändern sich nie.',
        edit ? '<button class="btn" id="geb-abbr">Abbrechen</button><button class="btn primaer" id="ok">Speichern</button>'
          : '<button class="btn" id="geb-neu">+ Neue Fassung</button><button class="btn" id="geb-aendern">Diese Fassung ändern</button><button class="btn" id="geb-druck">Drucken</button>') +
      '<div class="ab-modus geb-fassungen" role="tablist">' + f.map((j) => '<button type="button" role="tab" aria-selected="' + (j === jahr) + '" class="' + (j === jahr ? 'aktiv' : '') + '" data-fassung="' + j + '"' + (edit ? ' disabled' : '') + '>ab ' + j + (j === aktuell ? ' <span class="zahl-leise">gilt jetzt</span>' : j > SAISON ? ' <span class="zahl-leise">künftig</span>' : '') + '</button>').join('') + '</div>' +
      '<div class="panel geb-info' + (edit ? ' geb-edit' : '') + '"><div><strong>' + fassungText(jahr) + '</strong><br><small>Beiträge ab 1.1.' + jahr + ' · Sommerliegeplätze ab Sommer ' + jahr + ' · Winterlager ab Winter ' + jahr + '/' + String(jahr + 1).slice(2) + '</small></div>' +
        (edit ? '<label class="feld" style="margin:0;flex:1;min-width:220px">Beschluss / Stand<input id="geb-stand" value="' + esc(gb.stand || '') + '" placeholder="z. B. Beschluss JHV 14.03.2027"></label>'
          : '<div class="geb-stand"><small>Beschluss / Stand</small><br>' + (gb.stand ? esc(gb.stand) : '<em class="fin-leise">nicht eingetragen</em>') + '</div>') +
        (benutzt.length ? '<p class="hinweis warn" style="margin:0;flex-basis:100%">Mit dieser Fassung wurden schon <strong>' + benutzt.length + ' Rechnungen</strong> erstellt. ' + (edit ? 'Änderungen wirken nur auf Rechnungen, die noch erstellt werden – für neue Preise lieber „Abbrechen“ und eine <strong>neue Fassung</strong> ab der nächsten Saison anlegen.' : 'Die ändern sich nie. Neue Preise gehören in eine neue Fassung.') + '</p>' : '') +
        (edit ? '<p class="hinweis" style="margin:0;flex-basis:100%">Beträge mit Komma oder Punkt eingeben, z. B. 18,43.</p>' : '') + '</div>' +
      '<div class="panel"><h2>Wasserliegeplatz (Saison)</h2><table class="tab geb-tab fk"><thead><tr><th>Gebühr</th><th class="r">Box I</th><th class="r">Box II</th><th class="r">Box III</th></tr></thead><tbody>' +
      zeile('Ausübende/Probe: Sommerliegegebühr', 'sommerliegegebuehr') + zeile('Ausübende/Probe: Umlage Wasserpacht', 'wasserpacht') + zeile('Fördernde: Sommerlieger', 'foerdernd_sommer') + zeile('Gäste: Sommerlieger (Saison)', 'gast_saison') +
      '</tbody></table></div><div class="panel"><h2>Gäste, Land, Kran</h2><table class="tab geb-einzel"><tbody>' + einzel('Gast, einzelne Übernachtung', 'gast_nacht', '€') + einzel('Stromumlage (ausübend/Probe)', 'stromumlage', '€') +
      einzel('Landstellplatz außen', 'land_aussen_m2', '€ / m²') + einzel('Landstellplatz Halle (nur Winter)', 'land_halle_m2', '€ / m²') + einzel('Palette', 'palette_halbjahr', '€ / Halbjahr') +
      einzel('Schiffskran', 'schiffskran_std', '€ / angef. Std.') + einzel('Mastenkran', 'mastenkran_std', '€ / angef. Std.') + einzel('Schlüsselpfand', 'schluesselpfand', '€') + '</tbody></table></div>' +
      '<div class="panel"><h2>Mitgliedsbeitrag (Jahr)</h2><table class="tab geb-tab fk"><thead><tr><th>Mitgliedsart</th><th class="r">Vereinsbeitrag</th><th class="r">Verbandsbeitrag</th><th class="r">zusammen</th></tr></thead><tbody>' +
      Object.entries(gb.beitraege || {}).map(([art, w]) => '<tr><td><strong>' + H.ART[art] + '</strong></td>' + [['verein', 'Vereinsbeitrag'], ['verband', 'Verbandsbeitrag']].map(([t, l]) => '<td class="r" data-l="' + l + '">' + wert('beitraege.' + art + '.' + t, w[t]) + '</td>').join('') +
        '<td class="r nw" data-l="zusammen">' + H.geld(w.verein + w.verband) + '</td></tr>').join('') + '</tbody></table><table class="tab geb-einzel"><tbody>' + einzel('Eintrittsgeld Probemitglied (je Probejahr, bis zu 3 Jahre)', 'eintrittsgeld_probe', '€') + '</tbody></table></div>' +
      '<p class="hinweis">Neue Preise nach der Jahreshauptversammlung: „+ Neue Fassung“ ab der Saison, ab der sie gelten. Die Abrechnung nimmt automatisch die passende Fassung.</p>';
    main.querySelectorAll('[data-fassung]').forEach((b) => b.addEventListener('click', () => { gebStand.jahr = Number(b.dataset.fassung); gebStand.bearbeiten = null; zeige('gebuehren', true); }));
    const ga = $('#geb-aendern'); if (ga) ga.addEventListener('click', () => { gebStand.bearbeiten = jahr; zeige('gebuehren', true); const i = main.querySelector('.geb-feld'); if (i) i.focus({ preventScroll: true }); });
    const gx = $('#geb-abbr'); if (gx) gx.addEventListener('click', () => { gebStand.bearbeiten = null; zeige('gebuehren', true); });
    const gd = $('#geb-druck'); if (gd) gd.addEventListener('click', () => window.print());
    const ok = $('#ok'); if (ok) ok.addEventListener('click', () => {
      const neu = JSON.parse(JSON.stringify(gb)); let fehlt = false;
      main.querySelectorAll('[data-k]').forEach((i) => { const [k, b, c] = i.dataset.k.split('.'); const v = H.dez(i.value); if (v == null || isNaN(v) || v < 0 || String(i.value).trim() === '') { fehlt = true; i.setAttribute('aria-invalid', 'true'); return; } i.removeAttribute('aria-invalid'); if (c) neu[k][b][c] = v; else if (b) neu[k][b] = v; else neu[k] = v; });
      if (fehlt) return toast('Bitte alle Beträge als Zahl eintragen, z. B. 18,43 (0 ist erlaubt).', 'fehler');
      neu.stand = $('#geb-stand').value.trim() || gb.stand;
      if (JSON.stringify(neu) === JSON.stringify(gb)) { gebStand.bearbeiten = null; toast('Keine Änderung.'); return zeige('gebuehren', true); }
      if (benutzt.length && !confirm('Mit dieser Fassung wurden schon ' + benutzt.length + ' Rechnungen erstellt. Die ändern sich nicht – die neuen Beträge gelten nur für Rechnungen, die noch erstellt werden.\n\nTrotzdem diese Fassung ändern?')) return;
      d.gebuehren[jahr] = neu; gebStand.bearbeiten = null; speichern('Gebührenordnung (' + fassungText(jahr) + ') gespeichert.'); zeige('gebuehren', true);
    });
    const gn = $('#geb-neu'); if (gn) gn.addEventListener('click', () => {
      const vorschlag = Math.max(SAISON + 1, f[f.length - 1] + 1);
      const el = modal('<h2>Neue Fassung der Gebührenordnung</h2><form id="gf" class="form"><label class="feld">Gültig ab Saison<input name="ab" type="number" min="' + (f[0] + 1) + '" max="2100" required value="' + vorschlag + '"><small>Beiträge ab 1.1., Liegeplätze ab dieser Saison</small></label>' +
        '<label class="feld">Beschluss / Stand<input name="stand" placeholder="z. B. Beschluss JHV 14.03.' + vorschlag + '"></label><label class="feld voll">Vorlage<select name="von">' + f.slice().reverse().map((j) => '<option value="' + j + '">Beträge der Fassung ab ' + j + ' übernehmen</option>').join('') + '</select></label></form>' +
        '<p class="hinweis">Danach nur die geänderten Beträge anpassen. Fassungen für bereits abgerechnete Saisons lassen sich nicht neu anlegen.</p><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="gf-ok">Anlegen</button></div>');
      $('#gf-ok', el).addEventListener('click', () => {
        const fm = $('#gf', el); if (!fm.reportValidity()) return; const ab = Number(fm.ab.value);
        if (d.gebuehren[ab]) return toast('Für ' + ab + ' gibt es schon eine Fassung – bitte die bearbeiten.', 'fehler');
        if (d.rechnungen.some((r) => !r.storniert_am && r.saison >= ab)) return toast('Für Saison ' + ab + ' gibt es schon Rechnungen – eine neue Fassung muss später beginnen.', 'fehler');
        const kopie = JSON.parse(JSON.stringify(d.gebuehren[fm.von.value])); kopie.stand = fm.stand.value.trim() || 'Fassung ab ' + ab;
        // die neue Fassung öffnet gleich zum Ändern – dafür wurde sie angelegt
        d.gebuehren[ab] = kopie; gebStand.jahr = ab; gebStand.bearbeiten = ab; speichern('Neue Fassung ab Saison ' + ab + ' angelegt – jetzt die neuen Beträge eintragen.'); zu(); zeige('gebuehren', true);
      });
    });
  };

  /* ============================================================ Einstellungen */
  // Jedes Thema ist ein aufklappbarer Abschnitt mit einer Zusammenfassungszeile; Speichern steht fest unten (gilt für alle Abschnitte).
  // Datensicherung und „Demo zurücksetzen“ stehen als eigener Abschnitt „Sicherung“ ganz unten.
  const einstOffen = new Set();
  const STEUER_HINWEISE = [['kleinunternehmer', 'Kleinunternehmer: „Gemäß § 19 UStG wird keine Umsatzsteuer berechnet.“'], ['ust19', 'Umsatzsteuer 19 % ausweisen (Betrag wird aus dem Bruttopreis errechnet)'], ['frei', 'eigener Text (unten)']];
  const KARTE_OEFFENTLICH = [['aus', 'Nein – Karte ist nicht öffentlich'], ['heute', 'Ja – nur den heutigen Stand'], ['vorschau', 'Ja – heute und die nächsten Tage']];
  V.einstellungen = (main) => {
    const e = d.einstellungen;
    const f = (k, l, t = 'text', extra = '') => '<label class="feld">' + l + '<input name="' + k + '" type="' + t + '" value="' + esc(e[k] == null ? '' : e[k]) + '"' + extra + '></label>';
    const abschnitt = (id, titel, inhalt) => '<details class="panel einst" data-abschnitt="' + id + '"' + (einstOffen.has(id) ? ' open' : '') + '><summary><span class="einst-kopf"><strong>' + titel + '</strong><span class="einst-zus" data-zus="' + id + '"></span></span><span class="einst-auf" aria-hidden="true"></span></summary><div class="form einst-inhalt">' + inhalt + '</div></details>';
    main.innerHTML = kopf('Einstellungen', 'Ein Thema antippen zum Ansehen oder Ändern. Gespeichert wird unten mit „Speichern“.') +
      '<form id="f" class="einst-form" novalidate>' +
      abschnitt('verein', 'Verein & Bank', f('verein_name', 'Vereinsname') + f('verein_email', 'E-Mail') + f('verein_strasse', 'Straße') + f('verein_ort', 'PLZ und Ort') +
        f('glaeubiger_id', 'Gläubiger-ID') + f('iban', 'IBAN des Vereins') + f('bic', 'BIC') + f('bank', 'Bank') + f('kassenwart_name', 'Kassenwart (Gruß auf Rechnungen)') + f('hafenmeister_name', 'Hafenmeister') + f('hafenmeister_tel', 'Telefon Hafenmeister')) +
      abschnitt('gaeste', 'Gäste bezahlen direkt', '<p class="hinweis voll" style="margin:0">Gäste sehen nach der Anmeldung den Betrag und diese Zahlwege. Überweisung nutzt die IBAN unter „Verein & Bank“.</p>' +
        f('paypal_me', 'PayPal.me-Name des Vereins', 'text', ' placeholder="z. B. SSVLuebeck – leer = kein PayPal"') + f('gast_bar_hinweis', 'Hinweis für Barzahlung', 'text', ' placeholder="z. B. Umschlag in den Briefkasten am Vereinsheim"')) +
      abschnitt('rechnung', 'Rechnungen & Steuer', f('rechnung_praefix', 'Rechnungsnummer-Präfix') + f('zahlungsziel_tage', 'Einzug nach Rechnungsdatum (Tage)', 'number') + f('steuernummer', 'Steuernummer (Rechnungsfuß)') +
        '<label class="feld check voll"><input type="checkbox" name="stromumlage_ueber_hafen"' + (e.stromumlage_ueber_hafen ? ' checked' : '') + '> Stromumlage mit der Hafenrechnung einziehen (sonst über den Mitgliedsbeitrag)</label>' +
        '<h3 class="voll" style="margin:8px 0 0">Steuerhinweis auf Hafen-Rechnungen und Quittungen</h3>' +
        '<label class="feld voll">Hinweis<select name="steuer_hinweis"><option value="">noch nicht festgelegt (es wird nichts gedruckt)</option>' +
          STEUER_HINWEISE.map(([k, t]) => '<option value="' + k + '"' + (e.steuer_hinweis === k ? ' selected' : '') + '>' + t + '</option>').join('') +
          '</select><small>Bitte mit dem Steuerberater klären – Mitgliedsbeiträge erhalten keinen Steuerhinweis.</small></label>' +
        '<label class="feld voll">Eigener Text<input name="steuer_text" value="' + esc(e.steuer_text || '') + '" placeholder="nur bei „eigener Text“"></label>') +
      abschnitt('arbeit', 'Arbeitsdienst', f('arbeitsdienst_soll', 'Soll (Std./Jahr)', 'number') + f('arbeitsdienst_mahnung_ab', 'Schriftliche Aufforderung ab … Fehlstunden', 'number') +
        f('arbeitsdienst_befreit_ab', 'Befreit ab Alter (0 = keine Grenze)', 'number') + f('arbeitsdienst_satz', 'Ersatzzahlung je Fehlstunde in € (0 = keine)', 'number', ' step="0.5"') +
        '<label class="feld check voll"><input type="checkbox" name="arbeitsdienst_vorjahr"' + (e.arbeitsdienst_vorjahr ? ' checked' : '') + '> Fehlstunden des Vorjahres zählen mit</label>' +
        '<label class="feld check voll"><input type="checkbox" name="arbeitsdienst_bestaetigt"' + (e.arbeitsdienst_bestaetigt ? ' checked' : '') + '> Diese Regeln hat der Vorstand beschlossen (erst dann wird eine Ersatzzahlung berechnet)</label>') +
      abschnitt('saison', 'Saisontermine', [SAISON, SAISON + 1].map((j) => { const s = (d.saisons || []).find((x) => x.jahr === j) || {};
        return '<label class="feld">Auslagern ' + j + '<input type="date" name="aus_' + j + '" value="' + esc(s.auslagern || '') + '"></label><label class="feld">Einlagern ' + j + '<input type="date" name="ein_' + j + '" value="' + esc(s.einlagern || '') + '"></label>'; }).join('')) +
      (DB ? abschnitt('push', 'Push-Benachrichtigungen', '<label class="feld check voll"><input type="checkbox" name="push_aktiv"' + (e.push_aktiv ? ' checked' : '') + '> In „Mein SSV“ anbieten, Mitteilungen auch als Push aufs Handy zu bekommen (iPhone: nur wenn „Mein SSV“ zum Home-Bildschirm hinzugefügt ist)</label>') : '') +
      abschnitt('gewicht', 'Gewichtsgrenzen (inkl. Zubehör)', '<p class="hinweis voll" style="margin:0">Kran: Kranliste, Winterlager, Lagerplätze an Land. Steg: Wasserliegeplätze (Hafenbetriebsordnung 3.1.4). Gilt überall, auch für Warnungen und die Bootsanmeldung.</p>' +
        f('kran_max_t', 'Kran: höchstens (t)', 'number', ' step="0.1" min="1"') + f('max_gewicht_t', 'Steg/Wasserliegeplatz: höchstens (t)', 'number', ' step="0.1" min="1"')) +
      abschnitt('plan', 'Hafenplan', '<label class="feld check voll"><input type="checkbox" name="plan_bestaetigt"' + (e.plan_bestaetigt ? ' checked' : '') + '> Brückenzuordnung und Boxmaße unter „Liegeplätze“ sind geprüft und stimmen</label>') +
      abschnitt('karte', 'Hafenkarte für Gäste (öffentlich)', '<p class="hinweis voll" style="margin:0">Die Seite <a href="hafenplan.html" target="_blank" rel="noopener">hafenplan.html</a> zeigt Gästen ohne Anmeldung, welche Plätze frei sind – nur „frei“ oder „belegt“ je Platznummer und die Boxmaße, <strong>keine Namen und keine Boote</strong>. Ob ein Platz wegen eines grünen Schilds oder ohnehin frei ist, sieht man von außen nicht.</p>' +
        '<label class="feld">Öffentlich zeigen<select name="karte_oeffentlich">' + KARTE_OEFFENTLICH.map(([k, t]) => '<option value="' + k + '"' + ((e.karte_oeffentlich || 'aus') === k ? ' selected' : '') + '>' + t + '</option>').join('') + '</select></label>' +
        f('karte_tage', 'Wie viele Tage voraus? (höchstens 60)', 'number', ' min="0" max="60" placeholder="14"')) +
      '</form>' +
      '<div class="einst-fuss" role="region" aria-label="Speichern"><span class="einst-status" id="einst-status" aria-live="polite">Alles gespeichert.</span><button class="btn primaer" id="ok">Speichern</button></div>' +
      // Sicherung: eigener Abschnitt ganz unten (Datensicherung, Zurückspielen, Demo zurücksetzen)
      (darf('verlauf') || !DB ? '<div class="panel einst-sicherung" id="sicherung-panel"><h2>Sicherung</h2>' +
        (darf('verlauf') ? '<h3 style="margin:4px 0 6px">Datensicherung</h3><p class="hinweis">' + (DB ? 'Die Vereinsdatenbank wird beim Anbieter gesichert (Tarif prüfen: tägliche Sicherung). Zusätzlich kannst du hier jederzeit eine Kopie aller Hafen- und Mitgliederdaten herunterladen – z. B. einmal im Monat, sicher aufbewahren (enthält Bankdaten).' : 'In der Demo liegen die Daten nur in diesem Browser.') + '</p><div class="aktionen"><button class="btn" id="sicherung">Datensicherung herunterladen</button>' + (rolle === 'vorstand' ? '<label class="btn" for="sich-datei">Sicherung zurückspielen …</label><input type="file" id="sich-datei" accept=".json,application/json" hidden>' : '') + '</div>' +
          (rolle === 'vorstand' ? '<p class="hinweis" style="margin-top:10px">Zurückspielen zeigt zuerst einen Vergleich (Sicherung ↔ jetzt) und fragt dann nach. Mitglieder und Rechnungen werden dabei nie gelöscht, nur wiederhergestellt; hochgeladene Dokumente und die Getränkekasse sind nicht Teil dieser Sicherung.</p>' : '') : '') +
        (DB ? '' : '<div class="einst-demo"><h3 style="margin:14px 0 6px">Demo zurücksetzen</h3><p class="hinweis">Setzt alle Daten auf die erfundenen Beispieldaten zurück.</p><button class="btn gefahr" id="reset">Demo zurücksetzen</button></div>') + '</div>' : '');
    // Zusammenfassung je Abschnitt aus den aktuellen Eingaben (ändert sich beim Tippen mit)
    const fm = $('#f'); const v = (k) => { const el = fm.elements[k]; return !el ? '' : el.type === 'checkbox' ? el.checked : String(el.value || '').trim(); };
    const zahl = (k) => Number(String(v(k)).replace(',', '.')) || 0; const offen = (t) => '<span class="einst-offen">' + t + '</span>';
    const ZUS = {
      verein: () => [esc(v('verein_name') || 'Vereinsname fehlt'), v('iban') ? (SEPA.ibanGueltig(v('iban')) ? 'IBAN …' + esc(v('iban').replace(/\s/g, '').slice(-4)) : offen('IBAN ungültig')) : offen('IBAN fehlt'), v('glaeubiger_id') ? (SEPA.glaeubigerGueltig(v('glaeubiger_id')) ? 'Gläubiger-ID eingetragen' : offen('Gläubiger-ID ungültig')) : offen('Gläubiger-ID fehlt')],
      gaeste: () => [v('paypal_me') ? 'PayPal: ' + esc(v('paypal_me')) : 'kein PayPal', 'Überweisung', v('gast_bar_hinweis') ? 'bar mit Hinweis' : 'bar ohne Hinweis'],
      rechnung: () => ['Nummern „' + esc(v('rechnung_praefix') || '–') + '“', 'Einzug nach ' + zahl('zahlungsziel_tage') + ' Tagen', v('steuer_hinweis') ? 'Steuerhinweis: ' + ({ kleinunternehmer: 'Kleinunternehmer', ust19: '19 % USt.', frei: 'eigener Text' })[v('steuer_hinweis')] : offen('Steuerhinweis noch offen')],
      arbeit: () => [H.zahl(zahl('arbeitsdienst_soll'), zahl('arbeitsdienst_soll') % 1 ? 1 : 0) + ' Std./Jahr', zahl('arbeitsdienst_satz') ? H.geld(zahl('arbeitsdienst_satz')) + ' je Fehlstunde' : 'keine Ersatzzahlung', v('arbeitsdienst_bestaetigt') ? 'beschlossen' : offen('noch nicht beschlossen')],
      saison: () => [SAISON, SAISON + 1].map((j) => v('aus_' + j) && v('ein_' + j) ? (j === SAISON ? '' : j + ': ') + 'Auslagern ' + H.datum(v('aus_' + j)) + ' · Einlagern ' + H.datum(v('ein_' + j)) : offen(j + ': nicht eingetragen')),
      push: () => [v('push_aktiv') ? 'in „Mein SSV“ angeboten' : 'aus'],
      gewicht: () => ['Kran ' + H.zahl(zahl('kran_max_t'), 1) + ' t', 'Steg ' + H.zahl(zahl('max_gewicht_t'), 1) + ' t'],
      plan: () => [v('plan_bestaetigt') ? 'Boxmaße geprüft' : offen('Boxmaße noch Annahme')],
      karte: () => [({ aus: 'nicht öffentlich', heute: 'öffentlich: nur heute', vorschau: 'öffentlich: heute und ' + (v('karte_tage') === '' ? 14 : Math.min(60, zahl('karte_tage'))) + ' Tage voraus' })[v('karte_oeffentlich') || 'aus']]
    };
    const zusammen = () => main.querySelectorAll('[data-zus]').forEach((z) => { z.innerHTML = ZUS[z.dataset.zus]().join(' · '); });
    zusammen();
    let geaendert = false; const status = $('#einst-status');
    const stand = (an) => { geaendert = an; status.textContent = an ? 'Geändert – bitte speichern.' : 'Alles gespeichert.'; status.classList.toggle('warn', an); };
    fm.addEventListener('input', () => { zusammen(); stand(true); }); fm.addEventListener('change', () => { zusammen(); stand(true); });
    main.querySelectorAll('details.einst').forEach((x) => x.addEventListener('toggle', () => { if (x.open) einstOffen.add(x.dataset.abschnitt); else einstOffen.delete(x.dataset.abschnitt); }));
    // Fehler beim Speichern: Abschnitt aufklappen und das Feld zeigen
    const feldZeigen = (k, t) => { const el = fm.elements[k]; if (el) { const det = el.closest('details'); if (det) det.open = true; el.scrollIntoView({ block: 'center' }); el.focus({ preventScroll: true }); } toast(t, 'fehler', 5000); };
    $('#ok').addEventListener('click', () => {
      const x = Object.fromEntries(new FormData($('#f'))); ['stromumlage_ueber_hafen', 'arbeitsdienst_vorjahr', 'arbeitsdienst_bestaetigt', 'plan_bestaetigt'].concat(DB ? ['push_aktiv'] : []).forEach((k) => { x[k] = !!x[k]; });
      ['zahlungsziel_tage', 'arbeitsdienst_soll', 'arbeitsdienst_mahnung_ab', 'arbeitsdienst_befreit_ab', 'arbeitsdienst_satz', 'max_gewicht_t', 'kran_max_t'].forEach((k) => { x[k] = Number(String(x[k]).replace(',', '.')) || 0; });
      x.karte_tage = x.karte_tage === '' ? 14 : Math.min(60, Math.max(0, Math.round(Number(x.karte_tage) || 0)));
      if (!(x.max_gewicht_t >= 1) || !(x.kran_max_t >= 1)) return feldZeigen(!(x.kran_max_t >= 1) ? 'kran_max_t' : 'max_gewicht_t', 'Bitte die Höchstgewichte für Kran und Steg eintragen.');
      if (x.steuer_hinweis === 'frei' && !x.steuer_text.trim()) return feldZeigen('steuer_text', 'Bitte den eigenen Steuerhinweis eintragen.');
      for (const j of [SAISON, SAISON + 1]) {
        const aus = x['aus_' + j], ein = x['ein_' + j]; delete x['aus_' + j]; delete x['ein_' + j];
        if (!aus && !ein) continue; if (!aus || !ein || ein <= aus) return feldZeigen(aus ? 'ein_' + j : 'aus_' + j, 'Saison ' + j + ': bitte Auslagern und Einlagern eintragen (Einlagern nach dem Auslagern).');
        const s = d.saisons.find((y) => y.jahr === j); if (s) Object.assign(s, { auslagern: aus, einlagern: ein }); else d.saisons.push({ jahr: j, auslagern: aus, einlagern: ein });
      }
      if (x.iban && !SEPA.ibanGueltig(x.iban)) return feldZeigen('iban', 'IBAN des Vereins ist ungültig.');
      if (x.glaeubiger_id && !SEPA.glaeubigerGueltig(x.glaeubiger_id)) return feldZeigen('glaeubiger_id', 'Gläubiger-ID hat ein ungültiges Format.');
      Object.assign(e, x); speichern('Gespeichert.'); stand(false); zusammen();
    });
    const sich = $('#sicherung'); if (sich) sich.addEventListener('click', () => {
      const { dokumente, ...rest } = d; const stand = new Date().toISOString().slice(0, 16).replace(':', '-');
      download('ssv-datensicherung-' + stand + '.json', JSON.stringify({ erstellt: new Date().toISOString(), von: ROLLEN[rolle].name, hinweis: 'Enthält personenbezogene Daten und Bankdaten – sicher aufbewahren.', daten: rest }, null, 1), 'application/json');
      toast('Datensicherung heruntergeladen.');
    });
    const sd2 = $('#sich-datei'); if (sd2) sd2.addEventListener('change', async () => {
      const datei = sd2.files[0]; sd2.value = ''; if (!datei) return;
      let info; try { info = HF.sicherungLesen(await datei.text()); } catch (x) { return toast(x.message, 'fehler', 6000); }
      const NAME = { mitglieder: 'Mitglieder', boote: 'Boote', belegungen: 'Belegungen', abwesenheiten: 'Grünes Schild', gaeste: 'Gastlieger', warteliste: 'Warteliste', kran: 'Kran', arbeitsdienst: 'Arbeitsstunden', arbeitseinsaetze: 'Arbeitseinsätze', arbeitseinsatz_codes: 'QR-Codes der Einsätze', arbeitsbereiche: 'Arbeitsgruppen', arbeitsbereich_mitglieder: 'Gruppen-Zuordnungen', mitteilungen: 'Mitteilungen', veranstaltungen: 'Veranstaltungen', zusagen: 'Zu-/Absagen', rechnungen: 'Hafen- und Beitragsrechnungen', sepa_laeufe: 'Lastschrift-Dateien', antraege: 'Aufnahmeanträge', liegeplaetze: 'Liegeplätze', landplaetze: 'Lagerplätze', saisons: 'Saisontermine', aufgaben: 'Schäden/Wartung' };
      const el = modal('<h2>Sicherung zurückspielen</h2><p style="margin-top:0">Sicherung vom <strong>' + (info.erstellt ? new Date(info.erstellt).toLocaleString('de-DE') : 'unbekannten Datum') + '</strong>' + (info.von ? ' (' + esc(info.von) + ')' : '') + '. Alles, was danach geändert wurde, geht verloren.</p>' +
        '<table class="tab sich-vergleich"><thead><tr><th>Bereich</th><th class="r">Sicherung</th><th class="r">jetzt</th></tr></thead><tbody>' + info.vergleich.map((v) => '<tr' + (v.sicherung !== v.jetzt ? ' class="anders"' : '') + '><td>' + NAME[v.t] + '</td><td class="r">' + v.sicherung + '</td><td class="r">' + v.jetzt + '</td></tr>').join('') + '</tbody></table>' +
        '<label class="feld" style="margin-top:12px">Zur Bestätigung <strong>ZURÜCKSPIELEN</strong> eintippen<input id="sich-ok" autocomplete="off"></label>' +
        '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn gefahr" id="sich-los" disabled>Jetzt zurückspielen</button></div>', true);
      $('#sich-ok', el).addEventListener('input', (ev) => { $('#sich-los', el).disabled = ev.target.value.trim().toUpperCase() !== 'ZURÜCKSPIELEN'; });
      $('#sich-los', el).addEventListener('click', async () => {
        const k = $('#sich-los', el); if (k.disabled) return; k.disabled = true; k.textContent = 'Wird zurückgespielt …';
        try { await HF.zurueckspielen(info.daten); d = HF.d; zu(); toast('Sicherung zurückgespielt.', '', 5000); zeige('einstellungen', true); }
        catch (x) { k.disabled = false; k.textContent = 'Jetzt zurückspielen'; toast(x.message, 'fehler', 8000); }
      });
    });
    if ($('#reset')) $('#reset').addEventListener('click', () => { if (confirm('Alle Demo-Daten zurücksetzen?')) { d = HF.zuruecksetzen(); toast('Zurückgesetzt.'); zeige('uebersicht'); } });
  };

  /* ============================================================ Schäden & Wartung */
  const aufStand = { filter: 'offen' };
  const PRIO = { hoch: ['dringend', 'rot'], normal: ['normal', ''], niedrig: ['später', 'blass-tag'] };
  const AST = { offen: ['offen', 'warn'], in_arbeit: ['in Arbeit', 'gast'], erledigt: ['erledigt', 'ok'] };
  V.aufgaben = (main) => {
    const alle = (d.aufgaben || []).slice().sort((a, b) => (a.status === 'erledigt') - (b.status === 'erledigt') || ['hoch', 'normal', 'niedrig'].indexOf(a.prioritaet) - ['hoch', 'normal', 'niedrig'].indexOf(b.prioritaet) || (a.faellig || '9').localeCompare(b.faellig || '9'));
    const l = alle.filter((t) => aufStand.filter === 'alle' || (aufStand.filter === 'offen' ? t.status !== 'erledigt' : t.status === aufStand.filter));
    main.innerHTML = kopf('Schäden & Wartung', 'Was kaputt ist oder regelmäßig geprüft werden muss – mit Verantwortlichem und Stand. Mitglieder melden Schäden über „Mein SSV“.', '<button class="btn primaer" id="neu">+ Schaden / Wartung</button>') +
      '<div class="filter">' + [['offen', 'offen & in Arbeit'], ['erledigt', 'erledigt'], ['alle', 'alle']].map(([k, t]) => '<button class="btn klein' + (aufStand.filter === k ? ' aktiv' : '') + '" data-af="' + k + '">' + t + '</button>').join('') + '</div>' +
      '<div class="panel"><table class="tab"><thead><tr><th>Priorität</th><th>Was</th><th>Wo</th><th>Wer kümmert sich</th><th>fällig</th><th>Stand</th></tr></thead><tbody>' +
      (l.map((t) => '<tr class="klickbar' + (t.status === 'erledigt' ? ' blass' : '') + '" data-t="' + t.id + '"><td><span class="tag ' + PRIO[t.prioritaet][1] + '">' + PRIO[t.prioritaet][0] + '</span></td><td><strong>' + esc(t.titel) + '</strong><br><small style="color:var(--muted)">' + (t.art === 'wartung' ? 'Wartung' : 'Schaden') + ' · gemeldet ' + H.datum(t.erstellt) + ' von ' + esc(t.erstellt_von || '–') + '</small></td>' +
        '<td>' + esc(t.platz_id ? platzName(t.platz_id) : (t.ort || '')) + '</td><td>' + esc(t.verantwortlich || '–') + '</td><td class="nw">' + (t.faellig ? '<span' + (t.faellig < heute && t.status !== 'erledigt' ? ' class="tag rot"' : '') + '>' + H.datum(t.faellig) + '</span>' : '') + '</td><td><span class="tag ' + AST[t.status][1] + '">' + AST[t.status][0] + '</span></td></tr>').join('') ||
        '<tr><td colspan="6" class="leer">Nichts in dieser Ansicht.</td></tr>') + '</tbody></table></div>';
    main.querySelectorAll('[data-af]').forEach((b) => b.addEventListener('click', () => { aufStand.filter = b.dataset.af; zeige('aufgaben'); }));
    main.querySelectorAll('[data-t]').forEach((r) => r.addEventListener('click', () => aufgabeForm(d.aufgaben.find((t) => t.id === r.dataset.t))));
    $('#neu').addEventListener('click', () => aufgabeForm({}));
  };
  function aufgabeForm(t) {
    const neu = !t.id;
    const sel = (name, opts, v) => '<select name="' + name + '">' + opts.map(([k, txt]) => '<option value="' + k + '"' + (v === k ? ' selected' : '') + '>' + txt + '</option>').join('') + '</select>';
    const el = modal('<h2>' + (neu ? 'Schaden oder Wartung erfassen' : esc(t.titel)) + '</h2><form id="f" class="form">' +
      '<label class="feld voll">Was ist zu tun?<input name="titel" required maxlength="120" value="' + esc(t.titel || '') + '" placeholder="z. B. Stromsäule Ostbrücke ohne Funktion"></label>' +
      '<label class="feld">Art' + sel('art', [['schaden', 'Schaden'], ['wartung', 'Wartung / Prüfung']], t.art || 'schaden') + '</label>' +
      '<label class="feld">Priorität' + sel('prioritaet', [['hoch', 'dringend'], ['normal', 'normal'], ['niedrig', 'kann warten']], t.prioritaet || 'normal') + '</label>' +
      '<label class="feld">Ort<input name="ort" value="' + esc(t.ort || '') + '" placeholder="z. B. Westbrücke, Kran, Messe"></label>' +
      '<label class="feld">Liegeplatz (optional)<select name="platz_id"><option value="">–</option>' + d.liegeplaetze.map((p) => '<option value="' + p.id + '"' + (t.platz_id === p.id ? ' selected' : '') + '>' + esc(platzName(p.id)) + '</option>').join('') + '</select></label>' +
      '<label class="feld voll">Beschreibung<textarea name="beschreibung" rows="3">' + esc(t.beschreibung || '') + '</textarea></label>' +
      '<label class="feld">Wer kümmert sich?<input name="verantwortlich" value="' + esc(t.verantwortlich || '') + '" placeholder="Name oder Amt"></label>' +
      '<label class="feld">fällig bis<input name="faellig" type="date" value="' + esc(t.faellig || '') + '"></label>' +
      '<label class="feld">Stand' + sel('status', Object.entries(AST).map(([k, [txt]]) => [k, txt]), t.status || 'offen') + '</label>' +
      '<label class="feld">Foto / Dokument<input type="file" name="datei" accept="image/*,application/pdf"></label>' +
      '<label class="feld voll">Notiz<input name="notiz" value="' + esc(t.notiz || '') + '"></label></form>' +
      (neu ? '' : '<div class="abschnitt"><h3>Fotos und Dokumente</h3><div id="t-dok"><p class="leer">Wird geladen …</p></div></div>') +
      '<div class="modal-fuss">' + (!neu && rolle === 'vorstand' ? '<button class="btn gefahr links" id="weg">Löschen</button>' : '') + '<button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>', true);
    const dokListe = () => HF.dok.liste({ aufgabe_id: t.id }).then((l) => { $('#t-dok', el).innerHTML = l.length ? l.map((x) => '<button class="btn klein" data-dok="' + x.id + '">' + esc(x.name) + '</button>').join(' ') : '<p class="leer">Keine.</p>'; }).catch(() => {});
    if (!neu) { dokListe(); $('#t-dok', el).addEventListener('click', (e) => { const b = e.target.closest('[data-dok]'); if (b) HF.datei.oeffnen(b.dataset.dok).catch((x) => toast(x.message, 'fehler')); }); }
    $('#ok', el).addEventListener('click', async () => {
      const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm)); const file = fm.datei.files[0]; delete x.datei;
      let lese = null; if (file) { try { lese = await HF.datei.lesen(file); } catch (er) { return toast(er.message, 'fehler'); } }
      x.erledigt_am = x.status === 'erledigt' ? (t.erledigt_am || heute) : '';
      let ziel = t;
      if (neu) { ziel = { id: H.uid('T'), erstellt: new Date().toISOString(), erstellt_von: ROLLEN[rolle].name, boot_id: null, ...x }; d.aufgaben.push(ziel); } else Object.assign(t, x);
      zu(); const ok = await speichern(neu ? 'Erfasst.' : 'Gespeichert.');
      if (lese && ok !== false) { try { await HF.dok.hochladen({ ...lese, aufgabe_id: ziel.id, art: lese.typ === 'application/pdf' ? 'sonstiges' : 'foto' }, ROLLEN[rolle].name); toast('Gespeichert, Datei angehängt.'); } catch (er) { toast('Datei nicht gespeichert: ' + er.message, 'fehler'); } }
      zeige('aufgaben');
    });
    const w = $('#weg', el); if (w) w.addEventListener('click', () => { if (!confirm('Eintrag endgültig löschen?')) return; d.aufgaben = d.aufgaben.filter((y) => y.id !== t.id); speichern('Gelöscht.'); zu(); zeige('aufgaben'); });
  }

  /* ============================================================ Mitteilungen */
  const ZIEL = { alle: 'alle Mitglieder', bootseigner: 'Bootseigner', liegeplatz: 'Wasserlieger (Steg)' };
  V.mitteilungen = (main) => {
    const l = (d.mitteilungen || []).slice().sort((a, b) => String(b.erstellt).localeCompare(String(a.erstellt)));
    const aktuell = (x) => !x.gueltig_bis || x.gueltig_bis >= heute;
    const push = DB && d.einstellungen.push_aktiv;
    main.innerHTML = kopf('Mitteilungen', 'Kurze Nachrichten an die Mitglieder – erscheinen in „Mein SSV“ ganz oben' + (push ? ', auf Wunsch als Push aufs Handy' : '') + '. Wichtige Mitteilungen an alle zeigt auch die Getränkekasse.', '<button class="btn primaer" id="neu">+ Mitteilung</button>') +
      '<div class="panel"><table class="tab"><tbody>' + (l.map((x) => '<tr' + (aktuell(x) ? '' : ' class="blass"') + '><td>' + (x.wichtig ? '<span class="tag rot">wichtig</span> ' : '') + '<strong>' + esc(x.titel) + '</strong><br><small style="color:var(--muted)">' + esc(x.text || '') + '</small></td>' +
        '<td class="nw"><small>' + esc(ZIEL[x.zielgruppe] || x.zielgruppe) + '<br>' + (x.gueltig_bis ? 'bis ' + H.datum(x.gueltig_bis) : 'ohne Ende') + (x.push_gesendet ? '<br>Push gesendet' : '') + '</small></td><td class="r nw"><small style="color:var(--muted)">' + H.datum(x.erstellt) + ' · ' + esc(x.erstellt_von || '') + '</small><br><button class="btn klein gefahr" data-weg="' + x.id + '">Löschen</button></td></tr>').join('') || '<tr><td class="leer">Noch keine Mitteilungen.</td></tr>') + '</tbody></table></div>' +
      (DB ? '' : '<p class="hinweis">In der Demo erscheinen Mitteilungen in „Mein SSV“ und an der Kasse dieses Browsers. Push-Nachrichten aufs Handy gibt es nur mit der Vereinsdatenbank.</p>');
    main.querySelectorAll('[data-weg]').forEach((b) => b.addEventListener('click', () => { if (!confirm('Mitteilung löschen?')) return; d.mitteilungen = d.mitteilungen.filter((x) => x.id !== b.dataset.weg); speichern('Gelöscht.'); zeige(tab); }));
    $('#neu').addEventListener('click', () => {
      const bis = H.tag(new Date(Date.now() + 3 * 864e5));
      const el = modal('<h2>Mitteilung an die Mitglieder</h2><form id="f" class="form"><label class="feld voll">Titel<input name="titel" required maxlength="90" placeholder="z. B. Sturmwarnung: Boote zusätzlich sichern!"></label>' +
        '<label class="feld voll">Text<textarea name="text" rows="3" maxlength="600" placeholder="Was ist zu tun? Bis wann?"></textarea></label>' +
        '<label class="feld">An<select name="zielgruppe">' + Object.entries(ZIEL).map(([k, v]) => '<option value="' + k + '">' + v + '</option>').join('') + '</select></label><label class="feld">Anzeigen bis<input name="gueltig_bis" type="date" value="' + bis + '"></label>' +
        '<label class="feld check voll"><input type="checkbox" name="wichtig"> wichtig (rot hervorgehoben, z. B. Sturmwarnung)</label>' +
        (push ? '<label class="feld check voll"><input type="checkbox" name="push" checked> zusätzlich als Push-Nachricht aufs Handy senden (an alle, die das in „Mein SSV“ eingeschaltet haben)</label>' : '') +
        '</form><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Veröffentlichen</button></div>');
      $('#ok', el).addEventListener('click', async () => {
        const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm));
        const m = { id: H.uid('N'), titel: x.titel, text: x.text, wichtig: !!x.wichtig, zielgruppe: x.zielgruppe, gueltig_bis: x.gueltig_bis || null, erstellt: new Date().toISOString(), erstellt_von: ROLLEN[rolle].name, push_gesendet: null };
        d.mitteilungen.push(m); zu(); const ok = await speichern('Mitteilung veröffentlicht.');
        if (x.push && ok !== false) {
          try { const r = await window.SSV_SB.req('/functions/v1/push', { method: 'POST', body: { aktion: 'senden', mitteilung_id: m.id } }); toast('Push gesendet an ' + (r.gesendet || 0) + ' Gerät' + (r.gesendet === 1 ? '' : 'e') + '.'); m.push_gesendet = new Date().toISOString(); }
          catch (er) { toast('Push nicht gesendet: ' + er.message, 'fehler', 6000); }
        }
        zeige('mitteilungen');
      });
    });
  };

  /* ============================================================ Veranstaltungen
   * Einladungen an alle Mitglieder; sie sagen in „Mein SSV“ zu oder ab (bis zur Anmeldefrist, höchstens so viele wie Plätze).
   * Antworten per Telefon oder Zettel trägt der Verein hier nach. */
  let verAuswahl = null;   // offene Teilnehmerliste
  const verStand = (v) => { const z = (d.zusagen || []).filter((x) => x.veranstaltung_id === v.id); const ja = z.filter((x) => x.antwort === 'ja');
    return { z, ja, nein: z.filter((x) => x.antwort === 'nein'), pers: ja.reduce((s2, x) => s2 + (Number(x.personen) || 0), 0) }; };
  const verZeit = (v) => [v.beginn ? v.beginn + (v.ende ? '–' + v.ende : '') + ' Uhr' : '', v.ort].filter(Boolean).join(' · ');
  const verFrist = (v) => v.anmeldung_bis || v.datum;
  V.veranstaltungen = (main) => {
    const v0 = verAuswahl && (d.veranstaltungen || []).find((x) => x.id === verAuswahl);
    if (v0) return verTeilnehmer(main, v0);
    verAuswahl = null;
    const alle = d.veranstaltungen || [];
    const kommend = alle.filter((v) => v.datum >= heute).sort((a, b) => a.datum.localeCompare(b.datum) || String(a.beginn || '').localeCompare(String(b.beginn || '')));
    const vorbei = alle.filter((v) => v.datum < heute).sort((a, b) => b.datum.localeCompare(a.datum)).slice(0, 12);
    const zeile = (v) => { const st = verStand(v); const offen = !v.abgesagt && heute <= verFrist(v);
      return '<tr class="klickbar" data-ver-zeile="' + v.id + '"><td class="nw">' + H.datum(v.datum) + (v.beginn ? '<br><small style="color:var(--muted)">' + esc(v.beginn) + ' Uhr</small>' : '') + '</td>' +
        '<td><strong>' + esc(v.titel) + '</strong>' + (v.abgesagt ? ' <span class="tag rot">abgesagt</span>' : '') + (v.ort ? '<br><small style="color:var(--muted)">' + esc(v.ort) + '</small>' : '') + '</td>' +
        '<td>' + (v.abgesagt ? '–' : offen ? '<span class="tag ok">offen</span><br><small style="color:var(--muted)">bis ' + H.datum(verFrist(v)) + '</small>' : '<span class="tag">geschlossen</span>') + '</td>' +
        '<td class="r"><strong>' + st.pers + '</strong>' + (v.max_personen ? ' / ' + v.max_personen : '') + '<br><small style="color:var(--muted)">' + st.ja.length + ' Zusage' + (st.ja.length === 1 ? '' : 'n') + ' · ' + st.nein.length + ' Absage' + (st.nein.length === 1 ? '' : 'n') + '</small></td>' +
        '<td class="r aktion"><button class="btn klein" data-ver-liste="' + v.id + '">Teilnehmer</button> ' + zeilenMenue([
          '<button class="zm-punkt" data-ver-bearb="' + v.id + '">Bearbeiten</button>',
          v.datum >= heute ? '<button class="zm-punkt" data-ver-absagen="' + v.id + '">' + (v.abgesagt ? 'Wieder ansetzen' : 'Absagen') + '</button>' : '',
          '<button class="zm-punkt gefahr" data-ver-weg="' + v.id + '">Löschen</button>'].filter(Boolean)) + '</td></tr>'; };
    const tabelle = (l) => '<table class="tab"><thead><tr><th>Datum</th><th>Veranstaltung</th><th>Anmeldung</th><th class="r">Personen</th><th></th></tr></thead><tbody>' + l.map(zeile).join('') + '</tbody></table>';
    main.innerHTML = kopf('Veranstaltungen', 'Einladungen an alle Mitglieder – sie sagen in „Mein SSV“ zu oder ab. Hier steht, wer kommt.', '<button class="btn primaer" id="neu">+ Veranstaltung</button>') +
      '<div class="panel"><h2>Kommende</h2>' + (kommend.length ? tabelle(kommend) : '<p class="leer">Noch keine Veranstaltung geplant.</p>') + '</div>' +
      (vorbei.length ? '<div class="panel"><h2>Vergangene</h2>' + tabelle(vorbei) + '</div>' : '') +
      '<p class="hinweis">Mitglieder sehen Titel, Zeit, Ort, Kosten und wie viele Plätze noch frei sind – aber nicht, wer sonst kommt. Kosten lassen sich in der Teilnehmerliste mit „Kosten abrechnen“ als Rechnungen erstellen (Lastschrift oder Überweisung) – oder bleiben ein Hinweis wie „bar vor Ort“.</p>';
    main.querySelectorAll('[data-ver-zeile]').forEach((tr) => tr.addEventListener('click', (e) => { if (e.target.closest('button, .zm')) return; verAuswahl = tr.dataset.verZeile; zeige('veranstaltungen'); }));
    main.querySelectorAll('[data-ver-liste]').forEach((b) => b.addEventListener('click', () => { verAuswahl = b.dataset.verListe; zeige('veranstaltungen'); }));
    main.querySelectorAll('[data-ver-bearb]').forEach((b) => b.addEventListener('click', () => verForm(alle.find((v) => v.id === b.dataset.verBearb))));
    main.querySelectorAll('[data-ver-absagen]').forEach((b) => b.addEventListener('click', async () => {
      const v = alle.find((x) => x.id === b.dataset.verAbsagen);
      if (!v.abgesagt && !confirm('„' + v.titel + '“ absagen? Die Mitglieder sehen das in „Mein SSV“; zusätzlich erscheint dort eine Mitteilung.')) return;
      v.abgesagt = !v.abgesagt;
      if (v.abgesagt) d.mitteilungen.push({ id: H.uid('N'), titel: 'Abgesagt: ' + v.titel + ' am ' + H.kurz(v.datum), text: 'Die Veranstaltung fällt aus.', wichtig: false, zielgruppe: 'alle', gueltig_bis: v.datum, erstellt: new Date().toISOString(), erstellt_von: ROLLEN[rolle].name, push_gesendet: null });
      await speichern(v.abgesagt ? 'Abgesagt.' : 'Wieder angesetzt.'); zeige('veranstaltungen');
    }));
    main.querySelectorAll('[data-ver-weg]').forEach((b) => b.addEventListener('click', () => {
      const v = alle.find((x) => x.id === b.dataset.verWeg); const n = verStand(v).z.length;
      if (verRechnungen(v).length) return toast('Für diese Veranstaltung gibt es schon Rechnungen – sie bleibt deshalb erhalten. Stattdessen „Absagen“ oder die Rechnungen stornieren.', 'fehler', 6000);
      if (!confirm('„' + v.titel + '“ endgültig löschen?' + (n ? ' Die ' + n + ' Antworten der Mitglieder werden mit gelöscht.' : ''))) return;
      d.zusagen = (d.zusagen || []).filter((z) => z.veranstaltung_id !== v.id); d.veranstaltungen = alle.filter((x) => x.id !== v.id);
      speichern('Gelöscht.'); zeige('veranstaltungen');
    }));
    $('#neu').addEventListener('click', () => verForm(null));
  };
  function verForm(v) {
    const neu = !v; v = v || { datum: '', beginn: '', ende: '', titel: '', ort: 'Messe (Vereinsheim)', text: '', anmeldung_bis: '', max_personen: null, begleitung: 0, kosten: null, kosten_hinweis: '' };
    const push = DB && d.einstellungen.push_aktiv;
    const el = modal('<h2>' + (neu ? 'Neue Veranstaltung' : 'Veranstaltung bearbeiten') + '</h2><form id="f" class="form">' +
      '<label class="feld voll">Titel<input name="titel" required maxlength="90" value="' + esc(v.titel) + '" placeholder="z. B. Wintertreffen mit Grünkohl"></label>' +
      '<label class="feld">Datum<input name="datum" type="date" required value="' + esc(v.datum) + '"></label><label class="feld">Ort<input name="ort" maxlength="80" value="' + esc(v.ort || '') + '"></label>' +
      '<label class="feld">Beginn<input name="beginn" type="time" value="' + esc(v.beginn || '') + '"></label><label class="feld">Ende (optional)<input name="ende" type="time" value="' + esc(v.ende || '') + '"></label>' +
      '<label class="feld voll">Beschreibung<textarea name="text" rows="3" maxlength="1500" placeholder="Was erwartet die Mitglieder? Was mitbringen?">' + esc(v.text || '') + '</textarea></label>' +
      '<label class="feld">Anmeldung bis<input name="anmeldung_bis" type="date" value="' + esc(v.anmeldung_bis || '') + '"><small>leer = bis zum Tag selbst</small></label>' +
      '<label class="feld">Plätze höchstens<input name="max_personen" type="number" min="1" max="2000" value="' + (v.max_personen || '') + '"><small>leer = unbegrenzt; Begleitung zählt mit</small></label>' +
      '<label class="feld">Begleitung je Mitglied<select name="begleitung">' + [0, 1, 2, 3, 4, 5].map((n) => '<option value="' + n + '"' + (Number(v.begleitung) === n ? ' selected' : '') + '>' + (n === 0 ? 'keine' : n === 1 ? '1 Person' : 'bis zu ' + n + ' Personen') + '</option>').join('') + '</select></label>' +
      '<label class="feld">Kosten je Person (€)<input name="kosten" inputmode="decimal" autocomplete="off" value="' + (v.kosten == null ? '' : String(v.kosten).replace('.', ',')) + '" placeholder="z. B. 12,50"><small>leer = kostenlos</small></label>' +
      '<label class="feld voll">Hinweis zu den Kosten<input name="kosten_hinweis" maxlength="80" value="' + esc(v.kosten_hinweis || '') + '" placeholder="z. B. bar vor Ort"></label>' +
      (neu ? '<label class="feld check voll"><input type="checkbox" name="ankuendigen" checked> in „Mein SSV“ zusätzlich als Mitteilung ankündigen (oben auf der Seite)</label>' +
        (push ? '<label class="feld check voll"><input type="checkbox" name="push"> dazu als Push-Nachricht aufs Handy senden</label>' : '') : '') +
      '</form><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">' + (neu ? 'Einladen' : 'Speichern') + '</button></div>', true);
    $('#ok', el).addEventListener('click', async () => {
      const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm));
      if (x.anmeldung_bis && x.anmeldung_bis > x.datum) return toast('Die Anmeldefrist liegt nach der Veranstaltung.', 'fehler');
      if (x.ende && x.beginn && x.ende < x.beginn) return toast('Das Ende liegt vor dem Beginn.', 'fehler');
      const kosten = x.kosten.trim() === '' ? null : Math.round(H.dez(x.kosten) * 100) / 100;   // „12,50“ und „12.50“ – Number('12,50') wäre NaN
      if (kosten !== null && !(kosten >= 0)) { $('[name=kosten]', fm).focus(); return toast('Bitte bei den Kosten einen Betrag wie 12,50 eingeben.', 'fehler'); }
      const felder = { titel: x.titel.trim(), datum: x.datum, beginn: x.beginn, ende: x.ende, ort: x.ort.trim(), text: x.text.trim(), anmeldung_bis: x.anmeldung_bis, max_personen: x.max_personen ? Number(x.max_personen) : null,
        begleitung: Number(x.begleitung) || 0, kosten: kosten || null, kosten_hinweis: x.kosten_hinweis.trim() };
      if (!neu && felder.max_personen && verStand(v).pers > felder.max_personen && !confirm('Es haben schon ' + verStand(v).pers + ' Personen zugesagt – mehr als die neue Grenze. Trotzdem speichern?')) return;
      let m = null;
      if (neu) {
        v = { id: H.uid('V'), ...felder, abgesagt: false, erstellt: new Date().toISOString(), erstellt_von: ROLLEN[rolle].name }; if (!d.veranstaltungen) d.veranstaltungen = []; d.veranstaltungen.push(v);
        if (x.ankuendigen) { m = { id: H.uid('N'), titel: 'Einladung: ' + v.titel + ' am ' + H.kurz(v.datum), text: 'Bitte in „Mein SSV“ unter „Veranstaltungen“ zu- oder absagen' + (v.anmeldung_bis ? ' – bis ' + H.datum(v.anmeldung_bis) : '') + '.', wichtig: false, zielgruppe: 'alle', gueltig_bis: verFrist(v), erstellt: new Date().toISOString(), erstellt_von: ROLLEN[rolle].name, push_gesendet: null }; d.mitteilungen.push(m); }
      } else Object.assign(v, felder);
      zu(); const ok = await speichern(neu ? 'Eingeladen – die Mitglieder sehen es in „Mein SSV“.' : 'Gespeichert.');
      if (m && x.push && ok !== false) {
        try { const r = await window.SSV_SB.req('/functions/v1/push', { method: 'POST', body: { aktion: 'senden', mitteilung_id: m.id } }); toast('Push gesendet an ' + (r.gesendet || 0) + ' Gerät' + (r.gesendet === 1 ? '' : 'e') + '.'); m.push_gesendet = new Date().toISOString(); }
        catch (er) { toast('Push nicht gesendet: ' + er.message, 'fehler', 6000); }
      }
      zeige('veranstaltungen');
    });
  }
  // Teilnehmerliste: Zusagen mit Personen und Hinweisen, Absagen, Druck (SSV-Briefkopf) und CSV
  function verTeilnehmer(main, v) {
    const st = verStand(v); const name = (id) => { const m = Q.mitglied(id); return m ? m.nachname + ', ' + m.vorname : '(nicht mehr Mitglied)'; };
    const reVon = verRechnungen(v); const reZu = (mid) => reVon.find((r) => r.mitglied_id === mid);
    const offenAbr = verAbrechenbar(v); const darfGeld = darf('abrechnung');
    const sort = (l) => l.slice().sort((a, b) => name(a.mitglied_id).localeCompare(name(b.mitglied_id), 'de'));
    const ja = sort(st.ja), nein = sort(st.nein); const frei = v.max_personen ? v.max_personen - st.pers : null;
    const wann = (z) => z.geaendert ? new Date(z.geaendert).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }) : '';
    const menue = (z) => zeilenMenue(['<button class="zm-punkt" data-z-bearb="' + z.id + '">Ändern</button>', '<button class="zm-punkt gefahr" data-z-weg="' + z.id + '">Antwort löschen</button>']);
    main.innerHTML = druckKopf() + kopf(esc(v.titel) + (v.abgesagt ? ' <span class="tag rot">abgesagt</span>' : ''), H.datum(v.datum) + (verZeit(v) ? ' · ' + esc(verZeit(v)) : '') + (v.anmeldung_bis ? ' · Anmeldung bis ' + H.datum(v.anmeldung_bis) : ''),
        '<button class="btn" id="v-zurueck">← Alle Veranstaltungen</button><button class="btn" id="v-eintragen">+ Antwort eintragen</button>' + (v.kosten && darfGeld && offenAbr.length ? '<button class="btn" id="v-abr">Kosten abrechnen (' + offenAbr.length + ')</button>' : '') + (darfGeld && reVon.length ? '<button class="btn" id="v-mail">Rechnungen per E-Mail</button>' : '') + '<button class="btn" id="v-csv">CSV</button><button class="btn primaer" id="v-druck">Drucken</button>') +
      '<div class="karten ver-karten"><div class="kz"><small>Personen zugesagt</small><strong>' + st.pers + (v.max_personen ? ' / ' + v.max_personen : '') + '</strong><span>' + ja.length + ' Mitglied' + (ja.length === 1 ? '' : 'er') + (st.pers > ja.length ? ' + ' + (st.pers - ja.length) + ' Begleitung' : '') + '</span></div>' +
        (frei !== null ? '<div class="kz"><small>Plätze frei</small><strong>' + Math.max(0, frei) + '</strong><span>' + (frei <= 0 ? 'ausgebucht' : 'Mitglieder sehen nur diese Zahl') + '</span></div>' : '') +
        '<div class="kz"><small>Absagen</small><strong>' + nein.length + '</strong><span>' + (d.mitglieder.length ? 'noch keine Antwort: ' + Math.max(0, d.mitglieder.filter((m) => m.art !== 'gast' && !(m.austritt && m.austritt <= heute)).length - st.z.length) : '') + '</span></div>' +
        (v.kosten ? '<div class="kz"><small>Kosten</small><strong>' + H.geld(v.kosten * st.pers) + '</strong><span>' + st.pers + ' × ' + H.geld(v.kosten) + (reVon.length ? ' · ' + reVon.length + ' abgerechnet' + (offenAbr.length ? ', ' + offenAbr.length + ' noch nicht' : '') : v.kosten_hinweis ? ' ' + esc(v.kosten_hinweis) : '') + '</span></div>' : '') + '</div>' +
      '<div class="panel"><h2>Zusagen</h2>' + (ja.length ? '<table class="tab"><thead><tr><th class="r">#</th><th>Name</th><th class="r">Personen</th><th>Hinweis</th><th>Antwort</th>' + (reVon.length ? '<th>Rechnung</th>' : '') + '<th class="kein-druck"></th></tr></thead><tbody>' +
        ja.map((z, i) => { const r = reZu(z.mitglied_id); return '<tr><td class="r">' + (i + 1) + '</td><td>' + esc(name(z.mitglied_id)) + '</td><td class="r">' + z.personen + '</td><td>' + esc(z.bemerkung || '') + '</td><td><small>' + wann(z) + (z.quelle === 'verein' ? ' · vom Verein eingetragen' : z.quelle === 'kasse' ? ' · am Getränke-iPad' : '') + '</small></td>' +
          (reVon.length ? '<td>' + (r ? '<small>' + esc(r.nr) + '</small> <span class="tag ' + STUFE[stufe(r)][1] + '">' + STUFE[stufe(r)][0] + '</span>' : '<small style="color:var(--muted)">–</small>') + '</td>' : '') + '<td class="r aktion kein-druck">' + menue(z) + '</td></tr>'; }).join('') +
        '<tr class="summe"><td></td><td><strong>Zusammen</strong></td><td class="r"><strong>' + st.pers + '</strong></td><td colspan="' + (reVon.length ? 4 : 3) + '"></td></tr></tbody></table>' : '<p class="leer">Noch keine Zusagen.</p>') + '</div>' +
      (nein.length ? '<div class="panel"><h2>Absagen</h2><table class="tab"><tbody>' + nein.map((z) => '<tr><td>' + esc(name(z.mitglied_id)) + '</td><td>' + esc(z.bemerkung || '') + '</td><td><small>' + wann(z) + (z.quelle === 'verein' ? ' · vom Verein eingetragen' : z.quelle === 'kasse' ? ' · am Getränke-iPad' : '') + '</small></td><td class="r aktion kein-druck">' + menue(z) + '</td></tr>').join('') + '</tbody></table></div>' : '') +
      (v.text ? '<p class="hinweis kein-druck">' + esc(v.text) + '</p>' : '');
    $('#v-zurueck').addEventListener('click', () => { verAuswahl = null; zeige('veranstaltungen'); });
    $('#v-druck').addEventListener('click', () => window.print());
    $('#v-csv').addEventListener('click', () => download('ssv-teilnehmer-' + v.datum + '.csv', csv([['Veranstaltung', v.titel, H.datum(v.datum)], ['Mitgliedsnr', 'Name', 'Antwort', 'Personen', 'Hinweis', 'geantwortet am', 'eingetragen']].concat(
      ja.concat(nein).map((z) => { const m = Q.mitglied(z.mitglied_id) || {}; return [m.nr || '', name(z.mitglied_id), z.antwort === 'ja' ? 'Zusage' : 'Absage', z.personen, z.bemerkung || '', z.geaendert ? new Date(z.geaendert).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '', z.quelle === 'verein' ? 'vom Verein' : z.quelle === 'kasse' ? 'Getränke-iPad' : 'Mein SSV']; }))), 'text/csv'));
    $('#v-eintragen').addEventListener('click', () => zusageForm(v, null));
    const vabr = $('#v-abr'); if (vabr) vabr.addEventListener('click', () => verAbrechnenDialog(v));
    const vm = $('#v-mail'); if (vm) vm.addEventListener('click', () => mailVersandDialog('hafen', reVon, v.titel + ' · ' + H.datum(v.datum), () => zeige('veranstaltungen', true)));
    main.querySelectorAll('[data-z-bearb]').forEach((b) => b.addEventListener('click', () => zusageForm(v, st.z.find((z) => z.id === b.dataset.zBearb))));
    main.querySelectorAll('[data-z-weg]').forEach((b) => b.addEventListener('click', () => {
      const z = st.z.find((x) => x.id === b.dataset.zWeg); if (!confirm('Antwort von ' + name(z.mitglied_id) + ' löschen?')) return;
      d.zusagen = d.zusagen.filter((x) => x.id !== z.id); speichern('Gelöscht.'); zeige('veranstaltungen');
    }));
  }
  /* Veranstaltungskosten abrechnen: je Zusage eine Rechnung (Personen × Kosten), mit Mandat per Lastschrift, sonst Überweisung.
   * Die Rechnungen laufen danach wie alle anderen über Finanzen → „Abrechnen“ (auch dort ist „Kosten abrechnen“) und den Zahlungseingang. */
  const verRechnungen = (v) => d.rechnungen.filter((r) => r.veranstaltung_id === v.id && !r.storniert_am);
  const verAbrechenbar = (v) => { const schon = new Set(verRechnungen(v).map((r) => r.mitglied_id));
    return verStand(v).ja.filter((z) => !schon.has(z.mitglied_id) && Q.mitglied(z.mitglied_id) && Number(z.personen) > 0); };
  function verRechnungenErzeugen(v, datum) {
    const e = d.einstellungen; const jahr = datum.slice(0, 4); const praefix = (e.veranstaltung_praefix || 'SSV-V') + '-' + jahr + '-';
    let lfd = d.rechnungen.filter((r) => r.nr.startsWith(praefix)).reduce((mx, r) => Math.max(mx, parseInt(r.nr.slice(praefix.length), 10) || 0), 0);
    const faellig = H.tag(new Date(new Date(datum + 'T12:00:00').getTime() + Number(e.zahlungsziel_tage || 14) * 864e5));
    const text = v.titel + ' am ' + H.datum(v.datum);
    return verAbrechenbar(v).map((z) => { const m = Q.mitglied(z.mitglied_id); lfd += 1; const p = Number(z.personen);
      const re = { id: H.uid('R'), nr: praefix + String(lfd).padStart(4, '0'), mitglied_id: m.id, datum, saison: Number(v.datum.slice(0, 4)), periode: 'veranstaltung', veranstaltung_id: v.id, faellig,
        positionen: [{ text, menge: p, einheit: p === 1 ? 'Person' : 'Personen', einzelpreis: Number(v.kosten), betrag: Math.round(p * v.kosten * 100) / 100 }], summe: Math.round(p * v.kosten * 100) / 100,
        empfaenger: { nr: m.nr, vorname: m.vorname, nachname: m.nachname, strasse: m.strasse, plz: m.plz, ort: m.ort, email: m.email, art: m.art },
        sepa: !!(m.iban && m.mandat_ref && m.mandat_datum), mandat_ref: m.mandat_ref || '', mandat_datum: m.mandat_datum || '', bezahlt_am: null, storniert_am: null, sepa_lauf: null, zahlungen: [] };
      d.rechnungen.push(re); return re; });
  }
  let verAbrLaeuft = false;
  function verAbrechnenDialog(v, danach) {   // danach: Rücksprung (z. B. nach „Abrechnen“); sonst zurück zur Veranstaltung
    const l = verAbrechenbar(v); if (!l.length) return toast('Alle Zusagen sind schon abgerechnet.');
    const zeilen = l.map((z) => { const m = Q.mitglied(z.mitglied_id); const sepa = !!(m.iban && m.mandat_ref && m.mandat_datum);
      return '<tr><td>' + esc(m.nachname + ', ' + m.vorname) + '</td><td class="r">' + z.personen + ' × ' + H.geld(v.kosten) + '</td><td class="r"><strong>' + H.geld(z.personen * v.kosten) + '</strong></td><td>' + (sepa ? 'Lastschrift' : '<span class="tag warn">Überweisung</span>') + '</td></tr>'; }).join('');
    const summe = l.reduce((x, z) => x + z.personen * v.kosten, 0);
    const el = modal('<h2>Kosten abrechnen</h2><p style="margin-top:0">' + esc(v.titel) + ' · ' + H.datum(v.datum) + ' · ' + l.length + ' Rechnung' + (l.length === 1 ? '' : 'en') + ' über zusammen <strong>' + H.geld(summe) + '</strong></p>' +
      '<div style="max-height:40vh;overflow:auto"><table class="tab"><tbody>' + zeilen + '</tbody></table></div>' +
      '<form id="f" class="form" style="margin-top:12px"><label class="feld">Rechnungsdatum<input name="datum" type="date" required value="' + heute + '"><small>fällig ' + Number(d.einstellungen.zahlungsziel_tage || 14) + ' Tage später</small></label></form>' +
      '<p class="hinweis">Mit Lastschriftmandat wird der Betrag beim nächsten Lastschrift-Lauf eingezogen (Finanzen → Abrechnen), sonst steht auf der Rechnung die Bitte um Überweisung. Die Mitglieder sehen die Rechnung sofort in „Mein SSV“. Zusagen, die später dazukommen, lassen sich nachträglich abrechnen.</p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">' + l.length + ' Rechnung' + (l.length === 1 ? '' : 'en') + ' erstellen</button></div>', true);
    $('#ok', el).addEventListener('click', async () => {
      const fm = $('#f', el); if (!fm.reportValidity() || verAbrLaeuft) return; verAbrLaeuft = true; $('#ok', el).disabled = true;
      try {
        if (DB) { await HF.neuLaden(); d = HF.d; v = d.veranstaltungen.find((x) => x.id === v.id) || v; }   // neuester Stand: keine doppelten Rechnungen
        const neu = verRechnungenErzeugen(v, fm.datum.value); zu();
        if (!neu.length) { toast('Keine neuen Rechnungen – schon abgerechnet.'); return danach ? danach() : zeige('veranstaltungen'); }
        const ok = await speichern(); if (ok === false) return;
        toast(neu.length + ' Rechnungen erstellt.'); if (danach) danach(); else zeige('veranstaltungen');
        if (confirm('Rechnungen jetzt ansehen / als PDF sichern?')) oeffnen('drucken.html?art=rechnungen&ids=' + neu.map((r) => r.id).join(','));
      } catch (x) { toast('Rechnungen nicht erstellt: ' + x.message, 'fehler', 7000); if (danach) danach(); else zeige('veranstaltungen'); }
      finally { verAbrLaeuft = false; }
    });
  }
  // Antwort für ein Mitglied eintragen (Telefon, Zettel an der Messe) – der Verein darf auch nach der Frist und über die Grenze
  function zusageForm(v, z) {
    const st = verStand(v); const schon = new Set(st.z.map((x) => x.mitglied_id));
    const el = modal('<h2>' + (z ? 'Antwort ändern' : 'Antwort eintragen') + '</h2><p style="margin-top:0">' + esc(v.titel) + ' · ' + H.datum(v.datum) + '</p><form id="f" class="form">' +
      (z ? '<p class="voll" style="margin:0"><strong>' + esc(Q.name(Q.mitglied(z.mitglied_id))) + '</strong></p>' : '<label class="feld voll">Mitglied<select name="mitglied_id" required><option value="">– bitte wählen –</option>' + mOpt('', (m) => m.art !== 'gast' && !schon.has(m.id)) + '</select></label>') +
      '<label class="feld">Antwort<select name="antwort"><option value="ja"' + (!z || z.antwort === 'ja' ? ' selected' : '') + '>kommt</option><option value="nein"' + (z && z.antwort === 'nein' ? ' selected' : '') + '>kommt nicht</option></select></label>' +
      '<label class="feld">Personen (mit Begleitung)<input name="personen" type="number" min="1" max="10" value="' + (z && z.antwort === 'ja' ? z.personen : 1) + '"></label>' +
      '<label class="feld voll">Hinweis<input name="bemerkung" maxlength="200" value="' + esc((z && z.bemerkung) || '') + '" placeholder="z. B. vegetarisch"></label></form>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="ok">Speichern</button></div>');
    $('#ok', el).addEventListener('click', () => {
      const fm = $('#f', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm));
      const pers = x.antwort === 'ja' ? Math.max(1, Math.min(10, Number(x.personen) || 1)) : 0;
      const andere = st.pers - (z && z.antwort === 'ja' ? z.personen : 0);
      if (pers && v.max_personen && andere + pers > v.max_personen && !confirm('Damit wären es ' + (andere + pers) + ' Personen bei ' + v.max_personen + ' Plätzen. Trotzdem eintragen?')) return;
      const felder = { antwort: x.antwort, personen: pers, bemerkung: x.bemerkung.trim(), quelle: 'verein', geaendert: new Date().toISOString() };
      if (z) Object.assign(z, felder); else { if (!d.zusagen) d.zusagen = []; d.zusagen.push({ id: H.uid('Z'), veranstaltung_id: v.id, mitglied_id: x.mitglied_id, ...felder }); }
      zu(); speichern('Gespeichert.'); zeige('veranstaltungen');
    });
  }

  /* ============================================================ Änderungsverlauf */
  const verlaufErlaubt = () => darf('verlauf');
  const BEREICH = { mitglieder: 'Mitglied', mitglieder_bank: 'Bankdaten', boote: 'Boot', belegungen: 'Belegung', abwesenheiten: 'Grünes Schild', gaeste: 'Gastlieger', warteliste: 'Warteliste', kran: 'Kran', arbeitsdienst: 'Arbeitsdienst',
    hafen_rechnungen: 'Rechnung', sepa_laeufe: 'Lastschrift-Lauf', arbeitseinsaetze: 'Arbeitseinsatz', mitteilungen: 'Mitteilung', veranstaltungen: 'Veranstaltung', zusagen: 'Zu-/Absage', antraege: 'Aufnahmeantrag', liegeplaetze: 'Liegeplatz', gebuehren: 'Gebühren', hafen_einstellungen: 'Einstellungen', funktionen: 'Zugang/Rolle', aufgaben: 'Schaden/Wartung', dokumente: 'Dokument' };
  const AKTION = { neu: ['neu', 'ok'], geaendert: ['geändert', ''], geloescht: ['gelöscht', 'rot'] };
  // Änderungsverlauf lesbar: Feldnamen in Alltagssprache, Werte als Datum/Betrag/ja-nein, Listen (z. B. Zahlungen) als einzelne Einträge – nie rohes JSON
  const FELDNAME = { bezahlt_am: 'bezahlt am', zahlungen: 'Zahlungen', summe: 'Summe', betrag: 'Betrag', datum: 'Datum', faellig: 'fällig', sepa_lauf: 'Lastschrift-Datei', storniert_am: 'storniert am', platz_id: 'Platz', boot_id: 'Boot', eigner_id: 'Eigner', mitglied_id: 'Mitglied',
    vorname: 'Vorname', nachname: 'Nachname', strasse: 'Straße', plz: 'PLZ', ort: 'Ort', email: 'E-Mail', telefon: 'Telefon', iban: 'IBAN', bic: 'BIC', kontoinhaber: 'Kontoinhaber', mandat_datum: 'Mandat vom', mandat_ref: 'Mandatsreferenz', art: 'Art', status: 'Stand',
    laenge: 'Länge', breite: 'Breite', tiefgang: 'Tiefgang', gewicht_t: 'Gewicht (t)', max_laenge: 'Boxlänge', max_breite: 'Boxbreite', tiefe: 'Wassertiefe', von: 'von', bis: 'bis', ankunft: 'Ankunft', naechte: 'Nächte', notiz: 'Notiz', titel: 'Titel', text: 'Text',
    stunden: 'Stunden', personen: 'Personen', antwort: 'Antwort', kosten: 'Kosten', vers_status: 'Versicherung', vers_bis: 'versichert bis', vers_geprueft_am: 'Nachweis geprüft am', vers_geprueft_von: 'Nachweis geprüft von', eintritt: 'Eintritt', austritt: 'Austritt', geburtsdatum: 'Geburtsdatum', zahlung: 'Zahlweg', zahlung_gemeldet: 'Zahlung gemeldet',
    verein_name: 'Vereinsname', verein_strasse: 'Straße des Vereins', verein_ort: 'Ort des Vereins', verein_email: 'E-Mail des Vereins', glaeubiger_id: 'Gläubiger-ID', steuer_hinweis: 'Steuerhinweis', zahlungsziel_tage: 'Zahlungsziel (Tage)', kontoauszug_zuletzt: 'Kontoauszug zuletzt',
    abrechnung_zugestellt: 'Zustell-Vermerk', lageplan: 'Lageplan', lageplan_planungen: 'Planungen', karte_oeffentlich: 'Hafenkarte öffentlich', karte_tage: 'Tage voraus', kran_max_t: 'Kran höchstens (t)', max_gewicht_t: 'Steg höchstens (t)',
    quelle: 'Quelle', geaendert: 'geändert', gueltig_bis: 'gültig bis', zielgruppe: 'Zielgruppe', wichtig: 'wichtig', erstellt: 'erstellt', erstellt_von: 'erstellt von', begleitung: 'Begleitung', abgesagt: 'abgesagt',
    anmeldung_bis: 'Anmeldung bis', max_personen: 'Plätze höchstens', beginn: 'Beginn', ende: 'Ende', bemerkung: 'Bemerkung', name: 'Name', nr: 'Nummer', typ: 'Typ', segelnummer: 'Segelnummer', periode: 'Zeitraum', saison: 'Saison', bezahlt: 'bezahlt', push_gesendet: 'Push gesendet' };
  const feldName = (k) => FELDNAME[k] || String(k).replace(/_/g, ' ');
  const GELD_FELD = /^(betrag|summe|kosten|einzelpreis|preis|rest|arbeitsdienst_satz)$|_eur$|_preis$/;
  const eintragText = (o) => {   // ein Listeneintrag, z. B. eine Zahlung
    if (o == null || typeof o !== 'object') return wertText(o);
    if ('betrag' in o && ('datum' in o || 'art' in o)) return (o.art === 'ruecklastschrift' ? 'Rücklastschrift' : 'Zahlung') + (o.datum ? ' ' + H.datum(o.datum) : '') + ' · ' + H.geld(o.betrag) + (o.art && o.art !== 'ruecklastschrift' ? ' · ' + (o.art === 'eingang' ? 'Eingang' : o.art) : '') + (o.notiz ? ' · ' + o.notiz : '');
    if (Array.isArray(o)) return o.length + (o.length === 1 ? ' Eintrag' : ' Einträge');
    return Object.entries(o).filter(([k, v]) => v != null && v !== '' && typeof v !== 'object' && k !== 'id').slice(0, 4).map(([k, v]) => feldName(k) + ' ' + wertText(v, k)).join(', ') || 'Eintrag';
  };
  const wertText = (v, k) => {
    if (v == null || v === '') return '–';
    if (typeof v === 'boolean') return v ? 'ja' : 'nein';
    if (typeof v === 'number') return k && GELD_FELD.test(k) ? H.geld(v) : String(v).replace('.', ',');
    if (Array.isArray(v)) return !v.length ? 'keine' : v.every((x) => x == null || typeof x !== 'object') ? v.join(', ') : v.length === 1 ? eintragText(v[0]) : v.length + ' Einträge';
    if (typeof v === 'object') { const n = Object.keys(v).length; return n + (n === 1 ? ' Angabe' : ' Angaben'); }
    const t = String(v);
    if (/^\d{4}-\d{2}-\d{2}$/.test(t)) return H.datum(t);
    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(t)) return new Date(t).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    return t.length > 80 ? t.slice(0, 80) + ' …' : t;
  };
  const istObj = (v) => v != null && typeof v === 'object' && !Array.isArray(v);
  const diffZeilen = (k, alt, neu) => {   // eine Zeile je geänderter Angabe: „Feld: alt → neu“
    if (istObj(alt) && istObj(neu)) {   // z. B. Einstellungen: nur die geänderten Unterfelder
      return Object.keys({ ...alt, ...neu }).filter((u) => JSON.stringify(alt[u]) !== JSON.stringify(neu[u])).flatMap((u) => diffZeilen(u, alt[u], neu[u]).map(([f, t]) => [k === 'daten' ? f : feldName(k) + ' › ' + f, t]));
    }
    if (Array.isArray(alt) && Array.isArray(neu) && (alt.concat(neu).some((x) => x != null && typeof x === 'object'))) {   // Listen: hinzugekommene/entfernte Einträge
      const j = (x) => JSON.stringify(x); const dazu = neu.filter((x) => !alt.some((y) => j(y) === j(x))), weg = alt.filter((x) => !neu.some((y) => j(y) === j(x)));
      return dazu.map((x) => [feldName(k), 'neu: ' + eintragText(x)]).concat(weg.map((x) => [feldName(k), 'entfernt: ' + eintragText(x)]));
    }
    return [[feldName(k), wertText(alt, k) + ' → ' + wertText(neu, k)]];
  };
  const aenderungText = (x) => {
    const a = x.aenderung || {};
    if (x.aktion === 'geaendert') {
      // Demo: { feld: [alt, neu] }; Datenbank: ebenso, bei „daten“ schon { unterfeld: [alt, neu] }
      const z = Object.entries(a).flatMap(([k, v]) => Array.isArray(v) && v.length === 2 ? diffZeilen(k, v[0], v[1]) : istObj(v) ? Object.entries(v).flatMap(([u, w]) => Array.isArray(w) && w.length === 2 ? diffZeilen(u, w[0], w[1]) : [[feldName(u), wertText(w, u)]]) : [[feldName(k), wertText(v, k)]]);
      const MAXZ = 8;
      return z.slice(0, MAXZ).map(([f, t]) => '<span class="feldname">' + esc(f) + ':</span> ' + esc(t)).join('<br>') + (z.length > MAXZ ? '<br><small>… und ' + (z.length - MAXZ) + ' weitere Angaben</small>' : '');
    }
    return esc(Object.entries(a).filter(([k, v]) => v != null && v !== '' && !(Array.isArray(v) && !v.length) && !istObj(v) && !['id', 'positionen', 'empfaenger', 'daten'].includes(k) && !(/_id$/.test(k) && k !== 'platz_id')).slice(0, 6).map(([k, v]) => feldName(k) + ': ' + wertText(v, k)).join(' · '));
  };
  const verlaufTabelle = (l) => '<table class="tab verlauf"><thead><tr><th>Wann</th><th>Wer</th><th>Was</th><th>Änderung</th></tr></thead><tbody>' + (l.map((x) =>
    '<tr><td class="nw">' + new Date(x.zeit).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) + '</td><td>' + esc(x.wer || '–') + '</td>' +
    '<td><span class="tag ' + AKTION[x.aktion][1] + '">' + AKTION[x.aktion][0] + '</span> ' + esc(BEREICH[x.tabelle] || x.tabelle) + (x.bezeichnung ? ' <strong>' + esc(x.bezeichnung) + '</strong>' : '') + '</td><td class="vl-aenderung">' + aenderungText(x) + '</td></tr>').join('') ||
    '<tr><td colspan="4" class="leer">Noch keine Änderungen.</td></tr>') + '</tbody></table>';
  const verlaufStand = { tabelle: '', such: '' };
  V.verlauf = (main) => {
    main.innerHTML = kopf('Änderungsverlauf', 'Wer hat wann einen Platz, Betrag oder Mitgliedsdatensatz geändert – wird automatisch mitgeschrieben und nach 3 Jahren gelöscht. Bankdaten erscheinen nur gekürzt.') +
      '<div class="filter"><select class="suche" id="vt" style="min-width:0"><option value="">alle Bereiche</option>' + Object.entries(BEREICH).map(([k, v]) => '<option value="' + k + '"' + (verlaufStand.tabelle === k ? ' selected' : '') + '>' + v + '</option>').join('') + '</select>' +
      '<input class="suche" id="vs" placeholder="Name, Boot, Platz, Person …" value="' + esc(verlaufStand.such) + '"></div><div class="panel" id="vl"><p class="leer">Wird geladen …</p></div>';
    let daten = [];
    const zeig = () => { const q = verlaufStand.such.toLowerCase(); $('#vl').innerHTML = verlaufTabelle(daten.filter((x) => !q || ((x.bezeichnung || '') + ' ' + (x.wer || '') + ' ' + JSON.stringify(x.aenderung || {})).toLowerCase().includes(q))); };
    const laden = () => HF.verlauf({ tabelle: verlaufStand.tabelle, limit: 400 }).then((l) => { daten = l; zeig(); }).catch((e) => { $('#vl').innerHTML = '<p class="hinweis warn">' + esc(e.message) + '</p>'; });
    $('#vt').addEventListener('change', (e) => { verlaufStand.tabelle = e.target.value; laden(); });
    $('#vs').addEventListener('input', (e) => { verlaufStand.such = e.target.value; zeig(); });
    laden();
  };
  function verlaufDialog(tabelle, id, name) {
    const el = modal('<h2>Verlauf: ' + esc(name || '') + '</h2><div id="vd"><p class="leer">Wird geladen …</p></div><div class="modal-fuss"><button class="btn" data-zu>Schließen</button></div>', true);
    Promise.all([HF.verlauf({ tabelle, datensatz: id, limit: 100 }), tabelle === 'mitglieder' ? HF.verlauf({ tabelle: 'mitglieder_bank', datensatz: id, limit: 50 }) : Promise.resolve([])])
      .then(([a, b]) => { $('#vd', el).innerHTML = verlaufTabelle(a.concat(b).sort((x, y) => String(y.zeit).localeCompare(String(x.zeit)))); })
      .catch((e) => { $('#vd', el).innerHTML = '<p class="hinweis warn">' + esc(e.message) + '</p>'; });
  }

  /* ============================================================ Navigation */
  function zahlenJe() {
    const z = { gaeste: d.gaeste.filter((g) => g.status === 'angemeldet').length, antraege: (d.antraege || []).filter((a) => a.status === 'neu').length,
      arbeitsdienst: d.arbeitsdienst.filter((a) => a.status === 'eingereicht').length };
    Object.keys(z).forEach((t) => { if (!darf(t)) z[t] = 0; }); return z;
  }
  /* ============================================================ Schriftgröße
   * „Schrift größer“ gilt für dieses Gerät (localStorage) – auch in Mein SSV und der Getränkekasse (gleicher Schlüssel). */
  const SCHRIFT = 'ssv-schrift-gross';
  const schriftGross = () => { try { return localStorage.getItem(SCHRIFT) === '1'; } catch (e) { return false; } };
  const schriftSetzen = (an) => { try { localStorage.setItem(SCHRIFT, an ? '1' : '0'); } catch (e) { /* egal */ } document.documentElement.classList.toggle('schrift-gross', an); };
  document.documentElement.classList.toggle('schrift-gross', schriftGross());
  document.addEventListener('click', (e) => { if (!e.target.closest('#schrift')) return; schriftSetzen(!schriftGross()); nav(); toast(schriftGross() ? 'Schrift ist jetzt größer.' : 'Schrift ist wieder normal.'); });

  /* ============================================================ Suche „Was suchen Sie?“
   * Findet Aufgaben („Lastschrift einziehen“), Seiten, Hilfe-Antworten und Datensätze (Mitglieder, Boote, Plätze,
   * Rechnungen, Gäste, Veranstaltungen, Schäden). Groß-/Kleinschreibung, Umlaute und kleine Tippfehler sind egal. */
  const norm = (s) => String(s || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/[^a-z0-9]+/g, ' ').trim();
  const abstand = (a2, b2) => {   // Levenshtein, früh abbrechen ab 2
    if (Math.abs(a2.length - b2.length) > 1) return 2; const v = Array.from({ length: b2.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a2.length; i++) { let prev = v[0]; v[0] = i; let min = v[0];
      for (let j = 1; j <= b2.length; j++) { const t = v[j]; v[j] = Math.min(v[j] + 1, v[j - 1] + 1, prev + (a2[i - 1] === b2[j - 1] ? 0 : 1)); prev = t; min = Math.min(min, v[j]); }
      if (min > 1) return 2; }
    return v[b2.length]; };
  // Punktzahl eines Eintrags für die Suchwörter (0 = passt nicht); Titelwörter zählen mehr als Stichwörter
  function trefferWert(q, titel, mehr) {
    const tw = norm(titel).split(' '), mw = norm(mehr).split(' ').filter(Boolean); let summe = 0;
    for (const w of q) {
      let best = 0;
      const pruefe = (liste, faktor) => liste.forEach((x) => { const s2 = x === w ? 10 : x.startsWith(w) ? 7 : (w.length >= 3 && x.includes(w)) ? 4 : (w.length >= 4 && x.length >= 4 && abstand(w, x.slice(0, w.length + 1)) <= 1) ? 3 : 0; if (s2 * faktor > best) best = s2 * faktor; });
      pruefe(tw, 1.5); pruefe(mw, 1);
      if (!best) return 0; summe += best;
    }
    return summe;
  }
  // Aufgaben: was man tun will – mit Wörtern, die Leute dafür benutzen
  const AUFGABEN = [
    ['Neues Mitglied anlegen', 'mitglied person neu anlegen aufnehmen eintragen hinzufuegen', 'eigner', '#neu'],
    ['Mitglieder importieren (Excel/CSV)', 'import excel csv liste einlesen easyverein mitgliederliste', 'eigner', '#import'],
    ['Aufnahmeanträge bearbeiten', 'antrag aufnahme beitritt neue mitglieder bewerbung', 'antraege'],
    ['Boot anmelden', 'boot schiff neu anmelden eintragen yacht', 'boote', '#neu'],
    ['Gastlieger einweisen', 'gast gastlieger gastboot einweisen ankunft besucher', 'gaeste', '#neu'],
    ['Freie Plätze auf der Karte sehen (Zeitraum)', 'frei freie plaetze karte boje gruen rot zeitraum naechte anreise wann wo liegt belegungskarte', 'gastkarte'],
    ['Belegungskalender öffnen', 'kalender zeitleiste wer liegt wann wo belegung tage wochen gast gruenes schild uebersicht', 'gastkarte'],
    ['Grünes Schild eintragen', 'gruenes schild abwesenheit abwesend unterwegs platz frei urlaub toern melden', 'abwesenheiten', '#neu'],
    ['Hafenplan ansehen', 'hafenplan karte plan steg bruecke luftbild liegeplatz belegung', 'plan'],
    ['Liegeplatz vergeben (Belegung)', 'liegeplatz vergeben belegung zuweisen box platz sommer winter', 'belegung'],
    ['Warteliste ansehen', 'warteliste warten liegeplatz anspruch', 'warteliste'],
    ['Kran-Einsatz eintragen', 'kran kranen einsatz schiffskran mastenkran slippen mast stunde', 'lagern', '#kran'],
    ['Saisontermine Ein-/Auslagern ansehen', 'termin termine saison einlagern auslagern winterlager kran datum wann', 'lagern'],
    ['Belegungsplan Winterlager drucken', 'belegungsplan winterlager drucken liste einlagern auslagern kranliste lagerplatz', 'belegung', '#bel-druck'],
    ['Arbeitsstunden erfassen', 'arbeitsdienst stunden arbeitsstunden erfassen bestaetigen', 'arbeitsdienst', '#neu'],
    ['Wem fehlen noch Arbeitsstunden?', 'arbeitsdienst stundenstand fehlstunden fehlen soll rueckstand offen', 'arbeitsdienst'],
    ['Arbeitsgruppen und Aufgabenliste', 'arbeitsgruppe gruppe aufgabe aufgabenliste einkaufsliste team', 'arbeitsbereiche'],
    ['Schaden oder Wartung melden', 'schaden kaputt wartung reparatur defekt melden', 'aufgaben', '#neu'],
    ['Mitteilung an alle Mitglieder', 'mitteilung nachricht info rundschreiben sturmwarnung push benachrichtigung', 'mitteilungen', '#neu'],
    ['Veranstaltung anlegen / einladen', 'veranstaltung termin fest feier einladen einladung wintertreffen jhv versammlung ansegeln', 'veranstaltungen', '#neu'],
    ['Rechnungen erstellen (Beitrag, Sommer, Winter)', 'rechnung rechnungen erstellen abrechnen abrechnung beitrag winterlager sommer gebuehren', 'abrechnung'],
    ['Lastschrift einziehen', 'lastschrift einziehen einzug sepa bank datei abbuchen', 'abrechnung'],
    ['Veranstaltungskosten abrechnen', 'veranstaltung kosten abrechnen rechnung essen gruenkohl teilnehmer', 'abrechnung', '[data-per=veranstaltung]'],
    ['Zahlung von Hand buchen', 'zahlung buchen bezahlt eingang ueberweisung teilzahlung bar', 'rechnungen'],
    ['Offene Rechnungen ansehen', 'offen offene rechnungen posten unbezahlt ueberfaellig mahnen liste rechnungsliste', 'rechnungen'],
    ['Offene Posten drucken', 'offene posten drucken liste ausdruck unbezahlt', 'rechnungen', '#re-druck'],
    ['Kontoauszug abgleichen', 'kontoauszug bank umsaetze abgleich zahlungseingang camt csv onlinebanking', 'kontoauszug'],
    ['Gutschrift der Lastschrift buchen', 'gutschrift lastschrift sepa eingegangen bank sammellastschrift', 'kontoauszug', '#ze-lastschrift'],
    ['Gemeldete Gast-Zahlung bestätigen', 'gast zahlung gemeldet bestaetigen eingegangen paypal gastlieger hafengeld', 'kontoauszug', '#ze-gaeste'],
    ['Rechnungen per E-Mail senden', 'rechnung email mail senden verschicken zustellen versand', 'abrechnung'],
    ['Finanzen im Überblick', 'finanzen geld einnahmen offen ueberblick getraenke kasse summe monat eingang', 'finanzen'],
    ['Monatsbericht drucken', 'monatsbericht monat bericht drucken einnahmen eingaenge', 'finanzen', '#fin-druck'],
    ['Unterlagen für die Kassenprüfung', 'kassenpruefung kassenpruefer kassenbericht jahresabschluss jhv jahr eingaenge csv', 'finanzen', '#fin-jahr-knopf'],
    ['Hafengeld nach Monat oder Saison', 'hafengeld liegegebuehr gastlieger gaeste einnahmen bar monat saison naechte', 'hafengeld'],
    ['Gästeliste drucken (Hafengeld)', 'gaesteliste gastlieger liste drucken bar kasse hafengeld', 'hafengeld', '#hg-druck'],
    ['Gebührenordnung ansehen oder ändern', 'gebuehrenordnung preise gebuehren beitrag hoehe aendern neue fassung', 'gebuehren'],
    ['Verbandsmeldung (Bestandserhebung)', 'verband meldung bestandserhebung statistik landessportverband mitgliederzahl jahresmeldung', 'verband'],
    ['Einstellungen (Verein, Bank, Kran)', 'einstellungen bank iban glaeubiger kran gewicht verein adresse paypal', 'einstellungen'],
    ['Änderungen nachverfolgen (Verlauf)', 'verlauf aenderung wer hat protokoll historie', 'verlauf'],
    ['Datensicherung herunterladen', 'sicherung backup datensicherung export', 'einstellungen', '#sicherung-panel'],
    ['Anfahrt zum Hafen (Google Maps, Apple Karten)', 'anfahrt route navigation adresse weg google maps apple karten', 'plan', '.anfahrt']
  ];
  // Kurze Hilfe in Schritten (auch über die Suche erreichbar)
  const HILFE = [
    ['Wie ziehe ich die Beiträge per Lastschrift ein?', 'lastschrift beitrag einziehen sepa', 'abrechnung', ['Finanzen → „Abrechnen“ öffnen.', 'Oben „Beitrag …“ wählen. Schritt 1 „Prüfen“ zeigt, ob alles da ist – dann „Weiter“.', '„Rechnungen erstellen“ drücken – die Mitglieder sehen sie sofort in „Mein SSV“.', 'Schritt 4 „Lastschrift“: die Datei erzeugen und im Online-Banking hochladen.', 'Kommt das Geld an: Kontoauszug einlesen – fertig.']],
    ['Wie trage ich ein neues Mitglied ein?', 'mitglied neu aufnehmen', 'eigner', ['Im Menü „Mitglieder“ (bzw. „Mitglieder & Boote“) wählen, dann den Reiter „Mitglieder“.', 'Oben rechts „+ Person“.', 'Name, Anschrift und Mitgliedsart eintragen, für die Lastschrift auch IBAN und Mandat.', '„Speichern“.']],
    ['Wie weise ich einen Gast ein?', 'gast einweisen gastlieger', 'gaeste', ['Gäste & grünes Schild → „Gastlieger“.', '„+ Gast einweisen“ drücken.', 'Bootsname, Länge und Nächte eintragen – das Programm schlägt freie Plätze vor.', 'Platz wählen und speichern. Bezahlt der Gast, „Eingang bestätigen“.']],
    ['Wie sehe ich, welche Plätze für Gäste frei sind?', 'frei freie plaetze gast karte boje gruen rot kalender zeitraum', 'gastkarte', ['Gäste & grünes Schild → „Karte & Kalender“.', 'Anreise und Nächte wählen.', 'Grüne Boje = im ganzen Zeitraum frei, rote Boje = belegt.', 'Platz antippen und „Gast hier eintragen“ – oder oben „Kalender“ für die Übersicht über mehrere Wochen.']],
    ['Wie verschiebe ich eine einzelne Box oder einen Lagerplatz?', 'box lagerplatz verschieben groesse aendern loeschen hinzufuegen lageplan einzeln winterlager palette', 'plan', ['Hafen → „Hafenplan“ → oben „Plan ▾“ → „Lageplan bearbeiten …“.', 'Die Box oder den Lagerplatz antippen – er wird orange.', 'Ziehen verschiebt. An den zwei Punkten ziehen ändert Breite und Tiefe; rechts kannst du die Maße in Metern eintragen.', '„Löschen“ entfernt den Platz, „Lagerplatz“ oder „Einzelbox“ oben setzt einen neuen.', '„Speichern“ – oder „Als Planung sichern“, wenn es erst ein Entwurf ist.']],
    ['Wie plane ich den Hafen für nächstes Jahr?', 'planung naechstes jahr entwurf umstellen umbauen saison plan variante', 'plan', ['Hafen → „Hafenplan“.', 'Oben „Plan ▾“ → „+ Neue Planung …“ wählen und einen Namen geben.', 'Im Zeichenfenster umstellen und „Planung speichern“. Der gültige Plan bleibt, wie er ist.', 'Wenn es so weit ist: unter „Plan ▾“ die Planung wählen und „Gültig schalten“.']],
    ['Wie zeige ich einen Ausschnitt, das Luftbild oder die Abendstimmung?', 'ausschnitt ostbruecke westbruecke schwimmbruecke land lager naeher zoomen luftbild satellit foto abend abendstimmung nacht ansicht', 'plan', ['Hafen → „Hafenplan“.', '„Ausschnitt“ wählt Ganzer Hafen, Ostbrücke, Westbrücke, Schwimmbrücke oder die Lagerflächen an Land.', '„Ansicht ▾“ schaltet Luftbild oder Abendstimmung ein und aus.', 'Am Handy mit zwei Fingern zoomen, am PC mit dem Mausrad; ⤢ zeigt wieder den ganzen Hafen.']],
    ['Wie drucke ich den Hafenplan?', 'plan drucken ausdrucken pdf belegungsliste aushang', 'plan', ['Hafen → „Hafenplan“ → oben „Plan ▾“ → „Plan drucken …“ (wer kein Plan-Menü hat: „Drucken“).', 'Sommer, Winterlager oder nur den Plan wählen, dazu Ausschnitt und Papier.', '„Drucken“ – im Druckfenster geht auch „Als PDF sichern“.']],
    ['Was bedeutet das grüne Schild?', 'gruenes schild abwesenheit', 'abwesenheiten', ['Ein Mitglied ist mit dem Boot unterwegs – der Platz ist frei für Gäste.', 'Mitglieder melden das selbst in „Mein SSV“, der Hafenmeister sieht es im Hafenplan grün.', 'Kommt das Mitglied früher zurück, drückt es in „Mein SSV“ auf „Früher zurück“ – dann ist der Platz wieder belegt.']],
    ['Wie gleiche ich den Kontoauszug ab?', 'kontoauszug abgleich bank', 'kontoauszug', ['Im Online-Banking die Umsätze exportieren (CAMT oder CSV).', 'Finanzen → „Zahlungseingang“ öffnen und die Datei hineinziehen.', 'Grün markierte Zuordnungen sind sicher – Häkchen lassen. Gelbe Vorschläge prüfen.', '„Buchen“ drücken. Was übrig bleibt, steht auf der Klärliste.']],
    ['Was ist diesen Monat eingegangen?', 'monat eingegangen einnahmen eingaenge offen zu tun bar', 'finanzen', ['Finanzen → „Auf einen Blick“ öffnen, oben „Monat“.', 'Mit ◀ ▶ den Monat wählen: Eingegangen, davon bar, offen, zu klären.', '„Eingänge nach Bereich“ vergleicht mit Vormonat und Vorjahresmonat.', '„Monatsbericht drucken“ für die Unterlagen.']],
    ['Was gebe ich den Kassenprüfern?', 'kassenpruefung kassenpruefer kassenbericht jahr jhv', 'finanzen', ['Finanzen → „Auf einen Blick“, oben „Jahr“ und das Geschäftsjahr wählen.', '„Unterlagen Kassenprüfung“ drücken.', 'Bericht als PDF (im Briefkopf) und alle Eingänge als CSV – mit Rechnungsnummer und Beleg.', 'Ausgaben und Bankbestand stehen nicht darin – die kommen aus dem Online-Banking.']],
    ['Wie buche ich eine Zahlung von Hand?', 'zahlung buchen bar ueberweisung teilzahlung von hand', 'rechnungen', ['Finanzen → „Rechnungen & Offenes“.', 'Oben suchen (Name, Boot oder Rechnungsnummer).', 'In der Zeile „Zahlung“ drücken, Datum und Betrag prüfen, „Zahlung buchen“.', 'Weniger als offen = Teilzahlung; der Rest bleibt offen.']],
    ['Wie lade ich zu einer Veranstaltung ein?', 'veranstaltung einladen zusage', 'veranstaltungen', ['Mitteilungen & Veranstaltungen → „Veranstaltungen“ → „+ Veranstaltung“.', 'Datum, Anmeldefrist, Plätze und Kosten eintragen, „Einladen“.', 'Die Mitglieder sagen in „Mein SSV“ zu oder ab. Unter „Teilnehmer“ steht, wer kommt.']],
    ['Wie melde ich einen Schaden?', 'schaden melden kaputt', 'aufgaben', ['Arbeitsdienst → „Schäden & Wartung“ → „+ Schaden / Wartung“.', 'Kurz beschreiben, wo und was – ein Foto hilft.', 'Dringlichkeit wählen und speichern. Mitglieder können Schäden auch in „Mein SSV“ melden.']],
    ['Wie bestätige ich Arbeitsstunden?', 'arbeitsstunden bestaetigen arbeitsdienst', 'arbeitsdienst', ['Arbeitsdienst → „Stunden“.', 'Gemeldete Stunden stehen oben. „Bestätigen“ oder „Ablehnen“ drücken.', 'Darunter im „Stundenstand“: „Fehlen noch“ zeigt, wer sein Soll noch nicht erreicht hat.']],
    ['Wo finde ich die Saisontermine und den Kran?', 'kran termine einlagern auslagern saison winterlager', 'lagern', ['Hafen → „Kran & Termine“: Auslagern und Einlagern mit Datum, die Kran-Grenze und die Kran-Einsätze außerhalb der Termine.', 'Wer wo im Winterlager steht: Hafen → „Belegung“ → „Winter“. Dort steht auch „Belegungsplan Winter drucken“.', 'Termine ändern: Verwaltung → „Einstellungen“ → Saisontermine.']],
    ['Wo ist die Verbandsmeldung?', 'verband verbandsmeldung bestandserhebung', 'verband', ['Verwaltung → „Verbandsmeldung“ (einmal im Jahr, Stichtag 1.1.).', 'Die Zahlen stehen fertig da – oben „Drucken“ oder „CSV“ für die Datei.']],
    ['Wie mache ich die Schrift größer?', 'schrift groesser lesen sehen brille zoom', '', ['Links unten „Schrift größer“ drücken (am Handy im Menü).', 'Die Einstellung gilt für dieses Gerät, auch für „Mein SSV“.', 'Außerdem geht immer: Strg und + (am Mac ⌘ und +).']],
    ['Was ist der Unterschied zwischen Übersicht und den Bereichen?', 'uebersicht start anfang was ist zu tun', 'uebersicht', ['Die Übersicht zeigt nur, was heute wichtig ist und was ansteht – mit Pfeil direkt zur richtigen Stelle.', 'In den Bereichen links (z. B. „Mitglieder & Boote“) findet man alles zum Nachschlagen.', 'Oder oben „Suchen“ und einfach eintippen, was man sucht.']]
  ];
  let suchWahl = 0, suchListe = [];
  function suchIndex() {
    const l = [];
    BEREICHE.forEach(([bid, bn, ts]) => ts.forEach(([t, n]) => { if (darf(t)) l.push({ g: 'Seiten', t: n, u: bereichTitel(bid, bn), w: bn + ' ' + n, los: () => zeige(t) }); }));
    AUFGABEN.forEach(([t, w, ziel, klick]) => { if (darf(ziel)) l.push({ g: 'Aufgaben', t, u: '', w, los: () => { zeige(ziel); if (klick) setTimeout(() => { const k = $(klick); if (k) { if (/^(BUTTON|A|INPUT|SELECT|LABEL)$/.test(k.tagName)) k.click(); else k.scrollIntoView({ block: 'start' }); } }, 60); } }); });
    HILFE.forEach(([t, w, ziel, schritte]) => { if (!ziel || darf(ziel)) l.push({ g: 'Hilfe', t, u: 'Kurz erklärt', w, los: () => hilfeZeigen(t, schritte, ziel) }); });
    if (darf('eigner')) d.mitglieder.forEach((m) => l.push({ g: 'Mitglieder', t: m.nachname + ', ' + m.vorname, u: [H.ART[m.art], 'Nr. ' + m.nr, m.ort].filter(Boolean).join(' · '), w: [m.vorname, m.nachname, m.nr, m.ort, m.email, m.tel].join(' '), los: () => { zeige('eigner'); mitgliedAkte(m); } }));
    if (darf('boote')) d.boote.forEach((b) => { const m = Q.mitglied(b.eigner_id); l.push({ g: 'Boote', t: '„' + b.name + '“', u: [b.typ, m && Q.name(m), b.segelnr].filter(Boolean).join(' · '), w: [b.name, b.typ, b.segelnr, m && m.nachname, 'boot'].join(' '), los: () => { zeige('boote'); bootForm(b); } }); });
    if (darf('plan')) d.liegeplaetze.forEach((p) => { const bel = Q.belegungPlatz(SAISON, 'sommer', p.id); const b = bel && Q.boot(bel.boot_id);
      l.push({ g: 'Liegeplätze', t: (p.box === 'L' ? 'Längsseits ' : 'Platz ') + p.nr, u: [H.BRUECKE[p.bruecke], b ? '„' + b.name + '“' : 'frei im Sommer ' + SAISON].filter(Boolean).join(' · '), w: ['platz', 'liegeplatz', p.nr, p.id, H.BRUECKE[p.bruecke], b && b.name].join(' '),
        los: () => { Object.assign(planStand, { markiere: p.id, fokus: true, vb: null, modus: 'sommer', ansicht: 'gesamt' }); zeige('plan'); } }); });
    if (darf('plan')) (d.landplaetze || []).forEach((p) => l.push({ g: 'Liegeplätze', t: Q.platzName(p), u: 'Lagerplatz an Land (Winterlager)', w: ['lagerplatz', 'landplatz', 'winterlager', 'lager', 'palette', p.id, p.bez, Q.lage(p)].join(' '),
      los: () => { Object.assign(planStand, { markiere: p.id, fokus: true, vb: null, modus: 'winter', ansicht: 'land' }); zeige('plan'); } }));
    if (darf('abrechnung')) d.rechnungen.forEach((r) => l.push({ g: 'Rechnungen', t: r.nr, u: [r.empfaenger.vorname + ' ' + r.empfaenger.nachname, H.periodeText(r), H.geld(r.summe), Q.rest(r) > 0 ? 'offen ' + H.geld(Q.rest(r)) : r.storniert_am ? 'storniert' : 'bezahlt'].join(' · '),
      w: ['rechnung', r.nr, r.empfaenger.vorname, r.empfaenger.nachname, H.periodeText(r)].join(' '), los: () => { Object.assign(reStand, { such: r.nr, bereich: '', jahr: '', monat: '', status: '', stufe: '', mehr: false }); zeige('rechnungen'); zahlungDialog(r); } }));
    if (darf('gaeste')) d.gaeste.forEach((g2) => l.push({ g: 'Gäste', t: '„' + g2.bootsname + '“', u: [g2.skipper, H.datum(g2.ankunft), g2.platz_id ? platzName(g2.platz_id) : 'ohne Platz'].filter(Boolean).join(' · '), w: ['gast', g2.bootsname, g2.skipper, g2.herkunft].join(' '), los: () => { zeige('gaeste'); gastForm(g2); } }));
    if (darf('veranstaltungen')) (d.veranstaltungen || []).forEach((v) => l.push({ g: 'Veranstaltungen', t: v.titel, u: H.datum(v.datum) + (v.ort ? ' · ' + v.ort : ''), w: ['veranstaltung', 'termin', v.titel, v.ort].join(' '), los: () => { verAuswahl = v.id; zeige('veranstaltungen'); } }));
    if (darf('aufgaben')) (d.aufgaben || []).filter((x) => x.status !== 'erledigt').forEach((x) => l.push({ g: 'Schäden & Wartung', t: x.titel, u: [x.ort, x.status === 'in_arbeit' ? 'in Arbeit' : 'offen'].filter(Boolean).join(' · '), w: ['schaden', 'wartung', x.titel, x.ort, x.beschreibung].join(' '), los: () => { zeige('aufgaben'); aufgabeForm(x); } }));
    if (darf('arbeitsbereiche')) (d.arbeitsbereiche || []).forEach((b) => l.push({ g: 'Arbeitsgruppen', t: b.name, u: 'Arbeitsgruppe', w: ['gruppe', 'arbeitsgruppe', b.name, b.beschreibung].join(' '), los: () => zeige('arbeitsbereiche') }));
    return l;
  }
  const GRUPPEN = ['Aufgaben', 'Hilfe', 'Seiten', 'Mitglieder', 'Boote', 'Liegeplätze', 'Rechnungen', 'Gäste', 'Veranstaltungen', 'Schäden & Wartung', 'Arbeitsgruppen'];
  const OFT = { vorstand: ['Neues Mitglied anlegen', 'Rechnungen erstellen (Beitrag, Sommer, Winter)', 'Kontoauszug abgleichen', 'Mitteilung an alle Mitglieder', 'Veranstaltung anlegen / einladen'],
    kassenwart: ['Rechnungen erstellen (Beitrag, Sommer, Winter)', 'Lastschrift einziehen', 'Kontoauszug abgleichen', 'Offene Rechnungen ansehen', 'Zahlung von Hand buchen'],
    hafenmeister: ['Gastlieger einweisen', 'Hafenplan ansehen', 'Grünes Schild eintragen', 'Schaden oder Wartung melden', 'Kran-Einsatz eintragen'],
    brueckenwart: ['Hafenplan ansehen', 'Liegeplatz vergeben (Belegung)', 'Warteliste ansehen', 'Boot anmelden', 'Gastlieger einweisen'] };
  function sucheOeffnen(start) {
    const idx = suchIndex();
    const el = modal('<h2 class="such-titel">Was suchen Sie?</h2><div class="such-feld"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>' +
      '<input id="such-ein" type="search" autocomplete="off" spellcheck="false" placeholder="z. B. Nachname, Bootsname, Platz 12, Rechnung, Lastschrift" aria-label="Suchbegriff" aria-controls="such-erg"></div>' +
      '<div id="such-erg" class="such-erg" role="listbox" aria-label="Suchergebnisse"></div>', true);
    el.querySelector('.modal-karte').classList.add('such-karte');
    const ein = $('#such-ein', el), erg = $('#such-erg', el);
    const zeigen = () => {
      const q = norm(ein.value).split(' ').filter(Boolean);
      if (!q.length) {
        const oft = (OFT[rolle] || OFT.vorstand).map((t) => idx.find((x) => x.g === 'Aufgaben' && x.t === t)).filter(Boolean);
        suchListe = oft.concat(idx.filter((x) => x.g === 'Hilfe').slice(0, 4));
        erg.innerHTML = '<p class="such-tipp">Tippen Sie einfach ein, was Sie suchen oder tun möchten – einen Namen, ein Boot, eine Platznummer, eine Rechnungsnummer oder eine Aufgabe wie „Lastschrift“.</p>' +
          '<h3>Häufig gebraucht</h3>' + oft.map((x, i) => zeile(x, i)).join('') + '<h3>Kurz erklärt</h3>' + suchListe.slice(oft.length).map((x, i) => zeile(x, oft.length + i)).join('');
      } else {
        const tr = idx.map((x) => ({ x, s: trefferWert(q, x.t, x.w + ' ' + x.u) })).filter((y) => y.s > 0).sort((a2, b2) => b2.s - a2.s);
        const je = {}; tr.forEach(({ x }) => { (je[x.g] = je[x.g] || []).push(x); });
        const reihe = GRUPPEN.filter((g) => je[g]).sort((a2, b2) => (tr.findIndex((y) => y.x.g === a2)) - (tr.findIndex((y) => y.x.g === b2)));
        suchListe = []; reihe.forEach((g) => { suchListe.push(...je[g].slice(0, g === 'Seiten' ? 3 : 6)); });
        let i = 0;
        erg.innerHTML = suchListe.length ? reihe.map((g) => '<h3>' + g + (je[g].length > 6 ? ' <small>(' + je[g].length + ', die ersten 6)</small>' : '') + '</h3>' + je[g].slice(0, g === 'Seiten' ? 3 : 6).map((x) => zeile(x, i++)).join('')).join('')
          : '<p class="such-tipp"><strong>Nichts gefunden zu „' + esc(ein.value) + '“.</strong><br>Versuchen Sie ein anderes Wort – zum Beispiel nur den Nachnamen, den Bootsnamen oder eine Nummer.</p>';
      }
      suchWahl = 0; markieren();
    };
    const zeile = (x, i) => '<button type="button" class="such-zeile" role="option" data-i="' + i + '"><span class="such-t">' + esc(x.t) + '</span>' + (x.u ? '<span class="such-u">' + esc(x.u) + '</span>' : '') + '<span class="such-pfeil" aria-hidden="true">→</span></button>';
    const markieren = () => erg.querySelectorAll('.such-zeile').forEach((b2) => { const an = Number(b2.dataset.i) === suchWahl; b2.classList.toggle('gewaehlt', an); b2.setAttribute('aria-selected', an); if (an) b2.scrollIntoView({ block: 'nearest' }); });
    const los = (i) => { const x = suchListe[i]; if (!x) return; zu(); x.los(); };
    ein.addEventListener('input', zeigen);
    ein.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); suchWahl = Math.min(suchListe.length - 1, suchWahl + 1); markieren(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); suchWahl = Math.max(0, suchWahl - 1); markieren(); }
      else if (e.key === 'Enter') { e.preventDefault(); los(suchWahl); }
    });
    erg.addEventListener('click', (e) => { const b2 = e.target.closest('.such-zeile'); if (b2) los(Number(b2.dataset.i)); });
    if (start) ein.value = start;
    zeigen(); setTimeout(() => ein.focus(), 40);
  }
  function hilfeZeigen(titel, schritte, ziel) {
    const el = modal('<h2>' + esc(titel) + '</h2><ol class="hilfe-schritte">' + schritte.map((s2) => '<li>' + esc(s2) + '</li>').join('') + '</ol>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Schließen</button>' + (ziel && darf(ziel) ? '<button class="btn primaer" id="hilfe-hin">Dorthin</button>' : '') + '</div>');
    const h2 = $('#hilfe-hin', el); if (h2) h2.addEventListener('click', () => { zu(); zeige(ziel); });
  }
  document.addEventListener('click', (e) => { if (e.target.closest('[data-suche]')) { e.preventDefault(); sucheOeffnen(); } });
  document.addEventListener('keydown', (e) => {
    if (!rolle) return;
    const tipp = e.target && /^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName);
    if ((e.key === 'k' && (e.ctrlKey || e.metaKey)) || (e.key === '/' && !tipp && !$('#modal').firstChild)) { e.preventDefault(); if (!$('#such-ein')) sucheOeffnen(); }
  });

  function nav() {
    const z = zahlenJe(); const aktB = bereichVon(tab);
    const sichtbar = BEREICHE.map(([id, n, ts]) => [id, bereichTitel(id, n), ts.filter(([t]) => darf(t))]).filter(([, , ts]) => ts.length);
    const summe = (ts) => ts.reduce((s, [t]) => s + (z[t] || 0), 0);
    const gesamt = sichtbar.reduce((s, [, , ts]) => s + summe(ts), 0);
    const aktName = (sichtbar.find(([id]) => id === aktB) || [, 'Übersicht'])[1];
    $('#nav').classList.remove('offen'); document.body.classList.remove('nav-auf');
    $('#nav').innerHTML = '<div class="nav-leiste"><svg class="stander"><use href="#stander"/></svg><strong>' + aktName + '</strong>' +
      '<button class="such-knopf-m" data-suche aria-label="Suchen"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><span>Suchen</span></button><button id="navauf" aria-expanded="false" aria-controls="nav-inhalt">Menü' + (gesamt ? '<span class="zahl">' + gesamt + '</span>' : '') + '</button></div><div class="nav-inhalt" id="nav-inhalt">' +
      '<div class="marke"><svg class="stander"><use href="#stander"/></svg><div><strong>Hafen-Manager</strong><span>SSV · Teerhofinsel</span></div></div>' +
      '<div class="rolle-chip">Angemeldet als <strong>' + ROLLEN[rolle].name + '</strong><label class="saison-wahl">Saison <select id="saison-wahl">' +
        [SAISON - 1, SAISON, SAISON + 1].map((j) => '<option' + (j === SAISON ? ' selected' : '') + '>' + j + '</option>').join('') + '</select></label></div>' +
      '<button class="such-knopf" data-suche><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg><span>Suchen …</span><kbd>Strg K</kbd></button>' +
      '<div class="nav-bereiche">' + sichtbar.map(([id, n, ts]) => { const ziel = zuletzt[id] && darf(zuletzt[id]) ? zuletzt[id] : ts[0][0]; const s = summe(ts);
        return '<button data-tab="' + ziel + '" data-bereich="' + id + '" data-tabs="' + ts.map(([t]) => t).join(' ') + '" class="' + (id === aktB ? 'aktiv' : '') + '"' + (id === aktB ? ' aria-current="page"' : '') + '>' +
          '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[id] + '</svg><span>' + n + '</span>' + (s ? '<span class="zahl">' + s + '</span>' : '') + '</button>'; }).join('') + '</div>' +
      '<div class="nav-unten"><button id="schrift" aria-pressed="' + schriftGross() + '">' + (schriftGross() ? 'Schrift normal' : 'Schrift größer') + '</button><a href="mein-ssv.html" target="_blank">Mein SSV (Mitglieder) ↗</a><button id="abmelden">' + (DB ? 'Abmelden' : 'Rolle wechseln') + '</button></div></div>';
  }
  // Reiter des aktuellen Bereichs über dem Seiteninhalt
  function unterNav() {
    const b = BEREICHE.find(([id]) => id === bereichVon(tab)); const ts = b[2].filter(([t]) => darf(t)); if (ts.length < 2) return '';
    const z = zahlenJe();
    const bn = bereichTitel(b[0], b[1]);
    return '<nav class="reiter" aria-label="' + bn + '"><span class="reiter-titel">' + bn + '</span><div class="reiter-liste">' + ts.map(([t, n]) => '<button data-tab="' + t + '" class="' + (t === tab ? 'aktiv' : '') + '"' + (t === tab ? ' aria-current="page"' : '') + '>' + n + (z[t] ? '<span class="zahl">' + z[t] + '</span>' : '') + '</button>').join('') + '</div></nav>';
  }
  // Schwebender Knopf (nur am Handy) – [Text, Aktion, Zielreiter, Reiter, auf denen er erscheint].
  // Nur auf der Übersicht und im Zielbereich, damit er auf Formularen, Tabellen und Prüflisten nichts verdeckt.
  const SCHNELL = {
    hafenmeister: ['+ Gast einweisen', () => gastForm({}), 'gaeste', ['uebersicht', 'gaeste', 'gastkarte']],
    brueckenwart: ['+ Stunden erfassen', () => { zeige('arbeitsdienst'); $('#neu').click(); }, 'arbeitsdienst', ['uebersicht', 'arbeitsdienst']],
    vorstand: ['+ Mitteilung', () => { zeige('mitteilungen'); $('#neu').click(); }, 'mitteilungen', ['uebersicht', 'mitteilungen']]
  };
  function schnellknopf() {
    let k = $('#schnell'); const s = rolle && SCHNELL[rolle];
    const da = !!(s && s[3].includes(tab) && !(tab === 'plaetze' && masseModus));
    document.body.classList.toggle('schnell-doppelt', !!(s && s[2] === tab));   // Hauptknopf oben nicht doppelt zeigen
    document.body.classList.toggle('mit-schnell', da);                          // unten Platz freihalten, damit der Knopf nichts verdeckt
    if (!da) { if (k) k.remove(); return; }
    if (!k) { k = document.createElement('button'); k.id = 'schnell'; k.className = 'schnell'; k.type = 'button'; document.body.appendChild(k); k.addEventListener('click', () => SCHNELL[rolle] && SCHNELL[rolle][1]()); }
    k.textContent = s[0];
  }
  /* Weniger auf einmal: lange Erklärtexte stehen hinter „Erklärung anzeigen“, lange Untertitel zeigen erst den ersten Satz.
   * Warnungen, Fehler und Hinweise mit Knöpfen oder Eingaben bleiben immer sichtbar. */
  function einklappen(root) {
    if (!root) return;
    root.querySelectorAll('.hinweis').forEach((h) => {
      if (h.closest('details.erklaer, .modal, .demo-band') || /\b(warn|ok|fehler|stichtag|offen)\b/.test(h.className)) return;
      if (h.querySelector('button, input, select, textarea, form') || h.textContent.trim().length < 170) return;
      const det = document.createElement('details'); det.className = 'erklaer' + (h.classList.contains('voll') ? ' voll' : '');
      det.innerHTML = '<summary>Erklärung anzeigen</summary>'; h.replaceWith(det); det.appendChild(h);
      det.addEventListener('toggle', () => { det.firstChild.textContent = det.open ? 'Erklärung ausblenden' : 'Erklärung anzeigen'; });
    });
    const p = root.querySelector('.kopf > div > p');
    if (p && !p.children.length && p.textContent.length > 120) {
      const voll = p.textContent; const m = voll.match(/^(.{30,110}?[.!?])\s/) || voll.match(/^(.{30,110}?)\s·\s/);
      if (m) { p.textContent = m[1] + ' '; const k = document.createElement('button'); k.type = 'button'; k.className = 'kopf-mehr'; k.textContent = 'mehr'; k.setAttribute('aria-label', 'Ganzen Text zeigen');
        k.addEventListener('click', () => { p.textContent = voll; }); p.appendChild(k); }
    }
  }
  // Sprungziele mit Filter: data-re-filter/-bereich/-jahr → „Rechnungen & Offenes“ vorgefiltert, data-abr-per → Zeitraum in „Abrechnen“
  function sprungFilter(el) { const x = el.dataset;
    if (x.reFilter != null || x.reBereich != null) Object.assign(reStand, { status: x.reFilter || '', bereich: x.reBereich || '', jahr: x.reJahr || '', monat: '', stufe: '', such: '', mehr: false });
    if (x.abrPer) abrStand.periode = x.abrPer; }
  function zeige(t, ruhig) {
    if (!darf(t)) t = 'uebersicht';
    document.body.classList.remove('plan-vollbild'); if (t !== 'plan') planStand.voll = false;
    if (t !== 'veranstaltungen') verAuswahl = null;
    const y = window.scrollY; const vorher = tab; tab = t; zuletzt[bereichVon(t)] = t; nav(); V[t]($('#main')); einklappen($('#main'));
    const r = unterNav(); if (r) { $('#main').insertAdjacentHTML('afterbegin', r);
      // gewählten Reiter ins Bild rollen (scrollLeft statt scrollIntoView, damit die Seite nicht senkrecht springt)
      const rl = $('#main .reiter-liste'), ra = rl && rl.querySelector('.aktiv'); if (ra && rl.scrollWidth > rl.clientWidth) rl.scrollLeft = ra.offsetLeft - rl.offsetLeft - (rl.clientWidth - ra.offsetWidth) / 2; }
    window.scrollTo(0, ruhig ? y : 0); schnellknopf();
    if (sprung) { const z = $('#main').querySelector(sprung); sprung = null;
      const geschlossen = z && z.closest('details:not([open])'); if (geschlossen) geschlossen.open = true;   // Ziel in einem zugeklappten Abschnitt (z. B. Einstellungen): erst aufklappen
      if (z && z.type === 'checkbox') { if (!z.checked) { z.checked = true; z.dispatchEvent(new Event('change', { bubbles: true })); } }
      else if (z) { z.scrollIntoView({ block: 'center' }); z.focus({ preventScroll: true }); } }
    // neuer Bereich/Reiter → eigener Verlaufseintrag, damit die Zurück-Taste funktioniert
    try { if (location.hash.slice(1) !== t) history[!ruhig && vorher && vorher !== t ? 'pushState' : 'replaceState'](null, '', '#' + t); } catch (e) { /* egal */ }
  }
  // Zeilen-Menüs (⋯): fest positioniert, damit sie nicht im Panel abgeschnitten werden
  const zmLegen = (zk, l) => { const r = zk.getBoundingClientRect(); const w = l.offsetWidth, h = l.offsetHeight;
    l.style.left = Math.max(8, Math.min(r.right - w, innerWidth - w - 8)) + 'px'; l.style.top = (r.bottom + 4 + h > innerHeight ? Math.max(8, r.top - h - 4) : r.bottom + 4) + 'px'; };
  const zuMenues = () => document.querySelectorAll('.zm-liste:not([hidden])').forEach((l) => { l.hidden = true; const k = l.previousElementSibling; if (k) k.setAttribute('aria-expanded', 'false'); });
  document.addEventListener('click', (e) => {
    const zk = e.target.closest('.zm-knopf');
    if (zk) { const l = zk.nextElementSibling; const war = !l.hidden; zuMenues(); if (!war) { l.hidden = false; zk.setAttribute('aria-expanded', 'true'); zmLegen(zk, l);
      const erst = l.querySelector('button'); if (erst && e.detail === 0) erst.focus(); } return; }
    if (e.target.closest('.zm-liste')) setTimeout(zuMenues, 0); else zuMenues();
  });
  // Beim Scrollen folgt das Menü seinem Knopf; ist der Knopf nicht mehr zu sehen, geht es zu
  window.addEventListener('scroll', () => document.querySelectorAll('.zm-liste:not([hidden])').forEach((l) => { const k = l.previousElementSibling; const r = k.getBoundingClientRect();
    if (r.bottom < 0 || r.top > innerHeight) zuMenues(); else zmLegen(k, l); }), true);
  window.addEventListener('resize', zuMenues);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && document.querySelector('.zm-liste:not([hidden])')) { e.stopPropagation(); zuMenues(); } }, true);
  document.addEventListener('click', (e) => {
    const auf = e.target.closest('#navauf');
    if (auf) { const nv = $('#nav'); const o = nv.classList.toggle('offen'); auf.setAttribute('aria-expanded', o); document.body.classList.toggle('nav-auf', o); return; }
    const n = e.target.closest('#nav [data-tab], .reiter [data-tab]'); if (n) return zeige(n.dataset.tab);
    const g = e.target.closest('[data-gehe]'); if (g && darf(g.dataset.gehe)) { sprungFilter(g); return zeige(g.dataset.gehe); }
    if (e.target.closest('#abmelden') && DB) { try { sessionStorage.removeItem('ssv-hafen-rolle'); } catch (x) { /* egal */ } window.SSV_SB.abmelden().then(() => location.reload()); return; }
    if (e.target.closest('#abmelden')) { rolle = null; masseModus = false; try { sessionStorage.removeItem('ssv-hafen-rolle'); } catch (x) { /* egal */ } schnellknopf(); start(); }
  });
  // Zurück-Taste des Browsers und Links mit #bereich
  window.addEventListener('hashchange', () => { const t = location.hash.slice(1); if (rolle && V[t] && t !== tab && !$('#modal').firstChild) zeige(t); });
  document.addEventListener('change', (e) => {
    if (e.target.id !== 'saison-wahl') return;
    const u = new URL(location.href); u.searchParams.set('saison', e.target.value); location.href = u.toString();
  });
  // Vereinsdatenbank: nach 30 Minuten ohne Eingabe abmelden (Bankdaten nicht offen am Rechner lassen)
  if (DB) { let ruhe; const neu = () => { clearTimeout(ruhe); ruhe = setTimeout(() => { window.SSV_SB.abmelden().then(() => location.reload()); }, 30 * 60e3); };
    ['pointerdown', 'keydown'].forEach((ev) => document.addEventListener(ev, neu, { passive: true })); neu(); }
  if ($('#rollen')) $('#rollen').addEventListener('click', (e) => { const b = e.target.closest('[data-rolle]'); if (!b) return; rolle = b.dataset.rolle; try { sessionStorage.setItem('ssv-hafen-rolle', rolle); } catch (x) { /* egal */ } start(); });

  // Demo: Änderungen aus anderen Fenstern (QR-Gastanmeldung, Mein SSV) sofort übernehmen,
  // damit beim nächsten Speichern nichts überschrieben wird
  window.addEventListener('storage', (e) => { if (e.key === 'ssv-hafen-demo-v1') { d = HF.laden(); if (rolle) zeige(tab); } });

  function start() {
    try { rolle = rolle || sessionStorage.getItem('ssv-hafen-rolle'); } catch (e) { /* egal */ }
    $('#login').hidden = !!rolle; $('#app').hidden = !rolle;
    if (!rolle) return;
    HF.wer = ROLLEN[rolle].name + (DB ? '' : ' (Demo)');
    const t = location.hash.slice(1); zeige(V[t] ? t : 'uebersicht');
    // Direkt in eine Mitgliedsakte springen, z. B. aus der Getränkekasse: index.html?akte=<Mitglieds-ID>
    try { const q = new URLSearchParams(location.search); const id = q.get('akte'); const m = id && d.mitglieder.find((x) => x.id === id);
      if (m && darf('eigner')) { history.replaceState(null, '', location.pathname + '#eigner'); zeige('eigner'); mitgliedAkte(m); } } catch (e) { /* egal */ }
  }
  start();
})();
