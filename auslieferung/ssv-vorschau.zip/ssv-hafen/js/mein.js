/* SSV Hafen-Manager – Mitgliederbereich „Mein SSV“
 * Im Echtbetrieb meldet sich jedes Mitglied mit eigenem Konto an und sieht nur seine Daten.
 * In der Demo wählt man oben rechts, als welches Mitglied man die Seite ansieht. */
(function () {
  'use strict';
  const HF = window.HAFEN, G = window.HAFEN_GEBUEHREN, PLAN = window.HAFEN_PLAN;
  const KASSE = window.SSV && window.SSV.speicher; // Getränkekasse (fehlt, wenn die Kasse nicht mit ausgeliefert ist)
  const KASSE_PFAD = '../ssv-getraenke/';
  const { H, Q } = HF; const esc = H.esc;
  const $ = (s, r = document) => r.querySelector(s);
  let d = HF.laden(); const heute = H.tag(new Date()); const SAISON = HF.aktuelleSaison();
  const sd = G.saisonDaten(d, SAISON);

  function toast(t) { const el = $('#toast'); el.textContent = t; el.className = 'toast zeigen'; clearTimeout(toast.t); toast.t = setTimeout(() => { el.className = 'toast'; }, 3000); }
  function modal(html) { const m = $('#modal'); m.innerHTML = '<div class="modal"><div class="modal-karte" role="dialog" aria-modal="true" aria-labelledby="modal-titel"><button class="modal-x" data-zu aria-label="Schließen">×</button>' + html + '</div></div>'; const el = m.firstChild; const t = el.querySelector('h2'); if (t) t.id = 'modal-titel'; el.addEventListener('click', (e) => { if (e.target === el || e.target.closest('[data-zu]')) m.innerHTML = ''; }); return el; }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('#modal').innerHTML = ''; });

  const DBM = HF.modus === 'supabase';
  // Fußzeile mit Impressum und Datenschutz
  if (!document.querySelector('.mein-fuss')) { const f = document.createElement('footer'); f.className = 'mein-fuss'; f.innerHTML = '<a href="../website/index.html">Zur Website</a> · <a href="../website/impressum.html">Impressum</a> · <a href="../website/datenschutz.html#mein-ssv">Datenschutz</a>'; document.body.insertBefore(f, document.getElementById('modal')); }   // Vereinsdatenbank: angemeldetes Mitglied, keine Auswahl
  const sel = $('#wer');
  // Jedes Mitglied hat einen Zugang – mit oder ohne Boot
  const alle = d.mitglieder.filter((m) => m.art !== 'gast').sort((a, b) => a.nachname.localeCompare(b.nachname, 'de') || a.vorname.localeCompare(b.vorname, 'de'));
  const mitBoot = alle.filter((m) => Q.booteVon(m.id).length);
  sel.innerHTML = alle.map((m) => '<option value="' + m.id + '">' + esc(m.nachname + ', ' + m.vorname) + (Q.booteVon(m.id).length ? ' ⛵' : '') + '</option>').join('');
  const erster = (mitBoot[0] || alle[0] || {}).id;
  let mid; try { mid = sessionStorage.getItem('ssv-mein') || erster; } catch (e) { mid = erster; }
  if (!alle.some((m) => m.id === mid)) mid = erster;
  if (DBM) { mid = HF.db.mitgliedId; sel.hidden = true; }
  sel.value = mid;
  sel.addEventListener('change', () => { mid = sel.value; try { sessionStorage.setItem('ssv-mein', mid); } catch (e) { /* egal */ } zeigen(); });

  /* Weniger auf einmal: aufgeklappt sind beim Öffnen nur Kästen, in denen etwas zu tun ist (offene Rechnungen, offene Einladungen) –
     am Rechner wie am Handy. Alles andere zeigt im Kopf eine einzeilige Zusammenfassung und klappt bei Bedarf auf; die Wahl wird gemerkt. */
  const AUF = {};
  function sektion(key, titel, info, inhalt, klasse, handlungsbedarf) {
    const offen = key in AUF ? AUF[key] : !!handlungsbedarf;
    // Ein Schild (z. B. „3 Einladungen offen“) wird nie abgeschnitten: passt es nicht neben die Überschrift, rutscht es in die Zeile darunter
    const mitSchild = /class="tag/.test(info);
    return '<details class="panel sek' + (klasse ? ' ' + klasse : '') + '" data-sek="' + key + '"' + (offen ? ' open' : '') + '><summary><h2>' + titel + '</h2>' +
      '<span class="sek-info' + (mitSchild ? ' mit-schild' : '') + '" id="info-' + key + '">' + info + '</span></summary><div class="sek-inhalt">' + inhalt + '</div></details>';
  }
  const kachel = (ziel, titel, wert, unter, id) => '<button type="button" data-ziel="' + ziel + '"' + (id ? ' id="' + id + '"' : '') + '><small>' + titel + '</small><strong>' + wert + '</strong><span>' + unter + '</span></button>';

  const inSaisonF = () => heute >= sd.auslagern && heute < sd.einlagern;
  // Mitteilungen des Vereins (z. B. Sturmwarnung) – ausblendbar, wichtige bleiben bis zum Ablauf rot
  const WEG = 'ssv-mitteilung-weg'; const ausgeblendet = () => { try { return JSON.parse(localStorage.getItem(WEG)) || []; } catch (e) { return []; } };
  function mitteilungenHtml(eigner, lieger) {
    const l = (d.mitteilungen || []).filter((x) => (!x.gueltig_bis || x.gueltig_bis >= heute) && (x.zielgruppe === 'alle' || (x.zielgruppe === 'bootseigner' && eigner) || (x.zielgruppe === 'liegeplatz' && lieger)) && !ausgeblendet().includes(x.id))
      .sort((x, y) => (y.wichtig ? 1 : 0) - (x.wichtig ? 1 : 0) || String(y.erstellt).localeCompare(String(x.erstellt)));
    return l.map((x) => '<div class="mitteilung' + (x.wichtig ? ' wichtig' : '') + '" role="' + (x.wichtig ? 'alert' : 'status') + '"><div><strong>' + (x.wichtig ? '⚠ ' : '') + esc(x.titel) + '</strong>' + (x.text ? '<p>' + esc(x.text) + '</p>' : '') +
      '<small>' + H.datum(x.erstellt) + (x.erstellt_von ? ' · ' + esc(x.erstellt_von) : '') + '</small></div><button class="btn klein" data-mweg="' + x.id + '" aria-label="Mitteilung ausblenden">Gelesen</button></div>').join('');
  }
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-mweg]'); if (!b) return; try { localStorage.setItem(WEG, JSON.stringify(ausgeblendet().concat([b.dataset.mweg]).slice(-50))); } catch (x) { /* egal */ } b.closest('.mitteilung').remove(); });
  /* Veranstaltungen: zu- oder absagen bis zur Anmeldefrist (Regeln wie in der Datenbank, siehe HAFEN.zusageSetzen) */
  const vOffen = (v) => !v.abgesagt && heute <= (v.anmeldung_bis || v.datum);
  const vZeit = (v) => [v.beginn ? v.beginn + (v.ende ? '–' + v.ende : '') + ' Uhr' : '', v.ort].filter(Boolean).join(' · ');
  const vTag = (s) => new Date(s + 'T12:00:00');
  // Nur die nächste Einladung steht voll da, die übrigen hinter „n weitere Einladungen ▸“ (Sprung #veranstaltungen zeigt alle)
  let verAlle = location.hash === '#veranstaltungen'; let verZuletzt = '';
  function verListe(vers, offeneIds) {
    const haupt = (vers.find((v) => offeneIds.includes(v.id)) || vers[0]).id;
    const fest = (v) => v.id === haupt || v.id === verZuletzt;
    const rest = vers.filter((v) => !fest(v)); const restOffen = rest.filter((v) => offeneIds.includes(v.id)).length;
    const knopfText = verAlle ? 'Weniger anzeigen ▴' : rest.length + (rest.length === 1 ? ' weitere Einladung' : ' weitere Einladungen') + (restOffen ? ', ' + restOffen + ' davon offen' : '') + ' ▸';
    return '<div class="ver-liste' + (verAlle ? ' alle' : '') + '">' + vers.map((v) => vKarte(v, fest(v))).join('') + '</div>' +
      (rest.length ? '<button type="button" class="btn klein ver-weitere" aria-expanded="' + verAlle + '" data-text="' + esc(rest.length + (rest.length === 1 ? ' weitere Einladung' : ' weitere Einladungen') + (restOffen ? ', ' + restOffen + ' davon offen' : '') + ' ▸') + '">' + esc(knopfText) + '</button>' : '');
  }
  document.addEventListener('click', (e) => {
    const k = e.target.closest('.ver-weitere'); if (!k) return;
    verAlle = !verAlle; const liste = k.previousElementSibling;
    liste.classList.toggle('alle', verAlle); liste.querySelectorAll('.ver-karte:not(.ver-fest)').forEach((x) => { x.hidden = !verAlle; });
    k.setAttribute('aria-expanded', verAlle); k.textContent = verAlle ? 'Weniger anzeigen ▴' : k.dataset.text;
  });
  function vKarte(v, fest) {
    const me = v.meine; const frei = v.max_personen ? Math.max(0, v.max_personen - (Number(v.belegt) || 0)) : null; const offen = vOffen(v);
    const stand = v.abgesagt ? '<span class="tag rot">abgesagt</span>'
      : me && me.antwort === 'ja' ? '<span class="tag ok">Du hast zugesagt' + (me.personen > 1 ? ' · ' + me.personen + ' Personen' : '') + '</span>'
      : me ? '<span class="tag">Du hast abgesagt</span>'
      : offen ? '<span class="tag warn">Bitte zu- oder absagen' + (v.anmeldung_bis ? ' bis ' + H.kurz(v.anmeldung_bis) : '') + '</span>' : '<span class="tag">Anmeldung geschlossen</span>';
    const fakten = [
      v.kosten ? 'Kosten: ' + H.geld(v.kosten) + (v.kosten_hinweis ? ' ' + esc(v.kosten_hinweis) : '') : '',
      v.begleitung ? (v.begleitung === 1 ? 'eine Begleitperson willkommen' : 'bis zu ' + v.begleitung + ' Begleitpersonen') : '',
      frei !== null && !v.abgesagt ? (frei > 0 ? 'noch ' + frei + (frei === 1 ? ' Platz' : ' Plätze') + ' frei' : 'ausgebucht') : '',
      v.anmeldung_bis && offen ? 'Anmeldung bis ' + H.datum(v.anmeldung_bis) : ''
    ].filter(Boolean);
    const knoepfe = !offen ? (me && !v.abgesagt ? '<p class="ver-klein">Änderungen jetzt bitte direkt beim Vorstand.</p>' : '')
      : !me ? '<div class="aktionen"><button class="btn primaer" data-ver-ja="' + v.id + '"' + (frei === 0 ? ' disabled' : '') + '>Ich komme</button><button class="btn" data-ver-nein="' + v.id + '">Ich komme nicht</button></div>'
      : me.antwort === 'ja' ? '<div class="aktionen"><button class="btn klein" data-ver-ja="' + v.id + '">Zusage ändern</button></div>'
      : '<div class="aktionen"><button class="btn klein" data-ver-ja="' + v.id + '"' + (frei === 0 ? ' disabled' : '') + '>Doch zusagen</button></div>';
    return '<article class="ver-karte' + (v.abgesagt ? ' abgesagt' : '') + (fest ? ' ver-fest' : '') + '" data-ver="' + v.id + '"' + (fest || verAlle ? '' : ' hidden') + '><div class="ver-datum" aria-hidden="true"><small>' + vTag(v.datum).toLocaleDateString('de-DE', { weekday: 'short' }) + '</small><strong>' + vTag(v.datum).getDate() + '</strong><small>' +
      vTag(v.datum).toLocaleDateString('de-DE', { month: 'short' }) + '</small></div><div class="ver-text"><h3>' + esc(v.titel) + '</h3><p class="ver-zeit">' + H.datum(v.datum) + (vZeit(v) ? ' · ' + esc(vZeit(v)) : '') + '</p>' +
      '<p class="ver-stand">' + stand + (me && me.bemerkung ? ' <small>„' + esc(me.bemerkung) + '“</small>' : '') + '</p>' +
      (v.text ? '<p>' + esc(v.text) + '</p>' : '') + (fakten.length ? '<p class="ver-fakten">' + fakten.map((f) => '<span>' + f + '</span>').join('') + '</p>' : '') + knoepfe + '</div></article>';
  }
  function zusageDialog(v) {
    const me = v.meine && v.meine.antwort === 'ja' ? v.meine : null;
    const frei = v.max_personen ? v.max_personen - (Number(v.belegt) || 0) + (me ? me.personen : 0) : 99;
    const maxP = Math.max(1, Math.min(1 + (Number(v.begleitung) || 0), frei));
    const el = modal('<h2>' + esc(v.titel) + '</h2><p style="margin-top:0">' + H.datum(v.datum) + (vZeit(v) ? ' · ' + esc(vZeit(v)) : '') + '</p><form id="vzf" class="form">' +
      (v.begleitung ? '<label class="feld">Wie viele kommen?<select name="personen">' + Array.from({ length: maxP }, (_, i) => i + 1).map((n) => '<option value="' + n + '"' + (me && me.personen === n ? ' selected' : '') + '>' + (n === 1 ? 'nur ich' : 'ich + ' + (n - 1) + (n === 2 ? ' Begleitung' : ' Begleitpersonen')) + '</option>').join('') + '</select></label>' : '') +
      '<label class="feld voll">Hinweis an den Verein (optional)<input name="bemerkung" maxlength="200" value="' + esc((me && me.bemerkung) || '') + '" placeholder="z. B. vegetarisch, komme später"></label></form>' +
      (v.kosten ? '<p class="hinweis">Kosten: ' + H.geld(v.kosten) + (v.kosten_hinweis ? ' ' + esc(v.kosten_hinweis) : ' je Person') + '.</p>' : '') + '<p class="hinweis" id="vzf-info" hidden></p>' +
      '<div class="modal-fuss">' + (me ? '<button class="btn gefahr" id="vz-nein">Doch absagen</button>' : '<button class="btn" data-zu>Abbrechen</button>') + '<button class="btn primaer" id="vz-ja">' + (me ? 'Speichern' : 'Zusagen') + '</button></div>');
    const senden = async (antwort) => {
      const x = Object.fromEntries(new FormData($('#vzf', el))); const info = $('#vzf-info', el);
      el.querySelectorAll('.modal-fuss .btn').forEach((b) => { b.disabled = true; });
      try { await antworten(v, antwort, x.personen || 1, x.bemerkung); $('#modal').innerHTML = ''; }
      catch (er) { info.textContent = er.message; info.className = 'hinweis warn'; info.hidden = false; el.querySelectorAll('.modal-fuss .btn').forEach((b) => { b.disabled = false; }); }
    };
    $('#vz-ja', el).addEventListener('click', () => senden('ja'));
    const n = $('#vz-nein', el); if (n) n.addEventListener('click', () => senden('nein'));
  }
  async function antworten(v, antwort, personen, bemerkung) {
    await HF.zusageSetzen(mid, { veranstaltung_id: v.id, antwort, personen: Number(personen) || 1, bemerkung: bemerkung || '' });
    d = HF.d; AUF.veranstaltungen = true; verZuletzt = v.id;   // die gerade beantwortete Einladung bleibt sichtbar
    toast(antwort === 'ja' ? 'Schön, dass du kommst! Deine Zusage ist gespeichert.' : 'Schade – deine Absage ist gespeichert.');
    zeigen();
  }
  document.addEventListener('click', (e) => {
    const ja = e.target.closest('[data-ver-ja]'); const nein = e.target.closest('[data-ver-nein]'); if (!ja && !nein) return;
    const v = HF.meineVeranstaltungen(mid).find((x) => x.id === (ja || nein).dataset[ja ? 'verJa' : 'verNein']); if (!v) return;
    if (ja) return zusageDialog(v);
    nein.disabled = true; antworten(v, 'nein', 0, '').catch((er) => { nein.disabled = false; toast(er.message); });
  });

  /* „Was möchtest du tun?“ – Suchfeld oben: führt direkt zur richtigen Stelle (Abschnitt öffnen, Knopf drücken) */
  const norm = (s) => String(s || '').toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss').replace(/[^a-z0-9]+/g, ' ').trim();
  const TUN = [
    ['Meine Rechnungen ansehen', 'rechnung rechnungen bezahlen offen beitrag hafengeld lastschrift ueberweisung geld kosten', 'rechnungen'],
    ['Platz frei melden (grünes Schild)', 'gruenes schild platz frei unterwegs abwesend urlaub segeln toern weg reise', 'schild', '#awf [name=bis]'],
    ['Zu Veranstaltungen zu- oder absagen', 'veranstaltung zusagen absagen anmelden einladung termin fest feier wintertreffen', 'veranstaltungen'],
    ['Arbeitsstunden melden', 'stunden arbeitsdienst arbeitsstunden melden gearbeitet arbeit', 'arbeitsdienst', '#ad-melden'],
    ['Schaden melden', 'schaden kaputt defekt steg strom melden reparatur', 'schaden', '#schaden'],
    ['Adresse, Telefon oder E-Mail ändern', 'adresse anschrift umzug umgezogen telefon handy email mail aendern daten', 'daten', '#meine-daten'],
    ['Getränke-Code ändern', 'code pin getraenke kasse aendern vergessen geheimzahl', 'kasse', '#code'],
    ['Getränke-Verbrauch ansehen', 'getraenke kasse verbrauch bier trinken monat', 'kasse'],
    ['Versicherungsnachweis hochladen', 'versicherung nachweis police hochladen foto pdf', 'boot', '#nachweis'],
    ['Bootsdaten aktualisieren', 'boot daten laenge breite gewicht tiefgang aendern', 'boot', '#daten'],
    ['Mein Liegeplatz und Winterlager', 'liegeplatz platz box winterlager hafenplan wo boot', 'boot'],
    ['Meine Termine', 'termine datum wann einzug auslagern einlagern kalender', 'termine'],
    ['Warteliste', 'warteliste liegeplatz warten platz bekommen', 'warteliste'],
    ['Deine Arbeitsgruppen', 'arbeitsgruppe arbeitsgruppen gruppe aufgaben ansprechpartner leitung', 'arbeitsbereiche'],
    ['Benachrichtigungen aufs Handy', 'push benachrichtigung handy nachricht mitteilung', 'daten', '#push-box'],
    ['Schrift größer oder kleiner', 'schrift groesser kleiner lesen brille sehen', '', 'schrift']
  ];
  const FRAGEN = [
    ['Muss ich meine Rechnung überweisen?', 'ueberweisen bezahlen lastschrift einzug muss ich', 'Wenn du uns ein Lastschriftmandat gegeben hast: nein – der Betrag wird am Fälligkeitstag abgebucht, du musst nichts tun. Ohne Mandat steht auf der Rechnung, wohin und mit welchem Verwendungszweck du überweist.'],
    ['Was bedeutet das grüne Schild?', 'gruenes schild bedeutung', 'Bist du mit dem Boot unterwegs, meldest du hier „Platz frei“. Dann darf der Hafenmeister den Platz an Gäste geben. Kommst du früher zurück, drückst du „Früher zurück“.'],
    ['Getränke-Code vergessen?', 'code vergessen pin', 'Du kannst ihn hier unter „Getränkekasse“ neu festlegen. Klappt das nicht, hilft der Kassenwart.']
  ];
  function tunTreffer(q) {
    const w = norm(q).split(' ').filter(Boolean); if (!w.length) return [];
    const passt = (text) => { const ws = norm(text).split(' '); return w.every((x) => ws.some((y) => y.startsWith(x) || (x.length >= 4 && y.includes(x)))); };
    const da = (sek) => !sek || sekFinden(sek);
    return TUN.filter(([t, s, sek]) => da(sek) && passt(t + ' ' + s)).map((x) => ({ art: 'tun', x }))
      .concat(FRAGEN.filter(([t, s]) => passt(t + ' ' + s)).map((x) => ({ art: 'frage', x })));
  }
  // Arbeitsgruppen stehen bei Mitgliedern mit Arbeitsdienst im Kasten „Arbeitsdienst“, sonst in einem eigenen Kasten
  function sekFinden(sek) {
    const el = document.querySelector('details.sek[data-sek="' + sek + '"]'); if (el || sek !== 'arbeitsbereiche') return el;
    const ad = document.querySelector('details.sek[data-sek=arbeitsdienst]'); return ad && ad.querySelector('.mein-bereich') ? ad : null;
  }
  function tunAusfuehren(sek, ziel) {
    if (ziel === 'schrift') { schriftUmschalten(); return; }
    const el = sekFinden(sek); if (!el) return;
    el.open = true; AUF[el.dataset.sek] = true; el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (ziel) setTimeout(() => { const z = document.querySelector(ziel); if (!z) return; if (z.tagName === 'BUTTON') z.click(); else if (z.focus) z.focus(); }, 450);
  }
  const SCHRIFT = 'ssv-schrift-gross';
  const schriftGross = () => { try { return localStorage.getItem(SCHRIFT) === '1'; } catch (e) { return false; } };
  function schriftUmschalten() { const an = !schriftGross(); try { localStorage.setItem(SCHRIFT, an ? '1' : '0'); } catch (e) { /* egal */ } document.documentElement.classList.toggle('schrift-gross', an); const k = $('#schrift-m'); if (k) { k.textContent = an ? 'Schrift normal' : 'Schrift größer'; k.setAttribute('aria-pressed', an); } toast(an ? 'Schrift ist jetzt größer.' : 'Schrift ist wieder normal.'); }
  document.documentElement.classList.toggle('schrift-gross', schriftGross());
  (() => { const kopf = document.querySelector('.mein-kopf'); if (!kopf || $('#schrift-m')) return; const b = document.createElement('button'); b.id = 'schrift-m'; b.className = 'btn klein schrift-m'; b.type = 'button';
    b.textContent = schriftGross() ? 'Schrift normal' : 'Schrift größer'; b.setAttribute('aria-pressed', schriftGross()); b.addEventListener('click', schriftUmschalten); kopf.appendChild(b); })();
  const tunHtml = () => '<div class="mein-suche"><label for="mein-such">Was möchtest du tun?</label><div class="such-feld"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>' +
    '<input id="mein-such" type="search" autocomplete="off" placeholder="z. B. Rechnung, Platz frei, Code ändern" aria-controls="mein-such-erg"></div><div id="mein-such-erg" class="mein-such-erg"></div>' +
    '<div class="mein-schnell">' + [['Rechnungen', 'rechnungen'], ['Platz frei melden', 'schild', '#awf [name=bis]'], ['Veranstaltungen', 'veranstaltungen'], ['Stunden melden', 'arbeitsdienst', '#ad-melden'], ['Schaden melden', 'schaden', '#schaden']]
      .map(([t, sek, z]) => '<button type="button" class="chip" data-tun="' + sek + '"' + (z ? ' data-tun-ziel="' + esc(z) + '"' : '') + '>' + t + '</button>').join('') + '</div></div>';
  document.addEventListener('input', (e) => {
    if (e.target.id !== 'mein-such') return; const box = $('#mein-such-erg'); const l = tunTreffer(e.target.value);
    box.innerHTML = !e.target.value.trim() ? '' : l.length ? l.map(({ art, x }, i) => art === 'tun'
      ? '<button type="button" class="such-zeile" data-tun="' + x[2] + '" data-tun-ziel="' + esc(x[3] || '') + '"><span class="such-t">' + esc(x[0]) + '</span><span class="such-pfeil" aria-hidden="true">→</span></button>'
      : '<details class="mein-frage"><summary>' + esc(x[0]) + '</summary><p>' + esc(x[2]) + '</p></details>').join('')
      : '<p class="such-tipp">Dazu habe ich nichts gefunden. Probier ein anderes Wort – oder schreib an <a href="mailto:' + esc(d.einstellungen.verein_email) + '">' + esc(d.einstellungen.verein_email) + '</a>.</p>';
  });
  document.addEventListener('keydown', (e) => { if (e.target.id === 'mein-such' && e.key === 'Enter') { e.preventDefault(); const b = document.querySelector('#mein-such-erg [data-tun]'); if (b) b.click(); } });
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-tun]'); if (!b) return; const s = $('#mein-such'); if (s) { s.value = ''; $('#mein-such-erg').innerHTML = ''; }
    const sek = b.dataset.tun; const ziel = b.dataset.tunZiel; tunAusfuehren(sek, ziel); });

  function zeigen() {
    const m = Q.mitglied(mid); const boote = Q.booteVon(mid);
    const b = boote[0]; const sommer = b && Q.belegungBoot(SAISON, 'sommer', b.id); const winter = b && Q.belegungBoot(SAISON, 'winter', b.id);
    const platzS = sommer && Q.platz(sommer.platz_id); const platzW = winter && Q.platz(winter.platz_id);
    const aw = d.abwesenheiten.filter((a) => b && a.boot_id === b.id).sort((x, y) => y.von.localeCompare(x.von));
    // laufende Abwesenheit (heute zwischen von und bis), sonst die nächste geplante – aw ist absteigend nach „von“ sortiert
    const awLaufend = aw.find((a) => a.von <= heute && a.bis >= heute);
    const awGeplant = aw.slice().reverse().find((a) => a.von > heute);
    const awAktuell = awLaufend || awGeplant;
    const res = d.rechnungen.filter((r) => r.mitglied_id === mid && !r.storniert_am);
    const warte = d.warteliste.filter((w) => w.status === 'wartend').sort((x, y) => x.datum.localeCompare(y.datum));
    let meinW = warte.findIndex((w) => w.mitglied_id === mid);
    if (DBM) { const wp = HF.db.warteplatz; meinW = wp ? wp.platz - 1 : -1; if (wp) warte[meinW] = { datum: wp.seit }; }
    const vs = b ? Q.versicherungsStatus(b, heute) : 'ok';
    const naechste = (d.saisons || []).find((x) => x.jahr === SAISON + 1);
    const auslagernNeu = heute < sd.auslagern ? sd.auslagern : naechste && naechste.auslagern;
    const yy = String(SAISON + 1).slice(2);
    // Wo ist das Boot gerade? Saison und tatsächlicher Ort getrennt
    const ortJetzt = !b ? '' : inSaisonF() ? (platzS ? (platzS.bez ? esc(Q.platzName(platzS)) + ' (Sommer an Land)' : 'im Wasser, ' + (platzS.box === 'L' ? 'Längsseits ' : 'Platz ') + esc(platzS.nr)) : 'kein Sommerplatz bei uns')
      : (platzW ? 'im Winterlager, ' + esc(Q.platzName(platzW)) : 'im Winter ' + SAISON + '/' + yy + ' kein Landplatz bei uns gebucht');
    const NW = { geprueft: ['Nachweis geprüft' + (b && b.vers_geprueft_am ? ' am ' + H.datum(b.vers_geprueft_am) : ''), 'ok'], eingereicht: ['Nachweis eingereicht – wird geprüft', 'gast'], selbst: ['selbst angegeben – bitte Nachweis hochladen', 'warn'] };
    const nw = b ? (NW[b.vers_status] || ['noch kein Nachweis – bitte hochladen', 'warn']) : null;
    const platzText = platzS ? (platzS.bez ? esc(Q.platzName(platzS)) : (platzS.box === 'L' ? 'Längsseits ' : 'Platz ') + esc(platzS.nr)) : '';
    const wasser = sommer && sommer.platz_typ === 'wasser';
    const inSaison = inSaisonF();   // grünes Schild nur, solange die Boote im Wasser sind

    // Persönliche Termine (nur, was kommt)
    const termine = [];
    d.rechnungen.filter((r) => r.mitglied_id === mid && Q.rest(r) > 0 && r.faellig >= heute).forEach((r) => termine.push([r.faellig, r.sepa ? 'Lastschrift-Einzug ' + H.geld(Q.rest(r)) : 'Überweisung fällig ' + H.geld(Q.rest(r)), H.periodeText(r) + ' · ' + r.nr]));
    if (awAktuell) termine.push([awAktuell.bis, 'Rückkehr gemeldet', 'grünes Schild endet']);
    if (b && sd.einlagern >= heute) termine.push([sd.einlagern, 'Einlagern', 'Gemeinschaftsarbeit nach Belegungsplan']);
    (d.arbeitseinsaetze || []).filter((x) => x.datum >= heute).forEach((x) => termine.push([x.datum, 'Arbeitseinsatz: ' + x.titel, [x.beginn && x.beginn + (x.ende ? '–' + x.ende : '') + ' Uhr', x.notiz].filter(Boolean).join(' · ')]));
    if (b && auslagernNeu && auslagernNeu >= heute) termine.push([auslagernNeu, 'Auslagern', 'Gemeinschaftsarbeit nach Belegungsplan']);
    if (b && b.vers_bis && b.vers_bis >= heute) termine.push([b.vers_bis, 'Versicherung läuft ab', 'vorher neuen Nachweis hochladen']);
    const vers = HF.meineVeranstaltungen ? HF.meineVeranstaltungen(mid) : [];
    const vUnbeantwortet = vers.filter((v) => !v.meine && vOffen(v));
    vers.filter((v) => v.meine && v.meine.antwort === 'ja' && !v.abgesagt).forEach((v) => termine.push([v.datum, v.titel, [vZeit(v), 'du hast zugesagt'].filter(Boolean).join(' · ')]));
    vUnbeantwortet.filter((v) => v.anmeldung_bis).forEach((v) => termine.push([v.anmeldung_bis, 'Zu- oder absagen: ' + v.titel, 'Anmeldefrist']));
    termine.sort((x, y) => x[0].localeCompare(y[0])); termine.splice(5);
    // Arbeitsdienst: eigener Stundenstand nach den Regeln des Vereins
    const ad = G.arbeitsdienst && (m.art === 'ausuebend' || m.art === 'probe') ? G.arbeitsdienst(d, SAISON, m) : null;
    const meineStunden = (d.arbeitsdienst || []).filter((a) => a.mitglied_id === mid && String(a.datum).startsWith(String(SAISON))).sort((x, y) => y.datum.localeCompare(x.datum));
    const kommend = (d.arbeitseinsaetze || []).filter((x) => x.datum >= heute).sort((x, y) => x.datum.localeCompare(y.datum));
    const STAND = { eingereicht: ['wird geprüft', 'gast'], abgelehnt: ['nicht anerkannt', 'rot'] };
    // Eigene Arbeitsgruppen (intern „Arbeitsbereiche“: Kran, Steg …) mit Aufgaben und Ansprechpartner – Datenbank liefert sie fertig, die Demo rechnet selbst
    const meineBereiche = d.meine_bereiche || (d.arbeitsbereich_mitglieder || []).filter((z) => z.mitglied_id === mid).map((z) => {
      const b = (d.arbeitsbereiche || []).find((x) => x.id === z.bereich_id); if (!b || b.aktiv === false) return null;
      const leitung = d.arbeitsbereich_mitglieder.filter((y) => y.bereich_id === b.id && y.rolle === 'leitung').map((y) => Q.mitglied(y.mitglied_id)).filter(Boolean).map((x) => ({ name: x.vorname + ' ' + x.nachname, tel: x.tel }));
      return { ...b, rolle: z.rolle, leitung };
    }).filter(Boolean);
    const telLink = (t) => { t = String(t || '').replace(/[^\d+]/g, ''); return t.startsWith('0') ? '+49' + t.slice(1) : t; };
    // Arbeitsgruppen kompakt: je Gruppe eine Zeile „Krancrew · 14 offene Aufgaben ▸“, die Aufgaben klappen auf; Ansprechpartner steht immer sichtbar darunter
    const bereichZeile = (b) => { const offen = (b.aufgaben || []).filter((a) => a.art !== 'besorgen' && !a.erledigt);   // nur offene Aufgaben, ohne Einkaufsliste
      return '<div class="mein-bereich"><details><summary><strong>' + esc(b.name) + '</strong>' + (b.rolle === 'leitung' ? ' <span class="tag ok">du leitest</span>' : '') +
        ' <span class="mb-zahl">·</span> <span class="mb-zahl nw">' + (offen.length ? offen.length + (offen.length === 1 ? ' offene Aufgabe' : ' offene Aufgaben') : 'keine offenen Aufgaben') + '</span></summary>' +
        (b.treffpunkt ? '<p><small>' + esc(b.treffpunkt) + '</small></p>' : '') +
        (offen.length ? '<p style="margin-top:8px"><strong>Offene Aufgaben</strong></p><ul>' + offen.slice(0, 8).map((a) => '<li>' + esc(a.titel) + (a.zeitraum ? ' <small>· ' + esc(a.zeitraum) + '</small>' : '') + '</li>').join('') +
          (offen.length > 8 ? '<li><small>und ' + (offen.length - 8) + ' weitere – frag die Leitung</small></li>' : '') + '</ul>' : '<p><small>Gerade keine offenen Aufgaben.</small></p>') + '</details>' +
        ((b.leitung || []).length && b.rolle !== 'leitung' ? '<p class="mb-kontakt">Ansprechpartner: ' + b.leitung.map((l) => esc(l.name) + (l.tel ? ' · <a class="nw" href="tel:' + esc(telLink(l.tel)) + '">' + esc(l.tel) + '</a>' : '')).join(', ') + '</p>' : '') + '</div>'; };
    const bereicheListe = meineBereiche.map(bereichZeile).join('');
    const bereicheHtml = meineBereiche.length ? '<h3 class="mb-titel">Deine Arbeitsgruppen</h3>' + bereicheListe : '';
    const stdZahl = (x) => H.zahl(x, x % 1 ? 1 : 0);
    // Arbeitsdienst kompakt: Stand + „Stunden melden“, Gruppen als Zeilen; eigene Stunden, nächste Einsätze und Regeln zum Aufklappen
    const adInhalt = ad ? (ad.befreit ? '<p style="margin:0">Du bist vom Arbeitsdienst befreit (' + esc(ad.befreit) + ').</p>'
      : '<div class="ad-kurz"><p><strong>' + stdZahl(ad.ist) + ' von ' + ad.soll + ' Std.</strong> bestätigt' + (ad.fehl > 0 ? ' · noch ' + stdZahl(ad.fehl) + ' Std. offen' : ' – geschafft, danke!') + '</p>' +
        '<button class="btn" id="ad-melden">Stunden melden</button></div>' +
        (ad.gemeldet ? '<p class="ad-notiz">Dazu ' + stdZahl(ad.gemeldet) + ' Std. gemeldet – der Verein bestätigt sie noch.</p>' : '') +
        bereicheHtml +
        '<details class="mein-mehr"><summary>Deine Stunden' + (kommend.length ? ' und nächste Einsätze' : '') + '</summary>' +
        (meineStunden.length ? '<table class="tab"><tbody>' + meineStunden.map((a) => '<tr><td class="nw">' + H.datum(a.datum) + '</td><td>' + esc(a.taetigkeit || 'Arbeitseinsatz') + (STAND[a.status] ? ' <span class="tag ' + STAND[a.status][1] + '">' + STAND[a.status][0] + '</span>' : '') + '</td><td class="r">' + stdZahl(a.stunden) + ' Std.</td></tr>').join('') + '</tbody></table>' : '<p class="leer">Noch keine Stunden erfasst.</p>') +
        (kommend.length ? '<h3 style="margin:14px 0 6px;font-size:16px">Nächste Arbeitseinsätze</h3><table class="tab"><tbody>' + kommend.slice(0, 3).map((x) => '<tr><td class="nw">' + H.datum(x.datum) + '</td><td>' + esc(x.titel) + (x.beginn ? '<br><small style="color:var(--muted)">' + esc(x.beginn) + (x.ende ? '–' + esc(x.ende) : '') + ' Uhr' + (x.notiz ? ' · ' + esc(x.notiz) : '') + '</small>' : '') + '</td></tr>').join('') + '</tbody></table>' : '') +
        '<p class="hinweis" style="margin-top:10px">Soll: ' + ad.soll + ' Stunden im Jahr' + (ad.vorjahr ? ' (dazu ' + ad.vorjahr + ' aus dem Vorjahr)' : '') + '. Beim Arbeitseinsatz einfach den QR-Code am Vereinsheim scannen – oder hier Stunden melden; der Verein bestätigt sie.' + (d.einstellungen.arbeitsdienst_bestaetigt ? '' : ' Die genauen Regeln legt der Vorstand noch fest.') + '</p></details>') : '';

    const bootInhalt = b ? '<div class="detail" style="box-shadow:none;padding:0;position:static"><dl>' +
        '<dt>Typ</dt><dd>' + esc(b.typ) + '</dd><dt>Maße</dt><dd>' + H.zahl(b.laenge) + ' × ' + H.zahl(b.breite) + ' m · Tiefgang ' + H.zahl(b.tiefgang) + ' m · ' + H.zahl(b.gewicht_t, 1) + ' t</dd>' +
        '<dt>Jetzt</dt><dd><strong>' + ortJetzt + '</strong></dd>' +
        '<dt>Sommer ' + SAISON + '</dt><dd>' + (platzS ? (platzS.bez ? esc(Q.platzName(platzS)) + ' (an Land)' : platzText + ', ' + H.BRUECKE[platzS.bruecke]) : 'kein Platz') + '</dd>' +
        '<dt>Winter ' + SAISON + '/' + yy + '</dt><dd>' + (platzW ? esc(Q.platzName(platzW)) : 'kein Landplatz bei uns') + '</dd>' +
        '<dt>Versicherung</dt><dd>' + esc(b.versicherung || '–') + (b.vers_bis ? ', bis ' + H.datum(b.vers_bis) : '') + '<br><span class="tag ' + nw[1] + '">' + nw[0] + '</span></dd><dt>Kfz</dt><dd>' + esc(m.kfz || '–') + '</dd></dl></div>' +
        (platzS && !platzS.bez ? '<div id="miniplan" class="plan-flaeche mini-plan"></div><p style="font-size:12px;color:var(--muted);margin:4px 0 0">' + (inSaisonF() ? 'Hafenplan heute' : 'Dein Sommerplatz ' + SAISON + ' (Saison beendet)') + '</p>' : '') +
        '<div class="aktionen" style="margin-top:12px"><button class="btn primaer" id="nachweis">Versicherungsnachweis hochladen</button><button class="btn" id="daten">Daten aktualisieren</button></div>' : '';
    const awTabelle = aw.length ? '<table class="tab" style="margin-top:12px"><tbody>' + aw.map((a) => '<tr' + (a.bis < heute ? ' class="blass"' : '') + '><td class="nw">' + H.kurz(a.von) + ' – ' + H.datum(a.bis) + '</td><td>' + esc(a.notiz || '') + '</td><td class="r">' + (a.von > heute ? '<button class="btn klein gefahr" data-weg="' + a.id + '">Löschen</button>' : a.bis >= heute ? '<button class="btn klein" data-weg="' + a.id + '">Früher zurück</button>' : '') + '</td></tr>').join('') + '</tbody></table>' : '';
    const schildInhalt = wasser && !inSaison ? '<p style="margin:0">Das grüne Schild gibt es, solange die Boote im Wasser sind – wieder ab dem Auslagern' + (auslagernNeu ? ' am ' + H.datum(auslagernNeu) : '') + '. ' + (platzW ? 'Dein Boot steht gerade im Winterlager (' + esc(Q.platzName(platzW)) + ').' : 'Im Winter ' + SAISON + '/' + yy + ' hast du bei uns keinen Landplatz gebucht.') + '</p>' + (aw.some((a) => a.bis >= heute) ? awTabelle.replace(/<tr class="blass">.*?<\/tr>/g, '') : '') : wasser ? '<p style="margin-top:0;color:var(--muted)">Unterwegs? Dann wird dein Platz grün und der Hafenmeister kann ihn an Gäste geben. Bitte trotzdem das Schild am Steg drehen.</p>' +
        '<form id="awf" class="form"><label class="feld">ab<input type="date" name="von" required min="' + heute + '" value="' + heute + '"></label><label class="feld">zurück am<input type="date" name="bis" required min="' + heute + '"></label><label class="feld voll">Ziel (optional)<input name="notiz" placeholder="z. B. Dänische Südsee"></label></form>' +
        '<div class="aktionen" style="margin-top:10px"><button class="btn gruen" id="awok">Abwesenheit melden</button></div>' +
        awTabelle : '';

    $('#main').innerHTML = (DBM ? '' : '<div class="demo-band"><strong>Demo</strong> – erfundene Daten. Im Echtbetrieb meldest du dich mit deinem eigenen Zugang an.</div>') +
      '<div class="kopf"><div><h1>Moin ' + esc(m.vorname) + '!</h1><p>' + H.ART[m.art] + ' · Mitgliedsnr. ' + esc(m.nr) + '</p></div></div>' + tunHtml() +
      mitteilungenHtml(!!b, !!wasser) +
      (vs !== 'ok' && b ? '<p class="hinweis warn">Deine Bootsversicherung ' + (vs === 'bald' ? 'läuft am ' + H.datum(b.vers_bis) + ' ab' : vs === 'fehlt' ? 'ist noch nicht hinterlegt' : 'ist am ' + H.datum(b.vers_bis) + ' abgelaufen') + '. Bitte einen neuen Nachweis hochladen.</p><div class="aktionen" style="margin:-4px 0 12px"><button type="button" class="btn klein" data-tun="boot" data-tun-ziel="#nachweis">Nachweis hochladen</button></div>' : '') +
      '<div class="blick">' + kachel('rechnungen', 'Rechnungen', '…', 'wird geladen …', 'k-offen') +
        (b && !inSaison && platzW ? kachel('boot', 'Winterlager', esc(Q.platzName(platzW, 'kurz')), SAISON + '/' + yy) : platzS ? kachel(wasser ? 'schild' : 'boot', 'Liegeplatz', platzText, !inSaison ? 'Sommer ' + SAISON + ' (beendet)' : awLaufend ? 'grün bis ' + H.kurz(awLaufend.bis) : awGeplant ? 'grün ab ' + H.kurz(awGeplant.von) : (platzS.bez ? 'an Land' : H.BRUECKE[platzS.bruecke])) : meinW >= 0 ? kachel('warteliste', 'Warteliste', 'Platz ' + (meinW + 1), 'seit ' + H.datum(warte[meinW].datum)) : kachel('rechnungen', 'Mitglied seit', m.eintritt ? m.eintritt.slice(0, 4) : '–', H.ART[m.art])) +
        (KASSE ? kachel('kasse', 'Verbrauch ' + new Date().toLocaleDateString('de-DE', { month: 'long' }), '…', 'Getränke · noch nicht abgerechnet', 'k-getraenke') : '') + '</div>' +
      '<div class="mein-raster"><div>' +
      (b ? sektion('boot', 'Mein Boot', '„' + esc(b.name) + '“' + (platzText ? ' · ' + platzText : ''), bootInhalt) : '') +
      (meinW >= 0 ? sektion('warteliste', 'Warteliste', 'Platz ' + (meinW + 1), '<p style="margin:0">Du stehst auf <strong>Platz ' + (meinW + 1) + '</strong> der Warteliste (seit ' + H.datum(warte[meinW].datum) + ').</p>') : '') +
      (KASSE ? sektion('kasse', 'Getränkekasse', 'wird geladen …', '<div id="kasse"><p class="leer">Wird geladen …</p></div>') : '') +
      sektion('daten', 'Meine Daten', esc(m.ort || ''), '<div class="detail" style="box-shadow:none;padding:0;position:static"><dl>' +
        '<dt>Anschrift</dt><dd>' + esc(m.strasse || '–') + '<br>' + esc(((m.plz || '') + ' ' + (m.ort || '')).trim()) + '</dd><dt>Telefon</dt><dd>' + esc(m.tel || '–') + '</dd><dt>E-Mail</dt><dd>' + esc(m.email || '–') + '</dd>' +
        '<dt>Lastschrift</dt><dd>' + (m.iban ? 'Konto •••• ' + esc(String(m.iban).slice(-4)) : 'kein Mandat hinterlegt') + '</dd></dl></div>' +
        '<div class="aktionen" style="margin-top:12px"><button class="btn" id="meine-daten">Daten ändern</button></div><div id="meine-dok"></div>' +
        (DBM && d.einstellungen.push_aktiv ? '<h3 style="margin:16px 0 6px;font-size:15px">Benachrichtigungen</h3><div id="push-box"><p class="leer">…</p></div>' : '') +
        '<p class="hinweis" style="margin-top:12px">Neue Bankverbindung oder Fragen zu Rechnungen? Schreib an <a href="mailto:' + esc(d.einstellungen.verein_email) + '">' + esc(d.einstellungen.verein_email) + '</a> – für ein neues Konto braucht es ein neues Lastschriftmandat.</p>') +
      '</div><div>' +
      (wasser ? sektion('schild', 'Grünes Schild', awLaufend ? 'unterwegs ' + H.kurz(awLaufend.von) + '–' + H.kurz(awLaufend.bis) : awGeplant ? 'geplant ' + H.kurz(awGeplant.von) + '–' + H.kurz(awGeplant.bis) : 'Platz frei melden', schildInhalt, 'gruen-box') : '') +
      (vers.length ? sektion('veranstaltungen', 'Veranstaltungen', vUnbeantwortet.length ? '<span class="tag warn">' + (vUnbeantwortet.length === 1 ? '1 Einladung' : vUnbeantwortet.length + ' Einladungen') + ' offen</span>' : esc(vers[0].titel) + ' ' + H.kurz(vers[0].datum),
        verListe(vers, vUnbeantwortet.map((v) => v.id)) + '<p class="hinweis" style="margin-top:12px">Zu- und Absagen gehen bis zur Anmeldefrist. Der Verein sieht, wer kommt; andere Mitglieder sehen nur die Zahl.</p>', '', vUnbeantwortet.length > 0) : '') +
      sektion('rechnungen', 'Meine Rechnungen', '', '<div id="rechnungen"></div><p class="hinweis" style="margin-top:12px">Mit Lastschriftmandat wird alles eingezogen – du musst nichts tun. Fragen? Einfach den Kassenwart ansprechen.</p>', '', res.some((r) => Q.rest(r) > 0)) +
      (termine.length ? sektion('termine', 'Meine Termine', H.kurz(termine[0][0]) + ' · ' + esc(termine[0][1]), '<table class="tab"><tbody>' + termine.map(([t, txt, zus]) => '<tr><td class="nw">' + H.datum(t) + '</td><td>' + esc(txt) + (zus ? '<br><small style="color:var(--muted)">' + esc(zus) + '</small>' : '') + '</td></tr>').join('') + '</tbody></table>') : '') +
      (ad ? sektion('arbeitsdienst', 'Arbeitsdienst ' + SAISON, ad.befreit ? 'befreit' : H.zahl(ad.ist, ad.ist % 1 ? 1 : 0) + ' von ' + ad.soll + ' Std.', adInhalt) : '') +
      (!ad && meineBereiche.length ? sektion('arbeitsbereiche', 'Deine Arbeitsgruppen', esc(meineBereiche.map((b) => b.name).join(', ')), bereicheListe) : '') +
      sektion('schaden', 'Schaden melden', 'Steg, Strom, Kran …', '<p style="margin-top:0">Etwas kaputt im Hafen? Kurz melden – die Funktionsträger sehen es sofort und kümmern sich.</p><div class="aktionen"><button class="btn" id="schaden">Schaden melden</button></div>') +
      '</div></div>';

    // Schnellwahl nur für Abschnitte, die es bei diesem Mitglied gibt (kein Boot → kein grünes Schild)
    document.querySelectorAll('.mein-schnell [data-tun]').forEach((c) => { if (!document.querySelector('details.sek[data-sek="' + c.dataset.tun + '"]')) c.remove(); });
    // Aufklappen merken; Kacheln springen zum Bereich
    document.querySelectorAll('details.sek').forEach((el) => el.addEventListener('toggle', () => { if (el.dataset.auto) { delete el.dataset.auto; return; } AUF[el.dataset.sek] = el.open; }));
    document.querySelectorAll('.blick [data-ziel]').forEach((k) => k.addEventListener('click', () => {
      const el = document.querySelector('details.sek[data-sek="' + k.dataset.ziel + '"]'); if (!el) return;
      el.open = true; AUF[el.dataset.sek] = true; el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));

    // Rechnungen: Hafen und Beitrag sofort, Getränke sobald die Kasse geantwortet hat
    const hafenPosten = res.map((r) => ({ art: r.periode === 'beitrag' ? 'Beitrag' : r.periode === 'veranstaltung' ? 'Veranstaltung' : 'Hafen', nr: r.nr, datum: r.datum || '', text: r.periode === 'beitrag' ? String(r.saison) : H.periodeText(r),
      summe: Q.rest(r) || r.summe, rest: Q.rest(r), stand: Q.rstatus(r, heute), bezahlt_am: Q.rest(r) === 0 ? (r.bezahlt_am || heute) : null, sepa: r.sepa, faellig: r.faellig, href: 'drucken.html?art=rechnungen&ids=' + r.id + (DBM ? '&mein=1' : '') }));
    let bezahlteZeigen = false;
    const erklaerung = (r) => r.stand === 'ruecklastschrift' ? ['Lastschrift zurückgekommen – bitte überweisen', 'rot'] : r.stand === 'teilbezahlt' ? ['teilweise bezahlt – Rest ' + (r.sepa ? 'wird eingezogen' : 'bitte überweisen'), 'warn']
      : r.sepa ? [(r.faellig >= heute ? 'Einzug am ' + H.kurz(r.faellig) : 'wird eingezogen') + ' – du musst nichts tun', ''] : ['bitte überweisen bis ' + H.kurz(r.faellig), 'warn'];
    const rechnungenZeigen = (getraenke) => {
      const alle = hafenPosten.concat(getraenke || []).sort((x, y) => (y.datum || '').localeCompare(x.datum || '') || y.nr.localeCompare(x.nr));
      const offen = alle.filter((r) => !r.bezahlt_am); const bezahlt = alle.filter((r) => r.bezahlt_am);
      const summeOffen = offen.reduce((s2, r) => s2 + Math.round(r.summe * 100), 0) / 100;
      const ko = $('#k-offen');
      if (ko) {
        const naechste = offen.slice().sort((x, y) => (x.faellig || '').localeCompare(y.faellig || ''))[0];
        ko.querySelector('small').textContent = offen.length > 1 ? offen.length + ' offene Rechnungen' : offen.length ? 'Rechnung' : 'Rechnungen';
        ko.querySelector('strong').textContent = offen.length ? H.geld(summeOffen) : 'alles bezahlt';
        ko.querySelector('span').textContent = naechste ? erklaerung(naechste)[0] : 'nichts offen – danke!';
      }
      $('#info-rechnungen').textContent = offen.length ? H.geld(summeOffen) + ' offen' : 'alles bezahlt';
      // Getränkerechnungen kommen später dazu: ist dann etwas offen, klappt der Kasten auf (außer das Mitglied hat ihn selbst zugeklappt)
      const sr = $('details.sek[data-sek=rechnungen]'); if (sr && offen.length && !sr.open && !('rechnungen' in AUF)) { sr.dataset.auto = '1'; sr.open = true; }
      const zeile = (r) => '<tr><td><span class="tag' + (r.art === 'Hafen' ? '' : r.art === 'Beitrag' ? ' gruen' : ' gold') + '">' + r.art + '</span> ' + esc(r.text) +
        '<br><small style="color:var(--muted)">' + esc(r.nr) + '</small>' + (!r.bezahlt_am ? '<br><span class="erkl ' + erklaerung(r)[1] + '">' + erklaerung(r)[0] + '</span>' : '') + '</td><td class="r"><strong>' + H.geld(r.summe) + '</strong>' +
        (r.bezahlt_am ? '<br><span class="tag ok">bezahlt</span>' : '') + '</td><td class="r"><a class="btn klein" href="' + r.href + '" target="_blank">PDF</a></td></tr>';
      $('#rechnungen').innerHTML = (offen.length ? '<table class="tab rechn"><tbody>' + offen.map(zeile).join('') + '</tbody></table>' : '<p class="leer" style="margin:0">Keine offenen Rechnungen – alles bezahlt.</p>') +
        (bezahlt.length ? '<button class="btn klein" id="rmehr" style="margin-top:12px">' + (bezahlteZeigen ? 'Bezahlte Rechnungen ausblenden' : 'Bezahlte Rechnungen ansehen (' + bezahlt.length + ')') + '</button>' +
          (bezahlteZeigen ? '<table class="tab rechn" style="margin-top:8px"><tbody>' + bezahlt.map(zeile).join('') + '</tbody></table>' : '') : '');
      const mehr = $('#rmehr'); if (mehr) mehr.addEventListener('click', () => { bezahlteZeigen = !bezahlteZeigen; rechnungenZeigen(getraenke); });
    };
    rechnungenZeigen();
    if (KASSE) kasseZeigen(m, rechnungenZeigen);
    pushStand().catch(() => {});
    // Schnellknopf am Handy: in der Saison „Platz frei melden“, sonst „Stunden melden“ (nur wenn passend)
    let sk = $('#schnell'); const aktion = wasser && inSaison && !awLaufend ? ['Platz frei melden', 'schild'] : ad && !ad.befreit ? ['Stunden melden', 'stunden'] : null;
    if (!aktion) { if (sk) sk.remove(); } else {
      if (!sk) { sk = document.createElement('button'); sk.id = 'schnell'; sk.className = 'schnell'; sk.type = 'button'; document.body.appendChild(sk); }
      sk.textContent = aktion[0]; sk.onclick = () => { if (aktion[1] === 'stunden') return stundenDialog('');
        const el = document.querySelector('details.sek[data-sek=schild]'); if (el) { el.open = true; AUF.schild = true; el.scrollIntoView({ behavior: 'smooth', block: 'start' }); const v = $('#awf [name=bis]'); if (v) setTimeout(() => v.focus(), 400); } };
    }
    // Unterlagen, die der Verein für mich hinterlegt hat (Verträge, Nachweise)
    HF.dok.liste({ mitglied_id: mid }).then((l) => { const box = $('#meine-dok'); if (!box || !l.length) return;
      box.innerHTML = '<h3 style="margin:16px 0 6px;font-size:15px">Meine Unterlagen</h3><table class="tab"><tbody>' + l.map((x) => '<tr><td>' + esc(x.name) + '<br><small style="color:var(--muted)">' + H.datum(x.hochgeladen) + '</small></td><td class="r"><button class="btn klein" data-dok="' + x.id + '">Ansehen</button></td></tr>').join('') + '</tbody></table>';
      box.addEventListener('click', (e) => { const a = e.target.closest('[data-dok]'); if (a) HF.datei.oeffnen(a.dataset.dok).catch((x) => toast(x.message)); });
    }).catch(() => {});

    if (platzS && !platzS.bez && $('#miniplan')) {
      const svg = PLAN.zeichnen($('#miniplan'), { modus: 'sommer', saison: SAISON, datum: heute >= sd.auslagern && heute < sd.einlagern ? heute : (DBM ? H.tag(new Date(new Date(sd.einlagern + 'T12:00:00').getTime() - 864e5)) : '2026-08-15'), ansicht: platzS.bruecke === 'laengs' ? 'gesamt' : platzS.bruecke, markiere: platzS.id });
      svg.style.pointerEvents = 'none';
    }
    const awok = $('#awok'); if (awok) {
      const awf = $('#awf'); awf.von.addEventListener('change', () => { awf.bis.min = awf.von.value > heute ? awf.von.value : heute; });
      awok.addEventListener('click', async () => {
        const x = Object.fromEntries(new FormData(awf));
        const ueber = x.von && x.bis ? aw.find((a) => a.von <= x.bis && a.bis >= x.von) : null;
        if (!feldPruefen(awf, {
          von: !x.von ? 'Bitte angeben, ab wann du unterwegs bist.' : x.von < heute ? 'Das Datum liegt in der Vergangenheit – bitte ab heute angeben.' : '',
          bis: !x.bis ? 'Bitte angeben, wann du zurück bist.' : x.bis < heute ? 'Der Zeitraum liegt in der Vergangenheit.' : x.bis < x.von ? 'Das Rückkehrdatum liegt vor der Abfahrt.'
            : ueber ? 'Für diese Tage ist schon eine Abwesenheit gemeldet (' + H.kurz(ueber.von) + ' – ' + H.datum(ueber.bis) + '). Bitte die vorhandene löschen oder andere Tage wählen.' : ''
        })) return;
        const neu = { id: H.uid('AW'), boot_id: b.id, platz_id: sommer.platz_id, von: x.von, bis: x.bis, notiz: x.notiz, gemeldet: 'Mitglied (Mein SSV)' };
        awok.disabled = true; d.abwesenheiten.push(neu);
        try { await HF.sichern(); } catch (e) { d.abwesenheiten = d.abwesenheiten.filter((a) => a !== neu); awok.disabled = false; return toast('Nicht gespeichert: ' + e.message); }
        AUF.schild = true; toast('Gemeldet – gute Fahrt!'); zeigen();
      });
    }
    document.querySelectorAll('[data-weg]').forEach((btn) => btn.addEventListener('click', () => abwesenheitBeenden(aw.find((a) => a.id === btn.dataset.weg))));
    $('#meine-daten').addEventListener('click', () => {
      const el = modal('<h2>Meine Daten ändern</h2><form id="mf" class="form" novalidate>' +
        '<label class="feld voll">Straße und Hausnummer<input name="strasse" autocomplete="street-address" value="' + esc(m.strasse || '') + '"></label>' +
        '<label class="feld">PLZ<input name="plz" inputmode="numeric" maxlength="5" pattern="[0-9]{4,5}" autocomplete="postal-code" value="' + esc(m.plz || '') + '"></label><label class="feld">Ort<input name="ort" autocomplete="address-level2" value="' + esc(m.ort || '') + '"></label>' +
        '<label class="feld">Telefon<input name="tel" type="tel" autocomplete="tel" value="' + esc(m.tel || '') + '"></label><label class="feld">E-Mail<input name="email" type="email" autocomplete="email" value="' + esc(m.email || '') + '"></label></form>' +
        '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="mok">Speichern</button></div>');
      const f = $('#mf', el); const knopf = $('#mok', el);
      knopf.addEventListener('click', async () => {
        const x = Object.fromEntries(Object.entries(Object.fromEntries(new FormData(f))).map(([k, v]) => [k, String(v).trim()]));
        if (!feldPruefen(f, { plz: plzFehler(x.plz), email: mailFehler(x.email, m.email) })) return;
        const alt = { strasse: m.strasse, plz: m.plz, ort: m.ort, tel: m.tel, email: m.email };
        knopf.disabled = true;
        try {
          if (DBM) await HF.meinDatenAendern(x);
          Object.assign(m, x);
          if (!DBM) await HF.sichern();
        } catch (e) { Object.assign(m, alt); knopf.disabled = false; return toast('Nicht gespeichert: ' + e.message); }
        $('#modal').innerHTML = ''; toast('Gespeichert – danke!'); zeigen();
      });
    });
    const dat = $('#daten'); if (dat) dat.addEventListener('click', () => {
      const el = modal('<h2>Daten aktualisieren</h2><form id="df" class="form" novalidate>' +
        '<label class="feld">Gewicht (t)<input name="gewicht_t" inputmode="decimal" required value="' + esc(H.zahl(b.gewicht_t, 1)) + '"></label><label class="feld">Kfz-Kennzeichen<input name="kfz" value="' + esc(m.kfz || '') + '"></label>' +
        '<label class="feld">Telefon<input name="tel" type="tel" value="' + esc(m.tel || '') + '"></label><label class="feld">E-Mail<input name="email" type="email" value="' + esc(m.email || '') + '"></label></form>' +
        '<p class="hinweis">Bankverbindung ändern? Bitte formlos an den Kassenwart – dafür braucht es ein neues SEPA-Mandat.</p><div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="dok">Speichern</button></div>');
      const f = $('#df', el); const knopf = $('#dok', el);
      knopf.addEventListener('click', async () => {
        const x = Object.fromEntries(Object.entries(Object.fromEntries(new FormData(f))).map(([k, v]) => [k, String(v).trim()]));
        const g = Number(x.gewicht_t.replace(/\s/g, '').replace(',', '.'));
        if (!feldPruefen(f, {
          gewicht_t: !x.gewicht_t ? 'Bitte das Gewicht deines Boots in Tonnen angeben, z. B. 4,5.' : !(g > 0 && g <= 60) ? 'Bitte das Gewicht in Tonnen angeben – eine Zahl zwischen 0,1 und 60, z. B. 4,5.' : '',
          email: mailFehler(x.email, m.email)
        })) return;
        const alt = { gewicht_t: b.gewicht_t, kfz: m.kfz, tel: m.tel, email: m.email };
        knopf.disabled = true;
        try {
          // Mitglieder ändern nur über die Datenbank-Funktion (nur eigene Kontakt- und Bootsdaten)
          if (DBM) await HF.meinDatenAendern({ tel: x.tel, email: x.email, kfz: x.kfz, boot_id: b.id, gewicht_t: String(g) });
          b.gewicht_t = g; m.kfz = x.kfz; m.tel = x.tel; m.email = x.email;
          if (!DBM) await HF.sichern();
        } catch (e) { b.gewicht_t = alt.gewicht_t; Object.assign(m, { kfz: alt.kfz, tel: alt.tel, email: alt.email }); knopf.disabled = false; return toast('Nicht gespeichert: ' + e.message); }
        $('#modal').innerHTML = ''; toast('Gespeichert.'); zeigen();
      });
    });
    document.querySelectorAll('.sek-info').forEach((x) => { if (x.textContent) x.title = x.textContent; });
  }
  /* Eingaben prüfen: Meldung steht verständlich direkt unter dem Feld, gespeichert wird nur, wenn alles passt */
  const MAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const mailFehler = (v, vorher) => !v ? (vorher ? 'Bitte deine E-Mail-Adresse angeben – an sie schicken wir deine Rechnungen.' : '') : !MAIL.test(v) ? 'Das ist keine gültige E-Mail-Adresse. Bitte so schreiben: name@beispiel.de' : '';
  const plzFehler = (v) => v && !/^[0-9]{4,5}$/.test(v) ? 'Die Postleitzahl besteht aus 5 Ziffern (im Ausland 4), z. B. 23611.' : '';
  function feldPruefen(form, fehler) {
    form.querySelectorAll('.feld-fehler').forEach((x) => x.remove());
    let erstes = null;
    Array.from(form.elements).forEach((i) => {
      if (!i.name || !(i.name in fehler)) return;
      const t = fehler[i.name] || ''; i.setCustomValidity(t);
      if (!t) { i.removeAttribute('aria-invalid'); i.removeAttribute('aria-describedby'); return; }
      const hinweis = document.createElement('small'); hinweis.className = 'feld-fehler'; hinweis.id = 'fehler-' + form.id + '-' + i.name; hinweis.setAttribute('role', 'alert'); hinweis.textContent = t;
      i.setAttribute('aria-invalid', 'true'); i.setAttribute('aria-describedby', hinweis.id); i.insertAdjacentElement('afterend', hinweis);
      if (!i.dataset.pruefung) { i.dataset.pruefung = '1'; i.addEventListener('input', () => { i.setCustomValidity(''); i.removeAttribute('aria-invalid'); const h = document.getElementById('fehler-' + form.id + '-' + i.name); if (h) h.remove(); }); }
      erstes = erstes || i;
    });
    if (erstes) { erstes.focus(); return false; }
    return true;
  }
  /* Früher zurück (oder geplante Abwesenheit löschen): ab heute ist der Platz wieder belegt.
   * Liegt dort noch ein Gast, wird der Hafenmeister gebraucht – das sagen wir deutlich. */
  async function abwesenheitBeenden(a) {
    if (!a) return;
    const laufend = a.von <= heute;
    if (!confirm(laufend ? 'Bist du wieder da? Ab heute ist dein Platz wieder belegt und wird nicht mehr an Gäste vergeben.' : 'Geplante Abwesenheit löschen?')) return;
    let gaeste = [];
    try {
      if (DBM) {
        const r = await window.SSV_SB.rpc('meine_abwesenheit_beenden', { p_id: a.id });
        gaeste = (r && r.gaeste) || [];
        if (laufend && a.von < heute) a.bis = H.tag(new Date(Date.now() - 864e5)); else d.abwesenheiten = d.abwesenheiten.filter((x) => x !== a);
      } else {
        const abr = (g) => H.tag(new Date(new Date(g.ankunft + 'T12:00:00').getTime() + g.naechte * 864e5));
        gaeste = d.gaeste.filter((g) => g.platz_id === a.platz_id && g.status !== 'storniert' && g.status !== 'abgereist' && abr(g) > heute && g.ankunft <= a.bis).map((g) => ({ bootsname: g.bootsname, bis: abr(g) }));
        if (laufend && a.von < heute) a.bis = H.tag(new Date(Date.now() - 864e5)); else d.abwesenheiten = d.abwesenheiten.filter((x) => x !== a);
        await HF.sichern();
      }
    } catch (e) { return toast('Nicht gespeichert: ' + e.message); }
    zeigen();
    if (gaeste.length) {
      const e = d.einstellungen;
      modal('<h2>Willkommen zurück!</h2><p class="hinweis warn">Auf deinem Platz ist noch ein Gast eingeplant: ' + gaeste.map((g) => '„' + esc(g.bootsname) + '“ bis ' + H.datum(g.bis)).join(', ') +
        '. Bitte kurz beim Hafenmeister melden, damit er den Gast umlegt.</p><div class="modal-fuss"><button class="btn" data-zu>Schließen</button>' +
        (e.hafenmeister_tel ? '<a class="btn primaer" href="tel:' + esc(String(e.hafenmeister_tel).replace(/\s/g, '')) + '">Hafenmeister anrufen</a>' : '') + '</div>');
    } else toast(laufend ? 'Willkommen zurück – dein Platz ist wieder belegt.' : 'Gelöscht.');
  }

  /* ---------------------------------------------------------- Versicherungsnachweis und Schadensmeldung */
  document.addEventListener('click', (e) => {
    if (e.target.closest('#nachweis')) nachweisDialog();
    if (e.target.closest('#schaden')) schadenDialog();
    if (e.target.closest('#ad-melden')) stundenDialog('');
    if (e.target.closest('#push-an')) pushAn();
    if (e.target.closest('#push-aus')) pushAus();
  });

  /* Arbeitsstunden melden – per QR-Code am Einsatztag (?einsatz=CODE) oder frei; der Verein bestätigt */
  function stundenDialog(code) {
    const m = Q.mitglied(mid); const heuteE = (d.arbeitseinsaetze || []).filter((x) => x.datum === heute || x.datum === H.tag(new Date(Date.now() - 864e5)));
    const e1 = heuteE[0];
    const el = modal('<h2>' + (code ? 'Check-in Arbeitseinsatz' : 'Arbeitsstunden melden') + '</h2>' + (code ? '<p>' + (e1 ? '<strong>' + esc(e1.titel) + '</strong> · ' + H.datum(e1.datum) : 'Arbeitseinsatz heute') + ' – danke fürs Mitmachen, ' + esc(m.vorname) + '!</p>' : '<p>Für Arbeit außerhalb eines Einsatztermins, z. B. Rasen mähen oder Steg reparieren.</p>') +
      '<form id="adf" class="form">' + (code ? '' : '<label class="feld">Datum<input name="datum" type="date" required value="' + heute + '" max="' + heute + '"></label>') +
      '<label class="feld">Stunden<input name="stunden" type="number" step="0.5" min="0.5" max="12" required inputmode="decimal" value="' + (e1 && code ? e1.stunden : 2) + '"></label>' +
      '<label class="feld voll">Was hast du gemacht?<input name="taetigkeit" maxlength="120" placeholder="z. B. Steg gestrichen"' + (code ? '' : ' required') + '></label></form><p class="hinweis" id="adf-info" hidden></p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="adok">Melden</button></div>');
    $('#adok', el).addEventListener('click', async () => {
      const fm = $('#adf', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm)); const info = $('#adf-info', el);
      try {
        if (DBM) await window.SSV_SB.rpc('mein_arbeitsdienst_melden', { p: { code, stunden: String(x.stunden).replace(',', '.'), taetigkeit: x.taetigkeit, datum: x.datum } });
        else {
          let einsatz = null;
          if (code) {
            const c = (d.arbeitseinsatz_codes || []).find((y) => y.code === code.toUpperCase()); einsatz = c && d.arbeitseinsaetze.find((y) => y.id === c.einsatz_id);
            if (!einsatz) throw new Error('Der Code passt zu keinem Arbeitseinsatz.');
            if (einsatz.datum !== heute && einsatz.datum !== H.tag(new Date(Date.now() - 864e5))) throw new Error('Der Check-in geht nur am Tag des Einsatzes.');
            if (d.arbeitsdienst.some((a) => a.mitglied_id === m.id && a.einsatz_id === einsatz.id && a.status !== 'abgelehnt')) throw new Error('Für diesen Einsatz bist du schon eingetragen.');
          }
          const st = Number(String(x.stunden).replace(',', '.')); if (!(st > 0 && st <= 12)) throw new Error('Bitte zwischen 0,5 und 12 Stunden angeben.');
          d.arbeitsdienst.push({ id: H.uid('AD'), mitglied_id: m.id, datum: einsatz ? einsatz.datum : x.datum, stunden: st, taetigkeit: x.taetigkeit || (einsatz && einsatz.titel) || 'Arbeitseinsatz', status: 'eingereicht', einsatz_id: einsatz ? einsatz.id : null, gemeldet: new Date().toISOString(), geprueft_von: '' });
          await HF.sichern();
        }
        if (DBM) { await HF.neuLaden(); d = HF.d; }
        $('#modal').innerHTML = ''; toast('Danke! Deine Stunden sind gemeldet – der Verein bestätigt sie.'); AUF.arbeitsdienst = true; zeigen();
      } catch (er) { info.textContent = er.message; info.className = 'hinweis warn'; info.hidden = false; }
    });
  }
  if (location.hash === '#veranstaltungen') setTimeout(() => { const el = document.querySelector('details.sek[data-sek=veranstaltungen]'); if (el) { el.open = true; AUF.veranstaltungen = true; el.scrollIntoView({ block: 'start' }); } }, 300);
  const einsatzCode = new URLSearchParams(location.search).get('einsatz');
  if (einsatzCode) { try { history.replaceState(null, '', location.pathname); } catch (e) { /* egal */ } setTimeout(() => stundenDialog(einsatzCode), 300); }

  /* Push-Benachrichtigungen (nur Vereinsdatenbank, wenn der Vorstand sie freigeschaltet hat) */
  const istIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const istApp = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  const b64 = (s) => { const p = '='.repeat((4 - s.length % 4) % 4); const r = atob((s + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from(r, (c) => c.charCodeAt(0)); };
  async function pushStand() {
    const box = $('#push-box'); if (!box) return;
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
      box.innerHTML = istIOS && !istApp ? '<p style="margin:0">Auf dem iPhone geht das so: unten auf <strong>Teilen</strong> → <strong>Zum Home-Bildschirm</strong>, dann „Mein SSV“ vom Home-Bildschirm öffnen und hier einschalten.</p>' : '<p style="margin:0">Dieser Browser kann leider keine Benachrichtigungen empfangen.</p>';
      return;
    }
    const reg = await navigator.serviceWorker.getRegistration('./'); const sub = reg && await reg.pushManager.getSubscription();
    box.innerHTML = sub && Notification.permission === 'granted' ? '<p style="margin:0 0 8px">Auf diesem Gerät eingeschaltet – wichtige Mitteilungen (z. B. Sturmwarnung) kommen direkt aufs Handy.</p><button class="btn klein" id="push-aus">Ausschalten</button>'
      : Notification.permission === 'denied' ? '<p style="margin:0">Benachrichtigungen sind in den Einstellungen deines Handys für diese Seite gesperrt.</p>'
        : '<p style="margin:0 0 8px">Wichtige Mitteilungen (z. B. Sturmwarnung) direkt aufs Handy bekommen.</p><button class="btn primaer" id="push-an">Benachrichtigungen einschalten</button>';
  }
  async function pushAn() {
    try {
      const reg = await navigator.serviceWorker.register('sw-mein.js', { scope: './' }); await navigator.serviceWorker.ready;
      if (await Notification.requestPermission() !== 'granted') return pushStand();
      const k = await window.SSV_SB.req('/functions/v1/push', { method: 'POST', body: { aktion: 'schluessel' } });
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64(k.public_key) }); const j = sub.toJSON();
      await window.SSV_SB.req('/rest/v1/push_abos?on_conflict=endpoint', { method: 'POST', body: [{ mitglied_id: mid, endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth, geraet: (istIOS ? 'iOS' : navigator.platform || '').slice(0, 40) }], prefer: 'resolution=merge-duplicates,return=minimal' });
      toast('Benachrichtigungen sind eingeschaltet.');
    } catch (e) { toast('Hat nicht geklappt: ' + e.message); }
    pushStand();
  }
  async function pushAus() {
    try { const reg = await navigator.serviceWorker.getRegistration('./'); const sub = reg && await reg.pushManager.getSubscription();
      if (sub) { await window.SSV_SB.req('/rest/v1/push_abos?endpoint=eq.' + encodeURIComponent(sub.endpoint), { method: 'DELETE' }).catch(() => {}); await sub.unsubscribe(); }
      toast('Benachrichtigungen ausgeschaltet.'); } catch (e) { toast(e.message); }
    pushStand();
  }
  function nachweisDialog() {
    const m = Q.mitglied(mid); const b = Q.booteVon(mid)[0]; if (!b) return;
    const el = modal('<h2>Versicherungsnachweis</h2><p>Lade die aktuelle Police oder Bestätigung deiner Versicherung hoch (PDF oder Foto). Der Verein prüft sie und hakt sie ab.</p><form id="nf" class="form">' +
      '<label class="feld">Versicherung<input name="versicherung" required value="' + esc(b.versicherung || '') + '"></label><label class="feld">versichert bis<input name="vers_bis" type="date" required value="' + esc(b.vers_bis || '') + '"></label>' +
      '<label class="feld voll">Nachweis (PDF oder Foto)<input name="datei" type="file" accept="application/pdf,image/*" required></label></form><p class="hinweis" id="nf-info" hidden></p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="nok">Hochladen</button></div>');
    $('#nok', el).addEventListener('click', async () => {
      const fm = $('#nf', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm)); const info = $('#nf-info', el);
      const knopf = $('#nok', el); knopf.disabled = true; knopf.textContent = 'Wird hochgeladen …';
      try {
        const datei = await HF.datei.lesen(fm.datei.files[0]);
        if (DBM) await window.SSV_SB.rpc('mein_nachweis_hochladen', { p: { boot_id: b.id, versicherung: x.versicherung, vers_bis: x.vers_bis, ...datei } });
        else { d.dokumente.push({ id: H.uid('D'), mitglied_id: m.id, boot_id: b.id, art: 'versicherung', hochgeladen: new Date().toISOString(), von: 'Mitglied (Mein SSV)', ...datei }); }
        Object.assign(b, { versicherung: x.versicherung, vers_bis: x.vers_bis, vers_status: 'eingereicht', vers_geprueft_am: null, vers_geprueft_von: null });
        if (!DBM) await HF.sichern();
        $('#modal').innerHTML = ''; toast('Danke – der Nachweis ist eingereicht.'); zeigen();
      } catch (er) { knopf.disabled = false; knopf.textContent = 'Hochladen'; info.textContent = er.message; info.className = 'hinweis warn'; info.hidden = false; }
    });
  }
  function schadenDialog() {
    const m = Q.mitglied(mid);
    const el = modal('<h2>Schaden melden</h2><form id="sf" class="form"><label class="feld voll">Was ist kaputt?<input name="titel" required maxlength="120" placeholder="z. B. Stromsäule Ostbrücke ohne Funktion"></label>' +
      '<label class="feld voll">Wo?<input name="ort" placeholder="z. B. Westbrücke bei Platz 40"></label><label class="feld voll">Beschreibung (optional)<textarea name="beschreibung" rows="3"></textarea></label>' +
      '<label class="feld voll">Foto (optional)<input name="datei" type="file" accept="image/*"></label></form><p class="hinweis" id="sf-info" hidden></p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="sok">Melden</button></div>');
    $('#sok', el).addEventListener('click', async () => {
      const fm = $('#sf', el); if (!fm.reportValidity()) return; const x = Object.fromEntries(new FormData(fm)); const knopf = $('#sok', el); knopf.disabled = true;
      try {
        const foto = fm.datei.files[0] ? await HF.datei.lesen(fm.datei.files[0]) : null;
        if (DBM) await window.SSV_SB.rpc('schaden_melden', { p: { titel: x.titel, ort: x.ort, beschreibung: x.beschreibung, ...(foto || {}) } });
        else {
          const t = { id: H.uid('T'), titel: x.titel, beschreibung: x.beschreibung, ort: x.ort, platz_id: '', boot_id: null, art: 'schaden', prioritaet: 'normal', status: 'offen', verantwortlich: '', faellig: '', erstellt: new Date().toISOString(), erstellt_von: Q.name(m) + ' (Mein SSV)', erledigt_am: '', notiz: '' };
          d.aufgaben.push(t); if (foto) d.dokumente.push({ id: H.uid('D'), mitglied_id: m.id, aufgabe_id: t.id, art: 'foto', hochgeladen: new Date().toISOString(), von: 'Mitglied (Mein SSV)', ...foto });
          await HF.sichern();
        }
        $('#modal').innerHTML = ''; toast('Danke für die Meldung!');
      } catch (er) { knopf.disabled = false; const i = $('#sf-info', el); i.textContent = er.message; i.className = 'hinweis warn'; i.hidden = false; }
    });
  }

  /* ---------------------------------------------------------- Getränkekasse */
  const monatText = (von) => new Date(von + 'T12:00:00').toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
  async function kasseZeigen(m, rechnungenZeigen) {
    let u;
    try { u = await KASSE.mitgliedUebersicht(m.id); } catch (e) { const box = $('#kasse'); if (box) box.innerHTML = '<p class="hinweis warn">' + esc(e.message) + '</p>'; return; }
    const box = $('#kasse');
    if (!u || mid !== m.id || !box) return; // inzwischen anderes Mitglied gewählt
    rechnungenZeigen(u.rechnungen.map((r) => ({ art: 'Getränke', nr: r.nr, datum: r.datum, text: monatText(r.von), summe: r.summe, bezahlt_am: r.bezahlt_am, sepa: r.sepa, faellig: r.faellig,
      href: KASSE_PFAD + 'drucken.html?art=rechnung&ids=' + r.id + '&mein=' + encodeURIComponent(m.id) })));
    const kg = $('#k-getraenke'); if (kg) { kg.querySelector('strong').textContent = H.geld(u.monat_summe); kg.querySelector('span').textContent = 'Getränke · noch nicht abgerechnet'; }
    $('#info-kasse').textContent = (u.hat_pin ? '' : 'Code fehlt · ') + H.geld(u.monat_summe) + ' im ' + new Date().toLocaleDateString('de-DE', { month: 'long' });
    const bs = u.buchungen.slice(0, 5);
    box.innerHTML = '<div class="kasse-zahlen"><div><small>Verbrauch ' + new Date().toLocaleDateString('de-DE', { month: 'long' }) + '</small><strong>' + H.geld(u.monat_summe) + '</strong></div><div><small>insgesamt noch nicht abgerechnet</small><strong>' + H.geld(u.offen_summe) + '</strong></div></div>' +
      '<p style="margin:0 0 10px;font-size:13px;color:var(--muted)">Der Verbrauch wird am Monatsende abgerechnet und erscheint dann unter „Meine Rechnungen“.</p>' +
      (u.gesperrt_bis ? '<p class="hinweis warn">Dein Code wurde nach 5 Fehlversuchen kurz gesperrt. Mit einem neuen Code bist du sofort wieder frei.</p>' : '') +
      '<p style="margin:0 0 10px">' + (u.hat_pin
        ? 'Dein Code fürs iPad ist festgelegt. Vergessen? Leg einfach einen neuen fest.'
        : 'Du hast noch keinen Code fürs iPad. Leg ihn hier fest – oder beim ersten Mal an der Kasse mit deiner Mitgliedsnummer <strong>' + esc(m.nr) + '</strong>.') + '</p>' +
      '<div class="aktionen"><button class="btn' + (u.hat_pin ? '' : ' primaer') + '" id="code">' + (u.hat_pin ? 'Code ändern' : 'Code festlegen') + '</button></div>' +
      (bs.length ? '<table class="tab" style="margin-top:12px"><thead><tr><th>Letzte Buchungen</th><th class="r">Betrag</th></tr></thead><tbody>' + bs.map((x) =>
        '<tr' + (x.storniert_am ? ' class="blass"' : '') + '><td>' + x.anzahl + ' ' + (x.einheit === 'kasten' ? (x.anzahl === 1 ? 'Kasten' : 'Kästen') : '×') + ' ' + esc(x.produkt_name) + (x.storniert_am ? ' (storniert)' : '') +
        '<br><small style="color:var(--muted)">' + new Date(x.zeit).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) + ' Uhr</small></td><td class="r">' + H.geld(x.betrag) + '</td></tr>').join('') + '</tbody></table>' : '<p class="leer" style="margin-top:12px">Noch keine Buchungen.</p>');
    $('#code').addEventListener('click', () => codeAendern(m, u.hat_pin));
  }
  function codeAendern(m, hatPin) {
    const feld = (n, l) => '<label class="feld">' + l + '<input class="code-feld" name="' + n + '" type="password" inputmode="numeric" autocomplete="off" maxlength="4" pattern="[0-9]{4}" required></label>';
    const el = modal('<h2>' + (hatPin ? 'Getränke-Code ändern' : 'Getränke-Code festlegen') + '</h2><p>Mit diesem 4-stelligen Code meldest du dich am iPad der Getränkekasse an. Bitte nicht weitergeben.</p>' +
      '<form id="cf" class="form">' + feld('a', 'Neuer Code') + feld('b', 'Code wiederholen') + '</form><p class="hinweis" id="cf-fehler" hidden></p>' +
      '<div class="modal-fuss"><button class="btn" data-zu>Abbrechen</button><button class="btn primaer" id="cok">Speichern</button></div>');
    const fehler = (t) => { const f = $('#cf-fehler', el); f.textContent = t; f.className = 'hinweis warn'; f.hidden = false; };
    $('input', el).focus();
    const speichern = async () => {
      const x = Object.fromEntries(new FormData($('#cf', el)));
      if (!/^\d{4}$/.test(x.a)) return fehler('Der Code muss aus genau 4 Ziffern bestehen.');
      if (x.a !== x.b) return fehler('Die beiden Eingaben sind unterschiedlich.');
      try { await KASSE.mitgliedPinAendern(m.id, x.a); } catch (e) { return fehler(e.message); }
      $('#modal').innerHTML = ''; toast('Neuer Code gespeichert – gilt ab sofort an der Kasse.'); zeigen();
    };
    $('#cok', el).addEventListener('click', speichern);
    $('#cf', el).addEventListener('submit', (e) => { e.preventDefault(); speichern(); });
  }

  // Änderungen aus anderen Fenstern (Verwaltung, Kasse, Gast-Anmeldung) übernehmen
  window.addEventListener('storage', (e) => {
    if (e.key === 'ssv-hafen-demo-v1') { d = HF.laden(); if (!Q.mitglied(mid)) { location.reload(); return; } zeigen(); }   // Demo anderswo zurückgesetzt: Mitglied gibt es nicht mehr
    else if (e.key === 'ssvg-demo-v1' && Q.mitglied(mid)) zeigen();
  });
  zeigen();
})();
