/* SSV Getränkekasse – Datenschicht
 *
 * Eine Schnittstelle, zwei Speicher:
 *   DemoSpeicher      – localStorage, mit Beispieldaten (zum Ausprobieren)
 *   SupabaseSpeicher  – zentrale Datenbank über REST/RPC (supabase/schema.sql)
 * Alle Methoden sind async und liefern dieselben Datenformen.
 */
(function () {
  'use strict';

  const K = window.SSV_KONFIG || { modus: 'demo' };
  const ct = (v) => Math.round(Number(v) * 100);
  const eur = (c) => Math.round(c) / 100;
  const pad = (n, l = 2) => String(n).padStart(l, '0');
  const tag = (d) => { d = new Date(d); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
  const uuid = () => (crypto.randomUUID ? crypto.randomUUID()
    : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16);
      }));

  const STANDARD_EINSTELLUNGEN = {
    verein_name: 'Schwartauer Segler-Verein e.V.',
    verein_strasse: 'Zur Teerhofsinsel 5B',
    verein_ort: '23554 Lübeck',
    verein_email: 'info@ssv-net.de',
    steuernummer: '22 290 72188',
    bank: '[PLATZHALTER Bank]',
    iban: '',
    bic: '',
    zahlungsziel_tage: 14,
    rechnung_praefix: 'SSV-G',
    steuerhinweis: '[PLATZHALTER: Umsatzsteuer-Hinweis mit Kassenwart/Steuerberater abstimmen]',
    glaeubiger_id: '',
    sepa_text: '',
    kassenwart_name: 'Carsten Schneider',
    fusstext: 'Danke, dass du dabei bist – und allzeit gute Fahrt!',
    storno_minuten: 15,
    abmelden_sekunden: 60,
    pin_selbst_festlegen: true,   // Mitglieder legen ihren Code beim ersten Mal selbst fest
    pin_erst_nr_pruefen: false    // keine Mitgliedsnummer abfragen (Wunsch des Vereins, Nachtrag 19)
  };

  /* Mitglieder dürfen jeden 4-stelligen Code wählen (auch 1234). Nur der Zufalls-Code der Verwaltung meidet naheliegende Muster. */
  const SCHLECHTE_PIN = /^(\d)\1{3}$|^(0123|1234|2345|3456|4567|5678|6789|9876|8765|7654|6543|5432|4321|3210|1212|2580|0000)$/;
  const pinZuEinfach = (p) => SCHLECHTE_PIN.test(p);

  /* Zufalls-PIN ohne allzu naheliegende Muster */
  function zufallsPin() {
    let p;
    do {
      const a = new Uint32Array(1); crypto.getRandomValues(a);
      p = pad(a[0] % 10000, 4);
    } while (pinZuEinfach(p));
    return p;
  }

  /* Verdichtet Buchungen zu Rechnungspositionen */
  function verdichten(buchungen) {
    const map = new Map();
    buchungen.forEach((b) => {
      const k = b.produkt_name + '|' + b.einheit + '|' + b.einzelpreis;
      const p = map.get(k) || { name: b.produkt_name, einheit: b.einheit, einzelpreis: b.einzelpreis, anzahl: 0, stueck: 0, betrag: 0 };
      p.anzahl += b.anzahl; p.stueck += b.stueck; p.betrag = eur(ct(p.betrag) + ct(b.betrag));
      map.set(k, p);
    });
    return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, 'de') || a.einheit.localeCompare(b.einheit));
  }

  /* ======================================================== Demo-Speicher */
  class DemoSpeicher {
    constructor() { this.modus = 'demo'; this.KEY = 'ssvg-demo-v1'; this._laden(); }

    _laden() {
      try { this.d = JSON.parse(localStorage.getItem(this.KEY)); } catch (e) { this.d = null; }
      // Neu anlegen, wenn noch keine Daten da sind – oder der Hafen-Manager inzwischen einen ganz anderen Mitgliederstamm hat (Demo zurückgesetzt)
      const hm = this.d && this.d.version === 2 && this._hafenMitglieder();
      const fremd = hm && hm.length && !this.d.mitglieder.some((m) => hm.some((h) => h.id === m.id));
      if (!this.d || this.d.version !== 2 || fremd) {
        this.d = this._beispieldaten();
        // Historie: September abgerechnet und eingezogen, Oktober abgerechnet
        const j = new Date(); const vm = (k) => new Date(j.getFullYear(), j.getMonth() - k, 1);
        const ende = (d) => tag(new Date(d.getFullYear(), d.getMonth() + 1, 0));
        [2, 1].forEach((k) => {
          const a = vm(k); this._rechnungenErstellen(tag(a), ende(a), tag(new Date(a.getFullYear(), a.getMonth() + 1, 3)));
          if (k === 2) this.d.rechnungen.forEach((r) => { r.bezahlt_am = r.faellig; });
        });
        // Was schon abgerechnet ist, hat der Kassenwart damals geprüft
        this.d.buchungen.forEach((b) => { if (b.rechnung_id) { b.bestaetigt_am = b.zeit; b.bestaetigt_von = this.d.einstellungen.kassenwart_name || 'Kassenwart'; } });
        this._sichern();
      }
      this._abgleich();
      // Jugendschutz: Bier, Radler, Sekt erst ab 16 (ältere Demo-Daten nachrüsten)
      this.d.produkte.forEach((p) => { if (!('ab_alter' in p)) p.ab_alter = /Pils|Radler|Sekt|Bier|Wein/.test(p.name) ? 16 : null; });
      // Freigabe durch den Kassenwart (ältere Demo-Daten nachrüsten: Abgerechnetes gilt als bestätigt, der Rest ist offen)
      const kw = (this.d.einstellungen && this.d.einstellungen.kassenwart_name) || 'Kassenwart';
      let neu = false;
      this.d.buchungen.forEach((b) => { if (!('bestaetigt_am' in b)) { neu = true; b.bestaetigt_am = b.rechnung_id ? b.zeit : null; b.bestaetigt_von = b.rechnung_id ? kw : null; } });
      if (neu) this._sichern();
    }
    /* Gemeinsamer Mitgliederstamm: In der Demo kommen die Mitglieder aus dem Hafen-Manager
       (gleiche IDs), damit „Mein SSV“ Hafen- und Getränkerechnungen zusammen zeigen kann. */
    _hafenMitglieder() {
      const HF = window.HAFEN; if (!HF || !HF.laden) return null;
      try { return (HF.d || HF.laden()).mitglieder.filter((m) => m.art !== 'gast'); } catch (e) { return null; }
    }
    _abgleich() {
      const hm = this._hafenMitglieder(); if (!hm) return;
      let geaendert = false;
      hm.forEach((h) => {
        let m = this._m(h.id);
        if (!m) { m = { id: h.id, pin: null, fehlversuche: 0, gesperrt_bis: null, aktiv: true, sepa: !!h.iban, notiz: '' }; this.d.mitglieder.push(m); geaendert = true; }
        ['nr', 'vorname', 'nachname', 'email', 'strasse', 'plz', 'ort', 'geburtsdatum'].forEach((f) => { if (m[f] !== h[f]) { m[f] = h[f]; geaendert = true; } });
        const mr = h.mandat_ref || ''; if (m.mandatsreferenz !== mr) { m.mandatsreferenz = mr; geaendert = true; }
      });
      if (geaendert) this._sichern();
    }
    _sichern() { try { localStorage.setItem(this.KEY, JSON.stringify(this.d)); } catch (e) { console.warn('Demo-Daten konnten nicht gespeichert werden', e); } }
    zuruecksetzen() { localStorage.removeItem(this.KEY); this._laden(); }

    _beispieldaten() {
      const namen = [
        ['Anna', 'Albers'], ['Bernd', 'Brandt'], ['Clara', 'Claußen'], ['Dirk', 'Dahl'], ['Elke', 'Evers'],
        ['Frank', 'Fiedler'], ['Greta', 'Grote'], ['Hannes', 'Hinz'], ['Ida', 'Iversen'], ['Jan', 'Jessen'],
        ['Karin', 'Krüger'], ['Lars', 'Lorenzen'], ['Maren', 'Möller'], ['Nils', 'Nissen'], ['Ole', 'Ohlsen'],
        ['Petra', 'Paulsen'], ['Rolf', 'Rasmussen'], ['Sina', 'Schröder'], ['Timo', 'Thiessen'], ['Ute', 'Urban'],
        ['Volker', 'Voigt'], ['Wiebke', 'Wulf'], ['Svenja', 'Sievers'], ['Henning', 'Hansen']
      ];
      const orte = ['Bad Schwartau', 'Lübeck', 'Stockelsdorf', 'Ratekau'];
      // Jedes dritte Mitglied hat noch keinen Code – so lässt sich „Code beim ersten Mal festlegen“ ausprobieren
      const hm = this._hafenMitglieder();
      const mitglieder = hm
        ? hm.map((h, i) => ({ id: h.id, nr: h.nr, vorname: h.vorname, nachname: h.nachname, email: h.email, strasse: h.strasse, plz: h.plz, ort: h.ort,
            sepa: !!h.iban, mandatsreferenz: h.mandat_ref || '', notiz: '', aktiv: true, pin: i % 3 === 2 ? null : '1234', fehlversuche: 0, gesperrt_bis: null }))
        : namen.map(([v, n], i) => ({
            id: uuid(), nr: String(1001 + i), vorname: v, nachname: n,
            email: (v + '.' + n).toLowerCase().replace(/ß/g, 'ss').replace(/ü/g, 'ue').replace(/ö/g, 'oe') + '@beispiel.de',
            strasse: 'Beispielweg ' + (i + 3), plz: '2361' + (i % 10), ort: orte[i % orte.length],
            sepa: i !== 4, mandatsreferenz: 'SSV-' + (1001 + i), notiz: '', aktiv: true, pin: i % 3 === 2 ? null : '1234', fehlversuche: 0, gesperrt_bis: null
          }));
      const mitPin = mitglieder.filter((m) => m.pin);
      const P = (name, emoji, farbe, preis, kg, kp, sort) => ({ id: uuid(), name, emoji, farbe, preis, kasten_groesse: kg, kasten_preis: kp, sort, aktiv: true });
      const produkte = [
        P('Pils 0,33 l', '🍺', '#e0a526', 1.5, 24, 30, 1),
        P('Radler 0,33 l', '🍋', '#d9c23c', 1.5, 24, 30, 2),
        P('Alkoholfrei 0,33 l', '🌾', '#8fae3b', 1.5, 24, 30, 3),
        P('Cola 0,33 l', '🥤', '#b2272d', 1.2, 24, 24, 4),
        P('Apfelschorle 0,5 l', '🍏', '#4f9a3c', 1.2, 12, 12, 5),
        P('Wasser 0,7 l', '💧', '#2f7fc1', 1.0, 12, 10, 6),
        P('Kaffee', '☕', '#6b4a32', 1.0, null, null, 7),
        P('Sekt 0,2 l', '🥂', '#c79a5b', 3.0, null, null, 8)
      ];
      // Buchungsverlauf der letzten ~10 Wochen (deterministischer Zufall)
      let s = 7; const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
      const buchungen = []; const jetzt = Date.now();
      for (let i = 0; i < 260; i++) {
        const m = mitPin[Math.floor(rnd() * mitPin.length)];
        const p = produkte[Math.floor(rnd() * 6.6)];
        const kasten = p.kasten_groesse && rnd() < 0.06;
        const anzahl = kasten ? 1 : 1 + Math.floor(rnd() * rnd() * 4);
        const zeit = new Date(jetzt - rnd() * 70 * 864e5);
        zeit.setHours(11 + Math.floor(rnd() * 9), Math.floor(rnd() * 60));
        if (zeit.getTime() > jetzt) continue;
        const ep = kasten ? p.kasten_preis : p.preis;
        buchungen.push({
          id: uuid(), mitglied_id: m.id, produkt_id: p.id, produkt_name: p.name, einheit: kasten ? 'kasten' : 'stk',
          anzahl, stueck: anzahl * (kasten ? p.kasten_groesse : 1), einzelpreis: ep, betrag: eur(ct(ep) * anzahl),
          zeit: zeit.toISOString(), quelle: 'kasse', storniert_am: null, rechnung_id: null, bestaetigt_am: null, bestaetigt_von: null
        });
      }
      buchungen.sort((a, b) => a.zeit.localeCompare(b.zeit));
      return { version: 2, mitglieder, produkte, buchungen, rechnungen: [], einstellungen: { ...STANDARD_EINSTELLUNGEN, bank: 'Demo-Bank [PLATZHALTER]', glaeubiger_id: 'DE98ZZZ09999999999 [DEMO]' }, admin: { email: 'kassenwart@demo', passwort: 'demo' } };
    }

    _m(id) { return this.d.mitglieder.find((m) => m.id === id); }
    _summen(mid) {
      const jetzt = new Date(); let monat = 0, offen = 0;
      this.d.buchungen.forEach((b) => {
        if (b.mitglied_id !== mid || b.storniert_am) return;
        const z = new Date(b.zeit);
        if (z.getFullYear() === jetzt.getFullYear() && z.getMonth() === jetzt.getMonth()) monat += ct(b.betrag);
        if (!b.rechnung_id) offen += ct(b.betrag);
      });
      return { monat_summe: eur(monat), offen_summe: eur(offen) };
    }
    _pruefen(mid, pin) {
      const m = this._m(mid);
      if (!m || !m.aktiv) return { ok: false, fehler: 'mitglied' };
      if (!m.pin) return { ok: false, fehler: 'kein_pin' };
      if (m.gesperrt_bis && new Date(m.gesperrt_bis) > new Date()) return { ok: false, fehler: 'gesperrt', gesperrt_bis: m.gesperrt_bis };
      if (m.pin !== pin) {
        const n = m.fehlversuche + 1; m.fehlversuche = n;   // Sperre wird mit jeder Fehlerserie länger (5 → 15 → 45 Min. …)
        m.gesperrt_bis = n % 5 === 0 ? new Date(Date.now() + Math.min(1440, 5 * Math.pow(3, n / 5 - 1)) * 60e3).toISOString() : null;
        this._sichern();
        return { ok: false, fehler: 'pin', rest: n % 5 ? 5 - n % 5 : 0 };
      }
      if (m.fehlversuche || m.gesperrt_bis) { m.fehlversuche = 0; m.gesperrt_bis = null; this._sichern(); }
      return null;
    }
    _alter(m) { if (!m || !m.geburtsdatum) return null; const g = new Date(m.geburtsdatum + 'T12:00:00'), h = new Date(); return h.getFullYear() - g.getFullYear() - (h < new Date(h.getFullYear(), g.getMonth(), g.getDate()) ? 1 : 0); }
    _buchen(mid, posten, quelle, zeit) {
      if (!Array.isArray(posten) || !posten.length) throw new Error('Keine Posten');
      let summe = 0; const neu = [];
      posten.forEach((po) => {
        const p = this.d.produkte.find((x) => x.id === po.produkt_id && x.aktiv);
        const alt = this._alter(this._m(mid));
        if (p && p.ab_alter && alt != null && alt < p.ab_alter) throw new Error(p.name + ' gibt es erst ab ' + p.ab_alter + ' Jahren.');
        if (!p) throw new Error('Produkt nicht verfügbar');
        const kasten = po.einheit === 'kasten';
        if (kasten && !p.kasten_groesse) throw new Error('Kein Kasten für ' + p.name);
        const anzahl = Math.max(1, Math.min(99, parseInt(po.anzahl, 10) || 1));
        const ep = kasten ? p.kasten_preis : p.preis;
        neu.push({
          id: uuid(), mitglied_id: mid, produkt_id: p.id, produkt_name: p.name, einheit: kasten ? 'kasten' : 'stk',
          anzahl, stueck: anzahl * (kasten ? p.kasten_groesse : 1), einzelpreis: ep, betrag: eur(ct(ep) * anzahl),
          zeit: (zeit ? new Date(zeit) : new Date()).toISOString(), quelle, storniert_am: null, rechnung_id: null, bestaetigt_am: null, bestaetigt_von: null
        });
        summe += ct(ep) * anzahl;
      });
      this.d.buchungen.push(...neu); this._sichern();
      return eur(summe);
    }

    /* ---- Kasse ---- */
    async kasseStatus() { return { eingerichtet: true, name: 'Demo-Kasse' }; }
    async kasseMitglieder() {
      return this.d.mitglieder.filter((m) => m.aktiv)
        .map(({ id, vorname, nachname, pin }) => ({ id, vorname, nachname, hat_pin: !!pin }))
        .sort((a, b) => a.nachname.localeCompare(b.nachname, 'de') || a.vorname.localeCompare(b.vorname, 'de'));
    }
    async kasseProdukte() { return this.d.produkte.filter((p) => p.aktiv).sort((a, b) => a.sort - b.sort); }
    async kasseLogin(mid, pin) {
      const f = this._pruefen(mid, pin); if (f) return f;
      const m = this._m(mid);
      return { ok: true, vorname: m.vorname, nachname: m.nachname, alter: this._alter(m), ...this._summen(mid) };
    }
    async kasseBuchenNach(mid, pin, posten) { return this.kasseBuchen(mid, pin, posten); }
    // Veranstaltungen: Demo nutzt die Regeln des Hafen-Managers (gleicher Browser, gleiche Mitglieder-IDs)
    async kasseVeranstaltungen(mid, pin) {
      const f = this._pruefen(mid, pin); if (f) return f;
      const H = window.HAFEN; if (!H || !H.laden || !H.meineVeranstaltungen) return { ok: true, liste: [] };
      H.laden(); return { ok: true, liste: H.meineVeranstaltungen(mid) };
    }
    async kasseZusage(mid, pin, p) {
      const f = this._pruefen(mid, pin); if (f) return f;
      const H = window.HAFEN; if (!H || !H.zusageSetzen) throw new Error('Veranstaltungen sind hier nicht verfügbar.');
      H.laden(); await H.zusageSetzen(mid, p, 'kasse'); return { ok: true, antwort: p.antwort };
    }
    async kasseMitteilungen() {   // Demo: Mitteilungen aus dem Hafen-Manager (gleicher Browser)
      const H = window.HAFEN; if (!H || !H.laden) return []; const heute = new Date().toISOString().slice(0, 10);
      return (H.laden().mitteilungen || []).filter((x) => x.zielgruppe === 'alle' && (!x.gueltig_bis || x.gueltig_bis >= heute)).sort((a, b) => (b.wichtig ? 1 : 0) - (a.wichtig ? 1 : 0)).slice(0, 3);
    }
    async kasseBuchen(mid, pin, posten) {
      const f = this._pruefen(mid, pin); if (f) return f;
      const summe = this._buchen(mid, posten, 'kasse');
      return { ok: true, summe, ...this._summen(mid) };
    }
    async kasseOptionen() {
      const e = { ...STANDARD_EINSTELLUNGEN, ...this.d.einstellungen };
      return { pin_selbst_festlegen: !!e.pin_selbst_festlegen, pin_erst_nr_pruefen: false,
        abmelden_sekunden: Number(e.abmelden_sekunden) || 60, storno_minuten: Number(e.storno_minuten) || 15 };
    }
    /* Erstes Mal an der Kasse: Mitglied legt seinen Code selbst fest (zweimal eingeben, keine Mitgliedsnummer) */
    async kassePinFestlegen(mid, pin) {
      const o = await this.kasseOptionen(); const m = this._m(mid);
      if (!o.pin_selbst_festlegen) return { ok: false, fehler: 'aus' };
      if (!m || !m.aktiv) return { ok: false, fehler: 'mitglied' };
      if (m.pin) return { ok: false, fehler: 'schon_gesetzt' };
      if (m.gesperrt_bis && new Date(m.gesperrt_bis) > new Date()) return { ok: false, fehler: 'gesperrt', gesperrt_bis: m.gesperrt_bis };
      if (!/^\d{4}$/.test(pin)) return { ok: false, fehler: 'format' };
      m.pin = pin; m.fehlversuche = 0; m.gesperrt_bis = null; this._sichern();
      return { ok: true, vorname: m.vorname, nachname: m.nachname, ...this._summen(mid) };
    }
    async kasseVerlauf(mid, pin) {
      const f = this._pruefen(mid, pin); if (f) return f;
      const grenze = Date.now() - this.d.einstellungen.storno_minuten * 60e3;
      const liste = this.d.buchungen.filter((b) => b.mitglied_id === mid)
        .sort((a, b) => b.zeit.localeCompare(a.zeit)).slice(0, 15)
        .map((b) => ({ ...b, storniert: !!b.storniert_am, stornierbar: !b.storniert_am && !b.rechnung_id && new Date(b.zeit).getTime() > grenze }));
      return { ok: true, buchungen: liste };
    }
    async kasseStorno(mid, pin, bid) {
      const f = this._pruefen(mid, pin); if (f) return f;
      const b = this.d.buchungen.find((x) => x.id === bid && x.mitglied_id === mid);
      const grenze = Date.now() - this.d.einstellungen.storno_minuten * 60e3;
      if (!b || b.storniert_am || b.rechnung_id || new Date(b.zeit).getTime() <= grenze) return { ok: false, fehler: 'storno' };
      b.storniert_am = new Date().toISOString(); this._sichern();
      return { ok: true, ...this._summen(mid) };
    }

    /* ---- Verwaltung ---- */
    async anmelden(email, pw) {
      if (email.trim().toLowerCase() === this.d.admin.email && pw === this.d.admin.passwort) {
        try { sessionStorage.setItem('ssvg-demo-admin', '1'); } catch (e) { this._admin = true; } return true;
      }
      throw new Error('E-Mail oder Passwort falsch.');
    }
    async abmelden() { this._admin = false; try { sessionStorage.removeItem('ssvg-demo-admin'); } catch (e) { /* egal */ } }
    async angemeldet() { try { return this._admin || sessionStorage.getItem('ssvg-demo-admin') === '1'; } catch (e) { return !!this._admin; } }

    async mitglieder() {
      return this.d.mitglieder.map(({ pin, ...m }) => ({ ...m, hat_pin: !!pin }))
        .sort((a, b) => a.nachname.localeCompare(b.nachname, 'de') || a.vorname.localeCompare(b.vorname, 'de'));
    }
    async mitgliedSpeichern(m) {
      const felder = ['nr', 'vorname', 'nachname', 'email', 'strasse', 'plz', 'ort', 'sepa', 'mandatsreferenz', 'notiz', 'aktiv'];
      let z = m.id && this._m(m.id);
      if (!z) { z = { id: uuid(), pin: null, fehlversuche: 0, gesperrt_bis: null, aktiv: true, sepa: true }; this.d.mitglieder.push(z); }
      felder.forEach((f) => { if (f in m) z[f] = m[f]; });
      this._sichern(); return { ...z, pin: undefined, hat_pin: !!z.pin };
    }
    async mitgliedLoeschen(id) {
      if (this.d.buchungen.some((b) => b.mitglied_id === id)) { this._m(id).aktiv = false; this._sichern(); return 'deaktiviert'; }
      this.d.mitglieder = this.d.mitglieder.filter((m) => m.id !== id); this._sichern(); return 'geloescht';
    }
    async pinSetzen(id, pin) {
      if (!/^\d{4}$/.test(pin)) throw new Error('Code muss vierstellig sein');
      const m = this._m(id); m.pin = pin; m.fehlversuche = 0; m.gesperrt_bis = null; this._sichern();
    }
    /* Code löschen – das Mitglied legt beim nächsten Mal an der Kasse selbst einen neuen fest */
    async pinZuruecksetzen(id) { const m = this._m(id); m.pin = null; m.fehlversuche = 0; m.gesperrt_bis = null; this._sichern(); }

    /* ---- Mein SSV (Mitglied ist dort mit eigenem Konto angemeldet; Demo: per Auswahl) ---- */
    async mitgliedUebersicht(mid) {
      this._laden(); const m = this._m(mid);
      if (!m) return null;
      return {
        hat_pin: !!m.pin, gesperrt_bis: m.gesperrt_bis && new Date(m.gesperrt_bis) > new Date() ? m.gesperrt_bis : null, ...this._summen(mid),
        buchungen: this.d.buchungen.filter((b) => b.mitglied_id === mid).sort((a, b) => b.zeit.localeCompare(a.zeit)).slice(0, 20),
        rechnungen: this.d.rechnungen.filter((r) => r.mitglied_id === mid && !r.storniert_am).sort((a, b) => b.nr.localeCompare(a.nr))
          .map(({ id, nr, datum, von, bis, faellig, summe, sepa, bezahlt_am }) => ({ id, nr, datum, von, bis, faellig, summe, sepa, bezahlt_am }))
      };
    }
    async mitgliedPinAendern(mid, pin) {
      this._laden(); const m = this._m(mid);
      if (!m) throw new Error('Mitglied nicht gefunden.');
      if (!/^\d{4}$/.test(pin)) throw new Error('Der Code muss aus genau 4 Ziffern bestehen.');
      m.pin = pin; m.fehlversuche = 0; m.gesperrt_bis = null; this._sichern();
    }
    /* Eigene Rechnungen für die Druckansicht (nur die des Mitglieds) */
    async meineRechnungen(mid, ids) { this._laden(); return this.d.rechnungen.filter((r) => r.mitglied_id === mid && ids.includes(r.id)); }

    async produkte() { return [...this.d.produkte].sort((a, b) => a.sort - b.sort); }
    async produktSpeichern(p) {
      let z = p.id && this.d.produkte.find((x) => x.id === p.id);
      if (!z) { z = { id: uuid(), aktiv: true, sort: this.d.produkte.length + 1 }; this.d.produkte.push(z); }
      Object.assign(z, p, { id: z.id }); this._sichern(); return z;
    }
    async produktLoeschen(id) {
      const p = this.d.produkte.find((x) => x.id === id);
      if (this.d.buchungen.some((b) => b.produkt_id === id)) { p.aktiv = false; this._sichern(); return 'deaktiviert'; }
      this.d.produkte = this.d.produkte.filter((x) => x.id !== id); this._sichern(); return 'geloescht';
    }

    async buchungen({ von, bis, mitglied_id, rechnung_ids } = {}) {
      return this.d.buchungen.filter((b) => {
        if (rechnung_ids) return rechnung_ids.includes(b.rechnung_id);
        const t = tag(b.zeit);
        return (!von || t >= von) && (!bis || t <= bis) && (!mitglied_id || b.mitglied_id === mitglied_id);
      }).sort((a, b) => b.zeit.localeCompare(a.zeit));
    }
    async buchungStornieren(id) {
      const b = this.d.buchungen.find((x) => x.id === id);
      if (!b || b.rechnung_id) throw new Error('Bereits abgerechnete Buchungen bitte über die Rechnung stornieren.');
      b.storniert_am = new Date().toISOString(); this._sichern();
    }
    async buchungNachtragen(mid, posten, zeit) { return this._buchen(mid, posten, 'nachtrag', zeit); }

    async rechnungen() { return [...this.d.rechnungen].sort((a, b) => b.nr.localeCompare(a.nr)); }
    async rechnungenLaden(ids) { return this.d.rechnungen.filter((r) => ids.includes(r.id)); }
    async rechnungenErstellen(von, bis, datum) { return this._rechnungenErstellen(von, bis, datum); }
    _rechnungenErstellen(von, bis, datum) {
      if (von > bis) throw new Error('Zeitraum ungültig');
      const e = this.d.einstellungen; const jahr = datum.slice(0, 4); const praefix = e.rechnung_praefix || 'SSV-G';
      let lfd = this.d.rechnungen.filter((r) => r.nr.startsWith(praefix + '-' + jahr + '-'))
        .reduce((mx, r) => Math.max(mx, parseInt(r.nr.split('-').pop(), 10)), 0);
      const offen = this.d.buchungen.filter((b) => !b.rechnung_id && !b.storniert_am && tag(b.zeit) >= von && tag(b.zeit) <= bis);
      const proMitglied = new Map();
      offen.forEach((b) => { if (!proMitglied.has(b.mitglied_id)) proMitglied.set(b.mitglied_id, []); proMitglied.get(b.mitglied_id).push(b); });
      const reihenfolge = [...proMitglied.keys()].map((id) => this._m(id))
        .sort((a, b) => a.nachname.localeCompare(b.nachname, 'de') || a.vorname.localeCompare(b.vorname, 'de'));
      const faellig = new Date(datum); faellig.setDate(faellig.getDate() + Number(e.zahlungsziel_tage || 14));
      reihenfolge.forEach((m) => {
        const bs = proMitglied.get(m.id); lfd += 1;
        const r = {
          id: uuid(), nr: praefix + '-' + jahr + '-' + pad(lfd, 4), mitglied_id: m.id, datum, von, bis, faellig: tag(faellig),
          summe: eur(bs.reduce((s, b) => s + ct(b.betrag), 0)),
          empfaenger: { nr: m.nr, vorname: m.vorname, nachname: m.nachname, strasse: m.strasse, plz: m.plz, ort: m.ort, email: m.email, mandatsreferenz: m.mandatsreferenz || '' },
          positionen: verdichten(bs), sepa: !!m.sepa, bezahlt_am: null, storniert_am: null, erstellt: new Date().toISOString()
        };
        this.d.rechnungen.push(r); bs.forEach((b) => { b.rechnung_id = r.id; });
      });
      this._sichern(); return reihenfolge.length;
    }
    async rechnungBezahlt(id, datum) { const r = this.d.rechnungen.find((x) => x.id === id); r.bezahlt_am = datum; this._sichern(); }
    /* Freigabe: nur der Kassenwart bestätigt Buchungen; der Vorstand sieht sie mit Stand.
       Demo: im Kassenwart-Bereich immer erlaubt, im Hafen-Manager nur in der Rolle „Kassenwart“. */
    async darfBestaetigen() {
      if (!/ssv-hafen\//.test(location.pathname)) return true;
      try { return sessionStorage.getItem('ssv-hafen-rolle') === 'kassenwart'; } catch (e) { return false; }
    }
    async buchungenBestaetigen(ids) {
      if (!(await this.darfBestaetigen())) throw new Error('Nur der Kassenwart kann Buchungen bestätigen.');
      this._laden(); const jetzt = new Date().toISOString(); const wer = this.d.einstellungen.kassenwart_name || 'Kassenwart'; let n = 0;
      this.d.buchungen.forEach((b) => { if (ids.includes(b.id) && !b.bestaetigt_am && !b.storniert_am) { b.bestaetigt_am = jetzt; b.bestaetigt_von = wer; n++; } });
      this._sichern(); return n;
    }
    async rechnungStornieren(id) {
      const r = this.d.rechnungen.find((x) => x.id === id); if (!r || r.storniert_am) return;
      r.storniert_am = new Date().toISOString();
      this.d.buchungen.forEach((b) => { if (b.rechnung_id === id) b.rechnung_id = null; });
      this._sichern();
    }

    async einstellungen() { return { ...STANDARD_EINSTELLUNGEN, ...this.d.einstellungen }; }
    async einstellungenSpeichern(e) { this.d.einstellungen = { ...this.d.einstellungen, ...e }; this._sichern(); }
    async kasseEinrichten() { return true; }
    /* Bankdaten für die Lastschrift: stehen im gemeinsamen Mitgliederstamm des Hafen-Managers */
    async bankdaten(ids) {
      const HF = window.HAFEN; let hd = null;
      try { hd = HF && (HF.d || HF.laden()); } catch (e) { hd = null; }
      if (!hd) return { mitglieder: [], verein: {} };
      const he = hd.einstellungen || {};
      return { mitglieder: hd.mitglieder.filter((m) => ids.includes(m.id)).map((m) => ({ mitglied_id: m.id, iban: m.iban || '', bic: m.bic || '', kontoinhaber: m.kontoinhaber || '', mandat_datum: m.mandat_datum || '' })),
        verein: { iban: he.iban || '', bic: he.bic || '', glaeubiger_id: he.glaeubiger_id || '' } };
    }

    /* Sicherung (nur Demo) */
    async sicherungExport() { return JSON.stringify(this.d, null, 1); }
    async sicherungImport(text) { const d = JSON.parse(text); if (!d.version) throw new Error('Keine gültige Sicherung'); this.d = d; this._sichern(); }
  }

  /* ==================================================== Supabase-Speicher */
  class SupabaseSpeicher {
    constructor(url, key) {
      this.modus = 'supabase'; this.url = url.replace(/\/$/, ''); this.key = key;
      this.TOKEN = 'ssvg-kasse-token'; this.SESSION = 'ssv-session'; // gemeinsame Sitzung mit Hafen-Manager und Mein SSV
    }
    _session() { try { return JSON.parse(localStorage.getItem(this.SESSION)); } catch (e) { return null; } }
    async _jwt() {
      const s = this._session(); if (!s) return null;
      if (s.expires_at * 1000 - Date.now() < 60e3) {
        const r = await fetch(this.url + '/auth/v1/token?grant_type=refresh_token', {
          method: 'POST', headers: { apikey: this.key, 'Content-Type': 'application/json' },
          body: JSON.stringify({ refresh_token: s.refresh_token })
        });
        if (!r.ok) { localStorage.removeItem(this.SESSION); return null; }
        const n = await r.json(); localStorage.setItem(this.SESSION, JSON.stringify(n)); return n.access_token;
      }
      return s.access_token;
    }
    async _req(pfad, { method = 'GET', body, prefer, admin = true } = {}) {
      const jwt = admin ? await this._jwt() : null;
      const h = { apikey: this.key, Authorization: 'Bearer ' + (jwt || this.key), 'Content-Type': 'application/json' };
      if (prefer) h.Prefer = prefer;
      let r;
      try { r = await fetch(this.url + pfad, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) }); }
      catch (e) { throw Object.assign(new Error('Keine Verbindung zum Server – bitte WLAN prüfen und erneut versuchen.'), { offline: true }); }
      const t = await r.text(); const j = t ? JSON.parse(t) : null;
      if (!r.ok) throw new Error((j && (j.message || j.msg || j.error_description)) || ('Fehler ' + r.status));
      return j;
    }
    _rpc(fn, args, admin = true) { return this._req('/rest/v1/rpc/' + fn, { method: 'POST', body: args, admin }); }
    get _tok() { return localStorage.getItem(this.TOKEN); }

    /* ---- Kasse ---- */
    async kasseStatus() { return { eingerichtet: !!this._tok, name: localStorage.getItem(this.TOKEN + '-name') || '' }; }
    kasseMitglieder() { return this._rpc('kasse_mitglieder', { p_token: this._tok }, false); }
    async kasseProdukte() { return (await this._rpc('kasse_produkte', { p_token: this._tok }, false)).map(this._zahlen); }
    async kasseLogin(mid, pin) { return this._zahlenSumme(await this._rpc('kasse_login', { p_token: this._tok, p_mitglied: mid, p_pin: pin }, false)); }
    async kasseBuchen(mid, pin, posten) { return this._zahlenSumme(await this._rpc('kasse_buchen', { p_token: this._tok, p_mitglied: mid, p_pin: pin, p_posten: posten }, false)); }
    async kasseMitteilungen() { try { return await this._rpc('kasse_mitteilungen', { p_token: this._tok }, false); } catch (e) { if (e.offline) throw e; return []; } }
    async kasseVeranstaltungen(mid, pin) { return this._rpc('kasse_veranstaltungen', { p_token: this._tok, p_mitglied: mid, p_pin: pin }, false); }
    async kasseZusage(mid, pin, p) { return this._rpc('kasse_zusage', { p_token: this._tok, p_mitglied: mid, p_pin: pin, p }, false); }
    // Buchen mit Kennung und Zeit (auch nachträglich, nach einem Netzausfall) – dieselbe Kennung wird nur einmal verbucht
    async kasseBuchenNach(mid, pin, posten, zeit, ref) {
      try { return this._zahlenSumme(await this._rpc('kasse_buchen_nach', { p_token: this._tok, p_mitglied: mid, p_pin: pin, p_posten: posten, p_zeit: zeit, p_ref: ref }, false)); }
      catch (e) { if (!e.offline && /kasse_buchen_nach|function|Funktion/i.test(e.message) && !/unplausibel|Kennung/.test(e.message)) return this.kasseBuchen(mid, pin, posten); throw e; }   // Datenbank noch ohne Nachtrag 05
    }
    async kasseVerlauf(mid, pin) {
      const r = await this._rpc('kasse_verlauf', { p_token: this._tok, p_mitglied: mid, p_pin: pin }, false);
      if (r.buchungen) r.buchungen = r.buchungen.map(this._zahlen); return r;
    }
    async kasseOptionen() {
      try { return await this._rpc('kasse_optionen', { p_token: this._tok }, false); }
      catch (e) { return { pin_selbst_festlegen: false, pin_erst_nr_pruefen: false, abmelden_sekunden: 60, storno_minuten: 15 }; }
    }
    async kassePinFestlegen(mid, pin, nr) { return this._zahlenSumme(await this._rpc('kasse_pin_festlegen', { p_token: this._tok, p_mitglied: mid, p_pin: pin, p_nr: nr || null }, false)); }
    async kasseStorno(mid, pin, bid) { return this._zahlenSumme(await this._rpc('kasse_storno', { p_token: this._tok, p_mitglied: mid, p_pin: pin, p_buchung: bid }, false)); }
    _zahlen(o) {
      ['preis', 'kasten_preis', 'betrag', 'einzelpreis', 'summe'].forEach((k) => { if (o[k] != null) o[k] = Number(o[k]); });
      return o;
    }
    _zahlenSumme(o) { ['summe', 'monat_summe', 'offen_summe'].forEach((k) => { if (o[k] != null) o[k] = Number(o[k]); }); return o; }

    /* ---- Verwaltung ---- */
    async anmelden(email, pw) {
      const r = await fetch(this.url + '/auth/v1/token?grant_type=password', {
        method: 'POST', headers: { apikey: this.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pw })
      });
      const j = await r.json();
      if (!r.ok) throw new Error('E-Mail oder Passwort falsch.');
      localStorage.setItem(this.SESSION, JSON.stringify(j));
      if (!(await this._rpc('is_admin', {}))) { await this.abmelden(); throw new Error('Dieses Konto hat keine Kassenwart-Berechtigung.'); }
      return true;
    }
    async abmelden() {
      const jwt = await this._jwt();
      if (jwt) fetch(this.url + '/auth/v1/logout', { method: 'POST', headers: { apikey: this.key, Authorization: 'Bearer ' + jwt } }).catch(() => {});
      localStorage.removeItem(this.SESSION);
    }
    async angemeldet() { return !!(await this._jwt()); }

    static get M_SPALTEN() { return 'id,nr,vorname,nachname,email,strasse,plz,ort,sepa,mandatsreferenz,notiz,aktiv,hat_pin,fehlversuche,gesperrt_bis'; }
    mitglieder() { return this._req('/rest/v1/mitglieder?select=' + SupabaseSpeicher.M_SPALTEN + '&order=nachname,vorname'); }
    async mitgliedSpeichern(m) {
      const felder = ['nr', 'vorname', 'nachname', 'email', 'strasse', 'plz', 'ort', 'sepa', 'mandatsreferenz', 'notiz', 'aktiv'];
      const body = {}; felder.forEach((f) => { if (f in m) body[f] = m[f]; });
      const sel = '?select=' + SupabaseSpeicher.M_SPALTEN;
      const r = m.id
        ? await this._req('/rest/v1/mitglieder' + sel + '&id=eq.' + m.id, { method: 'PATCH', body, prefer: 'return=representation' })
        : await this._req('/rest/v1/mitglieder' + sel, { method: 'POST', body, prefer: 'return=representation' });
      return r[0];
    }
    async mitgliedLoeschen(id) {
      const b = await this._req('/rest/v1/buchungen?select=id&limit=1&mitglied_id=eq.' + id);
      if (b.length) { await this._req('/rest/v1/mitglieder?id=eq.' + id, { method: 'PATCH', body: { aktiv: false } }); return 'deaktiviert'; }
      await this._req('/rest/v1/mitglieder?id=eq.' + id, { method: 'DELETE' }); return 'geloescht';
    }
    pinSetzen(id, pin) { return this._rpc('admin_pin_setzen', { p_mitglied: id, p_pin: pin }); }
    pinZuruecksetzen(id) { return this._rpc('admin_pin_zuruecksetzen', { p_mitglied: id }); }

    /* ---- Mein SSV: das angemeldete Mitglied (auth.uid → mitglieder.user_id) ---- */
    async mitgliedUebersicht() {
      const r = await this._rpc('mitglied_uebersicht', {}); if (!r) return null;
      this._zahlenSumme(r); (r.buchungen || []).forEach(this._zahlen); (r.rechnungen || []).forEach(this._zahlen); return r;
    }
    async mitgliedPinAendern(_mid, pin) {
      const r = await this._rpc('mitglied_pin_aendern', { p_pin: pin });
      if (!r.ok) throw new Error('Der Code muss aus genau 4 Ziffern bestehen.');
    }
    async meineRechnungen(_mid, ids) { return (await this._req('/rest/v1/rechnungen?select=*&id=in.(' + ids.join(',') + ')')).map(this._zahlen); }

    async produkte() { return (await this._req('/rest/v1/produkte?select=*&order=sort,name')).map(this._zahlen); }
    async produktSpeichern(p) {
      const { id, ...body } = p;
      const r = id
        ? await this._req('/rest/v1/produkte?id=eq.' + id, { method: 'PATCH', body, prefer: 'return=representation' })
        : await this._req('/rest/v1/produkte', { method: 'POST', body, prefer: 'return=representation' });
      return this._zahlen(r[0]);
    }
    async produktLoeschen(id) {
      const b = await this._req('/rest/v1/buchungen?select=id&limit=1&produkt_id=eq.' + id);
      if (b.length) { await this._req('/rest/v1/produkte?id=eq.' + id, { method: 'PATCH', body: { aktiv: false } }); return 'deaktiviert'; }
      await this._req('/rest/v1/produkte?id=eq.' + id, { method: 'DELETE' }); return 'geloescht';
    }

    async buchungen({ von, bis, mitglied_id, rechnung_ids } = {}) {
      let q = '/rest/v1/buchungen?select=*&order=zeit.desc&limit=5000';
      if (rechnung_ids) q += '&rechnung_id=in.(' + rechnung_ids.join(',') + ')';
      if (von) q += '&zeit=gte.' + encodeURIComponent(new Date(von + 'T00:00:00').toISOString());
      if (bis) q += '&zeit=lt.' + encodeURIComponent(new Date(new Date(bis + 'T00:00:00').getTime() + 864e5).toISOString());
      if (mitglied_id) q += '&mitglied_id=eq.' + mitglied_id;
      return (await this._req(q)).map(this._zahlen);
    }
    async buchungStornieren(id) {
      const r = await this._req('/rest/v1/buchungen?id=eq.' + id + '&rechnung_id=is.null', { method: 'PATCH', body: { storniert_am: new Date().toISOString() }, prefer: 'return=representation' });
      if (!r.length) throw new Error('Bereits abgerechnete Buchungen bitte über die Rechnung stornieren.');
    }
    async buchungNachtragen(mid, posten, zeit) { return Number(await this._rpc('admin_buchen', { p_mitglied: mid, p_posten: posten, p_zeit: zeit || null })); }

    async rechnungen() { return (await this._req('/rest/v1/rechnungen?select=*&order=nr.desc')).map(this._zahlen); }
    async rechnungenLaden(ids) { return (await this._req('/rest/v1/rechnungen?select=*&id=in.(' + ids.join(',') + ')')).map(this._zahlen); }
    rechnungenErstellen(von, bis, datum) { return this._rpc('admin_rechnungen_erstellen', { p_von: von, p_bis: bis, p_datum: datum }); }
    rechnungBezahlt(id, datum) { return this._req('/rest/v1/rechnungen?id=eq.' + id, { method: 'PATCH', body: { bezahlt_am: datum } }); }
    async darfBestaetigen() { try { return !!(await this._rpc('darf_buchungen_bestaetigen', {})); } catch (e) { return false; } }
    async buchungenBestaetigen(ids) { return Number(await this._rpc('buchungen_bestaetigen', { p_ids: ids })); }
    rechnungStornieren(id) { return this._rpc('admin_rechnung_stornieren', { p_id: id }); }

    async einstellungen() {
      const r = await this._req('/rest/v1/einstellungen?select=daten&id=eq.1');
      return { ...STANDARD_EINSTELLUNGEN, ...((r[0] && r[0].daten) || {}) };
    }
    async einstellungenSpeichern(e) {
      const alt = await this.einstellungen();
      await this._req('/rest/v1/einstellungen?id=eq.1', { method: 'PATCH', body: { daten: { ...alt, ...e } } });
    }
    /* Bankdaten für die Lastschrift (Vereinsdatenbank: mitglieder_bank, nur Vorstand/Kassenwart dürfen lesen) */
    async bankdaten(ids) {
      const [b, he] = await Promise.all([
        ids.length ? this._req('/rest/v1/mitglieder_bank?select=mitglied_id,iban,bic,kontoinhaber,mandat_datum&mitglied_id=in.(' + ids.join(',') + ')') : [],
        this._req('/rest/v1/hafen_einstellungen?select=daten&id=eq.1').catch(() => [])]);
      const d = (he[0] && he[0].daten) || {};
      return { mitglieder: b || [], verein: { iban: d.iban || '', bic: d.bic || '', glaeubiger_id: d.glaeubiger_id || '' } };
    }
    async kasseEinrichten(name) {
      const t = await this._rpc('admin_kasse_einrichten', { p_name: name });
      localStorage.setItem(this.TOKEN, t); localStorage.setItem(this.TOKEN + '-name', name);
      await this.abmelden();   // das iPad darf danach nur noch Kasse sein – niemand bleibt angemeldet
      return true;
    }
  }

  window.SSV = {
    speicher: K.modus === 'supabase' && K.supabaseUrl
      ? new SupabaseSpeicher(K.supabaseUrl, K.supabaseAnonKey)
      : new DemoSpeicher(),
    hilfe: { ct, eur, pad, tag, zufallsPin, pinZuEinfach, verdichten,
      geld: (v) => Number(v || 0).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' }),
      datum: (d) => d ? new Date(d.length === 10 ? d + 'T12:00:00' : d).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '',
      zeit: (d) => new Date(d).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }),
      esc: (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
      einheitText: (b) => b.einheit === 'kasten' ? (b.anzahl === 1 ? 'Kasten' : 'Kästen') : 'Stk.'
    }
  };
})();
