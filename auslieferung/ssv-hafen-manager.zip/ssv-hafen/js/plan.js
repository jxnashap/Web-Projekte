/* SSV Hafen-Manager – interaktiver Hafenplan (SVG)
 *
 * Maßstäblicher Lageplan: Koordinatenraum 1000 × 750 Einheiten = 400 × 300 m (1 Einheit = 0,4 m), Gitternord oben.
 * Der Ausschnitt entspricht dem Luftbild img/luftbild-dop20.jpg (amtliches DOP20, ETRS89/UTM32N,
 * BBOX 611544.1,5974837.6 – 611944.1,5975137.6; © GeoBasis-DE/LVermGeo SH/CC BY 4.0).
 *
 * Der Plan kommt aus einem Datensatz („Lageplan“): Stege mit Platznummern, Flächen, Linien, Punkte, Lagerfelder.
 * STANDARD ist vom Luftbild abgelesen; der Verein kann ihn im Lageplan-Editor (js/plan-editor.js) selbst
 * nachzeichnen – gespeichert wird er in den Einstellungen (einstellungen.lageplan).
 * Vom Verein bestätigt: Kran an der Kaimauer am Parkplatz, Slip zwischen Vereinsheim und Opti-Schuppen am blauen Schwimmsteg,
 * Gebäude östlich davon = Mastenlager und Trecker.
 * Platzzahl vom Verein bestätigt (Nov. 2026): Ost 1–16, West 25–56, Schwimmbrücke 71–76 – Boxbreiten wie auf dem Luftbild (ca. 5–5,5 m).
 * [ANNAHME] genaue Lage der Nummern, Lagerfelder (auch „Halle“ H1–H4) und Längsseits-Plätze bis zur Bestätigung durch den Verein.
 */
(function () {
  'use strict';

  const QUELLE = 'Luftbild: © GeoBasis-DE/LVermGeo SH/CC BY 4.0';
  const STANDARD = {
    v: 1, breite: 1000, hoehe: 750, m: 0.4, bild: 'img/luftbild-dop20.jpg',
    stege: [
      // Platzzahl nach Luftbild (13.06.2025) und Angabe des Vereins (Nov. 2026): Ost 1–16, West 25–56, Schwimmbrücke 71–76
      { id: 'ost', name: 'Ostbrücke', bruecke: 'ost', a: [567, 328], b: [809, 219], von: 1, bis: 16, seite: 1, frei: [10.5, 8], tiefe: 10 },
      // Westbrücke laut Verein (Nov. 2026): vorne (am Land) die großen Boxen, nach hinten gleichmäßig kleiner – 14 m … 10 m lang, 4–5 m breit.
      // tiefe = Boxtiefe am Anfang, tiefe2 = am Ende des Abschnitts; dazwischen gleichmäßig abgestuft.
      { id: 'west1', name: 'Westbrücke', bruecke: 'west', a: [551, 352], b: [437, 409], von: 25, bis: 34, seite: -1, frei: [0, 0], tiefe: 14, tiefe2: 12.8 },
      { id: 'west2', name: 'Westbrücke', bruecke: 'west', a: [437, 409], b: [201.5, 600], von: 35, bis: 56, seite: -1, frei: [0, 0], tiefe: 12.7, tiefe2: 10 },
      { id: 'west-t', name: '', bruecke: '', a: [201.5, 600], b: [212, 617], von: null, bis: null, seite: -1, frei: [0, 0], tiefe: 10 },
      { id: 'schwimm', name: 'Schwimmbrücke', bruecke: 'schwimm', schwimm: true, a: [212, 617], b: [158, 661], von: 71, bis: 76, seite: -1, frei: [0, 0], tiefe: 8 },
      { id: 'quer', name: 'Schwimmsteg', bruecke: '', schwimm: true, a: [562, 325], b: [587, 366], von: null, bis: null, seite: 1, frei: [0, 0], tiefe: 10 }
    ],
    laengs: [{ nr: 'L1', x: 148, y: 673, rot: 132, w: 30 }, { nr: 'L2', x: 814, y: 243, rot: 61, w: 36 }],
    formen: [
      { id: 'f1', art: 'gruen', name: '', p: [[0, 0], [395, 0], [0, 325]] },
      { id: 'f2', art: 'gruen', name: '', p: [[0, 480], [600, 0], [1000, 0], [1000, 45], [750, 78], [600, 138], [400, 280], [134, 522], [0, 620]] },
      { id: 'f3', art: 'gruen', name: '', p: [[0, 655], [59, 612], [134, 552], [280, 425], [327, 381], [352, 345], [350, 372], [372, 398], [420, 400], [427, 407], [399, 431], [352, 472], [299, 510], [216, 570], [196, 585], [150, 630], [134, 662], [118, 700], [100, 750], [0, 750]] },
      { id: 'f4', art: 'gruen', name: '', p: [[610, 246], [640, 235], [690, 200], [748, 165], [760, 120], [1000, 100], [1000, 152], [930, 160], [870, 172], [830, 196], [800, 206], [760, 228], [700, 258], [650, 286], [600, 306], [588, 290], [614, 280]] },
      { id: 'f5', art: 'natur', name: 'Naturschutzgebiet', p: [[1000, 330], [940, 335], [900, 355], [860, 370], [800, 395], [740, 420], [700, 435], [650, 460], [600, 480], [560, 500], [500, 540], [440, 580], [400, 610], [370, 650], [355, 700], [360, 750], [1000, 750]] },
      { id: 'f6', art: 'wasser', name: 'Alter Travearm', t: [640, 395, -27], p: [[100, 750], [118, 700], [134, 662], [150, 630], [196, 585], [216, 570], [262, 540], [299, 510], [352, 472], [399, 431], [427, 407], [450, 384], [470, 376], [523, 350], [552, 333], [566, 322], [600, 306], [650, 286], [700, 258], [760, 228], [800, 206], [830, 196], [870, 172], [930, 160], [1000, 152],
        [1000, 330], [940, 335], [900, 355], [860, 370], [800, 395], [740, 420], [700, 435], [650, 460], [600, 480], [560, 500], [500, 540], [440, 580], [400, 610], [370, 650], [355, 700], [360, 750]] },
      { id: 'f7', art: 'strasse', name: 'Autobahn', t: [250, 215, -39], p: [[0, 325], [395, 0], [600, 0], [0, 480]] },
      { id: 'f8', art: 'hof', name: '', p: [[428, 262], [456.2, 255.2], [480.8, 215.2], [555.4, 186.3], [567.7, 193.5], [687, 147], [708.5, 147.5], [723.6, 182.5], [716.9, 198.8], [677.6, 213.5], [613.3, 241.6], [556.1, 259.7], [528, 265], [459, 282]] },
      // Lagerweg durch das Nordlager: vorne an der Messe vorbei, dann mittig bis zum Ende (Sackgasse)
      { id: 'f10', art: 'strasse', name: 'Lagerweg · Sackgasse', t: [644, 195, -20.4], p: [[471.3, 267.5], [533.2, 242.4], [581.8, 215.8], [618.7, 198.9], [703.1, 167.5], [705.8, 167.2], [708.3, 168.3], [709.8, 170.5], [710.1, 173.2], [709, 175.7], [706.8, 177.2], [622.5, 208.5], [586.5, 225.1], [537.6, 251.8], [475.2, 277.2]] },
      // Parkplatz nach Luftbild: Hecke zum Weg im Nordwesten, Zaun zum Nachbargrundstück im Südwesten (läuft gerade zum Wasser hinunter)
      { id: 'f9', art: 'parken', name: 'Parkplatz', t: [437, 325, -41], p: [[352, 374], [362, 359], [396, 331], [428, 304], [446, 296], [457, 301], [460, 322], [470, 342], [489, 337], [492, 350], [470, 376], [450, 384], [440, 396], [427, 407], [414, 409]] },
      { id: 'z1', art: 'zaun', name: '', p: [[352, 374], [424, 414]] },
      // Lagerflächen hinter dem Wendekreis (laut Verein, nach Luftbild): hinten die größere Fläche – links stehen Boote, rechts Gestelle –,
      // davor rechts ein kleiner Lagerbereich; dazwischen der Busch (bleibt Grünfläche)
      { id: 'f11', art: 'lagerfl', name: 'Gestelle', t: [791, 126, -83], p: [[712, 112], [760, 106], [801, 102], [805, 147], [760, 150], [728, 151], [713, 146]] },
      { id: 'f12', art: 'lagerfl', name: 'Lager', p: [[760, 153], [790, 150], [793, 172], [763, 175]] },
      { id: 'l1', art: 'bahn', name: 'Bahn', p: [[0, 625], [71, 583], [134, 527], [299, 371], [400, 285], [500, 207], [600, 144], [700, 100], [750, 83], [900, 60], [1000, 50]] },
      { id: 'l2', art: 'weg', name: '', p: [[0, 640], [59, 599], [134, 539], [280, 412], [327, 368], [450, 260], [550, 197], [650, 144], [724, 110], [780, 97], [1000, 76]] },
      { id: 'g1', art: 'gebaeude', name: 'Vereinsheim', p: [[459, 282], [528, 265], [542, 314], [516, 321], [518, 332], [489, 337], [483, 318], [462, 310]] },
      { id: 'g2', art: 'dach', name: 'Optis', p: [[553, 266], [562, 264], [572, 298], [563, 301]] },
      { id: 'g5', art: 'slipfl', name: '', p: [[543, 303], [552, 300], [561, 325], [552, 331]] },
      { id: 'g3', art: 'dach', name: 'Mastenlager · Trecker', t: [567, 261, 0], p: [[576, 257], [604, 249], [614, 280], [587, 289]] },
      { id: 'g4', art: 'dach', name: '', p: [[433, 396], [447, 393], [450, 402], [438, 407]] }
    ],
    // Fahrrinne (für das kleine Boot, das über die Karte zieht)
    route: [[232, 760], [300, 650], [390, 560], [480, 490], [600, 412], [740, 340], [880, 282], [1010, 238]],
    // Kran laut Verein 10–15 m weiter östlich an Land; Grillplatz rechts neben dem Mastenlager, Spielplatz etwa mittig auf der Grünfläche
    punkte: [{ id: 'p1', art: 'kran', name: 'Kran', x: 493, y: 354 }, { id: 'p2', art: 'slip', name: 'Slip', x: 551, y: 318 },
      { id: 'p3', art: 'grill', name: 'Grillplatz', x: 632, y: 257 }, { id: 'p4', art: 'spiel', name: 'Spielplatz', x: 728, y: 224 }],   // Lage so, dass keine Beschriftung verdeckt wird
    // Nordlager laut Verein: Lagerweg in der Mitte (Sackgasse), links eine Reihe, rechts zwei Reihen nebeneinander,
    // vorne links zwei Reihen schräg mit dem Bug zur Messe (Vereinsheim). neig = Schräge je Boot, bug = Bugrichtung (1 = zur Straße/nach vorn)
    lager: [
      { id: 'nv', name: 'Nord vorne · schräg', praefix: 'P', ab: 1, anzahl: 10, spalten: 5, stellen: 2, x: 520.7, y: 233.4, rot: -20.4, bw: 13, bh: 13, neig: 40, lw: 5.4, lh: 12.5, bug: 1 },
      { id: 'nl', name: 'Nord links', praefix: 'P', ab: 11, anzahl: 12, spalten: 12, stellen: 2, x: 623.3, y: 185.1, rot: -20.4, bw: 9, bh: 19, bug: 1, namenAbstand: 3 },
      { id: 'nr', name: 'Nord rechts · zwei Reihen', praefix: 'P', ab: 23, anzahl: 14, spalten: 7, stellen: 2, x: 645.4, y: 215.8, rot: -20.4, bw: 22, bh: 10, bug: 1 },
      // Winterlager West laut Verein (Nov. 2026): 8 große Plätze (12 × 4,5 m) vor dem Zaun zum Nachbargrundstück –
      // je zwei Boote hintereinander mit dem Bug zur Messe (Vereinsheim), vier solcher Reihen nebeneinander Richtung Wasser.
      // Die östliche Hälfte des Parkplatzes bis zum Kran bleibt frei.
      { id: 'w', name: 'Winterlager West', praefix: 'P', ab: 41, anzahl: 8, spalten: 2, stellen: 2, x: 408.2, y: 368.2, rot: -63.4, bw: 30, bh: 12, lw: 29.5, lh: 11.25, bug: 1, namenAbstand: 5, namenVersatz: 7 },   // Name neben dem Feld, frei von P41/P42 und vom Zaun
      // Außenlager hinter dem Wendekreis (laut Verein): nur links oben zwei Reihen, etwa 6 Boote, fast bis an den Wendekreis; rechts davon Gestelle.
      // Eine Bootshalle gibt es dort nicht – H1–H4 sind deshalb nicht mehr im Plan (in den Stammdaten bleiben sie, bis der Verein entscheidet).
      { id: 'a', name: 'Außenlager', praefix: 'A', ab: 1, anzahl: 6, spalten: 2, stellen: 0, x: 745, y: 127.5, rot: -7, bw: 30, bh: 11.5, lw: 29, lh: 10.5, bug: -1 }
    ]
  };

  // Flächen- und Linienarten (Reihenfolge z = Zeichenebene), Punktarten
  const ART = {
    gruen: { name: 'Grün / Bäume', zu: 1, z: 1 }, natur: { name: 'Schilf / Naturschutz', zu: 1, z: 1 }, wasser: { name: 'Wasser', zu: 1, z: 2 },
    strasse: { name: 'Straße', zu: 1, z: 3 }, hof: { name: 'Hof / Schotter', zu: 1, z: 3 }, parken: { name: 'Parkplatz', zu: 1, z: 3 }, lagerfl: { name: 'Lagerfläche', zu: 1, z: 3 },
    bahn: { name: 'Bahn', zu: 0, z: 4 }, weg: { name: 'Weg', zu: 0, z: 4 }, zaun: { name: 'Zaun / Grenze', zu: 0, z: 6 },
    gebaeude: { name: 'Gebäude', zu: 1, z: 5 }, dach: { name: 'Halle / Schuppen / Dach', zu: 1, z: 5 }, slipfl: { name: 'Slip / Rampe', zu: 1, z: 5 }
  };
  const PUNKT = {
    kran: ['K', 'Kran'], mastkran: ['M', 'Mastenkran'], slip: ['S', 'Slip'], wc: ['WC', 'WC / Duschen'], strom: ['⚡', 'Strom'], wasser: ['W', 'Wasser'],
    muell: ['Mü', 'Müll'], tor: ['T', 'Tor / Einfahrt'], rettung: ['R', 'Rettungsmittel'], feuer: ['F', 'Feuerlöscher'], info: ['i', 'Aushang / Info'], fahne: ['⚑', 'Flaggenmast'], grill: ['G', 'Grillplatz'], spiel: ['Sp', 'Spielplatz']
  };

  const STATUS_TEXT = {
    belegt: 'belegt', unterwegs: 'Eigner unterwegs – grünes Schild', gast: 'Gastlieger', saisongast: 'Saison-Gast',
    frei: 'frei', gesperrt: 'gesperrt', neu: 'neu in dieser Planung'
  };

  const gueltig = (p) => p && Array.isArray(p.stege) && Array.isArray(p.formen) && p.stege.every((s) => Array.isArray(s.a) && Array.isArray(s.b));
  // Aktiver Plan: vom Verein gezeichnet (Einstellungen) oder die Vorlage
  // Plan des Vereins (oder null) zu einem vollständigen Plan ergänzen
  const voll = (eigen) => gueltig(eigen) ? { ...STANDARD, laengs: [], punkte: [], lager: [], ...eigen } : STANDARD;
  function aktiv() {
    const d = window.HAFEN && window.HAFEN.d; const eigen = d && d.einstellungen && d.einstellungen.lageplan;
    return gueltig(eigen) ? { ...STANDARD, laengs: [], punkte: [], lager: [], ...eigen } : STANDARD;
  }

  /* ---------- Geometrie ---------- */
  function stegGeo(s, m) {
    const [ax, ay] = s.a, [bx, by] = s.b; const len = Math.hypot(bx - ax, by - ay) || 1;
    const ux = (bx - ax) / len, uy = (by - ay) / len; const sg = s.seite === -1 ? -1 : 1;
    return { len, ux, uy, nx: -uy * sg, ny: ux * sg, winkel: Math.atan2(uy, ux) * 180 / Math.PI, tiefe: (Number(s.tiefe) || 10) / m,
      tiefe2: (Number(s.tiefe2) || Number(s.tiefe) || 10) / m,   // Boxtiefe am Ende des Stegs (ohne Angabe: wie am Anfang)
      f0: ((s.frei && Number(s.frei[0])) || 0) / m, f1: ((s.frei && Number(s.frei[1])) || 0) / m };
  }
  const hatPlaetze = (s) => s.von != null && s.bis != null && s.von !== '' && s.bis !== '' && !isNaN(Number(s.von)) && !isNaN(Number(s.bis));
  const drehen = (x, y, rot) => { const r = rot * Math.PI / 180; return [x * Math.cos(r) - y * Math.sin(r), x * Math.sin(r) + y * Math.cos(r)]; };
  /* Boxen an den Stegen. Je Steg verteilen sich die Boxen gleichmäßig; einzelne Boxen können abweichen (s.aus[Nr]):
   *   b / t = eigene Breite / Tiefe in Metern (die übrigen teilen sich den Rest), l / q = frei gesetzt (Lage längs / quer zum Steg
   *   in Plan-Einheiten, gemessen ab Steg-Anfang – wandert mit dem Steg), w = Drehung in Grad, weg = Box entfernt.
   * Ergebnis je Platz: Mittelpunkt x/y, breite (gezeichnet), voll (Raster), tiefe, winkel (Steg), dreh (Richtung vom Steg ins Wasser). */
  function plaetzeVon(plan) {
    const plaetze = [], pfaehle = [], gesehen = new Set();
    const pfahl = (x, y) => { const k = Math.round(x * 2) + ':' + Math.round(y * 2); if (!gesehen.has(k)) { gesehen.add(k); pfaehle.push([x, y]); } };
    plan.stege.forEach((s) => {
      if (!hatPlaetze(s)) return;
      const g = stegGeo(s, plan.m); const von = Number(s.von), bis = Number(s.bis); const n = Math.abs(bis - von) + 1; const dir = bis >= von ? 1 : -1; const aus = s.aus || {};
      const nrn = []; for (let i = 0; i < n; i++) { const nr = String(von + dir * i); if (!(aus[nr] && aus[nr].weg)) nrn.push(nr); }
      const nutz = Math.max(1, g.len - g.f0 - g.f1);
      let fest = 0, nFest = 0; nrn.forEach((nr) => { const b = aus[nr] && Number(aus[nr].b); if (b > 0) { fest += b / plan.m; nFest++; } });
      const auto = nrn.length > nFest ? Math.max(2, (nutz - fest) / (nrn.length - nFest)) : 0;
      const nw = Math.atan2(g.ny, g.nx) * 180 / Math.PI;
      let t = g.f0;
      nrn.forEach((nr, k) => {
        const a = aus[nr] || {}; const voll = Number(a.b) > 0 ? Number(a.b) / plan.m : auto;
        // Boxtiefe: eigene Angabe, sonst gleichmäßig vom Anfang (tiefe) zum Ende (tiefe2) des Stegs abgestuft
        const tiefe = Number(a.t) > 0 ? Number(a.t) / plan.m : g.tiefe + (g.tiefe2 - g.tiefe) * (nrn.length > 1 ? k / (nrn.length - 1) : 0);
        const frei = a.l != null && a.l !== ''; const l = frei ? Number(a.l) : t + voll / 2, q = frei ? Number(a.q) || 0 : 0; t += voll;
        const w = Number(a.w) || 0; const fx = s.a[0] + g.ux * l + g.nx * q, fy = s.a[1] + g.uy * l + g.ny * q;   // Fußpunkt am Steg
        const [dx, dy] = drehen(g.nx, g.ny, w);   // Richtung ins Wasser
        plaetze.push({ nr, steg: s.id, bruecke: s.bruecke || '', x: fx + dx * tiefe / 2, y: fy + dy * tiefe / 2, breite: Math.max(1.5, voll - Math.min(1.3, voll * 0.1)), voll, tiefe,
          winkel: g.winkel + w, dreh: nw + w, l, q, frei, eigen: !!(a.b || a.t || frei || a.w) });
        const [sx, sy] = drehen(g.ux, g.uy, w);   // seitlich (längs des Stegs)
        [-1, 1].forEach((k) => pfahl(fx + sx * k * voll / 2 + dx * (tiefe + 1.5), fy + sy * k * voll / 2 + dy * (tiefe + 1.5)));
      });
    });
    return { plaetze, pfaehle };
  }
  // Lagerfelder: Raster aus Reihen; je Platz Mittelpunkt (mx, my im Lager-Koordinatensystem), Bootsfläche w × h,
  // optional schräg (neig°) und mit Bugrichtung (bug: 1 = zur +y-/+x-Seite, -1 = Gegenseite).
  // Einzelne Plätze können abweichen (L.aus[Index]): mx / my = verschoben, w / h = eigene Größe, neig, weg = entfernt.
  function lagerVon(plan) {
    const out = [];
    (plan.lager || []).forEach((L) => {
      const sp = Math.max(1, Number(L.spalten) || 1), n = Math.max(0, Number(L.anzahl) || 0), zeilen = Math.ceil(n / sp);
      const bw = Number(L.bw) || 10, bh = Number(L.bh) || 20; const w = sp * bw, h = zeilen * bh;
      const fw = Number(L.lw) || bw - 1, fh = Number(L.lh) || bh - 1; const aus = L.aus || {};
      for (let i = 0; i < n; i++) {
        const a = aus[i] || {}; if (a.weg) continue;
        const mx = a.mx != null ? Number(a.mx) : -w / 2 + (i % sp) * bw + bw / 2, my = a.my != null ? Number(a.my) : -h / 2 + Math.floor(i / sp) * bh + bh / 2;
        const zw = Number(a.w) || fw, zh = Number(a.h) || fh;
        out.push({ id: (L.praefix || '') + String((Number(L.ab) || 1) + i).padStart(Number(L.stellen) || 0, '0'), lager: L.id, nr: i,
          mx, my, x: mx - zw / 2, y: my - zh / 2, w: zw, h: zh, neig: a.neig != null ? Number(a.neig) || 0 : Number(L.neig) || 0, bug: Number(L.bug) === -1 ? -1 : 1, cx: L.x, cy: L.y, rot: Number(L.rot) || 0,
          eigen: !!(a.mx != null || a.my != null || a.w || a.h || a.neig != null) });
      }
    });
    return out;
  }
  // Ecken eines Lagerplatzes in Plan-Koordinaten (für Ansichten und den Editor)
  function lagerEcken(g) {
    return [[-g.w / 2, -g.h / 2], [g.w / 2, -g.h / 2], [g.w / 2, g.h / 2], [-g.w / 2, g.h / 2]].map(([x, y]) => {
      const [a, b] = drehen(x, y, g.neig); const [c, e] = drehen(g.mx + a, g.my + b, g.rot); return [g.cx + c, g.cy + e]; });
  }

  /* ---------- Boote (Draufsicht, Bug in +x-Richtung, Maße in Plan-Einheiten) ---------- */
  const f2 = (z) => (Math.round(z * 100) / 100).toString();
  function rumpfPfad(L, B) {
    const h = -L / 2, v = L / 2, b = B / 2;
    return `M${f2(h)} ${f2(-b * .72)} Q${f2(h)} ${f2(-b)} ${f2(h + L * .2)} ${f2(-b)} L${f2(L * .06)} ${f2(-b)} Q${f2(v - L * .1)} ${f2(-b * .8)} ${f2(v)} 0 Q${f2(v - L * .1)} ${f2(b * .8)} ${f2(L * .06)} ${f2(b)} L${f2(h + L * .2)} ${f2(b)} Q${f2(h)} ${f2(b)} ${f2(h)} ${f2(b * .72)} Z`;
  }
  const hash = (s) => { let h = 7; s = String(s || ''); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };
  const istMotor = (typ) => /motor|linssen|sport|kaj[üu]t|cruiser|schlauch|\brib\b|trawler|angel/i.test(String(typ || ''));
  // farbe: 0–5 = Rumpfvariante (aus dem Boot abgeleitet), 'gast' | 'saison' = Gäste, 'plane' = Winterplane
  function bootSvg(L, B, o = {}) {
    const k = typeof o.farbe === 'number' ? 'bf' + (o.farbe % 6) : 'b-' + (o.farbe || 'bf0'); const motor = !!o.motor;
    const deck = rumpfPfad(L * .9, B * .78);
    let auf;
    if (o.farbe === 'plane') auf = `<path class="b-deck" d="${deck}"/><line class="b-first" x1="${f2(-L * .42)}" y1="0" x2="${f2(L * .4)}" y2="0"/>`;
    else if (motor) auf = `<path class="b-deck" d="${deck}"/><rect class="b-plicht" x="${f2(-L * .4)}" y="${f2(-B * .27)}" width="${f2(L * .24)}" height="${f2(B * .54)}" rx="${f2(B * .08)}"/>` +
      `<rect class="b-kajuete" x="${f2(-L * .16)}" y="${f2(-B * .3)}" width="${f2(L * .36)}" height="${f2(B * .6)}" rx="${f2(B * .16)}"/><path class="b-scheibe" d="M${f2(L * .16)} ${f2(-B * .26)} Q${f2(L * .25)} 0 ${f2(L * .16)} ${f2(B * .26)}"/>`;
    else auf = `<path class="b-deck" d="${deck}"/><rect class="b-plicht" x="${f2(-L * .4)}" y="${f2(-B * .24)}" width="${f2(L * .22)}" height="${f2(B * .48)}" rx="${f2(B * .1)}"/>` +
      `<rect class="b-kajuete" x="${f2(-L * .17)}" y="${f2(-B * .25)}" width="${f2(L * .3)}" height="${f2(B * .5)}" rx="${f2(B * .18)}"/><line class="b-baum" x1="${f2(L * .13)}" y1="0" x2="${f2(-L * .27)}" y2="${f2(B * .05)}"/><circle class="b-mast" cx="${f2(L * .13)}" cy="0" r="${f2(Math.max(.35, B * .07))}"/>`;
    return `<g class="boot ${k}${motor ? ' motor' : ''}"><path class="b-schatten" d="${rumpfPfad(L, B)}" transform="translate(.9 1.2)"/><path class="b-rumpf" d="${rumpfPfad(L, B)}"/>${auf}</g>`;
  }

  /* ---------- Ansichten (Zoomstufen) aus der Geometrie ---------- */
  function rahmen(punkte, rand, minBreite) {
    if (!punkte.length) return null;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    punkte.forEach(([x, y]) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); });
    x0 -= rand; y0 -= rand; x1 += rand; y1 += rand;
    let w = Math.max(x1 - x0, minBreite || 0), h = y1 - y0; const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; const v = 1000 / 640;
    if (w / h < v) w = h * v; else h = w / v;
    return [cx - w / 2, cy - h / 2, w, h].map((z) => Math.round(z * 10) / 10);
  }
  const stegPunkte = (s, m) => { const g = stegGeo(s, m); const o = hatPlaetze(s) ? Math.max(g.tiefe, g.tiefe2) + 10 : 0; return [s.a, s.b, [s.a[0] + g.nx * o, s.a[1] + g.ny * o], [s.b[0] + g.nx * o, s.b[1] + g.ny * o]]; };
  function ansichten(plan) {
    const alle = [], je = {};
    plan.stege.forEach((s) => { const pk = stegPunkte(s, plan.m); alle.push(...pk); if (s.bruecke) (je[s.bruecke] = je[s.bruecke] || []).push(...pk); });
    const land = [];
    lagerVon(plan).forEach((g) => land.push(...lagerEcken(g)));
    plan.formen.filter((f) => ['gebaeude', 'dach', 'hof', 'parken', 'lagerfl', 'slipfl'].includes(f.art)).forEach((f) => alle.push(...f.p));
    (plan.laengs || []).forEach((l) => alle.push([l.x, l.y])); (plan.punkte || []).forEach((p) => alle.push([p.x, p.y])); alle.push(...land);
    const gesamt = rahmen(alle, 45, 300) || [0, 0, plan.breite, plan.hoehe];
    const wasser = []; plan.stege.forEach((s) => wasser.push(...stegPunkte(s, plan.m))); (plan.laengs || []).forEach((l) => wasser.push([l.x, l.y]));
    const a = { gesamt, land: rahmen(land, 30, 260) || gesamt, wasser: rahmen(wasser, 34, 300) || gesamt };
    ['ost', 'west', 'schwimm'].forEach((k) => { a[k] = rahmen(je[k] || [], 24, 200) || gesamt; });
    return a;
  }

  /* ---------- Zeichnen ---------- */
  const pfad = (p, zu) => p.map(([x, y], i) => (i ? 'L' : 'M') + x + ' ' + y).join(' ') + (zu ? ' Z' : '');
  function mitte(p) {   // Flächenschwerpunkt
    let a = 0, cx = 0, cy = 0;
    for (let i = 0; i < p.length; i++) { const [x0, y0] = p[i], [x1, y1] = p[(i + 1) % p.length]; const k = x0 * y1 - x1 * y0; a += k; cx += (x0 + x1) * k; cy += (y0 + y1) * k; }
    if (Math.abs(a) < 1e-6) return p[0]; return [cx / (3 * a), cy / (3 * a)];
  }
  const innen = (x, y, p) => { let drin = false; for (let i = 0, j = p.length - 1; i < p.length; j = i++) { const [xi, yi] = p[i], [xj, yj] = p[j]; if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) drin = !drin; } return drin; };
  const wuerfel = (seed) => { let s = seed % 2147483647 || 1; return () => ((s = (s * 16807) % 2147483647) / 2147483647); };
  function svgDefs() {
    return `<defs>
      <pattern id="schraffur" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="rgba(255,255,255,.55)" stroke-width="2"/></pattern>
      <pattern id="schilf" width="14" height="14" patternUnits="userSpaceOnUse"><path d="M3 12 L4.6 5 M3 12 L1.6 6.5 M9 13 L10 6.2 M9 13 L11.4 7.5 M12 5 L12.6 1.5" stroke="rgba(74,110,58,.5)" stroke-width=".9" stroke-linecap="round" fill="none"/></pattern>
      <pattern id="baeume" width="26" height="22" patternUnits="userSpaceOnUse"><circle cx="6" cy="6" r="5" fill="rgba(70,118,62,.16)"/><circle cx="19" cy="15" r="4.2" fill="rgba(70,118,62,.13)"/><circle cx="20" cy="4" r="2.4" fill="rgba(255,255,255,.1)"/></pattern>
      <pattern id="schotter" width="9" height="9" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r=".6" fill="rgba(120,108,84,.35)"/><circle cx="6.5" cy="5.5" r=".5" fill="rgba(120,108,84,.3)"/></pattern>
      <linearGradient id="wasser" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3f86ad"/><stop offset=".55" stop-color="#2f709a"/><stop offset="1" stop-color="#27628b"/></linearGradient>
      <pattern id="wellen" width="46" height="22" patternUnits="userSpaceOnUse"><path d="M2 8 q5 -3 10 0 t10 0" fill="none" stroke="rgba(255,255,255,.26)" stroke-width=".9" stroke-linecap="round"/><path d="M25 18 q4 -2.4 8 0 t8 0" fill="none" stroke="rgba(255,255,255,.18)" stroke-width=".8" stroke-linecap="round"/></pattern>
      <pattern id="wellen2" width="74" height="38" patternUnits="userSpaceOnUse"><path d="M6 12 q7 -4 14 0 t14 0" fill="none" stroke="rgba(190,230,245,.2)" stroke-width="1.1" stroke-linecap="round"/><path d="M40 30 q6 -3.4 12 0 t12 0" fill="none" stroke="rgba(10,40,80,.16)" stroke-width="1.1" stroke-linecap="round"/></pattern>
      <radialGradient id="halo-gruen"><stop offset="0" stop-color="#b9ffd6" stop-opacity=".95"/><stop offset=".3" stop-color="#3ee58a" stop-opacity=".55"/><stop offset="1" stop-color="#22c66f" stop-opacity="0"/></radialGradient>
      <radialGradient id="halo-rot"><stop offset="0" stop-color="#ffd0c8" stop-opacity=".9"/><stop offset=".3" stop-color="#ff5a4a" stop-opacity=".5"/><stop offset="1" stop-color="#e2392c" stop-opacity="0"/></radialGradient>
      <radialGradient id="halo-warm"><stop offset="0" stop-color="#fff3c4" stop-opacity=".95"/><stop offset=".35" stop-color="#ffcf66" stop-opacity=".45"/><stop offset="1" stop-color="#ffb52e" stop-opacity="0"/></radialGradient>
      <radialGradient id="boje-gruen" cx=".35" cy=".3"><stop offset="0" stop-color="#d6ffe6"/><stop offset=".5" stop-color="#2ed47c"/><stop offset="1" stop-color="#128a4b"/></radialGradient>
      <radialGradient id="boje-rot" cx=".35" cy=".3"><stop offset="0" stop-color="#ffd9d2"/><stop offset=".5" stop-color="#ee4a3b"/><stop offset="1" stop-color="#a51f17"/></radialGradient>
      <radialGradient id="boje-aus" cx=".35" cy=".3"><stop offset="0" stop-color="#f1f3f7"/><stop offset=".6" stop-color="#a9b0bf"/><stop offset="1" stop-color="#737b8d"/></radialGradient>
      <symbol id="baum" overflow="visible"><ellipse cx="2.2" cy="2.8" rx="5.2" ry="4.8" fill="rgba(30,55,35,.22)"/><circle r="5" fill="#6f9d5c"/><circle cx="-1.4" cy="-1.6" r="3.1" fill="#8db875"/><circle cx="-2.2" cy="-2.4" r="1.2" fill="#a9cf8f"/></symbol>
      <symbol id="funke" overflow="visible"><path d="M0 -2.2 L.5 -.5 L2.2 0 L.5 .5 L0 2.2 L-.5 .5 L-2.2 0 L-.5 -.5 Z" fill="#fff"/></symbol>
    </defs>`;
  }
  // Uferlinie einer Wasserfläche: alle Kanten, die nicht auf dem Blattrand liegen (dort endet nur der Ausschnitt)
  function uferPfad(f, plan) {
    const rand = ([x, y]) => x <= 0.5 || y <= 0.5 || x >= plan.breite - 0.5 || y >= plan.hoehe - 0.5; let dd = '', offen = false;
    for (let i = 0; i < f.p.length; i++) { const a = f.p[i], b = f.p[(i + 1) % f.p.length];
      if (rand(a) && rand(b)) { offen = false; continue; }
      dd += (offen ? '' : 'M' + a[0] + ' ' + a[1]) + 'L' + b[0] + ' ' + b[1]; offen = true; }
    return dd;
  }
  function formenSvg(plan) {
    const esc = window.HAFEN.H.esc;
    const liste = plan.formen.map((f, i) => ({ f, i })).filter((x) => ART[x.f.art] && x.f.p && x.f.p.length > 1).sort((a, b) => ART[a.f.art].z - ART[b.f.art].z || a.i - b.i);
    const flaechen = liste.map(({ f, i }) => {
      const zu = ART[f.art].zu; const dpf = pfad(f.p, zu);
      if (f.art === 'bahn') return `<path d="${dpf}" class="pf pf-bahn"/><path d="${dpf}" class="pf pf-bahn2"/>`;
      if (f.art === 'weg') return `<path d="${dpf}" class="pf pf-weg0"/><path d="${dpf}" class="pf pf-weg"/>`;
      if (f.art === 'wasser') return `<path d="${dpf}" class="pf pf-wasser"/>`;
      const muster = { natur: 'schilf', gruen: 'baeume', hof: 'schotter', parken: 'schotter', lagerfl: 'schotter' }[f.art];
      let extra = '';
      if (f.art === 'gruen' && f.p.length > 2) {   // einzelne Bäume, fest verteilt (immer gleich)
        const z = wuerfel(977 + i * 131); let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity; f.p.forEach(([x, y]) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); });
        for (let y = y0 + 9; y < y1; y += 27) for (let x = x0 + 9; x < x1; x += 31) { const px = x + (z() - .5) * 22, py = y + (z() - .5) * 18, gr = .55 + z() * .75; if (z() < .68 && innen(px, py, f.p)) extra += `<use href="#baum" transform="translate(${px.toFixed(1)} ${py.toFixed(1)}) scale(${gr.toFixed(2)})"/>`; }
        extra = `<g class="baeume">${extra}</g>`;
      }
      const schatten = (f.art === 'gebaeude' || f.art === 'dach') ? `<path d="${dpf}" class="pf-schatten" transform="translate(${f.art === 'gebaeude' ? '2.6 3.4' : '1.6 2.2'})"/>` : '';
      return schatten + `<path d="${dpf}" class="pf pf-${f.art}"/>` + (muster ? `<path d="${dpf}" fill="url(#${muster})" class="pf-muster"/>` : '') + extra +
        (f.art === 'gebaeude' ? `<path d="${dpf}" class="pf-first" transform="translate(${mitte(f.p).map((v) => (v * .14).toFixed(2)).join(' ')}) scale(.86)"/>` : '');
    }).join('');
    const texte = liste.filter(({ f }) => f.name).map(({ f }) => {
      const zu = ART[f.art].zu; let x, y, rot = 0;
      if (f.t) [x, y, rot] = f.t;
      else if (zu) [x, y] = mitte(f.p);
      else { const i = Math.max(0, Math.floor(f.p.length / 2) - 1); const [a, b] = [f.p[i], f.p[i + 1]]; x = (a[0] + b[0]) / 2; y = (a[1] + b[1]) / 2 - 6; rot = Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI; if (Math.abs(rot) > 90) rot += 180; }
      const kl = { wasser: 'gross wasser-text', natur: 'gross natur-text', gebaeude: 'hell', strasse: 'strasse-text' }[f.art] || 'klein';
      return `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" class="pl-label ${kl}" text-anchor="middle"${rot ? ` transform="rotate(${Number(rot).toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)})"` : ''}>${esc(f.name)}</text>`;
    }).join('');
    return { flaechen, texte };
  }
  // Wasser: Tiefenzonen entlang der Ufer, zwei ziehende Wellenlagen, Lichtreflexe, ein kleines Boot auf der Fahrrinne
  function wasserSvg(plan) {
    const wasser = plan.formen.filter((x) => x.art === 'wasser' && x.p && x.p.length > 2); if (!wasser.length) return '';
    const ufer = wasser.map((x) => uferPfad(x, plan)).join(' ');
    const z = wuerfel(4711); let funken = '';
    for (let i = 0, versuche = 0; i < 34 && versuche < 900; versuche++) { const x = z() * plan.breite, y = z() * plan.hoehe; if (!wasser.some((w) => innen(x, y, w.p))) continue;
      funken += `<use href="#funke" class="funke" style="--i:${i}" transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) scale(${(.5 + z() * .9).toFixed(2)})"/>`; i++; }
    const route = Array.isArray(plan.route) && plan.route.length > 1 ? `<g class="fahrt"><path id="fahrt-weg" d="${pfad(plan.route, false)}" fill="none"/>` +
      `<g class="fahrt-boot"><path class="kiel" d="M-9 0 L-34 -5 M-9 0 L-34 5"/><path class="b-rumpf" d="${rumpfPfad(11, 4)}"/><path class="segel" d="M2 0 L-4.5 3.4 L-4 0 Z"/><circle class="b-mast" cx="2" cy="0" r=".5"/>` +
      `<animateMotion dur="130s" repeatCount="indefinite" rotate="auto"><mpath href="#fahrt-weg"/></animateMotion></g></g>` : '';
    return `<clipPath id="wasser-clip">${wasser.map((x) => `<path d="${pfad(x.p, true)}"/>`).join('')}</clipPath>` +
      `<g clip-path="url(#wasser-clip)" class="wasser-ebene"><path d="${ufer}" class="tiefe t1"/><path d="${ufer}" class="tiefe t2"/><path d="${ufer}" class="tiefe t3"/>` +
      `<rect class="wellen w2" x="-80" y="-80" width="${plan.breite + 160}" height="${plan.hoehe + 160}" fill="url(#wellen2)"/><rect class="wellen" x="-60" y="-60" width="${plan.breite + 120}" height="${plan.hoehe + 120}" fill="url(#wellen)"/>` +
      `<g class="funken">${funken}</g>${route}<path d="${ufer}" class="tiefe saum"/></g>`;
  }
  function stegeSvg(plan, geo) {
    const esc = window.HAFEN.H.esc;
    const linie = (s, kl, tr) => `<line x1="${s.a[0]}" y1="${s.a[1]}" x2="${s.b[0]}" y2="${s.b[1]}" class="${kl}"${tr || ''}/>`;
    const linien = plan.stege.map((s) => linie(s, 'steg-schatten', ' transform="translate(1.4 2)"')).join('') +
      plan.stege.map((s) => `<line x1="${s.a[0]}" y1="${s.a[1]}" x2="${s.b[0]}" y2="${s.b[1]}" pathLength="1" class="steg${s.schwimm ? ' steg-schwimm' : ''}"/>` + linie(s, 'steg-licht') + linie(s, 'steg-planken')).join('');
    const pf = geo.pfaehle.map(([x, y]) => `<circle cx="${(x + .5).toFixed(1)}" cy="${(y + .7).toFixed(1)}" r="1.25" class="pfahl-s"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="1.15" class="pfahl"/><circle cx="${(x - .3).toFixed(1)}" cy="${(y - .3).toFixed(1)}" r=".45" class="pfahl-l"/>`).join('');
    const gesehen = new Set();
    const namen = plan.stege.filter((s) => s.name).map((s) => {
      // gleichnamige Abschnitte (z. B. Westbrücke in zwei Teilen): Name nur am längsten Abschnitt
      const gleich = plan.stege.filter((x) => x.name === s.name); const laengster = gleich.reduce((a, b) => stegGeo(b, plan.m).len > stegGeo(a, plan.m).len ? b : a);
      if (laengster !== s || gesehen.has(s.name)) return ''; gesehen.add(s.name);
      const g = stegGeo(s, plan.m); const ab = hatPlaetze(s) ? 18 : 7; const mx = (s.a[0] + s.b[0]) / 2 - g.nx * ab, my = (s.a[1] + s.b[1]) / 2 - g.ny * ab; const w = Math.abs(g.winkel) > 90 ? g.winkel + 180 : g.winkel;
      return `<text x="${mx.toFixed(1)}" y="${my.toFixed(1)}" class="pl-label bruecke" text-anchor="middle" dominant-baseline="middle" transform="rotate(${w.toFixed(1)} ${mx.toFixed(1)} ${my.toFixed(1)})">${esc(s.name)}</text>`;
    }).join('');
    // Laternen an den Steg-Enden und alle ca. 30 m (leuchten in der Abendansicht)
    const lampen = plan.stege.map((s) => { const g = stegGeo(s, plan.m); const n = Math.max(1, Math.round(g.len / 75)); let o = '';
      for (let i = 0; i <= n; i++) { const t = g.len * i / n; o += `<circle class="lampe" cx="${(s.a[0] + g.ux * t).toFixed(1)}" cy="${(s.a[1] + g.uy * t).toFixed(1)}" r="9" fill="url(#halo-warm)"/>`; } return o; }).join('');
    return { linien, pf, namen, lampen };
  }
  function punkteSvg(plan) {
    const esc = window.HAFEN.H.esc;
    return (plan.punkte || []).map((p) => { const [z, n] = PUNKT[p.art] || ['?', '']; const name = p.name || n;
      return `<g class="pkt pkt-${p.art}" transform="translate(${p.x} ${p.y})"><circle class="pkt-s" cx=".8" cy="1.2" r="7"/><circle r="7"/><text y="2.6" text-anchor="middle" class="pkt-z">${z}</text><text y="15" text-anchor="middle" class="pl-label klein pkt-n">${esc(name)}</text></g>`; }).join('');
  }
  // Maßstabsleiste und Nordrose unten rechts im Ausschnitt vb (Standard: ganzer Plan). In kleinen Ausschnitten wird beides
  // kleiner gezeichnet und die Leiste kürzer (50/20/10 m) – die Länge stimmt immer in Plan-Einheiten.
  function massstab(plan, vb) {
    vb = vb || [0, 0, plan.breite, plan.hoehe];
    const k = Math.min(1, vb[2] / 700); const L = [50, 20, 10].find((m) => m / plan.m <= vb[2] * .3) || 10; const e = L / plan.m, ei = e / k;
    const x = vb[0] + vb[2] - e - 60 * k, y = vb[1] + vb[3] - 34 * k; const sk = k < 1 ? ` scale(${k.toFixed(3)})` : '';
    return `<g class="massstab" transform="translate(${+x.toFixed(1)} ${+y.toFixed(1)})${sk}"><rect x="-10" y="-16" width="${+(ei + 20).toFixed(2)}" height="30" rx="4" class="ms-bg"/><rect width="${+(ei / 2).toFixed(2)}" height="4" class="ms-a"/><rect x="${+(ei / 2).toFixed(2)}" width="${+(ei / 2).toFixed(2)}" height="4" class="ms-b"/>
      <text y="-4" class="pl-label klein">0</text><text x="${+(ei / 2).toFixed(2)}" y="-4" text-anchor="middle" class="pl-label klein">${L / 2}</text><text x="${+ei.toFixed(2)}" y="-4" text-anchor="end" class="pl-label klein">${L} m</text></g>
      <g class="rose" transform="translate(${+(vb[0] + vb[2] - 40 * k).toFixed(1)} ${+(vb[1] + vb[3] - 84 * k).toFixed(1)})${sk}"><circle r="21" class="rose-bg"/><circle r="15.5" class="rose-ring"/><path d="M0 -15 L3.2 -3.2 L15 0 L3.2 3.2 L0 15 L-3.2 3.2 L-15 0 L-3.2 -3.2 Z" class="rose-stern"/><path d="M0 -18.5 L4.4 0 L-4.4 0 Z" class="rose-n"/><path d="M0 18.5 L4.4 0 L-4.4 0 Z" class="rose-s"/><text y="-23.5" text-anchor="middle" class="pl-label klein">N</text></g>`;
  }
  // Untergrund: Zeichnung oder Luftbild
  function svgGrund(plan, geo, luftbild) {
    const st = stegeSvg(plan, geo);
    if (luftbild) return { unten: svgDefs() + `<image href="${plan.bild}" x="0" y="0" width="${plan.breite}" height="${plan.hoehe}" preserveAspectRatio="none"/>` +
      `<g class="auf-bild">${st.linien}${st.pf}${st.namen}</g>`, punkte: `<g class="auf-bild">${punkteSvg(plan)}</g>`, lichter: '', oben: `<text x="6" y="${plan.hoehe - 6}" class="pl-label klein quelle">${QUELLE}</text>` };
    const f = formenSvg(plan);
    const heim = plan.formen.filter((x) => x.art === 'gebaeude' && x.p && x.p.length > 2).map((x) => { const [mx, my] = mitte(x.p); return `<circle class="lampe fenster" cx="${mx.toFixed(1)}" cy="${my.toFixed(1)}" r="26" fill="url(#halo-warm)"/>`; }).join('');
    return { unten: svgDefs() + `<rect x="-400" y="-400" width="${plan.breite + 800}" height="${plan.hoehe + 800}" class="grund"/>` + f.flaechen.replace(/(<path d="[^"]*" class="pf pf-wasser"\/>)(?![\s\S]*class="pf pf-wasser")/, '$1' + wasserSvg(plan)) + f.texte + st.linien + st.pf + st.namen,
      punkte: punkteSvg(plan), lichter: st.lampen + heim, oben: massstab(plan) };
  }

  /**
   * Zeichnet den Plan in ein Element.
   * opts: { modus: 'sommer'|'winter', saison, datum, markiere: platzId, onKlick(platzId), ansicht, namen, luftbild, plan,
   *         wasser(p) → { status, boot, gast }   eigene Belegung (z. B. öffentliche Karte, Zeitraum) statt der Vereinsdaten,
   *         karte(id) → HTML                      Inhalt der Schwebekarte (Standard: Platz, Status, mit opts.namen auch Boot/Eigner),
   *         abend: true                           Abendansicht (Bojen und Laternen leuchten stärker), schweb: false = keine Schwebekarte }
   */
  const FREI = { frei: 1, unterwegs: 1 };
  function zeichnen(el, opts) {
    const { Q } = window.HAFEN;
    const d = opts.daten || window.HAFEN.d;   // opts.daten = { liegeplaetze } für Seiten ohne Vereinsdaten (öffentliche Karte)
    const plan = opts.plan || aktiv();
    const geo = plaetzeVon(plan);
    const winter = opts.modus === 'winter';
    const lpById = new Map(d.liegeplaetze.map((p) => [p.nr, p]));
    const esc = window.HAFEN.H.esc, H = window.HAFEN.H;
    const M = plan.m;
    // Belegung eines Wasserplatzes: Status, Boot des Dauerliegers, Gast
    const lage = opts.wasser || ((p) => {
      const status = Q.statusWasser(p, opts.saison, opts.datum); const bel = Q.belegungPlatz(opts.saison, 'sommer', p.id);
      // In „Mein SSV“ kennt das Mitglied nur den Status fremder Plätze (keine Gästeliste, keine fremden Boote) – dann eben ohne Einzelheiten
      let gast = null; if (status === 'gast') { try { gast = Q.gastAm(p.id, opts.datum) || null; } catch (e) { gast = null; } }
      return { status, boot: bel ? (Q.boot(bel.boot_id) || null) : null, gast };
    });
    const lagen = new Map();
    const lageVon = (p) => { if (!lagen.has(p.id)) lagen.set(p.id, p.neu ? { status: 'neu' } : winter ? { status: p.gesperrt ? 'gesperrt' : 'leer' } : (lage(p) || { status: 'frei' })); return lagen.get(p.id); };
    // Boot in einer Box: echte Maße (Meter → Plan-Einheiten), Bug zum Steg
    const bootInBox = (x, tiefe, breite) => {
      if (!['belegt', 'gast', 'saisongast'].includes(x.status)) return '';
      const q = x.status === 'gast' ? (x.gast || {}) : (x.boot || {});
      const L = Math.min(tiefe + 4, Math.max(8, (Number(q.laenge) || (tiefe * M - 2.4)) / M)), B = Math.min(breite - .9, Math.max(3, (Number(q.breite) || Number(q.laenge) * .33 || 2.8) / M));
      const farbe = x.status === 'gast' ? 'gast' : x.status === 'saisongast' ? 'saison' : hash(q.id || q.name) % 6;
      return `<g class="boot-lage" transform="translate(${f2(-tiefe / 2 + 1.6 + L / 2)} 0) rotate(180)">${bootSvg(L, B, { farbe, motor: istMotor(q.typ) })}</g>`;
    };
    const lichter = [];
    const boje = (x, y, status, i) => { const art = status === 'gesperrt' || status === 'leer' || status === 'neu' || status === 'zuklein' ? 'aus' : FREI[status] ? 'gruen' : 'rot';
      lichter.push(`<g class="boje bo-${art}" style="--i:${i}" transform="translate(${x.toFixed(1)} ${y.toFixed(1)})"><g class="bo-i">${art === 'aus' ? '' : `<circle class="halo" r="8.5" fill="url(#halo-${art})"/>`}<circle class="bo-s" cx=".5" cy=".8" r="1.9"/><circle class="bo-k" r="1.8" fill="url(#boje-${art})"/></g></g>`); };

    const gezeichnet = new Set();
    const wasserPlaetze = geo.plaetze.map((g, idx) => {
      const p = lpById.get(g.nr) || (opts.entwurf ? { id: 'neu-' + g.nr, nr: g.nr, neu: true } : null); if (!p || gezeichnet.has(g.nr)) return ''; gezeichnet.add(g.nr);   // nur Plätze, die es im Verein gibt (in einer Planung auch neue); doppelte Nummern nur einmal
      const x = lageVon(p); const status = x.status;
      const mark = opts.markiere === p.id ? ' markiert' : '';
      const [bx, by] = drehen(g.tiefe / 2 + 5, 0, g.dreh); boje(g.x + bx, g.y + by, status, idx);
      const tw = ((g.dreh % 360) + 360) % 360; const kopf = tw > 0 && tw < 180;   // Nummer immer lesbar (nie auf dem Kopf)
      return `<g class="lp st-${status}${mark}${g.eigen ? ' eigen' : ''}" style="--i:${Math.round(g.x / 22)}" data-platz="${p.id}" transform="translate(${g.x.toFixed(1)} ${g.y.toFixed(1)}) rotate(${g.dreh.toFixed(1)})" tabindex="0" role="button" aria-label="Platz ${esc(p.nr)}: ${STATUS_TEXT[status] || (status === 'leer' ? 'Winterpause' : status)}">
        <rect class="box" x="${f2(-g.tiefe / 2)}" y="${f2(-g.breite / 2)}" width="${f2(g.tiefe)}" height="${f2(g.breite)}" rx="1.2"/><path class="leine" d="M${f2(-g.tiefe / 2)} ${f2(-g.voll / 2)} H${f2(g.tiefe / 2 + 1.5)} M${f2(-g.tiefe / 2)} ${f2(g.voll / 2)} H${f2(g.tiefe / 2 + 1.5)}"/>
        ${bootInBox(x, g.tiefe, g.breite)}${status === 'unterwegs' ? `<g class="schild" transform="translate(${f2(-g.tiefe / 2 + 3.4)} 0)"><rect x="-1.7" y="-2.6" width="3.4" height="5.2" rx=".7"/></g>` : ''}
        <text class="lp-nr" text-anchor="middle" transform="translate(${f2(-g.tiefe / 2 - 5.2)} 0) rotate(${kopf ? -90 : 90}) translate(0 1.9)">${esc(p.nr)}</text>
      </g>`;
    }).join('');

    const laengs = (plan.laengs || []).map((l, idx) => {
      const p = lpById.get(String(l.nr)) || (opts.entwurf ? { id: 'neu-' + l.nr, nr: String(l.nr), neu: true, box: 'L' } : null); if (!p) return '';
      const x = lageVon(p); const status = x.status; const hh = Number(l.h) || 10;
      const mark = opts.markiere === p.id ? ' markiert' : '';
      const [bx, by] = drehen(l.w / 2 + 5, 0, Number(l.rot) || 0); boje(l.x + bx, l.y + by, status, 60 + idx);
      const q = status === 'gast' ? (x.gast || {}) : (x.boot || {});
      const boot = ['belegt', 'gast', 'saisongast'].includes(status) ? bootSvg(Math.min(l.w - 2, Math.max(8, (Number(q.laenge) || 9) / M)), Math.min(hh - 1.4, Math.max(3, (Number(q.breite) || 3) / M)), { farbe: status === 'gast' ? 'gast' : status === 'saisongast' ? 'saison' : hash(q.id || q.name) % 6, motor: istMotor(q.typ) }) : '';
      return `<g class="lp laengs st-${status}${mark}" data-platz="${p.id}" transform="translate(${l.x} ${l.y}) rotate(${Number(l.rot) || 0})" tabindex="0" role="button" aria-label="${p.box === 'L' ? 'Längsseits' : 'Platz'} ${esc(p.nr)}: ${STATUS_TEXT[status] || status}">
        <rect class="box" x="${f2(-l.w / 2)}" y="${f2(-hh / 2)}" width="${l.w}" height="${hh}" rx="2"/>${boot}
        <text class="lp-nr" x="0" y="${f2(-hh / 2 - 2.5)}" text-anchor="middle">${esc(p.nr)}</text></g>`;
    }).join('');

    const per = winter ? 'winter' : 'sommer';
    const land = opts.daten ? '' : lagerVon(plan).map((g) => {
      const lp = Q.platz(g.id) || (opts.entwurf ? { id: g.id, bez: g.id, neu: true } : null); if (!lp) return '';
      const status = lp.neu ? 'neu' : opts.land ? opts.land(lp) : Q.statusLand(lp, opts.saison, per);
      const mark = opts.markiere === g.id ? ' markiert' : '';
      const bel = opts.land ? null : Q.belegungPlatz(opts.saison, per, g.id); const b = bel && Q.boot(bel.boot_id);
      const [px] = drehen(g.mx, g.my, g.rot);
      const lang = g.h >= g.w; const maxL = (lang ? g.h : g.w) - 1.4, maxB = (lang ? g.w : g.h) - 1.6;
      const bw = lang ? (g.bug === -1 ? -90 : 90) : (g.bug === -1 ? 180 : 0);
      const boot = status === 'belegt' ? `<g transform="rotate(${bw})">${bootSvg(Math.min(maxL, Math.max(maxL * .62, ((b && Number(b.laenge)) || 99) / M)), Math.min(maxB, Math.max(maxB * .6, ((b && Number(b.breite)) || 99) / M)), { farbe: winter ? 'plane' : hash(b && (b.id || b.name)) % 6, motor: istMotor(b && b.typ) })}</g>` : '';
      return `<g class="land st-${status}${mark}${g.eigen ? ' eigen' : ''}" style="--i:${Math.round((g.cx + px) / 22)}" data-platz="${g.id}" transform="translate(${g.cx} ${g.cy}) rotate(${g.rot})" tabindex="0" role="button" aria-label="${g.id}: ${status}">
        <g transform="translate(${g.mx.toFixed(1)} ${g.my.toFixed(1)})${g.neig ? ` rotate(${g.neig})` : ''}"><rect class="box" x="${(-g.w / 2).toFixed(1)}" y="${(-g.h / 2).toFixed(1)}" width="${g.w}" height="${g.h}" rx="1.5"/>${boot}</g>
        <text class="lp-nr" x="${g.mx.toFixed(1)}" y="${(g.my + 1.8).toFixed(1)}" text-anchor="middle">${g.id}</text>${opts.namen && b ? `<text class="lp-boot" x="${g.mx.toFixed(1)}" y="${(g.my + (g.h > g.w ? 6.5 : 4.6)).toFixed(1)}" text-anchor="middle">${esc(String(b.name).slice(0, 12))}</text>` : ''}</g>`;
    }).join('');
    // Lagernamen über (bzw. bei Lagern unterhalb des Wegs: unter) dem Feld
    const lagerNamen = opts.daten ? '' : (plan.lager || []).filter((L) => L.name).map((L) => { const zeilen = Math.ceil((Number(L.anzahl) || 0) / Math.max(1, Number(L.spalten) || 1));
      const unten = L.namenUnten || L.id === 'nr'; const dy = (zeilen * (Number(L.bh) || 20) / 2 + (unten ? 7 : 3) + (Number(L.namenAbstand) || 0)) * (unten ? 1 : -1);   // namenAbstand: Name weiter vom Feld weg, namenVersatz: entlang des Namens verschoben
      return `<text class="pl-label klein lager-name" text-anchor="middle" transform="translate(${L.x} ${L.y}) rotate(${Number(L.rot) || 0}) translate(${Number(L.namenVersatz) || 0} ${dy.toFixed(1)})">${esc(L.name)}</text>`; }).join('');

    const A = ansichten(plan);
    const vb = Array.isArray(opts.ansicht) ? opts.ansicht : (A[opts.ansicht || 'gesamt'] || A.gesamt);
    const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const G = svgGrund(plan, geo, !!opts.luftbild);
    let html = `<svg class="hafenplan${(vb[2] < 600) ? ' nah' : ''}${vb[2] < 260 ? ' sehr-nah' : ''}${opts.luftbild ? ' mit-bild' : ''}${winter ? ' winter' : ''}${opts.abend ? ' abend' : ''}${opts.intro === false || ruhig ? '' : ' intro'}" viewBox="${vb.join(' ')}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Hafenplan des SSV">` +
      `${G.unten}${land}${lagerNamen}${wasserPlaetze}${laengs}${G.punkte}<rect class="daemmer" x="-400" y="-400" width="${plan.breite + 800}" height="${plan.hoehe + 800}"/><g class="lichter">${G.lichter}${lichter.join('')}</g>${G.oben}</svg>`;
    // Zweiter Plan auf derselben Seite (z. B. Druckseite): eigene IDs, sonst greifen Verläufe/Muster auf den ersten Plan –
    // ist der ausgeblendet (Drucken), malt der Browser Wasser und Bojen ohne Farbe. CSS-Verweise (url(#wasser) …) siehe Druckregeln in hafen.css.
    if (opts.idPraefix) { const pre = opts.idPraefix; const ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
      html = html.replace(/(\s)id="([^"]+)"/g, (m, sp, id) => `${sp}id="${pre}${id}"`).replace(/url\(#([^)]+)\)/g, (m, id) => ids.has(id) ? `url(#${pre}${id})` : m).replace(/href="#([^"]+)"/g, (m, id) => ids.has(id) ? `href="#${pre}${id}"` : m); }
    el.innerHTML = html;
    const svg = el.firstChild; svg._ansichten = A; svg._plan = plan;
    if (svg.classList.contains('intro')) setTimeout(() => svg.classList.remove('intro'), 2100);
    const klick = (e) => { const g = e.target.closest('[data-platz]'); if (g && opts.onKlick) opts.onKlick(g.dataset.platz); };
    svg.addEventListener('click', klick);
    svg.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); klick(e); } });

    // Schwebekarte: beim Zeigen mit der Maus erscheint neben dem Platz, was dort los ist
    if (opts.schweb !== false) {
      const inhalt = opts.karte || ((id) => {
        const p = Q.platz(id); if (!p) return '';
        if (p.bez) { const bel = Q.belegungPlatz(opts.saison, per, id); const b = bel && Q.boot(bel.boot_id);
          return `<strong>${esc(Q.platzName ? Q.platzName(p) : p.bez)}</strong><span class="pk-st ${b ? 'rot' : 'gruen'}">${b ? 'belegt' : 'frei'}</span>` + (b && opts.namen ? `<p>„${esc(b.name)}“ · ${esc(Q.name(Q.mitglied(b.eigner_id)))}${bel.nicht_kranen ? ' · nicht kranen' : ''}</p>` : ''); }
        const x = lageVon(p); const st = x.status; const aw = st === 'unterwegs' && Q.abwesendAm(p.id, opts.datum);
        let h = `<strong>${p.box === 'L' ? 'Längsseits' : 'Platz'} ${esc(p.nr)}</strong><span class="pk-st ${st === 'gesperrt' || st === 'leer' ? 'aus' : FREI[st] ? 'gruen' : 'rot'}">${esc(st === 'leer' ? 'Winterpause' : st === 'unterwegs' ? 'frei · grünes Schild' : STATUS_TEXT[st] || st)}</span>`;
        if (aw) h += `<p>frei bis ${H.kurz(aw.bis)}</p>`;
        if (opts.namen && x.gast) h += `<p>Gast „${esc(x.gast.bootsname)}“ · ${H.kurz(x.gast.ankunft)}, ${x.gast.naechte} ${x.gast.naechte > 1 ? 'Nächte' : 'Nacht'}</p>`;
        if (opts.namen && x.boot && !winter) h += `<p>„${esc(x.boot.name)}“ · ${esc(Q.name(Q.mitglied(x.boot.eigner_id)))}</p>`;
        if (p.max_laenge) h += `<p class="pk-leise">bis ${H.zahl(p.max_laenge, 1)} × ${H.zahl(p.max_breite, 1)} m</p>`;
        return h; });
      const karte = document.createElement('div'); karte.className = 'plan-karte'; karte.hidden = true; el.appendChild(karte); let akt = null;
      const weg = () => { karte.hidden = true; akt = null; };
      svg.addEventListener('pointermove', (e) => {
        if (e.pointerType !== 'mouse' || e.buttons || svg.classList.contains('zieht')) return weg();
        const g = e.target.closest && e.target.closest('[data-platz]'); if (!g) return weg();
        if (g.dataset.platz !== akt) { akt = g.dataset.platz; const h = inhalt(akt); if (!h) return weg(); karte.innerHTML = h; karte.hidden = false; }
        const r = el.getBoundingClientRect(); const kw = karte.offsetWidth, kh = karte.offsetHeight; let x = e.clientX - r.left + 16, y = e.clientY - r.top + 18;
        if (x + kw > r.width - 6) x = e.clientX - r.left - kw - 14; if (y + kh > r.height - 6) y = e.clientY - r.top - kh - 12;
        karte.style.transform = `translate(${Math.max(4, x).toFixed(0)}px, ${Math.max(4, y).toFixed(0)}px)`;
      });
      svg.addEventListener('pointerleave', weg); svg.addEventListener('pointerdown', weg);
    }
    return svg;
  }

  /* ---------- Kamera: Verschieben und Zoomen wie in einer Karten-App ----------
   * Maus: ziehen = verschieben, Mausrad = zoomen (um den Mauszeiger), Doppelklick = näher (mit Umschalt: weiter weg).
   * Trackpad: zwei Finger = verschieben, Kneifen = zoomen. Touch: ein Finger = verschieben, zwei Finger = zoomen,
   * Doppeltipp = näher. Tastatur: + / − / 0 und Pfeiltasten. Nach dem Loslassen gleitet der Plan kurz nach (Trägheit).
   * Alle Wechsel laufen weich (gedämpfte Feder); bei „Bewegung reduzieren“ springt der Plan ohne Animation. */
  function kamera(svg, opt = {}) {
    if (svg._kamera) return svg._kamera;
    const plan = svg._plan || aktiv(); const ruhig = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const minW = opt.minW || 60, maxW = opt.maxW || plan.breite;
    let cur = svg.getAttribute('viewBox').split(/\s+/).map(Number), ziel = cur.slice(), vel = null, raf = 0, last = 0;
    const box = () => svg.getBoundingClientRect();
    const asp = () => { const r = box(); return r.width > 10 && r.height > 10 ? r.width / r.height : cur[2] / cur[3]; };
    // Ansicht an das Seitenverhältnis des Fensters anpassen (kein Rand) und im Plan halten
    function passend(v, fuellen) {
      let [x, y, w, h] = v; const a = asp(); const cx = x + w / 2, cy = y + h / 2;
      if (fuellen ? w / h > a : w / h < a) w = h * a; else h = w / a;
      // Nie weiter herauszoomen, als der Plan reicht, und nie über den Rand hinaus schieben: die Karte füllt ihren Rahmen immer ganz.
      const grenze = Math.min(maxW, plan.breite, plan.hoehe * a);
      if (w > grenze) { w = grenze; h = w / a; } if (w < minW) { w = minW; h = w / a; }
      const mx = Math.min(plan.breite - w / 2, Math.max(w / 2, cx)), my = Math.min(plan.hoehe - h / 2, Math.max(h / 2, cy));
      return [mx - w / 2, my - h / 2, w, h];
    }
    // Maßstabsleiste und Nordpfeil als feste Einblendung: bleiben beim Zoomen sichtbar und stimmen immer
    let mass = null, massM = 0, massPx = 0;
    const massZeigen = (v) => { if (!mass) return; const r = box(); if (!r.width) return; const pxJeM = r.width / v[2] / plan.m;
      const m = [2, 5, 10, 20, 50, 100, 200].find((x) => x * pxJeM >= 64) || 200; const px = Math.round(m * pxJeM);
      if (m !== massM || Math.abs(px - massPx) > 0) { massM = m; massPx = px; mass.querySelector('i').style.width = px + 'px'; mass.querySelector('b').textContent = m + ' m'; } };
    const setzen = (v) => { svg.setAttribute('viewBox', v.map((z) => z.toFixed(2)).join(' ')); svg.classList.toggle('nah', v[2] < 600); svg.classList.toggle('sehr-nah', v[2] < 260); massZeigen(v); if (opt.onAnsicht) opt.onAnsicht(v); };
    function tick(t) {
      const dt = Math.min(48, t - (last || t)); last = t;
      if (vel) { ziel = passend([ziel[0] + vel[0] * dt, ziel[1] + vel[1] * dt, ziel[2], ziel[3]]); const r = Math.pow(0.93, dt / 16); vel = [vel[0] * r, vel[1] * r];
        if (Math.hypot(vel[0], vel[1]) * 16 < cur[2] * 0.0004) vel = null; }
      const k = 1 - Math.exp(-dt / 70); cur = cur.map((c, i) => c + (ziel[i] - c) * k); setzen(cur);
      const fertig = !vel && cur.every((c, i) => Math.abs(c - ziel[i]) < Math.max(0.02, ziel[2] * 0.0002));
      if (fertig) { cur = ziel.slice(); setzen(cur); raf = 0; last = 0; } else raf = requestAnimationFrame(tick);
    }
    const los = () => { if (ruhig) { cur = ziel.slice(); vel = null; setzen(cur); return; } if (!raf) { last = 0; raf = requestAnimationFrame(tick); } };
    const sofort = (v) => { ziel = passend(v); cur = ziel.slice(); setzen(cur); };
    // Punkt unter dem Finger/Mauszeiger in Plan-Koordinaten (bezogen auf eine Ansicht v)
    const punkt = (cx, cy, v) => { const r = box(); return [v[0] + (cx - r.left) / r.width * v[2], v[1] + (cy - r.top) / r.height * v[3]]; };
    function zoom(f, cx, cy) {
      const r = box(); const [px, py] = punkt(cx == null ? r.left + r.width / 2 : cx, cy == null ? r.top + r.height / 2 : cy, ziel);
      const w = Math.min(maxW, Math.max(minW, ziel[2] * f)); const g = w / ziel[2];
      ziel = passend([px - (px - ziel[0]) * g, py - (py - ziel[1]) * g, w, ziel[3] * g]); vel = null; los();
    }
    function zu(z) { const A = svg._ansichten || ansichten(plan); const v = Array.isArray(z) ? z : (A[z] || A.gesamt); ziel = passend(v); vel = null; los(); }
    function auf(v) { ziel = passend(v.slice(), true); vel = null; los(); }   // genau diesen Ausschnitt zeigen (Lageplan-Fokus)
    // Mausrad / Trackpad
    svg.addEventListener('wheel', (e) => {
      e.preventDefault(); const r = box(); const pix = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? r.height : 1;
      if (!e.ctrlKey && Math.abs(e.deltaX) > 0.5 && e.deltaMode === 0) {   // Trackpad: zwei Finger schieben
        const dx = e.deltaX / r.width * ziel[2], dy = e.deltaY / r.height * ziel[3]; ziel = passend([ziel[0] + dx, ziel[1] + dy, ziel[2], ziel[3]]); vel = null; los(); return;
      }
      const d = e.deltaY * pix; zoom(Math.exp(d * (e.ctrlKey ? 0.012 : 0.0018)), e.clientX, e.clientY);
    }, { passive: false });
    // Zeiger: Verschieben, Kneifen, Doppeltipp
    const zeiger = new Map(); let start = null, bewegt = false, verlauf = [], tipp = null;
    svg.addEventListener('pointerdown', (e) => {
      if (e.button > 0) return;
      // Erster Finger einer neuen Berührung: Zeiger vergessen, deren Ende nie gemeldet wurde (kommt auf Handys nach dem Kneifen vor).
      // Sonst gälte das nächste Wischen mit einem Finger als Zwei-Finger-Geste – die Karte zoomt dann, statt sich zu verschieben.
      if (e.isPrimary && zeiger.size) { zeiger.clear(); start = null; }
      zeiger.set(e.pointerId, [e.clientX, e.clientY]); vel = null;
      if (zeiger.size === 1) { start = { x: e.clientX, y: e.clientY, v: cur.slice(), id: e.pointerId }; bewegt = false; verlauf = [[performance.now(), e.clientX, e.clientY]]; }
      if (zeiger.size === 2) { const [a, b] = [...zeiger.values()]; start = { zwei: true, d: Math.hypot(a[0] - b[0], a[1] - b[1]) || 1, m: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], v: cur.slice() }; bewegt = true; svg.classList.add('zieht'); }
    });
    svg.addEventListener('pointermove', (e) => {
      if (!zeiger.has(e.pointerId) || !start) return; zeiger.set(e.pointerId, [e.clientX, e.clientY]); const r = box();
      if (start.zwei && zeiger.size >= 2) {
        const [a, b] = [...zeiger.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]) || 1; const m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
        const w = Math.min(maxW, Math.max(minW, start.v[2] * start.d / d)); const g = w / start.v[2];
        const [px, py] = punkt(start.m[0], start.m[1], start.v);
        sofort([px - (m[0] - r.left) / r.width * w, py - (m[1] - r.top) / r.height * start.v[3] * g, w, start.v[3] * g]); return;
      }
      if (start.zwei) return;
      const dx = e.clientX - start.x, dy = e.clientY - start.y;
      if (!bewegt && Math.hypot(dx, dy) < 6) return;
      if (!bewegt) { bewegt = true; svg.classList.add('zieht'); if (e.pointerType !== 'touch') { try { svg.setPointerCapture(e.pointerId); } catch (x) { /* egal */ } } }   // Finger sind schon gebunden – erneutes Binden würde das Ziehen abbrechen
      sofort([start.v[0] - dx / r.width * start.v[2], start.v[1] - dy / r.height * start.v[3], start.v[2], start.v[3]]);
      verlauf.push([performance.now(), e.clientX, e.clientY]); if (verlauf.length > 6) verlauf.shift();
    });
    const ende = (e) => {
      if (!zeiger.has(e.pointerId)) return; zeiger.delete(e.pointerId); svg.classList.remove('zieht');
      if (start && start.zwei) { if (zeiger.size === 1) { const [p] = [...zeiger.values()]; start = { x: p[0], y: p[1], v: cur.slice() }; bewegt = true; svg.classList.add('zieht'); } else start = null; return; }
      if (bewegt && verlauf.length > 1 && e.type === 'pointerup') {   // nachgleiten
        const [t0, x0, y0] = verlauf[0], [t1, x1, y1] = verlauf[verlauf.length - 1]; const dt = Math.max(16, t1 - t0); const r = box();
        if (performance.now() - t1 < 80) { vel = [-(x1 - x0) / dt / r.width * cur[2], -(y1 - y0) / dt / r.height * cur[3]]; los(); }
      }
      if (!bewegt && e.pointerType !== 'mouse') {   // Doppeltipp = näher
        const jetzt = performance.now();
        if (tipp && jetzt - tipp.t < 320 && Math.hypot(e.clientX - tipp.x, e.clientY - tipp.y) < 30) { zoom(0.5, e.clientX, e.clientY); tipp = null; }
        else tipp = { t: jetzt, x: e.clientX, y: e.clientY };
      }
      start = null;
    };
    svg.addEventListener('pointerup', ende); svg.addEventListener('pointercancel', ende); svg.addEventListener('lostpointercapture', (e) => { if (e.target === svg && zeiger.has(e.pointerId)) ende(e); });
    // iPhone/iPad: Kneifen auf der Karte zoomt die Karte, nicht die ganze Seite
    ['gesturestart', 'gesturechange', 'gestureend'].forEach((g) => svg.addEventListener(g, (e) => e.preventDefault()));
    // … und Ziehen nach unten zieht nicht die ganze Seite mit (Gummiband / „Ziehen zum Neuladen“ am Seitenanfang)
    svg.addEventListener('touchmove', (e) => { if (e.cancelable) e.preventDefault(); }, { passive: false });
    // Kein Finger mehr auf dem Bildschirm: aufräumen (nach den Zeiger-Ereignissen, deshalb verzögert)
    const alleWeg = (e) => { if (e.touches && e.touches.length === 0) setTimeout(() => { if (zeiger.size) { zeiger.clear(); start = null; svg.classList.remove('zieht'); } }, 0); };
    svg.addEventListener('touchend', alleWeg); svg.addEventListener('touchcancel', alleWeg);
    // Nach dem Ziehen keinen Klick auf einen Platz auslösen
    svg.addEventListener('click', (e) => { if (bewegt) { e.stopImmediatePropagation(); e.preventDefault(); bewegt = false; } }, true);
    svg.addEventListener('dblclick', (e) => { e.preventDefault(); zoom(e.shiftKey ? 2 : 0.5, e.clientX, e.clientY); });
    svg.addEventListener('keydown', (e) => {
      const r = box(); const schritt = 0.12;
      const k = { '+': () => zoom(0.7), '=': () => zoom(0.7), '-': () => zoom(1.43), '0': () => zu('gesamt'),
        ArrowLeft: () => { ziel = passend([ziel[0] - ziel[2] * schritt, ziel[1], ziel[2], ziel[3]]); los(); }, ArrowRight: () => { ziel = passend([ziel[0] + ziel[2] * schritt, ziel[1], ziel[2], ziel[3]]); los(); },
        ArrowUp: () => { ziel = passend([ziel[0], ziel[1] - ziel[3] * schritt, ziel[2], ziel[3]]); los(); }, ArrowDown: () => { ziel = passend([ziel[0], ziel[1] + ziel[3] * schritt, ziel[2], ziel[3]]); los(); } }[e.key];
      if (k && r.width) { e.preventDefault(); k(); }
    });
    // Größe des Fensters ändert sich (Drehen, Vollbild): Ausschnitt anpassen, Mitte behalten
    if (window.ResizeObserver) new ResizeObserver(() => { ziel = passend(ziel); cur = passend(cur); setzen(cur); }).observe(svg);
    ziel = passend(cur); cur = ziel.slice(); setzen(cur);
    // Bedienknöpfe und kurzer Hinweis
    const huelle = opt.knoepfe || svg.parentElement;
    if (huelle && opt.knoepfe !== false) {
      huelle.classList.add('mit-kamera');
      const ctl = document.createElement('div'); ctl.className = 'plan-ctl';
      ctl.innerHTML = '<button type="button" data-k="rein" aria-label="Näher heran">+</button><button type="button" data-k="raus" aria-label="Weiter weg">−</button><button type="button" data-k="alles" aria-label="Ganzen Hafen zeigen" title="Ganzer Hafen">⤢</button>' +
        (opt.vollbild ? '<button type="button" data-k="voll" aria-label="Vollbild" title="Vollbild">⛶</button>' : '');
      ctl.addEventListener('click', (e) => { const b = e.target.closest('[data-k]'); if (!b) return; const k = b.dataset.k;
        if (k === 'rein') zoom(0.6); else if (k === 'raus') zoom(1.65); else if (k === 'alles') zu('gesamt'); else if (k === 'voll' && opt.vollbild) opt.vollbild(); });
      huelle.appendChild(ctl);
      mass = document.createElement('div'); mass.className = 'plan-mass'; mass.setAttribute('aria-hidden', 'true'); mass.innerHTML = '<span class="pm-n"><svg viewBox="-10 -12 20 24"><path d="M0 -11 L5 9 L0 5 L-5 9 Z" fill="#B8232B"/></svg>N</span><span class="pm-leiste"><i></i><b></b></span>';
      huelle.appendChild(mass); svg.classList.add('mit-kamera'); massZeigen(cur);
      let gesehen = false; try { gesehen = sessionStorage.getItem('ssv-plan-hinweis') === '1'; sessionStorage.setItem('ssv-plan-hinweis', '1'); } catch (x) { /* egal */ }
      // Kurzer Bedienhinweis je Gerät (Finger oder Maus), verschwindet nach 4 s; steht immer über der Maßstabs-Einblendung, nie darauf
      if (!gesehen) { const t = Object.assign({ touch: 'Mit zwei Fingern zoomen · Doppeltipp = näher', maus: 'Ziehen = verschieben · Mausrad = zoomen' }, opt.tipp || {});
        const h = document.createElement('div'); h.className = 'plan-tipp'; h.textContent = matchMedia('(pointer: coarse)').matches ? t.touch : t.maus;
        h.style.bottom = Math.max(58, (mass.offsetHeight || 0) + (parseFloat(getComputedStyle(mass).bottom) || 10) + 10) + 'px'; huelle.appendChild(h); setTimeout(() => h.remove(), 4000); }
    }
    svg._kamera = { zu, auf, zoom, get ansicht() { return ziel.slice(); } };
    return svg._kamera;
  }
  // Sanft zu einer Ansicht zoomen (mit Kamera weich gefedert, sonst einfache Animation)
  function zoomen(svg, ziel, dauer = 450) {
    if (svg._kamera) return svg._kamera.zu(ziel);
    const start = svg.getAttribute('viewBox').split(' ').map(Number);
    const A = svg._ansichten || ansichten(aktiv());
    const ende = Array.isArray(ziel) ? ziel : (A[ziel] || A.gesamt);
    const t0 = performance.now();
    const schritt = (t) => {
      const p = Math.min(1, (t - t0) / dauer), e = 1 - Math.pow(1 - p, 3);
      const vb = start.map((s, i) => s + (ende[i] - s) * e);
      svg.setAttribute('viewBox', vb.map((v) => v.toFixed(1)).join(' '));
      svg.classList.toggle('nah', vb[2] < 600);
      if (p < 1) requestAnimationFrame(schritt);
    };
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) { svg.setAttribute('viewBox', ende.join(' ')); svg.classList.toggle('nah', ende[2] < 600); return; }
    requestAnimationFrame(schritt);
  }

  // Für den Editor: welche Platznummern aus dem Verein fehlen im Plan, welche sind doppelt?
  function pruefen(plan, d) {
    const nrn = plaetzeVon(plan).plaetze.map((p) => p.nr).concat((plan.laengs || []).map((l) => String(l.nr)));
    const zaehl = {}; nrn.forEach((n) => { zaehl[n] = (zaehl[n] || 0) + 1; });
    const soll = (d.liegeplaetze || []).map((p) => String(p.nr));
    const landSoll = (d.landplaetze || []).map((p) => p.id); const landIst = new Set(lagerVon(plan).map((g) => g.id));
    return { fehlen: soll.filter((n) => !zaehl[n]), doppelt: Object.keys(zaehl).filter((n) => zaehl[n] > 1), unbekannt: Object.keys(zaehl).filter((n) => !soll.includes(n)),
      landFehlen: landSoll.filter((id) => !landIst.has(id)), landUnbekannt: [...landIst].filter((id) => !landSoll.includes(id)), anzahl: soll.length };
  }

  // Maßstab und Nordrose an den sichtbaren Ausschnitt (viewBox) eines gezeichneten Plans setzen – für den Druck von Ausschnitten
  function massstabInAnsicht(svg) {
    const plan = svg._plan; const v = svg.viewBox && svg.viewBox.baseVal; if (!plan || !v || !v.width) return;
    const alt = svg.querySelectorAll('.massstab, .rose'); if (!alt.length) return;
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g'); g.innerHTML = massstab(plan, [v.x, v.y, v.width, v.height]);
    alt[0].before(...g.childNodes); alt.forEach((x) => x.remove());
  }

  window.HAFEN_PLAN = { zeichnen, massstabInAnsicht, zoomen, kamera, lagerEcken, bootSvg, istMotor, voll, STATUS_TEXT, STANDARD, ART, PUNKT, QUELLE, aktiv, gueltig, plaetzeVon, lagerVon, stegGeo, hatPlaetze, ansichten, pruefen, svgDefs, formenSvg, mitte, drehen,
    get ANSICHTEN() { return ansichten(aktiv()); } };
})();
