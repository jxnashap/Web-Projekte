# SSV – Inbetriebnahme mit der Vereinsdatenbank

Stand: Datenbank (Supabase „SSV Manager“, Frankfurt) ist eingerichtet, die Live-Version
liegt geschützt bei Vercel (Team „ssv-manager“, Projekt **ssv-live**). Die Demo liegt im
Projekt **ssv-vorschau**. Beide sind nur nach Vercel-Login sichtbar, bis der Verein sie
freigibt.

## 1 · Datenbank-Nachträge einspielen (einmalig, in dieser Reihenfolge)

Bereits eingespielt: 01, 02. Neu: 03.

Supabase → Projekt „SSV Manager“ → **SQL Editor** → New query → Inhalt einfügen → **Run**:

1. `apps/ssv-hafen/supabase/nachtrag-01.sql` – Vereinsangaben für Mitglieder lesbar, Vorstand speichert
   Antragsentscheidungen, fester Suchpfad.
2. `apps/ssv-hafen/supabase/nachtrag-02.sql` – Sicherheit und Datenschutz aus dem Gesamt-Check:
   Spaltenrechte für Mitglieder (Konto-Verknüpfung, Getränke-Code und Bankdaten nicht mehr durch
   Hafen-Rollen änderbar), Admin-Liste nur für den Vorstand, Hafenplan-Status nur für Mitglieder,
   wachsende Sperre nach falschen Getränke-Codes, Jugendschutz an der Kasse (`ab_alter`),
   Aufnahmeantrag prüft Alter und Zustimmung der Eltern, Löschfristen (`daten_aufraeumen()`),
   Mitglieder ändern ihre Anschrift selbst.

3. `apps/ssv-hafen/supabase/nachtrag-03.sql` – verlässlicher Datenstand (Feedback-Runde): keine Doppelvergabe
   von Plätzen (auch nicht, wenn zwei Personen gleichzeitig einweisen), Prüfung der Gastlieger in der Datenbank
   (Freigabe des Eigners, Boxmaße, Tiefgang), Änderungsverlauf, Versicherungsnachweise und Dokumente,
   Zahlungen je Rechnung (Teilzahlung, Rücklastschrift), Schäden & Wartung, Arbeitsdienst-Befreiung.
   **Erst diesen Nachtrag einspielen, dann die neue Version in Vercel freischalten** – die Oberfläche braucht die neuen Spalten.

Alle dürfen mehrfach ausgeführt werden. Für neue Projekte reicht `ssv-komplett.sql` (enthält alles).

**Löschfristen automatisch:** Database → Extensions → `pg_cron` aktivieren, dann einmal im SQL Editor:
`select cron.schedule('ssv-loeschfristen', '0 3 * * 1', $$select public.daten_aufraeumen()$$);`
(abgelehnte Anträge nach 6 Monaten, Gast-Kontaktdaten 12 Monate nach Abreise, Kontakt-/Bankdaten
Ausgetretener nach 1 Jahr; Rechnungen bleiben wegen § 147 AO.)

## 2 · Anmelde-Einstellungen in Supabase

Authentication → **URL Configuration**:
- **Site URL**: Adresse der Live-Version, z. B. `https://ssv-live-ssv-manager.vercel.app`
  (später die Vereinsdomain, z. B. `https://mein.ssv-net.de`)
- **Redirect URLs**: `https://ssv-live-ssv-manager.vercel.app/ssv-hafen/mein-ssv.html`
  (für „E-Mail bestätigen“ und „Passwort vergessen“)

Authentication → **Emails / SMTP**: Solange kein eigenes Postfach eingetragen ist, verschickt
Supabase Mails nur an Mitglieder des Supabase-Teams und nur wenige pro Stunde. Für alle
Mitglieder: eigenes SMTP eintragen (z. B. `noreply@ssv-net.de` beim Mail-Anbieter des Vereins).

## 3 · Konten für Funktionsträger anlegen

Authentication → Users → **Add user → Create new user**: E-Mail + vorläufiges Passwort,
**Auto Confirm User** anhaken. Danach im SQL Editor die Rolle vergeben:

```sql
insert into public.funktionen (user_id, rolle, name)
select id, 'vorstand', 'Vorname Nachname' from auth.users where email = 'vorstand@ssv-net.de';
-- Rollen: vorstand · kassenwart · brueckenwart · hafenmeister · redaktion
```

Eine Person kann mehrere Rollen haben (eine Zeile je Rolle).

## 4 · Stammdaten

1. **Hafen-Manager** (`/ssv-hafen/`) als Vorstand oder Kassenwart anmelden →
   **Einstellungen**: IBAN, BIC, Gläubiger-ID, Kassenwart, Hafenmeister. **Gebührenordnung** prüfen.
2. **Mitglieder importieren**: Mitglieder & Eigner → „Mitglieder importieren (CSV)“ mit dem
   easyVerein-Export (Mitgliedsnummer, Anschrift, Geburtsdatum, IBAN, Mandatsreferenz, Mandatsdatum).
   Die Getränkekasse nutzt automatisch denselben Mitgliederstamm.
3. **Boote und Liegeplätze** eintragen (Boote, Belegung Sommer/Winter).
4. **Getränkekasse** (`/ssv-getraenke/kassenwart.html`) als Kassenwart: Getränke & Preise anlegen.

## 5 · iPad als Kasse einrichten

Auf dem iPad in Safari `…/ssv-getraenke/kassenwart.html` öffnen, als Kassenwart anmelden →
Einstellungen → **Dieses Gerät als Kasse einrichten**. Danach `…/ssv-getraenke/` öffnen,
„Teilen → Zum Home-Bildschirm“, und mit **Geführter Zugriff** auf die Kasse festsetzen.
Mitglieder legen ihren 4-stelligen Code beim ersten Mal selbst fest (mit Mitgliedsnummer).

## 5a · Getränke mit Jugendschutz

In der Getränkekasse (Kassenwart → Getränke) bei Bier, Wein, Sekt „ab 16“, bei Spirituosen „ab 18“
wählen. Mitglieder ohne Geburtsdatum oder unter der Grenze sehen diese Getränke an der Kasse nicht.

## 6 · Website-Redaktion

Konto mit Rolle `redaktion` (oder Vorstand) → `…/website/verwaltung/` anmelden →
Hinweis, Aktuelles, Termine, Zeiten, Fotos pflegen. Änderungen sind sofort live.

## 7 · Mitglieder informieren

Mitglieder legen ihr Konto in **Mein SSV** (`…/ssv-hafen/mein-ssv.html` → „Konto anlegen“) selbst an –
mit der E-Mail-Adresse, die im Mitgliederstamm steht. Voraussetzung: eigenes SMTP (Schritt 2).

## 6a · Regeln und Grunddaten im Hafen-Manager festlegen (Vorstand)

- **Einstellungen → Steuerhinweis** für Hafen-Rechnungen und Quittungen wählen (mit dem Steuerberater klären).
  Solange nichts gewählt ist, steht auf Rechnungen kein Steuersatz und die Abrechnung zeigt eine Warnung.
- **Einstellungen → Arbeitsdienst**: Soll, Aufforderung ab, Befreiung ab Alter, Ersatzzahlung je Fehlstunde,
  Übertrag aus dem Vorjahr – dann „vom Vorstand beschlossen“ anhaken. Erst danach wird eine Ersatzzahlung berechnet
  (mit der Beitragsrechnung des Folgejahres). Einzelne Befreiungen beim Mitglied eintragen.
- **Liegeplätze → Maße**: echte Boxmaße, Brücke und – wenn bekannt – Wassertiefe je Platz; danach unter
  Einstellungen „Boxmaße geprüft“ anhaken. Bis dahin kennzeichnet der Hafen-Manager die Platzempfehlung als Annahme.
- **Saisontermine** (Auslagern/Einlagern) für das nächste Jahr in der Tabelle `saisons` eintragen.

## 6b · Datensicherung

- Supabase sichert die Datenbank im **Pro-Tarif täglich** (7 Tage, Wiederherstellung per Klick); im kostenlosen
  Tarif gibt es keine automatische Sicherung. Für den Echtbetrieb Pro empfehlen.
- Zusätzlich: Hafen-Manager → Einstellungen → **Datensicherung herunterladen** (JSON, enthält Bankdaten –
  verschlüsselt aufbewahren), z. B. monatlich und vor jeder Jahresabrechnung.
- Wer wann was geändert hat, steht im **Änderungsverlauf** (Vorstand und Kassenwart), 3 Jahre lang.

## 7a · Vor der Veröffentlichung prüfen

- Website → **Impressum** und **Datenschutz**: alle `[PLATZHALTER]` ergänzen (Vorstand nach § 26 BGB,
  Vereinsregister, Telefon, Bank, E-Mail-Versanddienst) und vom Vorstand freigeben lassen.
- Mit Vercel und Supabase je einen **Auftragsverarbeitungsvertrag** (DPA) abschließen
  (Vercel: Dashboard → Settings → Legal; Supabase: Organization → Legal Documents).

## 8 · Freigeben und Domain

- In Vercel beim Projekt die gewünschte Version auf „Production“ setzen (Deployments → ⋯ → Promote).
- Domain verbinden (Projekt → Settings → Domains), danach Schritt 2 (Site URL) anpassen.
- Öffentlich machen: Projekt → Settings → Deployment Protection → für die eigene Domain ist die
  Seite automatisch öffentlich (Standard Protection schützt nur die vercel.app-Adressen).

## Neu bauen und hochladen

```bash
python3 apps/ssv-hafen/tools/paket_bauen.py /tmp/ssv-live supabase https://jprpgadcycaawxlyozkm.supabase.co <anon-key>
NODE_USE_ENV_PROXY=1 node apps/ssv-hafen/tools/vercel-vorschau.js /tmp/ssv-live ssv-live
```
