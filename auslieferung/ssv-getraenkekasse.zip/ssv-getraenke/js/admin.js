/* SSV Getränkekasse – Kassenwart-Bereich */
(function () {
  'use strict';

  const S = window.SSV.speicher;
  const H = window.SSV.hilfe;
  const $ = (s, r = document) => r.querySelector(s);
  const esc = H.esc;
  const heute = () => H.tag(new Date());
  let tab = 'uebersicht';
  let cache = { mitglieder: [], produkte: [] };

  /* ---------------------------------------------------------------- Helfer */
  function toast(text, art) {
    const t = $('#toast'); t.textContent = text; t.className = 'k-toast zeigen' + (art ? ' ' + art : '');
    clearTimeout(toast._t); toast._t = setTimeout(() => { t.className = 'k-toast'; }, 3400);
  }
  function modal(html) {
    const root = $('#modal-root');
    root.innerHTML = '<div class="a-modal"><div class="a-modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-titel">' + html + '</div></div>';
    const el = root.firstChild; const t = el.querySelector('h2'); if (t) t.id = 'modal-titel';
    if (!modal.esc) { modal.esc = true; document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && $('#modal-root').firstChild) zu(); }); }
    el.addEventListener('click', (e) => { if (e.target === el || e.target.closest('[data-zu]')) zu(); });
    const erstes = el.querySelector('input,select,textarea'); if (erstes) setTimeout(() => erstes.focus(), 30);
    return el;
  }
  function zu() { $('#modal-root').innerHTML = ''; }
  const name = (m) => m ? m.vorname + ' ' + m.nachname : '–';
  const mitglied = (id) => cache.mitglieder.find((m) => m.id === id);
  function csvDownload(dateiname, zeilen) {
    const text = zeilen.map((z) => z.map((v) => {
      const s = v == null ? '' : String(v); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }).join(';')).join('\r\n');
    const blob = new Blob(['﻿' + text], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = dateiname; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  function dateiDownload(dateiname, text, typ) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: typ })); a.download = dateiname; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  const zahl = (v) => Number(v).toFixed(2).replace('.', ',');
  // Zeitraum kurz und ohne Umbruch: „01.–31.10.2026“, „01.10.–15.11.2026“
  function zeitraumKurz(von, bis) {
    const a = H.datum(von), b = H.datum(bis);
    const kurz = a === b ? a : von.slice(0, 7) === bis.slice(0, 7) ? a.slice(0, 3) + '–' + b : von.slice(0, 4) === bis.slice(0, 4) ? a.slice(0, 6) + '–' + b : a + '–' + b;
    return '<span style="white-space:nowrap">' + kurz + '</span>';
  }
  // ⋯-Menü je Zeile (wie im Hafen-Manager): eine Hauptaktion sichtbar, der Rest im Menü
  const zeilenMenue = (knoepfe) => !knoepfe.length ? '' : '<span class="zm"><button type="button" class="a-btn klein zm-knopf" aria-haspopup="true" aria-expanded="false" title="Weitere Aktionen" aria-label="Weitere Aktionen">⋯</button><span class="zm-liste" role="menu" hidden>' + knoepfe.join('') + '</span></span>';
  const zmLegen = (zk, l) => { const r = zk.getBoundingClientRect(); const w = l.offsetWidth, h = l.offsetHeight;
    l.style.left = Math.max(8, Math.min(r.right - w, innerWidth - w - 8)) + 'px'; l.style.top = (r.bottom + 4 + h > innerHeight ? Math.max(8, r.top - h - 4) : r.bottom + 4) + 'px'; };
  const zuMenues = () => document.querySelectorAll('.zm-liste:not([hidden])').forEach((l) => { l.hidden = true; const k = l.previousElementSibling; if (k) k.setAttribute('aria-expanded', 'false'); });
  document.addEventListener('click', (e) => {
    const zk = e.target.closest('.zm-knopf');
    if (zk) { const l = zk.nextElementSibling; const war = !l.hidden; zuMenues(); if (!war) { l.hidden = false; zk.setAttribute('aria-expanded', 'true'); zmLegen(zk, l);
      const erst = l.querySelector('button'); if (erst && e.detail === 0) erst.focus(); } return; }
    if (e.target.closest('.zm-liste')) setTimeout(zuMenues, 0); else zuMenues();
  });
  window.addEventListener('scroll', () => document.querySelectorAll('.zm-liste:not([hidden])').forEach((l) => { const k = l.previousElementSibling; const r = k.getBoundingClientRect();
    if (r.bottom < 0 || r.top > innerHeight) zuMenues(); else zmLegen(k, l); }), true);
  window.addEventListener('resize', zuMenues);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && document.querySelector('.zm-liste:not([hidden])')) { e.stopPropagation(); zuMenues(); } }, true);
  const monatsAnfang = (d = new Date()) => H.tag(new Date(d.getFullYear(), d.getMonth(), 1));
  const monatsEnde = (d = new Date()) => H.tag(new Date(d.getFullYear(), d.getMonth() + 1, 0));
  function kopf(titel, unter, aktionen) {
    return '<div class="a-kopf"><div><h1>' + titel + '</h1>' + (unter ? '<p>' + unter + '</p>' : '') + '</div><div class="a-aktionen">' + (aktionen || '') + '</div></div>';
  }
  function drucken(art, ids) {
    const url = art === 'pins' ? 'drucken.html?art=pins' : 'drucken.html?art=rechnung&ids=' + ids.join(',');
    // Falls Pop-ups blockiert sind (z. B. iPad im Vollbildmodus): im selben Fenster öffnen
    if (!window.open(url, '_blank')) location.href = url;
  }

  /* -------------------------------------------------------------- Übersicht */
  async function uebersicht(main) {
    const von = monatsAnfang(), bis = monatsEnde();
    const [monat, alle, rechnungen] = await Promise.all([S.buchungen({ von, bis }), S.buchungen({}), S.rechnungen()]);
    const gueltig = (b) => !b.storniert_am;
    const umsatz = monat.filter(gueltig).reduce((s, b) => s + H.ct(b.betrag), 0);
    const offen = alle.filter((b) => gueltig(b) && !b.rechnung_id);
    const offenSumme = offen.reduce((s, b) => s + H.ct(b.betrag), 0);
    const unbezahlt = rechnungen.filter((r) => !r.bezahlt_am && !r.storniert_am);
    const unbezahltSumme = unbezahlt.reduce((s, r) => s + H.ct(r.summe), 0);

    const proProdukt = new Map();
    monat.filter(gueltig).forEach((b) => proProdukt.set(b.produkt_name, (proProdukt.get(b.produkt_name) || 0) + b.stueck));
    const top = [...proProdukt.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
    const max = top.length ? top[0][1] : 1;

    const proMitglied = new Map();
    offen.forEach((b) => proMitglied.set(b.mitglied_id, (proMitglied.get(b.mitglied_id) || 0) + H.ct(b.betrag)));
    const topOffen = [...proMitglied.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);

    const monatName = new Date().toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
    main.innerHTML = kopf('Übersicht', 'Stand ' + new Date().toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' }),
      '<button class="a-btn primaer" data-gehe="abrechnung">Abrechnung erstellen</button>') +
      '<div class="a-karten">' +
      '<div class="a-karte"><small>Umsatz ' + esc(monatName) + '</small><strong>' + H.geld(H.eur(umsatz)) + '</strong><span>' + monat.filter(gueltig).length + ' Buchungen</span></div>' +
      '<div class="a-karte"><small>Noch nicht abgerechnet</small><strong>' + H.geld(H.eur(offenSumme)) + '</strong><span>' + proMitglied.size + (proMitglied.size === 1 ? ' Mitglied' : ' Mitglieder') + '</span></div>' +
      '<div class="a-karte"><small>Offene Rechnungen</small><strong>' + H.geld(H.eur(unbezahltSumme)) + '</strong><span>' + unbezahlt.length + ' unbezahlt</span></div>' +
      '<div class="a-karte"><small>Aktive Mitglieder mit Code</small><strong>' + cache.mitglieder.filter((m) => m.aktiv && m.hat_pin).length + '</strong><span>von ' + cache.mitglieder.filter((m) => m.aktiv).length + ' aktiven</span></div>' +
      '</div><div class="a-zwei">' +
      '<div class="a-panel"><h2>Meistgebucht im ' + esc(new Date().toLocaleDateString('de-DE', { month: 'long' })) + ' (Stück)</h2>' +
      (top.length ? top.map(([n, v]) => '<div class="a-balken"><span>' + esc(n) + '</span><i style="width:' + Math.round(v / max * 60) + '%"></i><b>' + v + '</b></div>').join('') : '<p class="k-sub">Noch keine Buchungen in diesem Monat.</p>') +
      '</div><div class="a-panel"><h2>Höchste offene Beträge</h2><table class="a-tab"><tbody>' +
      (topOffen.length ? topOffen.map(([id, c]) => '<tr><td>' + esc(name(mitglied(id))) + '</td><td class="r">' + H.geld(H.eur(c)) + '</td></tr>').join('') : '<tr><td>Alles abgerechnet.</td></tr>') +
      '</tbody></table></div></div>' +
      '<div class="a-panel"><h2>Letzte Buchungen</h2>' + buchungsTabelle(alle.slice(0, 12), rechnungen, false) + '</div>';
  }

  function buchungsTabelle(liste, rechnungen, mitAktion) {
    const rnr = new Map(rechnungen.map((r) => [r.id, r.nr]));
    if (!liste.length) return '<p class="k-sub">Keine Buchungen im gewählten Zeitraum.</p>';
    return '<table class="a-tab"><thead><tr><th>Zeit</th><th>Mitglied</th><th>Artikel</th><th class="r">Menge</th><th class="r">Betrag</th><th>Status</th>' + (mitAktion ? '<th></th>' : '') + '</tr></thead><tbody>' +
      liste.map((b) => '<tr class="' + (b.storniert_am ? 'storniert' : '') + '"><td>' + H.zeit(b.zeit) + '</td><td>' + esc(name(mitglied(b.mitglied_id))) + '</td>' +
        '<td>' + esc(b.produkt_name) + (b.quelle === 'nachtrag' ? ' <span class="a-tag">Nachtrag</span>' : '') + '</td><td class="r">' + b.anzahl + ' ' + H.einheitText(b) + (b.einheit === 'kasten' ? ' (' + b.stueck + ')' : '') + '</td>' +
        '<td class="r">' + H.geld(b.betrag) + '</td><td>' +
        (b.storniert_am ? '<span class="a-tag rot">storniert</span>' : b.rechnung_id ? '<span class="a-tag ok">' + esc(rnr.get(b.rechnung_id) || 'abgerechnet') + '</span>' : '<span class="a-tag warn">offen</span>') + '</td>' +
        (mitAktion ? '<td class="r">' + (!b.storniert_am && !b.rechnung_id ? '<button class="a-btn klein gefahr" data-storno="' + b.id + '">Stornieren</button>' : '') + '</td>' : '') +
        '</tr>').join('') + '</tbody></table>';
  }

  /* ------------------------------------------------------------- Mitglieder */
  async function mitgliederTab(main, suche = '') {
    cache.mitglieder = await S.mitglieder();
    const offen = await S.buchungen({});
    const offenProM = new Map();
    offen.forEach((b) => { if (!b.storniert_am && !b.rechnung_id) offenProM.set(b.mitglied_id, (offenProM.get(b.mitglied_id) || 0) + H.ct(b.betrag)); });
    const ohnePin = cache.mitglieder.filter((m) => m.aktiv && !m.hat_pin).length;
    main.innerHTML = kopf('Mitglieder', cache.mitglieder.filter((m) => m.aktiv).length + ' aktiv · ' + ohnePin + ' ohne Code',
      '<button class="a-btn" id="m-import">CSV importieren</button>' +
      (ohnePin ? '<button class="a-btn dunkel" id="m-pins">Codes für ' + ohnePin + ' vergeben</button>' : '') +
      '<button class="a-btn primaer" id="m-neu">+ Neues Mitglied</button>') +
      '<div class="a-filter"><input class="a-suche" id="m-suche" type="search" placeholder="Suchen …" value="' + esc(suche) + '"></div>' +
      '<div class="a-panel"><table class="a-tab"><thead><tr><th>Nr.</th><th>Name</th><th>Ort</th><th>Lastschrift</th><th>Code</th><th class="r">Offen</th><th></th></tr></thead><tbody id="m-liste"></tbody></table></div>';
    const render = () => {
      const f = $('#m-suche').value.trim().toLowerCase();
      $('#m-liste').innerHTML = cache.mitglieder.filter((m) => !f || (m.vorname + ' ' + m.nachname + ' ' + (m.nr || '') + ' ' + (m.ort || '')).toLowerCase().includes(f))
        .map((m) => {
          const gesperrt = m.gesperrt_bis && new Date(m.gesperrt_bis) > new Date();
          return '<tr class="' + (m.aktiv ? '' : 'inaktiv') + '"><td>' + esc(m.nr || '') + '</td><td><strong>' + esc(m.nachname) + '</strong>, ' + esc(m.vorname) + (m.aktiv ? '' : ' <span class="a-tag">inaktiv</span>') + '</td>' +
            '<td>' + esc(m.ort || '') + '</td><td>' + (m.sepa ? '<span class="a-tag ok">Lastschrift</span>' : '<span class="a-tag warn">kein Mandat</span>') + '</td>' +
            '<td>' + (gesperrt ? '<span class="a-tag rot">gesperrt</span>' : m.hat_pin ? '<span class="a-tag ok">✓</span>' : '<span class="a-tag warn">fehlt</span>') + '</td>' +
            '<td class="r">' + H.geld(H.eur(offenProM.get(m.id) || 0)) + '</td>' +
            '<td class="r">' + (m.hat_pin ? '<button class="a-btn klein" data-reset="' + m.id + '" title="Code löschen – das Mitglied legt an der Kasse selbst einen neuen fest">Code zurücksetzen</button> ' : '') +
            '<button class="a-btn klein" data-pin="' + m.id + '" title="Neuen Code auslosen und als Zettel drucken">Neuen Code vergeben</button> <button class="a-btn klein" data-edit="' + m.id + '">Bearbeiten</button></td></tr>';
        }).join('');
    };
    render();
    $('#m-suche').addEventListener('input', render);
    $('#m-neu').addEventListener('click', () => mitgliedForm({}));
    $('#m-import').addEventListener('click', csvImport);
    if ($('#m-pins')) $('#m-pins').addEventListener('click', alleOhnePin);
    $('#m-liste').addEventListener('click', (e) => {
      const ed = e.target.closest('[data-edit]'); if (ed) return mitgliedForm(mitglied(ed.dataset.edit));
      const p = e.target.closest('[data-pin]'); if (p) return neuePin(mitglied(p.dataset.pin));
      const r = e.target.closest('[data-reset]');
      if (r) {
        const m = mitglied(r.dataset.reset);
        if (!confirm('Code von ' + name(m) + ' löschen? ' + m.vorname + ' legt beim nächsten Mal an der Kasse (oder in „Mein SSV“) selbst einen neuen fest.')) return;
        S.pinZuruecksetzen(m.id).then(() => { toast('Code zurückgesetzt.'); mitgliederTab(main); }).catch((err) => toast(err.message, 'fehler'));
      }
    });
  }

  function mitgliedForm(m) {
    const neu = !m.id;
    const el = modal('<h2>' + (neu ? 'Neues Mitglied' : 'Mitglied bearbeiten') + '</h2><form id="mf" class="a-form">' +
      '<label class="a-feld">Vorname<input name="vorname" required value="' + esc(m.vorname || '') + '"></label>' +
      '<label class="a-feld">Nachname<input name="nachname" required value="' + esc(m.nachname || '') + '"></label>' +
      '<label class="a-feld">Mitgliedsnummer<input name="nr" value="' + esc(m.nr || '') + '"></label>' +
      '<label class="a-feld">E-Mail<input name="email" type="email" value="' + esc(m.email || '') + '"></label>' +
      '<label class="a-feld voll">Straße und Hausnummer<input name="strasse" value="' + esc(m.strasse || '') + '"></label>' +
      '<label class="a-feld">PLZ<input name="plz" inputmode="numeric" value="' + esc(m.plz || '') + '"></label>' +
      '<label class="a-feld">Ort<input name="ort" value="' + esc(m.ort || '') + '"></label>' +
      '<label class="a-feld">Mandatsreferenz<input name="mandatsreferenz" value="' + esc(m.mandatsreferenz || '') + '" placeholder="wie im SEPA-Mandat"></label>' +
      '<label class="a-feld check" style="align-self:end"><input type="checkbox" name="sepa"' + (m.sepa !== false ? ' checked' : '') + '> SEPA-Lastschriftmandat liegt vor</label>' +
      '<label class="a-feld check voll"><input type="checkbox" name="aktiv"' + (m.aktiv !== false ? ' checked' : '') + '> Aktiv (erscheint an der Kasse)</label>' +
      '<label class="a-feld voll">Notiz<textarea name="notiz" rows="2">' + esc(m.notiz || '') + '</textarea></label>' +
      '</form><div class="a-modal-fuss">' + (neu ? '' : '<button class="a-btn gefahr" id="mf-del" style="margin-right:auto">Entfernen</button>') +
      '<button class="a-btn" data-zu>Abbrechen</button><button class="a-btn primaer" id="mf-ok">' + (neu ? 'Anlegen &amp; Code vergeben' : 'Speichern') + '</button></div>');
    $('#mf-ok', el).addEventListener('click', async () => {
      const f = $('#mf', el); if (!f.reportValidity()) return;
      const d = Object.fromEntries(new FormData(f)); d.sepa = f.sepa.checked; d.aktiv = f.aktiv.checked;
      if (m.id) d.id = m.id;
      const gespeichert = await S.mitgliedSpeichern(d);
      cache.mitglieder = await S.mitglieder();
      if (neu) { await neuePin(gespeichert); } else { zu(); toast('Gespeichert.'); }
      zeigeTab('mitglieder');
    });
    if (!neu) $('#mf-del', el).addEventListener('click', async () => {
      if (!confirm(name(m) + ' wirklich entfernen? Mitglieder mit Buchungen werden nur deaktiviert.')) return;
      const r = await S.mitgliedLoeschen(m.id); zu(); toast(r === 'deaktiviert' ? 'Mitglied deaktiviert (Buchungen bleiben erhalten).' : 'Mitglied entfernt.');
      zeigeTab('mitglieder');
    });
  }

  async function neuePin(m) {
    const pin = H.zufallsPin();
    await S.pinSetzen(m.id, pin);
    sessionStorage.setItem('ssvg-pinzettel', JSON.stringify([{ vorname: m.vorname, nachname: m.nachname, nr: m.nr, pin }]));
    const el = modal('<h2>Code für ' + esc(name(m)) + '</h2><div class="a-pin-gross">' + pin + '</div>' +
      '<p class="a-hinweis" style="margin-top:16px">Dieser Code wird nur jetzt angezeigt und ist danach nur noch verschlüsselt gespeichert. Bitte dem Mitglied mitteilen oder den Code-Zettel drucken. Vergessene Codes einfach neu vergeben.</p>' +
      '<div class="a-modal-fuss"><button class="a-btn" id="pz">Code-Zettel drucken</button><button class="a-btn primaer" data-zu>Fertig</button></div>');
    $('#pz', el).addEventListener('click', () => drucken('pins'));
    cache.mitglieder = await S.mitglieder();
    if (tab === 'mitglieder') { const s = $('#m-suche') ? $('#m-suche').value : ''; await mitgliederTab($('#main'), s); }
  }

  async function pinsVergeben(liste) {
    const zettel = [];
    for (const m of liste) { const pin = H.zufallsPin(); await S.pinSetzen(m.id, pin); zettel.push({ vorname: m.vorname, nachname: m.nachname, nr: m.nr, pin }); }
    sessionStorage.setItem('ssvg-pinzettel', JSON.stringify(zettel));
    return zettel;
  }
  async function alleOhnePin() {
    const liste = cache.mitglieder.filter((m) => m.aktiv && !m.hat_pin);
    if (!confirm('Für ' + liste.length + (liste.length === 1 ? ' Mitglied jetzt einen zufälligen Code' : ' Mitglieder jetzt zufällige Codes') + ' erzeugen?')) return;
    const z = await pinsVergeben(liste);
    const el = modal('<h2>' + z.length + (z.length === 1 ? ' Code' : ' Codes') + ' vergeben</h2><p class="a-hinweis">Die Codes werden nur jetzt angezeigt. Am einfachsten: Code-Zettel drucken, ausschneiden und verteilen.</p>' +
      '<table class="a-tab"><tbody>' + z.map((x) => '<tr><td>' + esc(x.nachname + ', ' + x.vorname) + '</td><td class="r"><strong>' + x.pin + '</strong></td></tr>').join('') + '</tbody></table>' +
      '<div class="a-modal-fuss"><button class="a-btn primaer" id="pz">Code-Zettel drucken</button><button class="a-btn" data-zu>Schließen</button></div>');
    $('#pz', el).addEventListener('click', () => drucken('pins'));
    zeigeTab('mitglieder');
  }

  /* CSV-Import, z. B. Mitgliederliste aus Excel oder der bisherigen Verwaltung */
  function csvImport() {
    const el = modal('<h2>Mitglieder importieren</h2>' +
      '<p class="a-hinweis">CSV-Datei mit Kopfzeile, z. B. aus Excel oder der bisherigen Mitgliederverwaltung. Erkannt werden die Spalten <strong>Vorname, Nachname</strong> (Pflicht) sowie Mitgliedsnummer, Mandatsreferenz, E-Mail, Straße, PLZ, Ort. Auf dem iPad öffnet „Datei“ die Dateien-App (iCloud Drive, E-Mail-Anhänge, USB-Stick). Trennzeichen Semikolon oder Komma.</p>' +
      '<label class="a-feld">Datei<input type="file" id="csv-datei" accept=".csv,text/csv,text/comma-separated-values,text/plain,application/vnd.ms-excel"></label>' +
      '<label class="a-feld" style="margin-top:12px">… oder hier einfügen<textarea id="csv-text" rows="6" placeholder="Vorname;Nachname;Mitgliedsnummer;E-Mail&#10;Anna;Albers;1001;anna@beispiel.de"></textarea></label>' +
      '<p class="k-sub" id="csv-vorschau"></p>' +
      '<label class="a-feld check"><input type="checkbox" id="csv-pins"> Allen neuen Mitgliedern direkt einen Code vergeben (sonst legen sie ihren Code selbst fest)</label>' +
      '<div class="a-modal-fuss"><button class="a-btn" data-zu>Abbrechen</button><button class="a-btn primaer" id="csv-ok" disabled>Importieren</button></div>');
    let zeilen = [];
    const parse = (text) => {
      const ls = text.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
      if (ls.length < 2) { zeilen = []; return; }
      const sep = (ls[0].match(/;/g) || []).length >= (ls[0].match(/,/g) || []).length ? ';' : ',';
      const split = (l) => { const out = []; let cur = '', q = false;
        for (let i = 0; i < l.length; i++) { const c = l[i];
          if (q) { if (c === '"' && l[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
          else if (c === '"') q = true; else if (c === sep) { out.push(cur); cur = ''; } else cur += c; }
        out.push(cur); return out.map((s) => s.trim()); };
      const kopfz = split(ls[0]).map((h) => h.toLowerCase().replace(/[^a-zäöüß]/g, ''));
      // erst exakte Spaltennamen, dann Teiltreffer („Vorname" darf nie als „Name" gelten)
      const idx = (...namen) => {
        const exakt = kopfz.findIndex((h) => namen.includes(h));
        return exakt >= 0 ? exakt : kopfz.findIndex((h) => h !== 'vorname' && namen.some((n) => h.includes(n)));
      };
      const ix = { vorname: idx('vorname'), nachname: idx('nachname', 'familienname', 'name'), nr: idx('mitgliedsnummer', 'mitgliedsnr', 'nummer', 'nr'),
        email: idx('email', 'mail'), mandatsreferenz: idx('mandatsreferenz', 'mandat'), strasse: idx('strasse', 'straße', 'anschrift'), plz: idx('plz', 'postleitzahl'), ort: idx('ort', 'stadt', 'wohnort') };
      if (ix.vorname < 0 || ix.nachname < 0) { zeilen = []; $('#csv-vorschau', el).textContent = 'Spalten „Vorname" und „Nachname" nicht gefunden.'; return; }
      zeilen = ls.slice(1).map(split).map((c) => { const o = {}; Object.entries(ix).forEach(([k, i]) => { if (i >= 0) o[k] = c[i] || ''; }); return o; })
        .filter((o) => o.vorname && o.nachname);
    };
    const update = () => {
      parse($('#csv-text', el).value);
      if (zeilen.length) $('#csv-vorschau', el).textContent = zeilen.length + ' Mitglieder erkannt, z. B. ' + zeilen.slice(0, 3).map((z) => z.vorname + ' ' + z.nachname).join(', ') + ' …';
      $('#csv-ok', el).disabled = !zeilen.length;
    };
    $('#csv-text', el).addEventListener('input', update);
    $('#csv-datei', el).addEventListener('change', async (e) => {
      const f = e.target.files[0]; if (!f) return;
      const buf = await f.arrayBuffer();
      let text = new TextDecoder('utf-8').decode(buf);
      if (text.includes('�')) text = new TextDecoder('windows-1252').decode(buf); // Excel-Export
      $('#csv-text', el).value = text; update();
    });
    $('#csv-ok', el).addEventListener('click', async () => {
      const vorhanden = new Set(cache.mitglieder.map((m) => (m.vorname + '|' + m.nachname).toLowerCase()));
      const neu = []; let doppelt = 0;
      for (const z of zeilen) {
        if (vorhanden.has((z.vorname + '|' + z.nachname).toLowerCase())) { doppelt++; continue; }
        neu.push(await S.mitgliedSpeichern({ ...z, aktiv: true, sepa: !!z.mandatsreferenz }));   // Lastschrift nur mit Mandat
      }
      cache.mitglieder = await S.mitglieder();
      if ($('#csv-pins', el).checked && neu.length) {
        await pinsVergeben(neu);
        zu(); toast(neu.length + ' importiert' + (doppelt ? ', ' + doppelt + ' schon vorhanden' : '') + '. Code-Zettel öffnen sich.');
        drucken('pins');
      } else { zu(); toast(neu.length + ' importiert' + (doppelt ? ', ' + doppelt + ' schon vorhanden' : '') + '.'); }
      zeigeTab('mitglieder');
    });
  }

  /* --------------------------------------------------------------- Produkte */
  const EMOJIS = ['🍺', '🍻', '🍋', '🌾', '🥤', '🍏', '🍊', '💧', '☕', '🍵', '🥂', '🍷', '🍾', '🧃', '🥃', '🍦', '🥨', '🌭'];
  async function produkteTab(main) {
    cache.produkte = await S.produkte();
    main.innerHTML = kopf('Getränke &amp; Preise', 'Diese Kacheln erscheinen an der Kasse. Preisänderungen gelten ab sofort für neue Buchungen.',
      '<button class="a-btn primaer" id="p-neu">+ Neues Getränk</button>') +
      '<div class="a-panel"><table class="a-tab"><thead><tr><th></th><th>Getränk</th><th class="r">Preis/Stück</th><th class="r">Kasten</th><th class="r">Kastenpreis</th><th>Status</th><th class="r">Reihenfolge</th><th></th></tr></thead><tbody>' +
      cache.produkte.map((p) => '<tr class="' + (p.aktiv ? '' : 'inaktiv') + '"><td style="font-size:26px">' + esc(p.emoji || '') + '</td><td><strong>' + esc(p.name) + '</strong></td>' +
        '<td class="r">' + H.geld(p.preis) + '</td><td class="r">' + (p.kasten_groesse ? p.kasten_groesse + ' Stk.' : '–') + '</td><td class="r">' + (p.kasten_preis != null && p.kasten_groesse ? H.geld(p.kasten_preis) : '–') + '</td>' +
        '<td>' + (p.aktiv ? '<span class="a-tag ok">an der Kasse</span>' : '<span class="a-tag">ausgeblendet</span>') + '</td><td class="r">' + p.sort + '</td>' +
        '<td class="r"><button class="a-btn klein" data-edit="' + p.id + '">Bearbeiten</button></td></tr>').join('') +
      '</tbody></table></div><p class="a-hinweis warn">Die Preise der Demo sind Beispielwerte <strong>[PLATZHALTER]</strong> – bitte die echten Vereinspreise eintragen.</p>';
    $('#p-neu').addEventListener('click', () => produktForm({ aktiv: true, sort: cache.produkte.length + 1, farbe: '#132a6b', emoji: '🥤' }));
    main.querySelector('tbody').addEventListener('click', (e) => {
      const b = e.target.closest('[data-edit]'); if (b) produktForm(cache.produkte.find((p) => p.id === b.dataset.edit));
    });
  }
  function produktForm(p) {
    const neu = !p.id;
    const el = modal('<h2>' + (neu ? 'Neues Getränk' : esc(p.name)) + '</h2><form id="pf" class="a-form">' +
      '<label class="a-feld voll">Name (mit Größe)<input name="name" required value="' + esc(p.name || '') + '" placeholder="z. B. Pils 0,33 l"></label>' +
      '<label class="a-feld">Preis pro Stück (€)<input name="preis" required inputmode="decimal" value="' + (p.preis != null ? zahl(p.preis) : '') + '"></label>' +
      '<label class="a-feld">Reihenfolge<input name="sort" type="number" value="' + (p.sort || 0) + '"></label>' +
      '<label class="a-feld">Flaschen pro Kasten<input name="kasten_groesse" type="number" min="2" value="' + (p.kasten_groesse || '') + '" placeholder="leer = kein Kasten"></label>' +
      '<label class="a-feld">Kastenpreis (€)<input name="kasten_preis" inputmode="decimal" value="' + (p.kasten_preis != null ? zahl(p.kasten_preis) : '') + '"></label>' +
      '<label class="a-feld">Jugendschutz<select name="ab_alter"><option value="">für alle</option><option value="16"' + (p.ab_alter === 16 ? ' selected' : '') + '>ab 16 (Bier, Wein, Sekt)</option><option value="18"' + (p.ab_alter === 18 ? ' selected' : '') + '>ab 18 (Spirituosen)</option></select></label>' +
      '<div class="a-feld voll">Symbol<div style="display:flex;flex-wrap:wrap;gap:6px" id="pf-emoji">' + EMOJIS.map((e) =>
        '<button type="button" data-e="' + e + '" class="a-btn klein" style="font-size:22px;' + (e === p.emoji ? 'outline:2px solid var(--rot)' : '') + '">' + e + '</button>').join('') + '</div></div>' +
      '<label class="a-feld">Akzentfarbe<input name="farbe" type="color" value="' + esc(p.farbe || '#132a6b') + '" style="height:44px;padding:4px"></label>' +
      '<label class="a-feld check" style="align-self:end"><input type="checkbox" name="aktiv"' + (p.aktiv !== false ? ' checked' : '') + '> an der Kasse anzeigen</label>' +
      '</form><div class="a-modal-fuss">' + (neu ? '' : '<button class="a-btn gefahr" id="pf-del" style="margin-right:auto">Löschen</button>') +
      '<button class="a-btn" data-zu>Abbrechen</button><button class="a-btn primaer" id="pf-ok">Speichern</button></div>');
    let emoji = p.emoji || '🥤';
    $('#pf-emoji', el).addEventListener('click', (e) => {
      const b = e.target.closest('[data-e]'); if (!b) return; emoji = b.dataset.e;
      el.querySelectorAll('#pf-emoji button').forEach((x) => { x.style.outline = x === b ? '2px solid var(--rot)' : ''; });
    });
    const geld = (v) => v === '' || v == null ? null : Number(String(v).replace(/\./g, '').replace(',', '.'));
    $('#pf-ok', el).addEventListener('click', async () => {
      const f = $('#pf', el); if (!f.reportValidity()) return;
      const d = Object.fromEntries(new FormData(f));
      const daten = { name: d.name.trim(), preis: geld(d.preis), sort: parseInt(d.sort, 10) || 0, emoji, farbe: d.farbe, aktiv: f.aktiv.checked,
        kasten_groesse: d.kasten_groesse ? parseInt(d.kasten_groesse, 10) : null, kasten_preis: d.kasten_groesse ? geld(d.kasten_preis) : null, ab_alter: d.ab_alter ? Number(d.ab_alter) : null };
      if (isNaN(daten.preis) || daten.preis < 0) return toast('Bitte einen gültigen Preis eingeben.', 'fehler');
      if (daten.kasten_groesse && (daten.kasten_preis == null || isNaN(daten.kasten_preis))) return toast('Bitte auch den Kastenpreis eintragen.', 'fehler');
      if (p.id) daten.id = p.id;
      await S.produktSpeichern(daten); zu(); toast('Gespeichert.'); zeigeTab('produkte');
    });
    if (!neu) $('#pf-del', el).addEventListener('click', async () => {
      if (!confirm(p.name + ' löschen? Bereits gebuchte Getränke werden nur ausgeblendet.')) return;
      const r = await S.produktLoeschen(p.id); zu(); toast(r === 'deaktiviert' ? 'Ausgeblendet (Buchungen bleiben erhalten).' : 'Gelöscht.'); zeigeTab('produkte');
    });
  }

  /* -------------------------------------------------------------- Buchungen */
  let bFilter = { von: monatsAnfang(), bis: heute(), mitglied_id: '' };
  async function buchungenTab(main) {
    const [liste, rechnungen] = await Promise.all([S.buchungen({ ...bFilter, mitglied_id: bFilter.mitglied_id || undefined }), S.rechnungen()]);
    const summe = liste.filter((b) => !b.storniert_am).reduce((s, b) => s + H.ct(b.betrag), 0);
    main.innerHTML = kopf('Buchungen', liste.length + ' Buchungen · ' + H.geld(H.eur(summe)) + ' (ohne Stornos)',
      '<button class="a-btn" id="b-csv">CSV exportieren</button><button class="a-btn primaer" id="b-neu">+ Nachtragen</button>') +
      '<div class="a-filter"><label class="a-feld">Von<input type="date" id="b-von" value="' + bFilter.von + '"></label>' +
      '<label class="a-feld">Bis<input type="date" id="b-bis" value="' + bFilter.bis + '"></label>' +
      '<label class="a-feld">Mitglied<select id="b-m"><option value="">Alle</option>' + cache.mitglieder.map((m) => '<option value="' + m.id + '"' + (m.id === bFilter.mitglied_id ? ' selected' : '') + '>' + esc(m.nachname + ', ' + m.vorname) + '</option>').join('') + '</select></label></div>' +
      '<div class="a-panel">' + buchungsTabelle(liste, rechnungen, true) + '</div>';
    ['#b-von', '#b-bis', '#b-m'].forEach((s) => $(s).addEventListener('change', () => {
      bFilter = { von: $('#b-von').value, bis: $('#b-bis').value, mitglied_id: $('#b-m').value }; buchungenTab(main);
    }));
    main.querySelector('.a-panel').addEventListener('click', async (e) => {
      const b = e.target.closest('[data-storno]'); if (!b) return;
      if (!confirm('Diese Buchung stornieren?')) return;
      try { await S.buchungStornieren(b.dataset.storno); toast('Storniert.'); buchungenTab(main); } catch (err) { toast(err.message, 'fehler'); }
    });
    $('#b-csv').addEventListener('click', () => {
      const rnr = new Map(rechnungen.map((r) => [r.id, r.nr]));
      csvDownload('buchungen_' + bFilter.von + '_' + bFilter.bis + '.csv', [['Datum', 'Uhrzeit', 'Mitgliedsnr', 'Mitglied', 'Artikel', 'Einheit', 'Anzahl', 'Stück', 'Einzelpreis', 'Betrag', 'Status', 'Rechnung']]
        .concat(liste.map((b) => { const m = mitglied(b.mitglied_id) || {}; const d = new Date(b.zeit);
          return [H.datum(b.zeit), d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }), m.nr, name(m), b.produkt_name, b.einheit === 'kasten' ? 'Kasten' : 'Stück',
            b.anzahl, b.stueck, zahl(b.einzelpreis), zahl(b.betrag), b.storniert_am ? 'storniert' : b.rechnung_id ? 'abgerechnet' : 'offen', rnr.get(b.rechnung_id) || '']; })));
    });
    $('#b-neu').addEventListener('click', nachtragen);
  }
  async function nachtragen() {
    if (!cache.produkte.length) cache.produkte = await S.produkte();
    const el = modal('<h2>Buchung nachtragen</h2><p class="a-hinweis">Für vergessene Striche oder Buchungen auf Zuruf. Nachträge sind in der Liste gekennzeichnet.</p><form id="nf" class="a-form">' +
      '<label class="a-feld voll">Mitglied<select name="mitglied" required><option value="">Bitte wählen</option>' + cache.mitglieder.filter((m) => m.aktiv).map((m) => '<option value="' + m.id + '">' + esc(m.nachname + ', ' + m.vorname) + '</option>').join('') + '</select></label>' +
      '<label class="a-feld voll">Getränk<select name="produkt" required>' + cache.produkte.filter((p) => p.aktiv).map((p) => '<option value="' + p.id + '">' + esc(p.emoji + ' ' + p.name) + ' – ' + H.geld(p.preis) + '</option>').join('') + '</select></label>' +
      '<label class="a-feld">Einheit<select name="einheit"><option value="stk">Stück</option><option value="kasten">Kasten</option></select></label>' +
      '<label class="a-feld">Anzahl<input name="anzahl" type="number" min="1" max="99" value="1" required></label>' +
      '<label class="a-feld voll">Datum<input name="datum" type="date" value="' + heute() + '" required></label>' +
      '</form><div class="a-modal-fuss"><button class="a-btn" data-zu>Abbrechen</button><button class="a-btn primaer" id="nf-ok">Buchen</button></div>');
    $('#nf-ok', el).addEventListener('click', async () => {
      const f = $('#nf', el); if (!f.reportValidity()) return;
      const d = Object.fromEntries(new FormData(f));
      try {
        const zeit = d.datum === heute() ? null : new Date(d.datum + 'T12:00:00').toISOString();
        await S.buchungNachtragen(d.mitglied, [{ produkt_id: d.produkt, einheit: d.einheit, anzahl: parseInt(d.anzahl, 10) }], zeit);
        zu(); toast('Nachgetragen.'); zeigeTab('buchungen');
      } catch (e) { toast(e.message, 'fehler'); }
    });
  }

  /* ------------------------------------------------------------- Abrechnung */
  function vorlagen() {
    const d = new Date(), j = d.getFullYear();
    const vm = new Date(j, d.getMonth() - 1, 1);
    return [
      ['Letzter Monat', monatsAnfang(vm), monatsEnde(vm)],
      ['Dieser Monat', monatsAnfang(d), heute()],
      ['Letztes Quartal', H.tag(new Date(j, Math.floor(d.getMonth() / 3) * 3 - 3, 1)), H.tag(new Date(j, Math.floor(d.getMonth() / 3) * 3, 0))],
      ['Saison ' + j + ' (Apr–Okt)', j + '-04-01', j + '-10-31'],
      ['Gesamtes Jahr ' + j, j + '-01-01', j + '-12-31'],
      ['Alles bis heute', '2000-01-01', heute()]
    ];
  }
  let aZeitraum = null;
  /* Rechnungen per E-Mail: Prüfen → bestätigen → senden (Edge Function „rechnung-mail“, art 'getraenke').
     Aus dem Browser gehen nur Rechnungs-IDs raus; die Adresse liest der Server aus dem Mitglied, dem die Rechnung gehört. */
  const DEMO_VERSAND = 'ssvg-versand-demo';
  const demoVersand = () => { try { return JSON.parse(localStorage.getItem(DEMO_VERSAND)) || []; } catch (e) { return []; } };
  async function versandListe() {
    if (S.modus === 'demo') return demoVersand();
    return S._req('/rest/v1/rechnung_versand?select=rechnung_id,email,gesendet&art=eq.getraenke&status=eq.gesendet&order=gesendet.desc').catch(() => []);
  }
  const mailOk = (s) => /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$/.test(String(s || '').trim()) && !/\.\./.test(String(s));
  const MST = { bereit: ['bereit', 'ok'], keine_email: ['keine E-Mail-Adresse', 'warn'], ungueltig: ['Adresse ungültig', 'rot'], schon_gesendet: ['schon gesendet', ''], storniert: ['storniert', ''], kein_mitglied: ['Mitglied fehlt', 'rot'], nicht_gefunden: ['nicht gefunden', 'rot'], gesendet: ['gesendet', 'ok'], fehler: ['Fehler', 'rot'], adresse_geaendert: ['Adresse inzwischen geändert – nicht gesendet', 'warn'] };
  async function mailPruefen(ids) {
    if (S.modus !== 'demo') return S._req('/functions/v1/rechnung-mail', { method: 'POST', body: { aktion: 'pruefen', art: 'getraenke', ids } });
    const [re, ms] = await Promise.all([S.rechnungen(), S.mitglieder()]); const vs = demoVersand();
    return { eingerichtet: true, demo: true, liste: ids.map((id) => { const r = re.find((x) => x.id === id); if (!r) return { id, status: 'nicht_gefunden' };
      const m = ms.find((x) => x.id === r.mitglied_id); const b = { id, nr: r.nr, betrag: r.summe, mitglied: m ? { nr: m.nr, name: m.vorname + ' ' + m.nachname } : null };
      if (r.storniert_am) return { ...b, status: 'storniert' }; if (!m) return { ...b, status: 'kein_mitglied' };
      const email = String(m.email || '').trim(); if (!email) return { ...b, status: 'keine_email' }; if (!mailOk(email)) return { ...b, email, status: 'ungueltig' };
      const v = vs.find((x) => x.rechnung_id === id); return { ...b, email, status: v ? 'schon_gesendet' : 'bereit', gesendet: v && v.gesendet }; }) };
  }
  async function mailDialog(ids, titel, nachher) {
    if (!ids.length) return toast('Keine Rechnungen zum Versenden.');
    const el = modal('<h2>Rechnungen per E-Mail</h2><p class="k-sub" style="margin-top:0">' + esc(titel) + ' · ' + ids.length + ' Rechnung' + (ids.length === 1 ? '' : 'en') + '</p><div id="mv"><p class="k-sub">Adressen werden geprüft …</p></div>');
    el.querySelector('.a-modal-card').classList.add('breit');
    const box = el.querySelector('#mv'); let pr;
    try { pr = await mailPruefen(ids); } catch (er) { box.innerHTML = '<p class="a-hinweis warn">Prüfen nicht möglich: ' + esc(er.message) + '</p>'; return; }
    const l = pr.liste; const n = (s) => l.filter((x) => x.status === s).length; let laeuft = false;
    const zeichnen = () => {
      const erneut = !!(el.querySelector('#mv-erneut') && el.querySelector('#mv-erneut').checked);
      const raus = l.filter((x) => x.status === 'bereit' || (erneut && x.status === 'schon_gesendet'));
      box.innerHTML = (!pr.eingerichtet ? '<p class="a-hinweis warn">Der E-Mail-Versand ist noch nicht eingerichtet (Mail-Dienst und Absender fehlen). Prüfen geht trotzdem.</p>' : '') +
        (pr.demo ? '<p class="a-hinweis">Demo: Es wird keine echte E-Mail verschickt – der Versand wird nur in diesem Browser vermerkt.</p>' : '') +
        '<p><span class="a-tag ok">' + n('bereit') + ' bereit</span> ' + (n('keine_email') + n('ungueltig') ? '<span class="a-tag warn">' + (n('keine_email') + n('ungueltig')) + ' ohne gültige Adresse</span> ' : '') + (n('schon_gesendet') ? '<span class="a-tag">' + n('schon_gesendet') + ' schon gesendet</span>' : '') + '</p>' +
        '<div class="mv-liste"><table class="a-tab"><thead><tr><th>Rechnung</th><th>Mitglied · geht an</th><th class="r">Betrag</th><th>Stand</th></tr></thead><tbody>' +
        l.map((x) => '<tr><td><strong>' + esc(x.nr || '–') + '</strong></td><td>' + esc(x.mitglied ? x.mitglied.name : '–') + (x.email ? '<br><strong class="mv-adresse">' + esc(x.email) + '</strong>' : '') + '</td><td class="r">' + H.geld(x.betrag || 0) + '</td><td>' +
          '<span class="a-tag ' + MST[x.status][1] + '">' + MST[x.status][0] + (x.gesendet ? ' ' + H.datum(String(x.gesendet).slice(0, 10)) : '') + '</span></td></tr>').join('') + '</tbody></table></div>' +
        (n('keine_email') + n('ungueltig') ? '<p class="a-hinweis warn">Ohne gültige Adresse geht nichts raus – diese Rechnungen bitte ausdrucken oder die Adresse unter „Mitglieder“ nachtragen.</p>' : '') +
        (n('schon_gesendet') ? '<label class="a-feld check"><input type="checkbox" id="mv-erneut"' + (erneut ? ' checked' : '') + '> Schon gesendete noch einmal senden</label>' : '') +
        '<p class="a-hinweis">Jede Rechnung geht <strong>nur an die Adresse, die beim jeweiligen Mitglied eingetragen ist</strong> – einzeln, mit genau dieser einen Rechnung als PDF. Ändert sich eine Adresse nach dem Prüfen, bleibt diese Rechnung liegen.</p>' +
        '<label class="a-feld check" style="font-size:15px"><input type="checkbox" id="mv-geprueft"> Ich habe die Liste geprüft – Mitglieder und Adressen passen.</label>' +
        '<div class="a-modal-fuss"><button class="a-btn" id="mv-test" style="margin-right:auto"' + (pr.eingerichtet && raus.length ? '' : ' disabled') + '>Test-Mail an mich</button><button class="a-btn" data-zu>Abbrechen</button><button class="a-btn primaer" id="mv-los" disabled>' + raus.length + ' Rechnung' + (raus.length === 1 ? '' : 'en') + ' senden</button></div>';
      const er = el.querySelector('#mv-erneut'); if (er) er.addEventListener('change', zeichnen);
      const gp = el.querySelector('#mv-geprueft'), los = el.querySelector('#mv-los');
      gp.addEventListener('change', () => { los.disabled = !gp.checked || !raus.length || !pr.eingerichtet; });
      el.querySelector('#mv-test').addEventListener('click', async (ev) => { const k = ev.currentTarget; k.disabled = true;
        try { if (S.modus === 'demo') toast('Demo: Die Test-Mail ginge an deine Anmelde-Adresse.'); else { const t = await S._req('/functions/v1/rechnung-mail', { method: 'POST', body: { aktion: 'test', art: 'getraenke', ids: [raus[0].id] } }); toast('Test-Mail an ' + t.an + ' gesendet.'); } }
        catch (x) { toast('Test-Mail nicht gesendet: ' + x.message, 'fehler'); } finally { k.disabled = false; } });
      los.addEventListener('click', async () => {
        if (laeuft || !gp.checked) return; laeuft = true; el.querySelectorAll('.a-modal-fuss .a-btn, input').forEach((b) => { b.disabled = true; });
        const erg = [];
        try {
          for (let i = 0; i < raus.length; i += 20) {
            const teil = raus.slice(i, i + 20); los.textContent = 'Wird gesendet … ' + Math.min(i + 20, raus.length) + ' von ' + raus.length;
            if (S.modus === 'demo') { const vs = demoVersand(); teil.forEach((x) => { vs.push({ rechnung_id: x.id, email: x.email, gesendet: new Date().toISOString() }); erg.push({ nr: x.nr, status: 'gesendet' }); }); localStorage.setItem(DEMO_VERSAND, JSON.stringify(vs)); }
            else { const a2 = await S._req('/functions/v1/rechnung-mail', { method: 'POST', body: { aktion: 'senden', art: 'getraenke', ids: teil.map((x) => x.id), erwartet: Object.fromEntries(teil.map((x) => [x.id, x.email])), erneut } }); erg.push(...a2.ergebnis); }
          }
        } catch (x) { erg.push({ status: 'fehler', fehler: x.message }); }
        const ok = erg.filter((x) => x.status === 'gesendet'), nicht = erg.filter((x) => x.status !== 'gesendet');
        box.innerHTML = '<p class="a-hinweis ' + (nicht.length ? 'warn' : '') + '"><strong>' + ok.length + ' Rechnung' + (ok.length === 1 ? '' : 'en') + ' gesendet.</strong>' + (nicht.length ? ' ' + nicht.length + ' nicht gesendet:' : ' Jede an die eingetragene Adresse des Mitglieds.') + '</p>' +
          (nicht.length ? '<ul>' + nicht.map((x) => '<li>' + esc(x.nr || '') + ' – ' + esc(MST[x.status] ? MST[x.status][0] : x.status) + (x.fehler ? ': ' + esc(x.fehler) : '') + '</li>').join('') + '</ul>' : '') +
          '<div class="a-modal-fuss"><button class="a-btn primaer" id="mv-fertig">Fertig</button></div>';
        el.querySelector('#mv-fertig').addEventListener('click', () => { zu(); if (nachher) nachher(); });
      });
    };
    zeichnen();
  }

  async function abrechnungTab(main) {
    if (!aZeitraum) { const v = vorlagen()[0]; aZeitraum = { von: v[1], bis: v[2], datum: heute() }; }
    const [offen, rechnungen, e, versand] = await Promise.all([S.buchungen({ von: aZeitraum.von, bis: aZeitraum.bis }), S.rechnungen(), S.einstellungen(), versandListe()]);
    const gesendetAm = (id) => { const v = versand.find((x) => x.rechnung_id === id); return v ? ' <span class="a-tag ok" title="per E-Mail an ' + esc(v.email) + '">✉ ' + H.datum(String(v.gesendet).slice(0, 10)) + '</span>' : ''; };
    const ungesendet = rechnungen.filter((r) => !r.storniert_am && !versand.some((v) => v.rechnung_id === r.id));
    const proM = new Map();
    offen.filter((b) => !b.storniert_am && !b.rechnung_id).forEach((b) => {
      const x = proM.get(b.mitglied_id) || { n: 0, c: 0 }; x.n++; x.c += H.ct(b.betrag); proM.set(b.mitglied_id, x);
    });
    const vorschau = [...proM.entries()].map(([id, x]) => ({ m: mitglied(id), ...x })).sort((a, b) => name(a.m).localeCompare(name(b.m), 'de'));
    const gesamt = vorschau.reduce((s, x) => s + x.c, 0);
    const ohneAdresse = vorschau.filter((x) => x.m && (!x.m.strasse || !x.m.ort)).length;
    const ohneMandat = vorschau.filter((x) => x.m && !x.m.sepa).length;
    const status = (r) => r.storniert_am ? '<span class="a-tag rot">storniert</span>' : r.bezahlt_am ? '<span class="a-tag ok">bezahlt ' + H.datum(r.bezahlt_am) + '</span>'
      : (r.faellig && r.faellig < heute()) ? '<span class="a-tag rot">überfällig</span>' : '<span class="a-tag warn">offen</span>';
    const offeneRe = rechnungen.filter((r) => !r.storniert_am && !r.bezahlt_am);
    const laeufe = e.sepa_laeufe || [];
    const inLastschrift = (id) => { const l = laeufe.find((x) => (x.ids || []).includes(id)); return l ? ' <span class="a-tag" title="in der Lastschrift-Datei ' + esc(l.id) + ' vom ' + H.datum(l.datum) + '">in SEPA-Datei</span>' : ''; };

    main.innerHTML = kopf('Abrechnung', 'Aus offenen Buchungen werden Rechnungen pro Mitglied – fortlaufend nummeriert, jede Buchung genau einmal.') +
      '<div class="a-panel"><h2>1 · Zeitraum wählen</h2><div class="a-filter">' +
      '<label class="a-feld">Vorlage<select id="a-vorlage"><option value="">– eigener Zeitraum –</option>' + vorlagen().map((v, i) => '<option value="' + i + '"' + (v[1] === aZeitraum.von && v[2] === aZeitraum.bis ? ' selected' : '') + '>' + v[0] + '</option>').join('') + '</select></label>' +
      '<label class="a-feld">Von<input type="date" id="a-von" value="' + aZeitraum.von + '"></label>' +
      '<label class="a-feld">Bis<input type="date" id="a-bis" value="' + aZeitraum.bis + '"></label>' +
      '<label class="a-feld">Rechnungsdatum<input type="date" id="a-datum" value="' + aZeitraum.datum + '"></label></div>' +
      '<h2 style="margin-top:8px">2 · Vorschau: ' + (vorschau.length === 1 ? '1 Rechnung' : vorschau.length + ' Rechnungen') + ' über ' + H.geld(H.eur(gesamt)) + '</h2>' +
      (ohneMandat ? '<p class="a-hinweis warn">' + ohneMandat + ' Mitglieder ohne SEPA-Mandat – ihre Rechnung nennt statt des Einzugs die Bankverbindung zur Überweisung.</p>' : '') +
      (!e.glaeubiger_id ? '<p class="a-hinweis warn">Bitte unter Einstellungen die Gläubiger-ID eintragen – sie gehört auf jede Lastschrift-Ankündigung.</p>' : '') +
      (ohneAdresse ? '<p class="a-hinweis warn">' + ohneAdresse + ' Mitglieder ohne vollständige Anschrift – die Rechnung entsteht trotzdem, ggf. vorher unter „Mitglieder" ergänzen.</p>' : '') +
      (vorschau.length ? '<table class="a-tab"><thead><tr><th>Mitglied</th><th>Zahlart</th><th class="r">Buchungen</th><th class="r">Betrag</th></tr></thead><tbody>' +
        vorschau.map((x) => '<tr><td>' + esc(name(x.m)) + '</td><td>' + (x.m && x.m.sepa ? 'Lastschrift' : '<span class="a-tag warn">kein Mandat</span>') + '</td><td class="r">' + x.n + '</td><td class="r">' + H.geld(H.eur(x.c)) + '</td></tr>').join('') +
        '</tbody><tfoot><tr><td colspan="3">Summe</td><td class="r">' + H.geld(H.eur(gesamt)) + '</td></tr></tfoot></table>'
        : '<p class="k-sub">Keine offenen Buchungen in diesem Zeitraum.</p>') +
      '<h2 style="margin-top:20px">3 · Rechnungen erstellen</h2>' +
      '<div class="a-modal-fuss" style="margin-top:0;justify-content:flex-start"><button class="a-btn primaer" id="a-los"' + (vorschau.length ? '' : ' disabled') + '>' + (vorschau.length === 1 ? '1 Rechnung' : vorschau.length + ' Rechnungen') + ' erstellen</button></div></div>' +
      '<div class="a-panel"><div class="a-kopf" style="margin-bottom:8px"><h2 style="margin:0">Rechnungen</h2><div class="a-aktionen">' +
      '<button class="a-btn primaer" id="r-mail"' + (ungesendet.length ? '' : ' disabled') + '>Per E-Mail senden (' + ungesendet.length + ')</button>' +
      '<button class="a-btn" id="r-druck-offen"' + (offeneRe.length ? '' : ' disabled') + '>Alle offenen drucken (' + offeneRe.length + ')</button>' +
      '<button class="a-btn" id="r-sepa">Lastschrift (SEPA-Datei)</button><button class="a-btn" id="r-csv">Rechnungsliste (CSV)</button></div></div>' +
      (rechnungen.length ? '<table class="a-tab"><thead><tr><th>Nr.</th><th>Datum</th><th>Mitglied</th><th>Zeitraum</th><th class="r">Betrag</th><th>Status</th><th></th></tr></thead><tbody>' +
        rechnungen.map((r) => '<tr class="' + (r.storniert_am ? 'storniert' : '') + '"><td><strong>' + esc(r.nr) + '</strong></td><td>' + H.datum(r.datum) + '</td><td>' + esc(r.empfaenger.vorname + ' ' + r.empfaenger.nachname) + '</td>' +
          '<td>' + zeitraumKurz(r.von, r.bis) + '</td><td class="r">' + H.geld(r.summe) + '<br><small style="color:var(--ink-2);font-size:14px">' + (r.sepa ? 'Lastschrift' : 'Überweisung') + '</small></td><td>' + status(r) + gesendetAm(r.id) + inLastschrift(r.id) + '</td>' +
          '<td class="r aktion"><button class="a-btn klein" data-druck="' + r.id + '">Ansehen</button> ' +
          zeilenMenue(r.storniert_am ? [] : ['<button class="zm-punkt" role="menuitem" data-mail="' + r.id + '">Per E-Mail senden</button>',
            r.bezahlt_am ? '<button class="zm-punkt" role="menuitem" data-unbezahlt="' + r.id + '">Wieder auf „offen“ setzen</button>' : '<button class="zm-punkt" role="menuitem" data-bezahlt="' + r.id + '">Als bezahlt markieren</button>',
            '<button class="zm-punkt gefahr" role="menuitem" data-rstorno="' + r.id + '">Stornieren</button>']) + '</td></tr>').join('') + '</tbody></table>'
        : '<p class="k-sub">Noch keine Rechnungen erstellt.</p>') + '</div>';

    const neuLaden = () => { aZeitraum = { von: $('#a-von').value, bis: $('#a-bis').value, datum: $('#a-datum').value }; abrechnungTab(main); };
    $('#a-vorlage').addEventListener('change', (ev) => {
      const v = vorlagen()[ev.target.value]; if (!v) return; $('#a-von').value = v[1]; $('#a-bis').value = v[2]; neuLaden();
    });
    ['#a-von', '#a-bis', '#a-datum'].forEach((s) => $(s).addEventListener('change', neuLaden));
    $('#a-los').addEventListener('click', async (ev) => {
      const knopf = ev.currentTarget; if (knopf.disabled) return;   // Schutz gegen Doppelklick
      if (!confirm((vorschau.length === 1 ? '1 Rechnung' : vorschau.length + ' Rechnungen') + ' über ' + H.geld(H.eur(gesamt)) + ' erstellen?\nDie enthaltenen Buchungen gelten danach als abgerechnet.')) return;
      knopf.disabled = true;
      try {
        const n = await S.rechnungenErstellen(aZeitraum.von, aZeitraum.bis, aZeitraum.datum);
        toast((n === 1 ? '1 Rechnung' : n + ' Rechnungen') + ' erstellt.'); await abrechnungTab(main);
        const neu = (await S.rechnungen()).filter((r) => r.datum === aZeitraum.datum && !r.storniert_am && !r.bezahlt_am).slice(0, n);
        if (neu.length && confirm('Rechnungen jetzt zum Drucken / als PDF öffnen?')) drucken('rechnung', neu.map((r) => r.id));
      } catch (err) { toast(err.message, 'fehler'); knopf.disabled = false; }
    });
    const tbody = main.querySelectorAll('.a-panel')[1];
    tbody.addEventListener('click', async (ev) => {
      const t = ev.target.closest('button'); if (!t) return;
      if (t.dataset.druck) return drucken('rechnung', [t.dataset.druck]);
      if (t.dataset.bezahlt) { await S.rechnungBezahlt(t.dataset.bezahlt, heute()); toast('Als bezahlt markiert.'); return abrechnungTab(main); }
      if (t.dataset.unbezahlt) { await S.rechnungBezahlt(t.dataset.unbezahlt, null); return abrechnungTab(main); }
      if (t.dataset.rstorno) {
        if (!confirm('Rechnung stornieren? Die Nummer bleibt belegt, die Buchungen werden wieder „offen" und können neu abgerechnet werden.')) return;
        await S.rechnungStornieren(t.dataset.rstorno); toast('Rechnung storniert.'); return abrechnungTab(main);
      }
      if (t.dataset.mail) { const r = rechnungen.find((x) => x.id === t.dataset.mail); return mailDialog([r.id], r.nr + ' · ' + r.empfaenger.vorname + ' ' + r.empfaenger.nachname, () => abrechnungTab(main)); }
    });
    $('#r-druck-offen').addEventListener('click', () => drucken('rechnung', offeneRe.map((r) => r.id)));
    $('#r-mail').addEventListener('click', () => mailDialog(ungesendet.map((r) => r.id), 'Getränkerechnungen, noch nicht per E-Mail gesendet', () => abrechnungTab(main)));
    $('#r-csv').addEventListener('click', () => csvDownload('rechnungen.csv', [['Rechnungsnr', 'Datum', 'Fällig', 'Mitgliedsnr', 'Name', 'Von', 'Bis', 'Betrag', 'Zahlart', 'Bezahlt am', 'Storniert']]
      .concat(rechnungen.map((r) => [r.nr, H.datum(r.datum), H.datum(r.faellig), r.empfaenger.nr, r.empfaenger.vorname + ' ' + r.empfaenger.nachname, H.datum(r.von), H.datum(r.bis),
        zahl(r.summe), r.sepa ? 'Lastschrift' : 'Überweisung', H.datum(r.bezahlt_am), r.storniert_am ? 'ja' : '']))));
    $('#r-sepa').addEventListener('click', () => lastschriftDialog(rechnungen, e, () => abrechnungTab(main)));
  }

  /* Lastschrift für Getränkerechnungen: SEPA-Datei pain.008.001.08 wie im Hafen-Manager (../ssv-hafen/js/sepa.js).
     IBAN, BIC und Mandatsdatum stehen nur im gemeinsamen Mitgliederstamm (Hafen-Manager, Tabelle mitglieder_bank).
     Welche Rechnungen schon in einer Datei waren, merkt sich die Kasse in den Einstellungen (sepa_laeufe) – nichts wird doppelt eingezogen. */
  async function lastschriftDialog(rechnungen, e, nachher) {
    const SEPA = window.HAFEN_SEPA;
    const alle = rechnungen.filter((r) => r.sepa && !r.storniert_am && !r.bezahlt_am);
    if (!alle.length) return toast('Keine offenen Lastschrift-Rechnungen.');
    if (!SEPA) return toast('Die SEPA-Bausteine des Hafen-Managers fehlen (../ssv-hafen/js/sepa.js).', 'fehler');
    const el = modal('<h2>Lastschrift für Getränkerechnungen</h2><div id="ls"><p class="k-sub">Bankdaten werden geladen …</p></div>');
    el.querySelector('.a-modal-card').classList.add('breit');
    const box = el.querySelector('#ls');
    let bank;
    try { bank = await S.bankdaten([...new Set(alle.map((r) => r.mitglied_id))]); } catch (er) { box.innerHTML = '<p class="a-hinweis warn">Bankdaten nicht lesbar: ' + esc(er.message) + '</p>'; return; }
    const bv = new Map(bank.mitglieder.map((b) => [b.mitglied_id, b]));
    const hv = bank.verein || {};
    // Vereinskonto und Gläubiger-ID: aus den Kassen-Einstellungen, sonst wie im Hafen-Manager eingetragen
    const verein = { name: e.verein_name, iban: e.iban || hv.iban || '', bic: e.iban ? e.bic : hv.bic, glaeubiger_id: SEPA.glaeubigerGueltig(e.glaeubiger_id) ? e.glaeubiger_id : (hv.glaeubiger_id || e.glaeubiger_id || '') };
    const vereinFehlt = [!SEPA.ibanGueltig(verein.iban) ? 'IBAN des Vereinskontos' : '', !SEPA.glaeubigerGueltig(verein.glaeubiger_id) ? 'Gläubiger-ID' : ''].filter(Boolean);
    const laeufe = e.sepa_laeufe || [];
    const inDatei = new Map(); laeufe.forEach((l) => (l.ids || []).forEach((id) => inDatei.set(id, l)));
    const kurzIban = (i) => { i = String(i || '').replace(/\s/g, ''); return i ? i.slice(0, 4) + ' … ' + i.slice(-4) : ''; };
    const posten = alle.map((r) => {
      const b = bv.get(r.mitglied_id) || {}; const ref = r.empfaenger.mandatsreferenz || '';
      const fehlt = [!b.iban ? 'IBAN fehlt' : !SEPA.ibanGueltig(b.iban) ? 'IBAN ungültig' : '', !ref ? 'Mandatsreferenz fehlt' : '', !b.mandat_datum ? 'Mandatsdatum fehlt' : ''].filter(Boolean);
      return { r, b, ref, fehlt, lauf: inDatei.get(r.id) };
    }).sort((a, b) => a.r.nr.localeCompare(b.r.nr));
    const zeichnen = () => {
      const erneut = !!(el.querySelector('#ls-erneut') && el.querySelector('#ls-erneut').checked);
      const raus = posten.filter((p) => !p.fehlt.length && (!p.lauf || erneut));
      const summe = raus.reduce((x, p) => x + H.ct(p.r.summe), 0);
      const schon = posten.filter((p) => p.lauf).length, ohne = posten.filter((p) => p.fehlt.length).length;
      box.innerHTML = '<p class="a-hinweis">Die Datei wird im Online-Banking als <strong>Sammellastschrift</strong> hochgeladen (SEPA-XML, Format pain.008.001.08 – wie bei Hafen- und Beitragsrechnungen). Die Getränkerechnung ist zugleich die Ankündigung des Einzugs.</p>' +
        (vereinFehlt.length ? '<p class="a-hinweis warn">Es fehlt: <strong>' + vereinFehlt.join(' und ') + '</strong>. Bitte unter „Einstellungen“ eintragen – ohne diese Angaben nimmt die Bank die Datei nicht an.</p>' : '') +
        '<p><span class="a-tag ok">' + raus.length + ' bereit</span> ' + (ohne ? '<span class="a-tag warn">' + ohne + ' ohne vollständige Bankdaten</span> ' : '') + (schon ? '<span class="a-tag">' + schon + ' schon in einer Datei</span>' : '') + '</p>' +
        '<div class="mv-liste"><table class="a-tab"><thead><tr><th>Rechnung</th><th>Mitglied · Konto</th><th class="r">Betrag</th><th>Einzug am</th><th>Stand</th></tr></thead><tbody>' +
        posten.map((p) => '<tr><td><strong>' + esc(p.r.nr) + '</strong></td><td>' + esc(p.b.kontoinhaber || (p.r.empfaenger.vorname + ' ' + p.r.empfaenger.nachname)) + (p.b.iban ? '<br><small>' + esc(kurzIban(p.b.iban)) + (p.ref ? ' · Mandat ' + esc(p.ref) : '') + '</small>' : '') + '</td>' +
          '<td class="r">' + H.geld(p.r.summe) + '</td><td>' + H.datum(p.r.faellig) + '</td><td>' +
          (p.fehlt.length ? '<span class="a-tag warn">' + esc(p.fehlt.join(', ')) + '</span>' : p.lauf ? '<span class="a-tag">schon in ' + esc(p.lauf.id) + '</span>' : '<span class="a-tag ok">bereit</span>') + '</td></tr>').join('') + '</tbody></table></div>' +
        (ohne ? '<p class="a-hinweis warn">Rechnungen ohne vollständige Bankdaten bleiben draußen. IBAN, Mandatsreferenz und Mandatsdatum pflegen Vorstand oder Kassenwart im Hafen-Manager beim Mitglied.</p>' : '') +
        (schon ? '<label class="a-feld check"><input type="checkbox" id="ls-erneut"' + (erneut ? ' checked' : '') + '> Rechnungen, die schon in einer Datei waren, noch einmal aufnehmen (nur wenn die Bank die alte Datei nicht angenommen hat)</label>' : '') +
        '<div class="a-modal-fuss"><button class="a-btn" id="ls-csv" style="margin-right:auto">Liste mit Bankdaten (CSV)</button><button class="a-btn" data-zu>Abbrechen</button>' +
        '<button class="a-btn primaer" id="ls-los"' + (raus.length && !vereinFehlt.length ? '' : ' disabled') + '>SEPA-Datei für ' + (raus.length === 1 ? '1 Rechnung' : raus.length + ' Rechnungen') + ' (' + H.geld(H.eur(summe)) + ')</button></div>';
      const er = el.querySelector('#ls-erneut'); if (er) er.addEventListener('change', zeichnen);
      el.querySelector('#ls-csv').addEventListener('click', () => csvDownload('getraenke-lastschrift.csv', [['Rechnung', 'Mitgliedsnr', 'Kontoinhaber', 'IBAN', 'BIC', 'Mandatsreferenz', 'Mandatsdatum', 'Betrag', 'Verwendungszweck', 'Einzug am', 'Hinweis']]
        .concat(posten.map((p) => [p.r.nr, p.r.empfaenger.nr, p.b.kontoinhaber || p.r.empfaenger.vorname + ' ' + p.r.empfaenger.nachname, String(p.b.iban || '').replace(/\s/g, ''), p.b.bic || '', p.ref, H.datum(p.b.mandat_datum), zahl(p.r.summe),
          'Getraenke ' + p.r.nr, H.datum(p.r.faellig), p.fehlt.join(', ') || (p.lauf ? 'schon in ' + p.lauf.id : '')]))));
      el.querySelector('#ls-los').addEventListener('click', async (ev) => {
        const k = ev.currentTarget; if (k.disabled) return; k.disabled = true;
        if (!confirm('Lastschrift-Datei für ' + raus.length + (raus.length === 1 ? ' Rechnung' : ' Rechnungen') + ' über ' + H.geld(H.eur(summe)) + ' erstellen?\n\nDanach im Online-Banking als Sammellastschrift hochladen.')) { k.disabled = false; return; }
        const heuteT = heute(); const nachTag = new Map();
        raus.forEach((p) => { const t = p.r.faellig < heuteT ? heuteT : p.r.faellig; if (!nachTag.has(t)) nachTag.set(t, []); nachTag.get(t).push(p); });
        const neu = [];
        nachTag.forEach((liste, faellig) => {   // je Einzugstag eine Datei, damit der Termin stimmt
          const id = 'SSV-G-SEPA-' + heuteT + '-' + (laeufe.length + neu.length + 1);
          const xml = SEPA.erzeugen(verein, liste.map((p) => ({ betrag: p.r.summe, mandat_ref: p.ref, mandat_datum: p.b.mandat_datum, name: p.b.kontoinhaber || (p.r.empfaenger.vorname + ' ' + p.r.empfaenger.nachname),
            iban: p.b.iban, bic: p.b.bic, zweck: 'Getraenke ' + p.r.nr + ' ' + H.datum(p.r.von) + '-' + H.datum(p.r.bis), e2e: p.r.nr })), faellig, id);
          dateiDownload(id + '.xml', xml, 'application/xml');
          neu.push({ id, datum: heuteT, faellig, anzahl: liste.length, summe: H.eur(liste.reduce((x, p) => x + H.ct(p.r.summe), 0)), ids: liste.map((p) => p.r.id) });
        });
        try { await S.einstellungenSpeichern({ sepa_laeufe: laeufe.concat(neu) }); } catch (x) { toast('Datei erstellt, aber nicht vermerkt: ' + x.message, 'fehler'); }
        zu(); toast(raus.length + (raus.length === 1 ? ' Lastschrift' : ' Lastschriften') + ' in ' + neu.length + (neu.length === 1 ? ' Datei' : ' Dateien') + ' erstellt.');
        if (nachher) nachher();
      });
    };
    zeichnen();
  }

  /* ---------------------------------------------------------- Einstellungen */
  async function einstellungenTab(main) {
    const e = await S.einstellungen();
    const f = (k, l, extra = '') => '<label class="a-feld' + (extra.includes('voll') ? ' voll' : '') + '">' + l + '<input name="' + k + '" value="' + esc(e[k] == null ? '' : e[k]) + '"' + extra.replace('voll', '') + '></label>';
    main.innerHTML = kopf('Einstellungen', 'Angaben für die Rechnungen und das Verhalten der Kasse.') +
      '<div class="a-panel"><h2>Verein &amp; Rechnung</h2><form id="ef" class="a-form">' +
      f('verein_name', 'Vereinsname', 'voll') + f('verein_strasse', 'Straße') + f('verein_ort', 'PLZ und Ort') + f('verein_email', 'E-Mail') + f('steuernummer', 'Steuernummer') +
      f('glaeubiger_id', 'Gläubiger-ID (SEPA)') + f('bank', 'Bank') + f('iban', 'IBAN (nur für Überweisungen ohne Mandat)') + f('bic', 'BIC') + f('rechnung_praefix', 'Rechnungsnummer-Präfix') + f('kassenwart_name', 'Name des Kassenwarts (Gruß auf der Rechnung)') +
      f('zahlungsziel_tage', 'Einzug nach Rechnungsdatum (Tage, mind. 14 für die Vorabankündigung)', ' type="number" min="0"') + f('storno_minuten', 'Selbst-Storno an der Kasse (Minuten)', ' type="number" min="0"') +
      f('abmelden_sekunden', 'Automatisch abmelden nach (Sekunden)', ' type="number" min="15"') +
      '<label class="a-feld voll check"><input type="checkbox" name="pin_selbst_festlegen"' + (e.pin_selbst_festlegen ? ' checked' : '') + '> Mitglieder legen ihren 4-stelligen Code beim ersten Mal an der Kasse selbst fest</label>' +
      '<label class="a-feld voll check"><input type="checkbox" name="pin_erst_nr_pruefen"' + (e.pin_erst_nr_pruefen ? ' checked' : '') + '> … vorher die eigene Mitgliedsnummer abfragen (schützt davor, dass jemand für andere einen Code anlegt)</label>' +
      '<label class="a-feld voll">Steuerhinweis auf der Rechnung<textarea name="steuerhinweis" rows="2">' + esc(e.steuerhinweis) + '</textarea></label>' +
      '<label class="a-feld voll">Zusatz bei SEPA-Lastschrift<textarea name="sepa_text" rows="2">' + esc(e.sepa_text) + '</textarea></label>' +
      f('fusstext', 'Grußzeile', 'voll') +
      '</form><div class="a-modal-fuss"><button class="a-btn primaer" id="ef-ok">Speichern</button></div></div>' +
      '<div class="a-panel"><h2>Kasse (iPad)</h2>' +
      (S.modus === 'demo'
        ? '<p class="a-hinweis warn"><strong>Demo-Modus:</strong> Alle Daten liegen nur im Browser dieses Geräts. Für den Echtbetrieb wird eine zentrale Datenbank angebunden (siehe README) – dann wird das iPad hier einmalig als Kasse freigeschaltet.</p>'
        : '<p class="a-hinweis">Auf dem iPad einmal hier anmelden und das Gerät freischalten. Danach zeigt es die Kasse – ohne dass dort jemand angemeldet bleibt.</p><div class="a-filter"><label class="a-feld">Gerätename<input id="k-name" value="iPad Messe"></label><button class="a-btn dunkel" id="k-ok">Dieses Gerät als Kasse einrichten</button></div>') +
      '</div>' +
      (S.modus === 'demo' ? '<div class="a-panel"><h2>Datensicherung (Demo)</h2><div class="a-aktionen"><button class="a-btn" id="d-export">Sicherung herunterladen</button>' +
        '<label class="a-btn">Sicherung einspielen<input type="file" id="d-import" accept=".json" hidden></label><button class="a-btn gefahr" id="d-reset">Demo zurücksetzen</button></div></div>' : '');
    $('#ef-ok').addEventListener('click', async () => {
      const d = Object.fromEntries(new FormData($('#ef')));
      ['zahlungsziel_tage', 'storno_minuten', 'abmelden_sekunden'].forEach((k) => { d[k] = parseInt(d[k], 10) || 0; });
      d.pin_selbst_festlegen = !!d.pin_selbst_festlegen; d.pin_erst_nr_pruefen = !!d.pin_erst_nr_pruefen;
      await S.einstellungenSpeichern(d); toast('Gespeichert.');
    });
    if ($('#k-ok')) $('#k-ok').addEventListener('click', async () => {
      try { await S.kasseEinrichten($('#k-name').value); toast('Gerät eingerichtet – du bist abgemeldet, die Kasse startet.'); setTimeout(() => { location.href = 'index.html'; }, 1500); } catch (err) { toast(err.message, 'fehler'); }
    });
    if ($('#d-export')) {
      $('#d-export').addEventListener('click', async () => {
        const blob = new Blob([await S.sicherungExport()], { type: 'application/json' });
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'ssv-kasse-sicherung-' + heute() + '.json'; a.click();
      });
      $('#d-import').addEventListener('change', async (ev) => {
        try { await S.sicherungImport(await ev.target.files[0].text()); toast('Sicherung eingespielt.'); start(); } catch (err) { toast(err.message, 'fehler'); }
      });
      $('#d-reset').addEventListener('click', () => { if (confirm('Alle Demo-Daten verwerfen und Beispieldaten neu laden?')) { S.zuruecksetzen(); toast('Demo zurückgesetzt.'); start(); } });
    }
  }

  /* ----------------------------------------------------------- Navigation */
  const TABS = { uebersicht, mitglieder: mitgliederTab, produkte: produkteTab, buchungen: buchungenTab, abrechnung: abrechnungTab, einstellungen: einstellungenTab };
  async function zeigeTab(t) {
    tab = t;
    document.querySelectorAll('#nav [data-tab]').forEach((b) => b.classList.toggle('aktiv', b.dataset.tab === t));
    try { await TABS[t]($('#main')); } catch (e) { toast(e.message, 'fehler'); if (/JWT|Berechtigung|401/.test(e.message)) start(); }
    history.replaceState(null, '', '#' + t);
  }
  $('#nav').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) { zeigeTab(b.dataset.tab); window.scrollTo(0, 0); } });
  $('#main').addEventListener('click', (e) => { const g = e.target.closest('[data-gehe]'); if (g) zeigeTab(g.dataset.gehe); });
  $('#abmelden').addEventListener('click', async () => { await S.abmelden(); start(); });

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault(); $('#login-fehler').textContent = '';
    try { await S.anmelden($('#login-email').value, $('#login-pw').value); start(); }
    catch (err) { $('#login-fehler').textContent = err.message; }
  });

  async function start() {
    const ok = await S.angemeldet().catch(() => false);
    $('#login').hidden = ok; $('#app').hidden = !ok;
    if (!ok) {
      if (S.modus === 'demo') { $('#login-demo').hidden = false; $('#login-email').value = 'kassenwart@demo'; $('#login-pw').value = 'demo'; }
      return;
    }
    cache.mitglieder = await S.mitglieder();
    cache.produkte = await S.produkte();
    const t = location.hash.slice(1);
    zeigeTab(TABS[t] ? t : 'uebersicht');
  }
  start();
})();
